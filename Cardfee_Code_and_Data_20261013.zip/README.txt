CARD FEE MODEL CODE AND DATA BUNDLE
Prepared: October 13, 2026

Contents
  commercial_card_model/  October 13 Commercial Card and Small Business model,
                          including fully recursive OOT backtesting.
  consumer_card_model/    October 13 Consumer Card model, with Student-t p-values
                          used for forward-selection eligibility and ranking.
  debit_card_model/       Existing October 1 standardized Debit Card package,
                          retained without changes.

Each folder contains its original model script, README.md, and source CSV data.
All 16 original files are preserved byte-for-byte. No MDDs, temporary files,
pre-generated results, credentials, or machine-specific environments are added.
Source package names and SHA-256 checksums are recorded in PACKAGE_MANIFEST.json.

Running the models
1. Extract this ZIP completely.
2. Follow the dependency and execution instructions in each model's README.md.
3. Run that model's Python script; inputs and outputs follow the paths documented
   in its README. Use separate result directories for the three models.

Revenue units in fee_history.csv are $000; this bundle applies no conversions.
This is a packaging update only: no model logic, input values, or original
documentation has been changed.
