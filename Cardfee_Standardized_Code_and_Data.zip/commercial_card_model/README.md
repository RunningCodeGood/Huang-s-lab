# Commercial Card and Small Business Model

This standalone script estimates a long-run fee relationship, constructs a scaled error-correction term and trend overlay, fits a short-run growth model, and produces historical fitted results and Baseline/S4 forecasts. All coefficients, screening statistics, overlays and predictions are calculated from the input data during each run.

## Run

Use Python 3.12:

```bash
python -m pip install numpy==2.3.5 pandas==2.2.3 scipy==1.18.1 statsmodels==0.15.0
python commercial_card_model.py
```

Paths are relative to the script. Use `--data-dir` for another folder with the same input schema and `--output-dir` for a new or empty results directory. The default output is `results/`. A nonempty output directory is not overwritten. No Excel, network connection or other project files are needed after the numerical dependencies are installed.

## Input files

| File | Period | Purpose |
| --- | --- | --- |
| `data/fee_history.csv` | Jan 2011 to Dec 2025 | Original Commercial Card and Small Business fees |
| `data/macro_history.csv` | Jan 2011 to Dec 2025 | Historical levels of all eight candidate macro series |
| `data/macro_baseline.csv` | Jan 2026 to Mar 2028 | Baseline macro scenario levels |
| `data/macro_s4.csv` | Jan 2026 to Mar 2028 | S4 CPI and corporate-profits scenario levels |

The monthly date key is `date`, formatted as `YYYY-MM-DD` using the first day of the month. History and future scenarios are separate files. Macro CSV column names retain the original Moody's codes. `MACRO_COLUMNS` in Python maps them to descriptive business names.

Revenue source fields `Commercial Card` and `Small Business` map to `commercial_card_fee` and `small_business_card_fee`. Their sum is `commercial_small_business_fee`. QualPay and Sponsorships are not included. Fees retain their original source units without currency-scale conversion.

| Moody's CSV header | Internal variable | Level units |
| --- | --- | --- |
| `M_FLBR_B.IUSA` | `unemployment_rate` | Percent |
| `M_FCPIU_B.IUSA` | `consumer_price_index` | Index |
| `M_FYPDPIQ_B.IUSA` | `disposable_personal_income` | Original source units |
| `M_FSBINQ_B.IUSA` | `small_business_optimism` | Index |
| `M_FGDP42Q_B.IUSA` | `wholesale_trade_gdp` | Original source units |
| `M_FIP_B.IUSA` | `industrial_production` | Index |
| `M_FZA_B.IUSA` | `corporate_profits` | Original source units |
| `M_FDJMIIUSDD_WCFTDQ_B.IUSA` | `dow_jones_total_market_index` | Index |

Historical and Baseline macro values come from the supplied macro CSV; its actual coverage starts in January 2011. S4 CPI and corporate profits come from the `Macro Path` sheet of the supplied `S4_Downside_Macro_Path.xlsx`. Raw numeric values are retained without interpolation, rescaling or missing-value filling. Monthly rows describe the supplied observation frequency, not necessarily each series' native publication frequency.

The supplied Baseline file has blank disposable-income, wholesale-GDP, industrial-production and market-index values for January 2027 through March 2028. S4 contains only CPI and corporate profits. Current selected drivers have the required paths. Different selected variables would require the corresponding future inputs and a review of the scenario-driver setup. Macroeconomic scenarios are external inputs, not estimated by this fee model.

## Variable naming

| Variable | Meaning |
| --- | --- |
| `commercial_small_business_fee_pct_change_12m` | `100 * (fee_t / fee_t_minus_12m - 1)` |
| `commercial_small_business_fee_pct_change_12m_lag_1m` | Annual fee growth lagged one month |
| `corporate_profits_pct_change_12m_lag_2m` | Annual corporate-profit growth lagged two months |
| `unemployment_rate_diff_12m_pp_lag_0m` | Contemporaneous annual unemployment change, in percentage points |
| `long_run_fitted_fee` | Macro-implied long-run fee level |
| `ec_residual` | Actual fee less the fitted long-run level |
| `ec_scaled_pct` | `100 * ec_residual / long_run_fitted_fee` |
| `ec_trend_overlay_pct` | Estimated trend adjustment on the scaled EC scale |
| `ec_scaled_adjusted_pct` | Scaled EC less the contemporaneous overlay |
| `ec_scaled_adjusted_pct_lag_12m` | Adjusted EC lagged 12 months |

`pct_change_12m` means annual percentage growth, while `lag_2m` means a two-month lag of that growth rate. These horizons are independent. `pp` denotes percentage points. The suffix `_input` identifies a value used by a particular prediction. Source CSV files contain levels; transformations and lags are generated in Python.

## Estimation method

1. In-sample estimation covers January 2011 through September 2023; OOT covers October 2023 through December 2025.
2. Long-run forward selection considers CPI, disposable income, wholesale GDP, corporate profits and the total-market index in levels. Added-term Student-t p < 0.05, maximum VIF < 10 and ordinary residual ADF p < 0.05 are required. Candidates are ranked by adjusted R-squared and fixed tie order.
3. Scale the long-run residual by the fitted long-run fee. Estimate a trend on the 27 realized OOT scaled residuals using `month_index` from 1 to 27. The overlay is zero in-sample, follows the fitted trend in OOT, and is held at its December 2025 value for future forecasts. Subtract the overlay before constructing the 12-month adjusted-EC lag.
4. Screen transformed macro families using in-sample ADF and KPSS. A family passes if ADF p < 0.05 or KPSS p > 0.05. Evaluate monthly lags 0-12 using partial correlations controlling for the intercept and lagged adjusted EC. Require p < 0.20 in both IS and OOT with matching signs. The implemented correlation probability uses a Student-t reference with n minus 2 degrees of freedom after residualization.
5. Keep adjusted EC at lag 12 in the short-run model. Forward selection considers all passing macro terms and target lags 1-12, using added-term Student-t p < 0.05 and maximum VIF < 10. Rank additions by adjusted R-squared and fixed tie order. Coefficients use in-sample observations only.

OLS inference is classical and nonrobust. ADF includes an intercept and AIC lag selection. KPSS includes an intercept and automatic bandwidth selection, with boundary probabilities labeled as bounds. Ordinary residual ADF is not an Engle-Granger-calibrated cointegration test. Both windows inform screening and OOT also estimates the overlay, so OOT errors describe a fitted backtest rather than untouched validation.

## Predictions and scenarios

Static historical predictions use observed own-growth lags and observed year-ago fee levels. Dynamic OOT recursively updates own-growth lags but retains observed year-ago fee anchors and observed adjusted EC. The output mode `dynamic_y_only` denotes that limited recursion.

Future Baseline and S4 forecasts run from January 2026 through March 2028, starting from December 2025 actuals. Both use fixed in-sample coefficients without a production refit. The future forecast recursively updates fee levels, target lags and adjusted EC. The overlay remains fixed at its final estimated value. S4 replaces only future CPI and corporate-profit levels; historical inputs are shared. Growth rates are calculated after joining each future scenario to that history.

Monthly predictions are converted to levels using the actual or previously predicted year-ago fee. Each quarterly forecast sums its three monthly revenue levels. `2026 total` sums the four 2026 quarters; `9-quarter total` sums all nine quarters from 2026Q1 through 2028Q1. All aggregation uses unrounded predictions.

## Generated results

| File | Content |
| --- | --- |
| `long_run_trials.csv`, `long_run_rounds.csv`, `long_run_coefficients.csv` | Long-run selection and estimation |
| `long_run_residual_stationarity.csv`, `ec_scaled_stationarity.csv` | Stationarity statistics |
| `overlay_trend.csv`, `overlay_coefficients.csv` | Estimated overlay parameters and inference |
| `macro_stationarity.csv`, `short_run_screen_all.csv`, `short_run_screen_passed.csv` | Macro screening |
| `short_run_trials.csv`, `short_run_rounds.csv`, `short_run_coefficients.csv` | Short-run selection and estimation |
| `short_run_diagnostics.csv` | R-squared, AIC, DW, JB, Ljung-Box and VIF |
| `static_in_sample.csv`, `static_oot.csv`, `dynamic_oot.csv` | Historical fee-level predictions |
| `forecast_accuracy.csv` | Historical MAPE, RMSE, MAE and mean error |
| `historical_data_and_features.csv`, `short_run_estimation_sample.csv`, `long_run_history.csv` | Model data and calculated features |
| `forecast_monthly.csv` | Baseline and S4 monthly fee forecasts and inputs |
| `forecast_quarterly_summary.csv` | Quarterly and cumulative scenario totals |
| `summary.json` | Model statistics and quarterly forecast summary |

Monthly outputs use `date`, `scenario`, `predicted_fee` and `predicted_pct_change_12m`. Quarterly summaries use `period`, `months`, `baseline_total` and `s4_total`, with quarter labels such as `2026Q1`. Coefficient tables use `standard_error`, `t_stat` and `p_student_t`. Overlay parameters are `intercept_pct`, `slope_pct_per_month`, `slope_p_student_t` and `held_value_pct`. CSV exports retain 15 significant digits, matching the existing numerical export convention. No pre-generated results are included in this package.
