#!/usr/bin/env python3
"""Estimate the Commercial Card and Small Business two-step model.

Run: python commercial_card_model.py
Inputs are read from data/ and computed results are written to results/.
All coefficients, transformations, selections and statistics are calculated
from the raw input data during each run.
Baseline and S4 monthly forecasts are summed into calendar-quarter fee totals.
"""

from __future__ import annotations

import argparse
import json
import sys
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats
import statsmodels.api as sm
from statsmodels.stats.diagnostic import acorr_ljungbox
from statsmodels.stats.outliers_influence import variance_inflation_factor
from statsmodels.stats.stattools import durbin_watson, jarque_bera
from statsmodels.tools.sm_exceptions import InterpolationWarning
from statsmodels.tsa.stattools import adfuller, kpss


# Monthly estimation periods and selection thresholds.
ROOT = Path(__file__).resolve().parent
START = pd.Timestamp("2011-01-01")
IS_END = pd.Timestamp("2023-09-01")
OOT_START = pd.Timestamp("2023-10-01")
END = pd.Timestamp("2025-12-01")
FORECAST_START = pd.Timestamp("2026-01-01")
FORECAST_END = pd.Timestamp("2028-03-01")
ALPHA = 0.05
SCREEN_ALPHA = 0.20
VIF_LIMIT = 10.0
EC_TERM = "ec_scaled_adjusted_pct_lag_12m"

MACRO_COLUMNS = {
    "M_FLBR_B.IUSA": "unemployment_rate",
    "M_FCPIU_B.IUSA": "consumer_price_index",
    "M_FYPDPIQ_B.IUSA": "disposable_personal_income",
    "M_FSBINQ_B.IUSA": "small_business_optimism",
    "M_FGDP42Q_B.IUSA": "wholesale_trade_gdp",
    "M_FIP_B.IUSA": "industrial_production",
    "M_FZA_B.IUSA": "corporate_profits",
    "M_FDJMIIUSDD_WCFTDQ_B.IUSA": "dow_jones_total_market_index",
}
MACROS = list(MACRO_COLUMNS.values())
LONG_RUN_POOL = [
    "consumer_price_index",
    "disposable_personal_income",
    "wholesale_trade_gdp",
    "corporate_profits",
    "dow_jones_total_market_index",
]


TARGET_LAGS = {
    f"commercial_small_business_fee_pct_change_12m_lag_{lag}m": lag for lag in range(1, 13)
}
MACRO_CHANGES = {
    family: (
        f"{family}_diff_12m_pp" if family == "unemployment_rate" else f"{family}_pct_change_12m"
    )
    for family in MACROS
}
MACRO_FEATURES = {
    f"{MACRO_CHANGES[family]}_lag_{lag}m": (family, lag) for family in MACROS for lag in range(13)
}


def macro_lag_name(family, lag):
    """Return the explicit transformation and monthly lag name."""
    return f"{MACRO_CHANGES[family]}_lag_{lag}m"


# Fixed ordering keeps selection ties independent of the display labels.
FAMILY_SELECTION_ORDER = [
    "consumer_price_index",
    "corporate_profits",
    "dow_jones_total_market_index",
    "disposable_personal_income",
    "wholesale_trade_gdp",
    "industrial_production",
    "small_business_optimism",
    "unemployment_rate",
]
SELECTION_ORDER = [
    term
    for family in FAMILY_SELECTION_ORDER
    for term in [family] + [macro_lag_name(family, lag) for lag in sorted(range(13), key=str)]
] + sorted(TARGET_LAGS, key=lambda term: str(TARGET_LAGS[term]))
SELECTION_PRIORITY = {term: position for position, term in enumerate(SELECTION_ORDER)}


def load_data(data_dir: Path) -> pd.DataFrame:
    """Read historical source levels and map raw column labels once."""
    revenue = pd.read_csv(data_dir / "fee_history.csv", parse_dates=["date"])
    revenue = (
        revenue.set_index("date")
        .sort_index()
        .rename(
            columns={
                "Commercial Card": "commercial_card_fee",
                "Small Business": "small_business_card_fee",
            }
        )
    )
    revenue = revenue.apply(pd.to_numeric, errors="raise")
    revenue["commercial_small_business_fee"] = (
        revenue["commercial_card_fee"] + revenue["small_business_card_fee"]
    )
    macro = read_macro(data_dir / "macro_history.csv")
    data = macro.reindex(pd.date_range(START, END, freq="MS")).join(revenue, how="left")
    data.index.name = "date"
    return data


def read_macro(path: Path) -> pd.DataFrame:
    """Keep Moody's labels in CSV files and use business names in calculations."""
    frame = pd.read_csv(path, parse_dates=["date"], encoding="utf-8-sig")
    return (
        frame.set_index("date")
        .sort_index()
        .rename(columns=MACRO_COLUMNS)
        .apply(pd.to_numeric, errors="raise")
    )


def stationarity(series: pd.Series) -> dict:
    """Run constant-only ADF and KPSS tests on the available observations."""
    values = series.dropna()
    adf = adfuller(values, regression="c", autolag="AIC", maxlag=None, result_object=False)
    # KPSS uses tabulated probabilities; retain the bound in the output.
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", InterpolationWarning)
        kp = kpss(values, regression="c", nlags="auto", result_object=False)
    return {
        "n": len(values),
        "adf_stat": float(adf[0]),
        "adf_p": float(adf[1]),
        "adf_lags": int(adf[2]),
        "adf_effective_n": int(adf[3]),
        "adf_critical_5pct": float(adf[4]["5%"]),
        "kpss_stat": float(kp[0]),
        "kpss_p": float(kp[1]),
        "kpss_lags": int(kp[2]),
        "kpss_critical_5pct": float(kp[3]["5%"]),
        "kpss_p_bound": (
            ">=0.10" if kp[1] == 0.1 else "<=0.01" if kp[1] == 0.01 else "interpolated"
        ),
        # A macro family is eligible if either test supports stationarity.
        "stationary": bool(adf[1] < ALPHA or kp[1] > ALPHA),
    }


def fit(frame: pd.DataFrame, target: str, terms: list[str]):
    """Estimate OLS with an intercept on candidate-specific complete cases."""
    sample = frame[[target] + terms].dropna()
    regressors = sm.add_constant(sample[terms], has_constant="add")
    return sm.OLS(sample[target], regressors).fit()


def vifs(model) -> dict:
    """Calculate regressor VIFs with the intercept included in the design."""
    return {
        name: float(variance_inflation_factor(model.model.exog, column))
        for column, name in enumerate(model.params.index)
        if name != "const"
    }


def coefficients(model, name: str) -> pd.DataFrame:
    """Return coefficients, nonrobust OLS inference and collinearity measures."""
    vif = vifs(model)
    intervals = model.conf_int(alpha=ALPHA)
    return pd.DataFrame(
        [
            {
                "model": name,
                "term": term,
                "coefficient": float(model.params[term]),
                "standard_error": float(model.bse[term]),
                "t_stat": float(model.tvalues[term]),
                "p_student_t": float(model.pvalues[term]),
                "vif": vif.get(term, np.nan),
                "ci_lower_95": float(intervals.loc[term, 0]),
                "ci_upper_95": float(intervals.loc[term, 1]),
                "df_resid": float(model.df_resid),
                "covariance": "nonrobust OLS",
            }
            for term in model.params.index
        ]
    )


def forward_select(frame, target, candidates, base_terms=None, residual_adf_gate=False):
    """Add the eligible term giving the highest adjusted R-squared each round.

    New terms require Student-t p < 0.05 and maximum VIF < 10. Long-run selection also
    requires ordinary residual ADF p-value < 0.05. Base terms are retained throughout.
    """
    selected = list(base_terms or [])
    pending = list(candidates)
    trials, rounds = [], []
    for round_number in range(1, len(candidates) + 1):
        current = []
        for candidate in pending:
            model = fit(frame, target, selected + [candidate])
            max_vif = max(vifs(model).values())
            residual_p = (
                float(adfuller(model.resid, regression="c", autolag="AIC", result_object=False)[1])
                if residual_adf_gate
                else np.nan
            )
            eligible = model.pvalues[candidate] < ALPHA and max_vif < VIF_LIMIT
            if residual_adf_gate:
                eligible = eligible and residual_p < ALPHA
            current.append(
                {
                    "round": round_number,
                    "candidate": candidate,
                    "selected_before": " + ".join(selected),
                    "coefficient": float(model.params[candidate]),
                    "p_student_t": float(model.pvalues[candidate]),
                    "max_vif": float(max_vif),
                    "residual_adf_p": residual_p,
                    "eligible": bool(eligible),
                    "r_squared": float(model.rsquared),
                    "adjusted_r_squared": float(model.rsquared_adj),
                    "n": int(model.nobs),
                }
            )

        eligible = [row for row in current if row["eligible"]]
        # Resolve exact adjusted R-squared ties by candidate name.
        winner = (
            min(
                eligible,
                key=lambda row: (-row["adjusted_r_squared"], SELECTION_PRIORITY[row["candidate"]]),
            )
            if eligible
            else None
        )
        for row in current:
            row["chosen"] = bool(winner and row["candidate"] == winner["candidate"])
        trials.extend(current)
        rounds.append(
            {
                "round": round_number,
                "added": winner["candidate"] if winner else "none",
                "adjusted_r_squared_after": winner["adjusted_r_squared"] if winner else np.nan,
                "p_student_t": winner["p_student_t"] if winner else np.nan,
                "n": winner["n"] if winner else np.nan,
            }
        )
        if winner is None:
            break
        selected.append(winner["candidate"])
        pending.remove(winner["candidate"])
    return selected, pd.DataFrame(trials), pd.DataFrame(rounds)


def engineer(data, long_run):
    """Construct scaled error correction, the OOT trend overlay, growth rates and lags."""
    frame = data.copy()
    terms = [term for term in long_run.params.index if term != "const"]
    frame["long_run_fitted_fee"] = long_run.predict(
        sm.add_constant(frame[terms], has_constant="add")
    )
    frame["ec_residual"] = frame["commercial_small_business_fee"] - frame["long_run_fitted_fee"]
    frame["ec_scaled_pct"] = 100 * frame["ec_residual"] / frame["long_run_fitted_fee"]

    # Fit the overlay to OOT scaled error correction using month indices 1 through 27.
    oot = frame.loc[OOT_START:END]
    time = pd.Series(np.arange(1, len(oot) + 1), index=oot.index, name="month_index")
    trend_model = sm.OLS(oot["ec_scaled_pct"], sm.add_constant(time)).fit()
    intercept = float(trend_model.params["const"])
    slope = float(trend_model.params["month_index"])
    frame["ec_trend_overlay_pct"] = 0.0
    frame.loc[oot.index, "ec_trend_overlay_pct"] = intercept + slope * time
    frame["ec_scaled_adjusted_pct"] = frame["ec_scaled_pct"] - frame["ec_trend_overlay_pct"]
    # Subtract the contemporaneous overlay before applying the 12-month lag.
    frame[EC_TERM] = frame["ec_scaled_adjusted_pct"].shift(12)

    # Growth is expressed in percentage units, so 10 denotes 10 percent.
    features = {
        "commercial_small_business_fee_pct_change_12m": frame[
            "commercial_small_business_fee"
        ].pct_change(12, fill_method=None)
        * 100
    }
    for lag in range(1, 13):
        features[f"commercial_small_business_fee_pct_change_12m_lag_{lag}m"] = features[
            "commercial_small_business_fee_pct_change_12m"
        ].shift(lag)
    for family in MACROS:
        # Unemployment uses a 12-month percentage-point difference.
        change = (
            frame[family].diff(12)
            if family == "unemployment_rate"
            else frame[family].pct_change(12, fill_method=None) * 100
        )
        features[MACRO_CHANGES[family]] = change
        for lag in range(13):
            features[macro_lag_name(family, lag)] = change.shift(lag)
    frame = pd.concat([frame, pd.DataFrame(features, index=frame.index)], axis=1)
    trend = {
        "intercept_pct": intercept,
        "slope_pct_per_month": slope,
        "slope_p_student_t": float(trend_model.pvalues["month_index"]),
        "r_squared": float(trend_model.rsquared),
        "n": int(trend_model.nobs),
        "held_value_pct": intercept + slope * len(oot),
    }
    return frame, trend, trend_model


def partial_correlation(frame, candidate):
    """Correlate residuals after controlling for an intercept and lagged adjusted error correction."""
    sample = frame[["commercial_small_business_fee_pct_change_12m", EC_TERM, candidate]].dropna()
    controls = sm.add_constant(sample[[EC_TERM]], has_constant="add")
    y_residual = (
        sm.OLS(sample["commercial_small_business_fee_pct_change_12m"], controls).fit().resid
    )
    x_residual = sm.OLS(sample[candidate], controls).fit().resid
    rho = float(stats.pearsonr(y_residual, x_residual).statistic)
    # The screening rule uses n - 2 degrees of freedom after residualization.
    degrees = len(sample) - 2
    statistic = rho * np.sqrt(degrees / max(1 - rho * rho, np.finfo(float).eps))
    probability = float(2 * stats.t.sf(abs(statistic), degrees))
    return {"rho": rho, "n": len(sample), "p_student_t": probability, "df": degrees}


def screen_macros(frame):
    """Screen macro lags for stationarity, significance and matching IS/OOT signs."""
    stationarity_table = pd.DataFrame(
        [
            {"family": family, **stationarity(frame.loc[START:IS_END, MACRO_CHANGES[family]])}
            for family in MACROS
        ]
    )
    eligible_families = set(stationarity_table.loc[stationarity_table["stationary"], "family"])
    rows = []
    for family in MACROS:
        for lag in range(13):
            term = macro_lag_name(family, lag)
            in_sample = partial_correlation(frame.loc[START:IS_END], term)
            oot = partial_correlation(frame.loc[OOT_START:END], term)
            same_sign = bool(np.sign(in_sample["rho"]) == np.sign(oot["rho"]))
            row = {"candidate": term, "family": family, "lag": lag}
            for suffix, result in [("is", in_sample), ("oot", oot)]:
                row.update({f"{key}_{suffix}": value for key, value in result.items()})
            row.update(
                same_sign=same_sign,
                stationarity_pass_is=family in eligible_families,
                passed=bool(
                    family in eligible_families
                    and same_sign
                    and in_sample["p_student_t"] < SCREEN_ALPHA
                    and oot["p_student_t"] < SCREEN_ALPHA
                ),
            )
            rows.append(row)
    screen = pd.DataFrame(rows)
    candidates = screen.loc[screen["passed"], "candidate"].tolist()
    candidates += list(TARGET_LAGS)
    return screen, candidates, stationarity_table


def model_diagnostics(model):
    """Calculate residual diagnostics and descriptive goodness-of-fit measures."""
    jb, jb_p, _, _ = jarque_bera(model.resid)
    lb = acorr_ljungbox(model.resid, lags=[12], model_df=0, return_df=True).iloc[0]
    return {
        "n": int(model.nobs),
        "r_squared": float(model.rsquared),
        "adjusted_r_squared": float(model.rsquared_adj),
        "aic": float(model.aic),
        "durbin_watson": float(durbin_watson(model.resid)),
        "jarque_bera": float(jb),
        "jarque_bera_p": float(jb_p),
        "ljung_box_lag_12": float(lb.lb_stat),
        "ljung_box_lag_12_p": float(lb.lb_pvalue),
        "ljung_box_model_df": 0,
        "max_vif": max(vifs(model).values()),
    }


def score(predictions):
    """Summarize fee-level errors; mape_pct is expressed as a percentage."""
    actual_fee = predictions["actual_fee"].to_numpy()
    predicted = predictions["predicted_fee"].to_numpy()
    error = predicted - actual_fee
    return {
        "n": len(actual_fee),
        "rmse": float(np.sqrt(np.mean(error ** 2))),
        "mae": float(np.mean(abs(error))),
        "mape_pct": float(np.mean(abs(error / actual_fee)) * 100),
        "bias": float(np.mean(error)),
    }


def oot_path(frame, model, dynamic):
    """Construct static or growth-lag-recursive OOT fee-level predictions.

    Both modes use observed year-ago fee levels and observed adjusted error correction.
    Dynamic mode substitutes predicted growth into subsequent own-growth lags.
    """
    growth = frame["commercial_small_business_fee_pct_change_12m"].copy()
    if dynamic:
        growth.loc[OOT_START:END] = np.nan
    rows = []
    for date in pd.date_range(OOT_START, END, freq="MS"):
        inputs = {}
        for term in model.params.index:
            if term == "const":
                value = 1.0
            elif term in TARGET_LAGS:
                lag = TARGET_LAGS[term]
                value = growth.at[date - pd.DateOffset(months=lag)]
            else:
                value = frame.at[date, term]
            inputs[term] = float(value)
        predicted_growth = float(
            sum(model.params[term] * inputs[term] for term in model.params.index)
        )
        anchor_date = date - pd.DateOffset(months=12)
        anchor = frame.at[anchor_date, "commercial_small_business_fee"]
        predicted_fee = float(anchor * (1 + predicted_growth / 100))
        long_run = float(frame.at[date, "long_run_fitted_fee"])
        ec_trend_overlay_pct = float(frame.at[date, "ec_trend_overlay_pct"])
        predicted_ec = 100 * (predicted_fee - long_run) / long_run
        rows.append(
            {
                "date": date,
                "mode": "dynamic_y_only" if dynamic else "static",
                "actual_fee": frame.at[date, "commercial_small_business_fee"],
                "predicted_fee": predicted_fee,
                "actual_pct_change_12m": frame.at[
                    date, "commercial_small_business_fee_pct_change_12m"
                ],
                "predicted_pct_change_12m": predicted_growth,
                "anchor_date": anchor_date,
                "fee_lag_12m_input": anchor,
                "long_run_fitted_fee": long_run,
                "ec_trend_overlay_pct": ec_trend_overlay_pct,
                "predicted_ec_scaled_pct": predicted_ec,
                "predicted_ec_scaled_adjusted_pct": predicted_ec - ec_trend_overlay_pct,
                **{f"{term}_input": value for term, value in inputs.items() if term != "const"},
            }
        )
        if dynamic:
            growth.at[date] = predicted_growth
    return pd.DataFrame(rows)


def forecast_path(history, macro, long_run, short_run, held_overlay, scenario):
    """Forecast 27 months recursively from the December 2025 actual history.

    Each month updates fee levels, own-growth lags and adjusted error correction. Model
    coefficients remain fixed, and the overlay stays at its December 2025 value.
    """
    dates = pd.date_range(START, FORECAST_END, freq="MS")
    future_dates = pd.date_range(FORECAST_START, FORECAST_END, freq="MS")
    macro = macro.reindex(dates)
    long_terms = [term for term in long_run.params.index if term != "const"]
    long_run_fitted_fee = long_run.predict(sm.add_constant(macro[long_terms], has_constant="add"))

    # Initialize only from realized history. Future fee states start empty.
    levels = history.loc[:END, "commercial_small_business_fee"].reindex(dates).copy()
    growth = history.loc[:END, "commercial_small_business_fee_pct_change_12m"].reindex(dates).copy()
    adjusted_ec = history.loc[:END, "ec_scaled_adjusted_pct"].reindex(dates).copy()

    # Apply the same macro transformations and lags as the short-run model.
    macro_lags = {}
    for term in short_run.params.index:
        if term == "const" or term == EC_TERM or term in TARGET_LAGS:
            continue
        family, lag = MACRO_FEATURES[term]
        change = (
            macro[family].diff(12)
            if family == "unemployment_rate"
            else macro[family].pct_change(12, fill_method=None) * 100
        )
        macro_lags[term] = change.shift(int(lag))

    rows = []
    for date in future_dates:
        inputs = {}
        for term in short_run.params.index:
            if term == "const":
                value = 1.0
            elif term == EC_TERM:
                value = adjusted_ec.at[date - pd.DateOffset(months=12)]
            elif term in TARGET_LAGS:
                lag = TARGET_LAGS[term]
                value = growth.at[date - pd.DateOffset(months=lag)]
            else:
                value = macro_lags[term].at[date]
            inputs[term] = float(value)

        predicted_growth = float(
            sum(short_run.params[term] * inputs[term] for term in short_run.params.index)
        )
        anchor_date = date - pd.DateOffset(months=12)
        anchor = float(levels.at[anchor_date])
        predicted_fee = float(anchor * (1 + predicted_growth / 100))
        long_level = float(long_run_fitted_fee.at[date])
        # Do not emit partial fee totals when a required scenario input is absent.
        if not np.isfinite([predicted_growth, predicted_fee, long_level]).all() or long_level == 0:
            raise ValueError(f"Cannot calculate {scenario} forecast for {date:%Y-%m}.")
        raw_ec = 100 * (predicted_fee - long_level) / long_level
        adjusted = raw_ec - held_overlay

        levels.at[date] = predicted_fee
        growth.at[date] = predicted_growth
        adjusted_ec.at[date] = adjusted
        rows.append(
            {
                "date": date,
                "scenario": scenario,
                "predicted_fee": predicted_fee,
                "predicted_pct_change_12m": predicted_growth,
                "long_run_fitted_fee": long_level,
                "anchor_date": anchor_date,
                "fee_lag_12m_input": anchor,
                "ec_trend_overlay_pct": held_overlay,
                "predicted_ec_scaled_pct": raw_ec,
                "predicted_ec_scaled_adjusted_pct": adjusted,
                **{f"{term}_input": value for term, value in inputs.items() if term != "const"},
            }
        )
    return pd.DataFrame(rows)


def scenario_forecasts(data_dir, history, long_run, short_run, trend):
    """Join each future macro scenario to the same historical observations."""
    macro_history = read_macro(data_dir / "macro_history.csv")
    macro_baseline = read_macro(data_dir / "macro_baseline.csv")
    baseline = pd.concat([macro_history, macro_baseline]).sort_index()[MACROS]
    s4_inputs = read_macro(data_dir / "macro_s4.csv")
    future_dates = pd.date_range(FORECAST_START, FORECAST_END, freq="MS")
    downside = baseline.copy()
    # S4 changes only the supplied CPI and corporate-profits scenario levels.
    scenario_drivers = ["consumer_price_index", "corporate_profits"]
    downside.loc[future_dates, scenario_drivers] = s4_inputs.reindex(future_dates)[scenario_drivers]
    paths = [
        forecast_path(history, macro, long_run, short_run, trend["held_value_pct"], scenario)
        for scenario, macro in [("Baseline", baseline), ("S4", downside)]
    ]
    return pd.concat(paths, ignore_index=True)


def quarterly_forecast_summary(monthly):
    """Sum monthly fee levels into nine quarters and two cumulative totals.

    Quarterly figures are three-month sums, not monthly averages or quarter-end
    values. December 2025 is a historical starting point and is not included.
    """
    data = monthly.assign(quarter=monthly["date"].dt.to_period("Q-DEC"))
    quarters = pd.period_range(FORECAST_START, FORECAST_END, freq="Q-DEC")
    quarterly = (
        data.groupby(["quarter", "scenario"])["predicted_fee"]
        .sum(min_count=3)
        .unstack("scenario")
        .reindex(index=quarters, columns=["Baseline", "S4"])
    )
    rows = [
        {
            "period": str(quarter),
            "months": 3,
            "baseline_total": float(quarterly.at[quarter, "Baseline"]),
            "s4_total": float(quarterly.at[quarter, "S4"]),
        }
        for quarter in quarters
    ]

    # Sum unrounded quarterly amounts; never add a subtotal into another total.
    for label, values, count in [
        ("2026 total", quarterly.loc[quarterly.index.year == 2026], 4),
        ("9-quarter total", quarterly, 9),
    ]:
        totals = values.sum(min_count=count)
        rows.append(
            {
                "period": label,
                "months": count * 3,
                "baseline_total": float(totals["Baseline"]),
                "s4_total": float(totals["S4"]),
            }
        )
    return pd.DataFrame(rows)


def run(data_dir: Path, output_dir: Path):
    """Estimate both stages and save the resulting model analysis."""
    output_dir = output_dir.resolve()
    # Protect source files and previous results from accidental replacement.
    if output_dir.exists() and any(output_dir.iterdir()):
        raise ValueError(f"Output directory is not empty: {output_dir}. Use a new --output-dir.")
    data = load_data(data_dir)
    tables = {}

    # Step 1: estimate the long-run relationship using IS observations only.
    lr_terms, tables["long_run_trials"], tables["long_run_rounds"] = forward_select(
        data.loc[START:IS_END],
        "commercial_small_business_fee",
        LONG_RUN_POOL,
        residual_adf_gate=True,
    )
    if not lr_terms:
        raise ValueError("No long-run candidate meets the selection criteria.")
    long_run = fit(data.loc[START:IS_END], "commercial_small_business_fee", lr_terms)
    tables["long_run_coefficients"] = coefficients(long_run, "long_run")
    tables["long_run_residual_stationarity"] = pd.DataFrame([stationarity(long_run.resid)])
    frame, trend, trend_model = engineer(data, long_run)
    tables["ec_scaled_stationarity"] = pd.DataFrame(
        [{"window": "2011-01 to 2023-09", **stationarity(frame.loc[START:IS_END, "ec_scaled_pct"])}]
    )
    tables["overlay_trend"] = pd.DataFrame([trend])
    tables["overlay_coefficients"] = coefficients(trend_model, "ec_trend_overlay_pct")

    # Step 2: screen macro terms, then select the short-run growth regressors.
    screen, candidates, tables["macro_stationarity"] = screen_macros(frame)
    tables["short_run_screen_all"] = screen
    tables["short_run_screen_passed"] = screen.loc[screen["passed"]]
    sr_terms, tables["short_run_trials"], tables["short_run_rounds"] = forward_select(
        frame.loc[START:IS_END],
        "commercial_small_business_fee_pct_change_12m",
        candidates,
        base_terms=[EC_TERM],
    )
    short_run = fit(
        frame.loc[START:IS_END], "commercial_small_business_fee_pct_change_12m", sr_terms
    )
    tables["short_run_coefficients"] = coefficients(short_run, "short_run")
    diagnostics = model_diagnostics(short_run)
    tables["short_run_diagnostics"] = pd.DataFrame([diagnostics])

    # Reconstruct IS fee levels from predicted YoY growth and observed anchors.
    dates = short_run.resid.index
    level_fit = frame["commercial_small_business_fee"].shift(12).loc[dates] * (
        1 + short_run.fittedvalues / 100
    )
    tables["static_in_sample"] = pd.DataFrame(
        {
            "date": dates,
            "actual_fee": frame.loc[dates, "commercial_small_business_fee"].to_numpy(),
            "predicted_fee": level_fit.to_numpy(),
        }
    )
    tables["static_oot"] = oot_path(frame, short_run, dynamic=False)
    tables["dynamic_oot"] = oot_path(frame, short_run, dynamic=True)
    tables["forecast_accuracy"] = pd.DataFrame(
        [
            {"sample": name, **score(tables[table])}
            for name, table in [
                ("in_sample_fitted", "static_in_sample"),
                ("OOT_static", "static_oot"),
                ("OOT_dynamic_recursive_y_lags", "dynamic_oot"),
            ]
        ]
    )
    tables["historical_data_and_features"] = frame.reset_index()
    tables["short_run_estimation_sample"] = (
        frame.loc[dates, ["commercial_small_business_fee_pct_change_12m"] + sr_terms]
        .assign(fitted_pct_change_12m=short_run.fittedvalues, residual=short_run.resid)
        .reset_index()
    )
    tables["long_run_history"] = frame[
        ["commercial_small_business_fee"] + lr_terms + ["long_run_fitted_fee", "ec_residual"]
    ].reset_index()

    # Forecast each scenario from the same Dec 2025 starting point, then aggregate.
    tables["forecast_monthly"] = scenario_forecasts(data_dir, frame, long_run, short_run, trend)
    tables["forecast_quarterly_summary"] = quarterly_forecast_summary(tables["forecast_monthly"])

    output_dir.mkdir(parents=True, exist_ok=True)
    for name, table in tables.items():
        table.to_csv(
            output_dir / f"{name}.csv",
            index=False,
            encoding="utf-8",
            float_format="%.15g",
            date_format="%Y-%m-%d",
        )
    summary = {
        "periods": {"IS": "2011-01 to 2023-09", "OOT": "2023-10 to 2025-12"},
        "long_run_terms": lr_terms,
        "long_run_r_squared": float(long_run.rsquared),
        "long_run_adjusted_r_squared": float(long_run.rsquared_adj),
        "long_run_residual_adf_p": float(tables["long_run_residual_stationarity"].iloc[0]["adf_p"]),
        "ec_trend_overlay_pct": trend,
        "short_run_terms": sr_terms,
        "screen_pass_count": int(screen["passed"].sum()),
        "diagnostics": diagnostics,
        "forecast_accuracy": tables["forecast_accuracy"].to_dict("records"),
        "forecast_period": "2026-01 to 2028-03",
        "forecast_quarterly_summary": tables["forecast_quarterly_summary"].to_dict("records"),
    }
    summary_text = json.dumps(summary, indent=2, ensure_ascii=True, allow_nan=False)
    (output_dir / "summary.json").write_text(summary_text + "\n", encoding="utf-8")
    print(summary_text)
    print(f"Results saved to: {output_dir}")


def main():
    parser = argparse.ArgumentParser(
        description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter
    )
    parser.add_argument(
        "--data-dir",
        type=Path,
        default=ROOT / "data",
        help="Directory containing the four raw input CSV files.",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=ROOT / "results",
        help="New or empty directory for computed results.",
    )
    args = parser.parse_args()
    try:
        run(args.data_dir, args.output_dir)
    except (ValueError, OSError, KeyError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
