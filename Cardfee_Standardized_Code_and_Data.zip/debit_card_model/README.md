# Debit Card Fee Model

This standalone script prepares Debit Card fee history, evaluates four regression approaches, and calculates the adopted quarterly Baseline and Stress levels from raw observations.

## Run

Use Python 3.10 or later:

```bash
python -m pip install "numpy>=1.26,<3" "pandas>=2.2,<3" "scipy>=1.11,<2" "statsmodels>=0.14,<0.16"
python debit_card_model.py
```

Input and output paths are relative to the script. Use `--data-dir` for another folder with the same input schema and `--output-dir` for a new or empty results directory. The default output is `results/`. A nonempty output directory is not overwritten.

## Input files

| File | Period | Purpose |
| --- | --- | --- |
| `data/fee_history.csv` | Jan 2011 to Dec 2025 | Original Debit Card fee observations before outlier treatment |
| `data/macro_history.csv` | Jan 2011 to Dec 2025 | Historical levels of the 14 candidate macro series |

Both files use `date` in `YYYY-MM-DD` format, with the first day of each month. Revenue uses the source column `Debit Card`, mapped to `debit_card_fee_raw`. Macro CSV headers retain the Moody's source names; `MACRO_COLUMNS` maps them to business names in Python. Explanatory annotations attached to the original retail-sales and consumer-confidence headers are retained.

| Moody's CSV header | Internal variable | Level units |
| --- | --- | --- |
| `M_FLBR_B.IUSA` | `unemployment_rate` | Percent |
| `M_FCPIU_B.IUSA` | `consumer_price_index` | Index |
| `M_FYPDPIQ_B.IUSA` | `disposable_personal_income` | Original source units |
| `M_FRT_B.IUSA (Retail Sales Total_Bil.USD,CDASAAR)` | `retail_sales` | Billions of USD; source label CDASAAR |
| `M_FCBC_B.IUSA(Consumer confidence index)` | `consumer_confidence` | Index |
| `M_FSBINQ_B.IUSA` | `small_business_optimism` | Index |
| `M_FGDP42Q_B.IUSA` | `wholesale_trade_gdp` | Original source units |
| `M_FIP_B.IUSA` | `industrial_production` | Index |
| `M_FZA_B.IUSA` | `corporate_profits` | Original source units |
| `M_FDJMIIUSDD_WCFTDQ_B.IUSA` | `dow_jones_total_market_index` | Index |
| `M_FRT4451_B.IUSA` | `grocery_sales` | Original source units |
| `M_FRT447_B.IUSA` | `gasoline_sales` | Original source units |
| `M_FRT454_B.IUSA` | `nonstore_sales` | Original source units |
| `M_FETP_B.IUSA` | `private_employment` | Original source units |

Fee revenue and macro values retain the supplied source units. No currency-scale conversion, interpolation or seasonal adjustment is applied. Monthly rows describe the supplied data frequency, not necessarily each series' native publication frequency. Only actual observations belong in these files. The adopted qualitative forecast does not require future macro scenarios, so this package has no Baseline or S4 macro input files.

## Revenue treatment

`debit_card_fee_raw` retains all source observations. A working copy, `debit_card_fee_adjusted`, replaces March and December 2012 with the arithmetic mean of the adjacent raw monthly fees. Both replacements are recalculated from data. The unconfirmed 2014 anomalies and the sustained 2015 level shift remain unchanged.

Model estimation starts in January 2012 and ends in September 2023. The excluded 2011 observations do not enter regression lags or growth denominators. They remain available for the historical regulatory-period description. Quarterly fee revenue is the sum of three monthly observations; quarterly macro inputs use the quarter-end monthly observation.

## Regression approaches and feature names

| Approach | Target | Macro treatment and lags |
| --- | --- | --- |
| Level | `debit_card_fee_adjusted` | Monthly macro levels; target lags 1-12 and macro lags 0-12 |
| YoY static screen | `debit_card_fee_adjusted_pct_change_12m` | Annual changes of contemporaneous monthly macro values |
| MoM | `debit_card_fee_adjusted_pct_change_1m` | Monthly changes; target lags 1-12 and macro lags 0-12 |
| Quarterly QoQ | `debit_card_fee_quarterly_pct_change_1q` | Quarterly changes in quarter-end macros; target lags 1-4 and macro lags 0-4 |

`pct_change_1m` and `pct_change_12m` are `100 * (current / prior - 1)` at the stated horizon. Unemployment instead uses `diff_1m_pp`, `diff_12m_pp` or `diff_1q_pp`, measured in percentage points. Quarterly macro names include `quarter_end` to identify their aggregation convention. `lag_1m` is one month; `lag_1q` is one quarter; `lag_0m` denotes a contemporaneous value.

For example, `corporate_profits_pct_change_12m_lag_0m` is contemporaneous annual profit growth, while `unemployment_rate_quarter_end_diff_1q_pp_lag_1q` is a one-quarter lag of the quarterly change in the quarter-end unemployment rate.

Each approach uses its own common complete-case sample and starts with an intercept-only model. Each proposed addition requires Student-t p < 0.05, DW from 1.5 to 2.5 inclusive, JB p > 0.05 and maximum nonconstant VIF < 10. Passing terms are ranked by p-value, adjusted R-squared and fixed tie order. There are no forced terms or joint additions. If no first addition passes, no final model is accepted. The YoY route ends at screening; this script does not estimate an ECM afterward.

## Qualitative scenarios

Adjusted monthly fees are summed into complete calendar quarters. Both scenario levels are calculated from these totals:

- Baseline: mean of the latest eight complete actual quarters. With the supplied data, the window is 2024Q1 through 2025Q4.
- Stress floor: mean minus two sample standard deviations (`ddof=1`) of all complete quarters from 2015Q1 onward. With the supplied data, the window ends in 2025Q4.

Appending complete actual quarters advances the Baseline window and extends the Stress window. An incomplete quarter does not enter either calculation. No document-reported revenue level is hardcoded. The regression estimation cutoff remains September 2023.

The results are quarterly revenue levels, not a dated forecast trajectory or a macro response function. The monthly equivalent equals the quarterly Stress floor divided by three. Intermediate and exported calculations are not rounded to a prescribed number of decimal places. Mean minus two standard deviations is a scenario rule, not an estimated tail probability.

## Generated results

| File | Content |
| --- | --- |
| `regression_summary.csv` | Samples, accepted terms and diagnostic pass counts by approach |
| `regression_candidates.csv` | Candidate coefficients, Student-t inference and diagnostic outcomes |
| `historical_statistics.csv` | Quarterly distribution statistics and historical changes |
| `monthly_revenue.csv` | Raw and adjusted monthly fee history |
| `quarterly_revenue.csv` | Complete-quarter fee totals |
| `qualitative_scenarios.csv` | Calculated Baseline and Stress levels |

Results use descriptive lower-case column names, including `standard_error`, `p_student_t`, `r_squared`, `durbin_watson` and `jarque_bera_p`. Quarterly history uses quarter-end dates. All calculations occur at runtime; no generated results are required as inputs.
