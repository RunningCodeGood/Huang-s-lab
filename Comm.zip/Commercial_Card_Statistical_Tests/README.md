# Commercial Card statistical tests

本包将最新 22 页英文 Deck `Commercial_Card_Two_Step_Model_Deck_Reference_v5.pptx` 涉及的统计检验、变量筛选、模型诊断和 IS/OOT 拟合误差整理为一个可独立运行的 Python 脚本。代码和输出字段使用英文。

计算从原始数据重新估计模型，不读取已保存的系数进行拟合。`reference/` 仅在计算完成后用于比较原结果，不参与任何模型估计或选择。本包复现原计算口径，不等同于对建模方法的全面独立验证。

## 快速运行

建议使用 Python 3.12。解压后进入 `Commercial_Card_Statistical_Tests` 目录，执行：

```bash
python -m pip install -r requirements.txt
python commercial_card_statistical_tests.py
```

结果生成于 `results/`。依赖安装后，计算不需要联网，不需要 Excel、PowerPoint 或其他项目文件。

再次运行时请指定新的输出目录，脚本不会覆盖已有非空目录：

```bash
python commercial_card_statistical_tests.py --output-dir results_run2
```

也可从任意工作目录运行脚本的完整路径。默认输入路径相对于脚本所在位置解析。

```bash
python commercial_card_statistical_tests.py --data-dir data --output-dir results_new --skip-reference-check
```

最后一个命令用于不依赖原结果的运行，或替换同结构输入后的分析。修改数据后不应期待与原 Deck 一致。IS/OOT 日期、阈值和候选集合在脚本顶部定义。

退出码：`0` 为成功，`1` 为输入或运行配置错误，`2` 为数值自检或原结果比较失败。失败信息和 CSV 会指出具体位置，不会强行修改结果以匹配 Deck。

## 包内文件

- `commercial_card_statistical_tests.py`：唯一的 Python 代码文件，包含完整计算链。
- `data/`：两份未经修改的原始输入 CSV。
- `requirements.txt`：本次运行使用的四个直接依赖版本。
- `reference/`：原模型的 16 份结果 CSV，仅用于复现比较。`deck_statistics_text.json` 保留相关页文字，`provenance.json` 记录原文件与哈希。
- `example_results/`：本次实际运行的输出，可先查看 `summary.json`、`reference_comparison.csv` 和 `numerical_checks.csv`。

## 原始数据与变量

`Cardfee.csv` 包含 Jan 2011–Dec 2025 的 180 个月，列为 `YYYYMM`、`Commercial Card`、`Small Business`。目标水平值为两项收入之和，保留源数据单位，不另做美元/千元/百万元换算。

`Macro_Data_201001-202803.csv` 实际覆盖 Jan 2011–Mar 2028，尽管文件名含 `201001`。为保留原始文件完整性，未来行未删去；本脚本只使用 Jan 2011–Dec 2025 历史区间。S4 预测输入不参与这些统计检验，因此本包不包含 S4 工作簿，也不生成未来情景预测图。

| 模型变量 | 原始列 | 短期变换 |
| --- | --- | --- |
| Unrate | M_FLBR_B.IUSA | 当月减 12 个月前，百分点 |
| CPI | M_FCPIU_B.IUSA | 12 个月同比变动 × 100 |
| DPI | M_FYPDPIQ_B.IUSA | 同比变动 × 100 |
| SBOpt | M_FSBINQ_B.IUSA | 同比变动 × 100 |
| GDP_Wholesale | M_FGDP42Q_B.IUSA | 同比变动 × 100 |
| IP | M_FIP_B.IUSA | 同比变动 × 100 |
| CorpProfits | M_FZA_B.IUSA | 同比变动 × 100 |
| DJ_TotalMkt | M_FDJMIIUSDD_WCFTDQ_B.IUSA | 同比变动 × 100 |

短期因变量 `y(t) = 100 × [Combined(t) / Combined(t-12) - 1]`。宏观变量检查 lag 0–12，因变量自身检查 lag 1–12。脚本不插值、不填补缺失值、不使用未来宏观行估计历史关系。

## Deck 页码与代码对应

页码以加入 long-run 拟合图后的最新 v5 为准。

| 页码 | 项目 | 代码函数 | 主要输出 |
| --- | --- | --- | --- |
| P6 | 长期 OLS、候选变量显著性、VIF、前向选择、残差 ADF | `forward_select`, `fit`, `coefficients`, `stationarity` | `long_run_trials`, `long_run_rounds`, `long_run_coefficients`, `long_run_residual_stationarity` |
| P7 | 冻结 IS 系数后的全历史长期拟合 | `engineer` | `long_run_history` |
| P8 | EC_scaled 的 ADF / KPSS | `stationarity` | `ec_scaled_stationarity` |
| P9 | 27 个月 overlay OLS、斜率 t 检验、R² | `engineer`, `coefficients` | `overlay_trend`, `overlay_coefficients` |
| P10 | 宏观变换的平稳性预筛、IS/OOT 偏相关显著性及方向筛选 | `screen_macros`, `partial_correlation` | `macro_stationarity`, `short_run_screen_all`, `short_run_screen_passed`, `P10_displayed_screen` |
| P11 | 固定调整后 EC 项的短期前向选择 | `forward_select` | `short_run_trials`, `short_run_rounds` |
| P12 | 最终短期模型系数、标准误、t 值、p 值、VIF | `coefficients` | `short_run_coefficients` |
| P13 | Jarque–Bera、Ljung–Box(12)、Durbin–Watson、R²、调整 R²、AIC | `model_diagnostics` | `short_run_diagnostics` |
| P13–P15 | IS 重构水平及 OOT static/dynamic 的 MAPE、RMSE、MAE | `score`, `oot_path`, `run` | `accuracy`, `in_sample_predictions`, `oot_static`, `oot_dynamic` |
| P2、P4–P5 | 上述结果与方法的摘要 | 同上 | `summary.json` |

上表输出名除特殊标注外均为 `.csv`。R²、AIC、VIF、MAPE、RMSE、MAE 以及单独的 Durbin–Watson 值不是本包中带 p 值的假设检验，但一并保留，便于复核 Deck。

`prepared_monthly_data.csv` 导出所有变换、lag、EC 和 overlay；`short_run_estimation_sample.csv` 导出最终 135 个估计样本及残差。P16–P22 为情景预测方法与点预测，不含新增统计检验，本包不复现这些预测页。

## 复现口径与需要注意的事项

1. **样本与 OOT 使用。** 长期估计使用 Jan 2011–Sep 2023 的 153 个月。最终短期估计使用 Jul 2012–Sep 2023 的 135 个月。Oct 2023–Dec 2025 的 27 个月既用于 overlay 估计，也用于变量筛选；OOT 误差是 fitted backtest，不能视为完全未触碰的样本外验证。

2. **长期选择。** 固定候选池为 CPI、DPI、GDP_Wholesale、CorpProfits、DJ_TotalMkt。SBOpt 不进入长期候选池，但保留在短期宏观筛选中。候选池的 I(1) 标签继承原方法，并非本包重新证明。原代码在新增项 p < 0.05、最大 VIF < 10 之外，还要求普通残差 ADF p < 0.05，然后按调整 R² 排序。代码保留这一实际执行规则。

3. **残差 ADF 的解释。** 长期残差 p = 0.009148 来自 `adfuller(residual, regression='c', autolag='AIC')`。它不是采用残差协整分布校准的 Engle–Granger p 值，不能将它直接称为正式协整检验。本包没有把另一种检验悄悄替换进原结果。

4. **平稳性。** ADF 原假设为单位根，KPSS 原假设为水平平稳。两者均含常数，不含线性趋势。ADF 采用 AIC 自动选 lag，KPSS 使用 `nlags='auto'`。宏观短期变换预筛沿用原代码的 OR 规则：ADF p < 0.05 或 KPSS p > 0.05；同时输出更严格的 AND 标记。KPSS 输出 0.100 是查表边界，不是精确 p 值，另有 `KPSS_p_bound` 与警告字段说明。

5. **偏相关自由度。** 原代码将 y 与候选项分别对常数和一个 EC 控制项回归，然后计算残差相关系数。原 p 值使用 n−2 自由度。控制一个变量的通常偏相关检验使用 n−3。本包主结果保留 n−2 以复现 Deck，另在 `partial_correlation_df_sensitivity.csv` 输出 n−3 的 p 值和筛选标记。本次两种自由度的通过集合均为 14 项，未改变进入短期选择的集合。这些检验未做时间序列 HAC 或多重比较调整。

6. **P10 只展示部分通过项。** Deck 显示 8 项，原筛选实际通过 14 项。额外 6 项为 Unrate_lag1、Unrate_lag3、Unrate_lag4、Unrate_lag5、Unrate_lag7、Unrate_lag9。代码使用实际通过的全部 14 个宏观项加 12 个自身 lag 进行前向选择，不能把 P10 表误读为完整候选清单。最终仍选中 y_lag1、y_lag6、CorpProfits_lag2。

7. **前向选择与标准误。** 每次候选回归使用自身可用的完整样本，因而不同 lag 对应的 n 可能不同。可通过的候选按调整 R² 降序选取，平局按变量名排序。新增项要求 p < 0.05、最大 VIF < 10；短期 EC 项固定保留。所有回归 p 值及置信区间为非稳健 OLS、双侧 t 检验，未做 HAC、bootstrap、选择后推断或生成回归量修正。

8. **残差诊断。** Ljung–Box 为 12 lag、`model_df=0`，与原代码一致；不声称其自由度已扣除模型估计参数。Jarque–Bera 检查残差正态性，Ljung–Box 检查前 12 lag 自相关；不拒绝原假设不等于证明模型正确。Durbin–Watson 仅输出统计量，不给出 p 值。

9. **OOT dynamic 的准确含义。** static 使用实际自身增长 lag；dynamic 仅递归更新自身增长 lag。两者都保留实际 t−12 收入水平作为重构锚点，且 EC 控制项基于实际历史、经过 overlay 调整。这里的 dynamic 不等同于 P16 中未来预测的全状态递归。

10. **复现与独立验证的边界。** 脚本重跑原始数据并逐列比较原输出，另用 NumPy 最小二乘核对三组回归的系数、标准误和 p 值。这能检查实现和数值一致性，但不会消除上述模型设计、样本使用及推断假设的限制。

## 本次运行结果

16 份原结果 CSV 共 164 个表/列检查全部通过，比较容差为 `rtol=1e-9, atol=1e-9`，用于容纳原 CSV 的 12 位有效数字导出误差。额外 11 项数值/样本检查通过。

| 指标 | 重新计算结果 |
| --- | ---: |
| Long-run R² | 0.9271677145 |
| Long-run residual ADF p | 0.0091481338 |
| EC_scaled ADF p | 0.0193032813 |
| EC_scaled KPSS p（边界值） | 0.100 |
| Overlay slope | -0.9092539576 |
| Overlay slope p | 1.3246629031e-08 |
| Short-run adjusted R² | 0.7356537038 |
| Jarque–Bera p | 0.7573259809 |
| Ljung–Box(12) p | 0.3180075667 |
| IS MAPE | 5.3853252922% |
| OOT static MAPE | 8.7641346103% |
| OOT dynamic MAPE | 16.1579303208% |

源数据与脚本 SHA-256、Python 和依赖版本记录于每次运行的 `run_manifest.json`，便于核实不同电脑是否使用相同输入。`summary.json` 汇总实际重跑结果；README 表格仅为这次运行的静态摘要。

## 检验定义参考

- [Statsmodels Engle–Granger test](https://www.statsmodels.org/stable/generated/statsmodels.tsa.stattools.coint.html)：正式协整检验与普通残差 ADF 的区别。
- [Statsmodels KPSS](https://www.statsmodels.org/stable/generated/statsmodels.tsa.stattools.kpss.html)：p 值查表边界及参数定义。
- [Statsmodels Ljung–Box](https://www.statsmodels.org/stable/generated/statsmodels.stats.diagnostic.acorr_ljungbox.html)：`model_df` 和自由度定义。
- [Penn State partial correlation](https://online.stat.psu.edu/stat505/Lesson06)：控制 c 个变量时的 n−2−c 自由度。
