#!/usr/bin/env python3
"""Reproduce the statistical calculations in Commercial Card Deck Reference v5.

Run: python commercial_card_statistical_tests.py
Only data/Cardfee.csv and data/Macro_Data_201001-202803.csv feed estimation.
reference/*.csv are optional AFTER-THE-FACT comparisons, never model inputs.
No other project scripts, internet access, Excel or PowerPoint are required.

Deck-compatible conventions are intentionally retained and disclosed:
* Partial-correlation p-values use n-2 degrees of freedom in the original run.
  Additional n-3 p-values are exported, but do not silently change selection.
* Long-run selection uses ordinary residual ADF, not an Engle-Granger test.
* OOT informs both the overlay and screening, so it is a fitted backtest.
* Dynamic OOT recurses growth lags only, retaining observed level anchors/EC.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import platform
import sys
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
import scipy
from scipy import stats
import statsmodels
import statsmodels.api as sm
from statsmodels.stats.diagnostic import acorr_ljungbox
from statsmodels.stats.outliers_influence import variance_inflation_factor
from statsmodels.stats.stattools import durbin_watson, jarque_bera
from statsmodels.tsa.stattools import adfuller, kpss

ROOT = Path(__file__).resolve().parent
START, IS_END = pd.Timestamp("2011-01-01"), pd.Timestamp("2023-09-01")
OOT_START, END = pd.Timestamp("2023-10-01"), pd.Timestamp("2025-12-01")
ALPHA, SCREEN_ALPHA, VIF_LIMIT = 0.05, 0.20, 10.0
EC_TERM = "EC_scaled_adj_lag12"
CARD_FILE = "Cardfee.csv"
MACRO_FILE = "Macro_Data_201001-202803.csv"
MAPPING = {
    "Unrate": "M_FLBR_B.IUSA", "CPI": "M_FCPIU_B.IUSA",
    "DPI": "M_FYPDPIQ_B.IUSA", "SBOpt": "M_FSBINQ_B.IUSA",
    "GDP_Wholesale": "M_FGDP42Q_B.IUSA", "IP": "M_FIP_B.IUSA",
    "CorpProfits": "M_FZA_B.IUSA", "DJ_TotalMkt": "M_FDJMIIUSDD_WCFTDQ_B.IUSA",
}
LONG_RUN_POOL = ["CPI", "DPI", "GDP_Wholesale", "CorpProfits", "DJ_TotalMkt"]
DECK_SCREEN_ROWS = [
    "Unrate_lag6", "Unrate_lag8", "GDP_Wholesale_lag9", "GDP_Wholesale_lag10",
    "DPI_lag9", "CorpProfits_lag2", "CorpProfits_lag3", "CorpProfits_lag10",
]
REFERENCE_TABLES = [
    "long_run_trials", "long_run_rounds", "long_run_coefficients",
    "ec_scaled_stationarity", "overlay_trend", "macro_stationarity",
    "short_run_screen_all", "short_run_screen_passed", "short_run_trials",
    "short_run_rounds", "short_run_coefficients", "short_run_diagnostics",
    "in_sample_predictions", "oot_static", "oot_dynamic", "accuracy",
]


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save_csv(out: Path, name: str, frame: pd.DataFrame) -> None:
    frame.to_csv(out / f"{name}.csv", index=False, encoding="utf-8-sig",
                 float_format="%.15g", date_format="%Y-%m-%d")


def load_data(data_dir: Path) -> pd.DataFrame:
    """Validate monthly keys; never interpolate, fill gaps or use future actuals."""
    frames = []
    for filename, required in [
        (CARD_FILE, ["Commercial Card", "Small Business"]),
        (MACRO_FILE, list(MAPPING.values())),
    ]:
        frame = pd.read_csv(data_dir / filename, encoding="utf-8-sig")
        missing = set(["YYYYMM"] + required) - set(frame.columns)
        if missing:
            raise ValueError(f"{filename}: missing columns {sorted(missing)}")
        frame["date"] = pd.to_datetime(frame.pop("YYYYMM").astype(str), format="%Y%m")
        if frame["date"].duplicated().any():
            raise ValueError(f"{filename}: duplicate monthly keys")
        frame = frame.set_index("date").sort_index()[required]
        frame = frame.apply(pd.to_numeric, errors="raise")
        frames.append(frame)
    card, macro = frames
    card["Combined"] = card["Commercial Card"] + card["Small Business"]
    macro = macro.rename(columns={v: k for k, v in MAPPING.items()})
    dates = pd.date_range(START, END, freq="MS")
    data = macro.reindex(dates).join(card, how="left")
    data.index.name = "date"
    if not np.isfinite(data.to_numpy()).all():
        raise ValueError("All required historical inputs must be finite for Jan 2011-Dec 2025")
    if (data["Combined"] <= 0).any():
        raise ValueError("Combined revenue must be positive for YoY/MAPE calculations")
    if (data[[x for x in MAPPING if x != "Unrate"]] == 0).any().any():
        raise ValueError("Zero macro levels cannot be used as YoY denominators")
    return data


def stationarity(series: pd.Series) -> dict:
    """ADF H0: unit root. KPSS H0: level stationarity. Both include a constant."""
    x = series.dropna()
    adf = adfuller(x, regression="c", autolag="AIC", maxlag=None, result_object=False)
    with warnings.catch_warnings(record=True) as captured:
        warnings.simplefilter("always")
        kp = kpss(x, regression="c", nlags="auto", result_object=False)
    return {
        "n": len(x), "ADF_stat": float(adf[0]), "ADF_p": float(adf[1]),
        "ADF_lags": int(adf[2]), "ADF_effective_n": int(adf[3]),
        "ADF_critical_5pct": float(adf[4]["5%"]),
        "KPSS_stat": float(kp[0]), "KPSS_p": float(kp[1]), "KPSS_lags": int(kp[2]),
        "KPSS_critical_5pct": float(kp[3]["5%"]),
        "KPSS_p_bound": ">=0.10" if kp[1] == .1 else "<=0.01" if kp[1] == .01 else "interpolated",
        "KPSS_warning": " ".join(str(w.message).replace("\n", " ") for w in captured),
        # OR is the original macro pre-screen. AND is also reported, not substituted.
        "stationary_OR": bool(adf[1] < ALPHA or kp[1] > ALPHA),
        "stationary_AND": bool(adf[1] < ALPHA and kp[1] > ALPHA),
    }


def fit(frame: pd.DataFrame, target: str, terms: list[str]):
    # Candidate-specific complete cases reproduce the original selection run.
    z = frame[[target] + terms].dropna()
    return sm.OLS(z[target], sm.add_constant(z[terms], has_constant="add")).fit()


def vifs(model) -> dict:
    return {name: float(variance_inflation_factor(model.model.exog, j))
            for j, name in enumerate(model.params.index) if name != "const"}


def coefficients(model, name: str) -> pd.DataFrame:
    vf = vifs(model)
    ci = model.conf_int(alpha=ALPHA)
    return pd.DataFrame([{
        "model": name, "term": term, "coefficient": float(model.params[term]),
        "SE": float(model.bse[term]), "t": float(model.tvalues[term]),
        "p": float(model.pvalues[term]), "VIF": vf.get(term, np.nan),
        "CI_lower_95": float(ci.loc[term, 0]), "CI_upper_95": float(ci.loc[term, 1]),
        "df_resid": float(model.df_resid), "covariance": "nonrobust OLS",
    } for term in model.params.index])


def forward_select(frame, target, candidates, base_terms=None, residual_adf_gate=False):
    """P6/P11: candidate p<.05, max VIF<10, highest adjusted R2 wins.

    The original LR run ALSO requires ordinary residual ADF p<.05.
    The fixed EC control is not re-screened or removed in short-run selection.
    No common-sample restriction or multiple-testing adjustment is added.
    """
    selected, pending = list(base_terms or []), list(candidates)
    trials, rounds = [], []
    for round_number in range(1, len(candidates) + 1):
        current = []
        for candidate in pending:
            model = fit(frame, target, selected + [candidate])
            max_vif = max(vifs(model).values())
            p_adf = (float(adfuller(model.resid, regression="c", autolag="AIC", result_object=False)[1])
                     if residual_adf_gate else np.nan)
            eligible = model.pvalues[candidate] < ALPHA and max_vif < VIF_LIMIT
            if residual_adf_gate:
                eligible = eligible and p_adf < ALPHA
            current.append({
                "round": round_number, "candidate": candidate,
                "selected_before": " + ".join(selected),
                "coefficient": float(model.params[candidate]),
                "p_added": float(model.pvalues[candidate]), "max_VIF": float(max_vif),
                "residual_ADF_p": p_adf, "eligible": bool(eligible),
                "R2": float(model.rsquared), "adj_R2": float(model.rsquared_adj),
                "n": int(model.nobs),
            })
        eligible = [r for r in current if r["eligible"]]
        winner = min(eligible, key=lambda r: (-r["adj_R2"], r["candidate"])) if eligible else None
        for row in current:
            row["chosen"] = bool(winner and row["candidate"] == winner["candidate"])
        trials.extend(current)
        rounds.append({"round": round_number, "added": winner["candidate"] if winner else "none",
                       "adj_R2_after": winner["adj_R2"] if winner else np.nan,
                       "p_added": winner["p_added"] if winner else np.nan,
                       "n": winner["n"] if winner else np.nan})
        if winner is None:
            break
        selected.append(winner["candidate"])
        pending.remove(winner["candidate"])
    return selected, pd.DataFrame(trials), pd.DataFrame(rounds)


def engineer(data, long_run):
    """P7-P9: compute EC, estimate OOT overlay, then lag adjusted EC."""
    d = data.copy()
    terms = [x for x in long_run.params.index if x != "const"]
    d["fitted_lr"] = long_run.predict(sm.add_constant(d[terms], has_constant="add"))
    if np.isclose(d["fitted_lr"], 0).any():
        raise ValueError("Zero long-run fitted level prevents EC scaling")
    d["EC"] = d["Combined"] - d["fitted_lr"]
    d["EC_scaled"] = 100 * d["EC"] / d["fitted_lr"]
    oot = d.loc[OOT_START:END]
    t = pd.Series(np.arange(1, len(oot) + 1), index=oot.index, name="t")
    trend_model = sm.OLS(oot["EC_scaled"], sm.add_constant(t)).fit()
    a, b = float(trend_model.params["const"]), float(trend_model.params["t"])
    d["overlay"] = 0.0
    d.loc[oot.index, "overlay"] = a + b * t
    d["EC_scaled_adj"] = d["EC_scaled"] - d["overlay"]
    d[EC_TERM] = d["EC_scaled_adj"].shift(12)
    features = {"y": d["Combined"].pct_change(12, fill_method=None) * 100}
    for lag in range(1, 13):
        features[f"y_lag{lag}"] = features["y"].shift(lag)
    for family in MAPPING:
        change = (d[family].diff(12) if family == "Unrate"
                  else d[family].pct_change(12, fill_method=None) * 100)
        features[f"{family}_change"] = change
        for lag in range(13):
            features[f"{family}_lag{lag}"] = change.shift(lag)
    d = pd.concat([d, pd.DataFrame(features, index=d.index)], axis=1)
    trend = {"a": a, "b": b, "b_p": float(trend_model.pvalues["t"]),
             "R2": float(trend_model.rsquared), "n": int(trend_model.nobs),
             "held_value": a + b * len(oot)}
    return d, trend, trend_model


def partial_correlation(frame, candidate):
    """P10: residualize y and x on constant + adjusted lagged EC.

    'p' uses the original n-2 convention. 'p_df_corrected' uses n-3 for
    one control. Neither is HAC-adjusted for dependent monthly observations.
    """
    z = frame[["y", EC_TERM, candidate]].dropna()
    controls = sm.add_constant(z[[EC_TERM]], has_constant="add")
    ry = sm.OLS(z["y"], controls).fit().resid
    rx = sm.OLS(z[candidate], controls).fit().resid
    rho = float(stats.pearsonr(ry, rx).statistic)
    def significance(df):
        t = rho * np.sqrt(df / max(1 - rho * rho, np.finfo(float).eps))
        return float(2 * stats.t.sf(abs(t), df))
    return {"rho": rho, "n": len(z), "p": significance(len(z) - 2),
            "df_original": len(z) - 2, "p_df_corrected": significance(len(z) - 3),
            "df_corrected": len(z) - 3}


def screen_macros(d):
    st = pd.DataFrame([{"family": f, **stationarity(d.loc[START:IS_END, f"{f}_change"])}
                       for f in MAPPING])
    eligible = set(st.loc[st["stationary_OR"], "family"])
    rows = []
    for family in MAPPING:
        for lag in range(13):
            term = f"{family}_lag{lag}"
            is_r = partial_correlation(d.loc[START:IS_END], term)
            oot_r = partial_correlation(d.loc[OOT_START:END], term)
            same_sign = bool(np.sign(is_r["rho"]) == np.sign(oot_r["rho"]))
            gate = family in eligible and same_sign
            row = {"candidate": term, "family": family, "lag": lag}
            for suffix, result in [("IS", is_r), ("OOT", oot_r)]:
                row.update({f"{key}_{suffix}": value for key, value in result.items()})
            row.update(same_sign=same_sign, stationarity_pass_IS=family in eligible,
                       passed=bool(gate and is_r["p"] < SCREEN_ALPHA and oot_r["p"] < SCREEN_ALPHA),
                       passed_df_corrected=bool(gate and is_r["p_df_corrected"] < SCREEN_ALPHA
                                                and oot_r["p_df_corrected"] < SCREEN_ALPHA),
                       displayed_on_P10=term in DECK_SCREEN_ROWS)
            rows.append(row)
    screen = pd.DataFrame(rows)
    candidates = screen.loc[screen["passed"], "candidate"].tolist()
    candidates += [f"y_lag{k}" for k in range(1, 13)]
    return screen, candidates, st


def model_diagnostics(model):
    """P13: JB normality, Ljung-Box(12), DW and descriptive fit statistics."""
    jb, jb_p, _, _ = jarque_bera(model.resid)
    # Explicitly retain model_df=0 from the original run.
    lb = acorr_ljungbox(model.resid, lags=[12], model_df=0, return_df=True).iloc[0]
    return {"n": int(model.nobs), "R2": float(model.rsquared),
            "adj_R2": float(model.rsquared_adj), "AIC": float(model.aic),
            "Durbin_Watson": float(durbin_watson(model.resid)),
            "Jarque_Bera": float(jb), "Jarque_Bera_p": float(jb_p),
            "Ljung_Box_12": float(lb.lb_stat), "Ljung_Box_12_p": float(lb.lb_pvalue),
            "Ljung_Box_model_df": 0, "max_VIF": max(vifs(model).values())}


def score(predictions):
    actual, pred = predictions["actual"].to_numpy(), predictions["prediction"].to_numpy()
    if not np.isfinite(actual).all() or not np.isfinite(pred).all() or (actual == 0).any():
        raise ValueError("Accuracy metrics require finite predictions and nonzero actuals")
    error = pred - actual
    return {"n": len(actual), "RMSE": float(np.sqrt(np.mean(error ** 2))),
            "MAE": float(np.mean(abs(error))), "MAPE": float(np.mean(abs(error / actual)) * 100),
            "bias": float(np.mean(error))}


def oot_path(d, model, dynamic):
    """P15: recurse y only in dynamic mode, exactly as in the reported backtest.

    Observed t-12 fee levels and adjusted EC remain in BOTH OOT modes.
    This is not the fully recursive future-forecast method on P16.
    """
    growth = d["y"].copy()
    if dynamic:
        growth.loc[OOT_START:END] = np.nan
    rows = []
    for date in pd.date_range(OOT_START, END, freq="MS"):
        x = {}
        for term in model.params.index:
            if term == "const":
                value = 1.0
            elif term.startswith("y_lag"):
                value = growth.at[date - pd.DateOffset(months=int(term.removeprefix("y_lag")))]
            else:
                value = d.at[date, term]
            if not np.isfinite(value):
                raise ValueError(f"Missing OOT input: {date:%Y-%m} {term}")
            x[term] = float(value)
        yhat = float(sum(model.params[k] * x[k] for k in model.params.index))
        anchor_date = date - pd.DateOffset(months=12)
        anchor = d.at[anchor_date, "Combined"]
        pred = float(anchor * (1 + yhat / 100))
        lr, overlay = float(d.at[date, "fitted_lr"]), float(d.at[date, "overlay"])
        raw_ec = 100 * (pred - lr) / lr
        rows.append({"date": date, "mode": "dynamic_y_only" if dynamic else "static",
                     "actual": d.at[date, "Combined"], "prediction": pred,
                     "y_actual": d.at[date, "y"], "y_prediction": yhat,
                     "anchor_date": anchor_date, "anchor_level": anchor,
                     "fitted_lr": lr, "overlay": overlay,
                     "predicted_EC_scaled": raw_ec, "predicted_EC_scaled_adj": raw_ec - overlay,
                     **{f"{k}_used": v for k, v in x.items() if k != "const"}})
        if dynamic:
            growth.at[date] = yhat
    return pd.DataFrame(rows)


def compare_reference(out, reference_dir):
    """Compare every original CSV column and cell, including rejected trials.

    Tolerance accounts for the original CSV's 12-significant-digit export.
    New explanatory/audit columns do not replace original columns.
    """
    checks = []
    for name in REFERENCE_TABLES:
        expected_path = reference_dir / f"{name}.csv"
        if not expected_path.is_file():
            checks.append({"table": name, "column": "file", "passed": False,
                           "note": "Reference file is missing"})
            continue
        expected, actual = pd.read_csv(expected_path), pd.read_csv(out / f"{name}.csv")
        same_rows = len(expected) == len(actual)
        checks.append({"table": name, "column": "row_count", "passed": same_rows,
                       "reference_rows": len(expected), "computed_rows": len(actual)})
        for column in expected:
            ok, delta = False, np.nan
            if same_rows and column in actual:
                e, a = expected[column], actual[column]
                if pd.api.types.is_numeric_dtype(e) and not pd.api.types.is_bool_dtype(e):
                    av, ev = pd.to_numeric(a).to_numpy(float), e.to_numpy(float)
                    ok = bool(np.allclose(av, ev, rtol=1e-9, atol=1e-9, equal_nan=True))
                    diffs = abs(av - ev)
                    delta = float(np.nanmax(diffs)) if np.isfinite(diffs).any() else 0.0
                else:
                    ok = e.fillna("<NA>").astype(str).equals(a.fillna("<NA>").astype(str))
            checks.append({"table": name, "column": column, "passed": ok, "max_abs_diff": delta})
    result = pd.DataFrame(checks)
    save_csv(out, "reference_comparison", result)
    return result


def numerical_checks(models, d):
    """Independent NumPy least-squares and direct t-test checks, not a model audit."""
    rows = []
    for name, model in models.items():
        x, y = model.model.exog, model.model.endog
        beta = np.linalg.lstsq(x, y, rcond=None)[0]
        resid = y - x @ beta
        dof = len(y) - np.linalg.matrix_rank(x)
        pinv = np.linalg.pinv(x)
        se = np.sqrt(np.diag(pinv @ pinv.T) * (resid @ resid / dof))
        pvals = 2 * stats.t.sf(abs(beta / se), dof)
        for metric, computed, expected in [
            ("OLS_coefficients", beta, model.params.to_numpy()),
            ("OLS_standard_errors", se, model.bse.to_numpy()),
            ("OLS_pvalues", pvals, model.pvalues.to_numpy()),
        ]:
            rows.append({"model": name, "check": metric,
                         "max_abs_diff": float(np.max(abs(computed - expected))),
                         "passed": bool(np.allclose(computed, expected, rtol=1e-8, atol=1e-8))})
    rows.append({"model": "overlay", "check": "IS_overlay_zero",
                 "max_abs_diff": float(abs(d.loc[START:IS_END, "overlay"]).max()),
                 "passed": bool((d.loc[START:IS_END, "overlay"] == 0).all())})
    rows.append({"model": "inputs", "check": "180_month_history",
                 "max_abs_diff": abs(len(d) - 180), "passed": len(d) == 180})
    return pd.DataFrame(rows)


def run(args):
    out = args.output_dir.resolve()
    # Do not silently replace an earlier run or overwrite input/reference data.
    if out.exists() and any(out.iterdir()):
        raise ValueError(f"Output directory is not empty: {out}. Choose a new --output-dir.")
    data = load_data(args.data_dir)
    out.mkdir(parents=True, exist_ok=True)
    tables = {}
    lr_terms, tables["long_run_trials"], tables["long_run_rounds"] = forward_select(
        data.loc[START:IS_END], "Combined", LONG_RUN_POOL, residual_adf_gate=True)
    if not lr_terms:
        raise ValueError("No long-run candidate passed the documented gates")
    lr = fit(data.loc[START:IS_END], "Combined", lr_terms)
    tables["long_run_coefficients"] = coefficients(lr, "long_run")
    tables["long_run_residual_stationarity"] = pd.DataFrame([stationarity(lr.resid)])
    d, trend, trend_model = engineer(data, lr)
    tables["ec_scaled_stationarity"] = pd.DataFrame([
        {"window": "2011-01 to 2023-09", **stationarity(d.loc[START:IS_END, "EC_scaled"])}])
    tables["overlay_trend"] = pd.DataFrame([trend])
    tables["overlay_coefficients"] = coefficients(trend_model, "overlay")
    screen, candidates, tables["macro_stationarity"] = screen_macros(d)
    tables["short_run_screen_all"] = screen
    tables["short_run_screen_passed"] = screen.loc[screen["passed"]]
    tables["P10_displayed_screen"] = screen.set_index("candidate").loc[DECK_SCREEN_ROWS].reset_index()
    tables["partial_correlation_df_sensitivity"] = screen[[
        "candidate", "rho_IS", "n_IS", "df_original_IS", "df_corrected_IS", "p_IS", "p_df_corrected_IS",
        "rho_OOT", "n_OOT", "df_original_OOT", "df_corrected_OOT", "p_OOT", "p_df_corrected_OOT",
        "passed", "passed_df_corrected"]]
    sr_terms, tables["short_run_trials"], tables["short_run_rounds"] = forward_select(
        d.loc[START:IS_END], "y", candidates, base_terms=[EC_TERM])
    sr = fit(d.loc[START:IS_END], "y", sr_terms)
    tables["short_run_coefficients"] = coefficients(sr, "short_run")
    diagnostics = model_diagnostics(sr)
    tables["short_run_diagnostics"] = pd.DataFrame([diagnostics])
    dates = sr.resid.index
    level_fit = d["Combined"].shift(12).loc[dates] * (1 + sr.fittedvalues / 100)
    tables["in_sample_predictions"] = pd.DataFrame({"date": dates,
        "actual": d.loc[dates, "Combined"].to_numpy(), "prediction": level_fit.to_numpy()})
    tables["oot_static"] = oot_path(d, sr, False)
    tables["oot_dynamic"] = oot_path(d, sr, True)
    tables["accuracy"] = pd.DataFrame([
        {"sample": name, **score(tables[table])} for name, table in [
            ("in_sample_fitted", "in_sample_predictions"), ("OOT_static", "oot_static"),
            ("OOT_dynamic_recursive_y_lags", "oot_dynamic")]])
    # Diagnostic data allow downstream reviewers to reproduce every fitted point.
    tables["prepared_monthly_data"] = d.reset_index()
    tables["short_run_estimation_sample"] = d.loc[dates, ["y"] + sr_terms].assign(
        y_fitted=sr.fittedvalues, residual=sr.resid).reset_index()
    tables["long_run_history"] = d[["Combined", "CPI", "fitted_lr", "EC"]].reset_index()
    tables["numerical_checks"] = numerical_checks({"long_run": lr, "overlay": trend_model, "short_run": sr}, d)
    for name, table in tables.items():
        save_csv(out, name, table)
    checks = None if args.skip_reference_check else compare_reference(out, args.reference_dir)
    comparison_ok = None if checks is None else bool(checks["passed"].all())
    num_ok = bool(tables["numerical_checks"]["passed"].all())
    summary = {
        "scope": "Deck v5 P6-P15 statistical tests, selection, diagnostics and fitted backtest",
        "periods": {"IS": "2011-01 to 2023-09", "OOT": "2023-10 to 2025-12"},
        "long_run_terms": lr_terms, "long_run_R2": float(lr.rsquared),
        "long_run_adjusted_R2": float(lr.rsquared_adj),
        "long_run_residual_ADF_p": tables["long_run_residual_stationarity"].iloc[0]["ADF_p"],
        "overlay": trend, "short_run_terms": sr_terms, "diagnostics": diagnostics,
        "screen_pass_count": int(screen["passed"].sum()),
        "P10_displayed_count": len(DECK_SCREEN_ROWS),
        "screen_pass_count_df_corrected": int(screen["passed_df_corrected"].sum()),
        "screen_membership_changes_df_corrected": screen.loc[
            screen["passed"] != screen["passed_df_corrected"], "candidate"].tolist(),
        "accuracy": tables["accuracy"].to_dict("records"),
        "reference_checks": None if checks is None else len(checks),
        "reference_reproduction_passed": comparison_ok, "numerical_checks_passed": num_ok,
    }
    manifest = {
        "python": platform.python_version(),
        "packages": {"numpy": np.__version__, "pandas": pd.__version__,
                     "scipy": scipy.__version__, "statsmodels": statsmodels.__version__},
        "input_sha256": {name: sha256(args.data_dir / name) for name in [CARD_FILE, MACRO_FILE]},
        "script_sha256": sha256(Path(__file__)),
        "actual_history_used": "2011-01 to 2025-12 only; later macro rows are unused",
        "OLS_covariance": "nonrobust", "alpha": ALPHA, "screen_alpha": SCREEN_ALPHA,
        "VIF_limit": VIF_LIMIT, "ADF": "constant, autolag=AIC, maxlag=None",
        "KPSS": "constant, nlags=auto", "partial_correlation_default_df": "n-2 (original convention)",
        "Ljung_Box": "lag=12, model_df=0", "network_access_required": False,
    }
    for name, payload in [("summary", summary), ("run_manifest", manifest)]:
        (out / f"{name}.json").write_text(json.dumps(payload, indent=2, ensure_ascii=False, allow_nan=False) + "\n", encoding="utf-8")
    print(json.dumps(summary, indent=2, ensure_ascii=False, allow_nan=False))
    print(f"Outputs: {out}")
    if not num_ok or comparison_ok is False:
        print("CHECK FAILED: inspect numerical_checks.csv / reference_comparison.csv", file=sys.stderr)
        return 2
    return 0


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--data-dir", type=Path, default=ROOT / "data")
    parser.add_argument("--output-dir", type=Path, default=ROOT / "results")
    parser.add_argument("--reference-dir", type=Path, default=ROOT / "reference")
    parser.add_argument("--skip-reference-check", action="store_true",
                        help="Estimate using raw inputs only without checking original output CSVs")
    args = parser.parse_args()
    try:
        return run(args)
    except (ValueError, FileNotFoundError, KeyError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
