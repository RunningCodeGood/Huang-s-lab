# Commercial Card and Small Business Two-Step Model

Estimate the long-run fee relationship, construct an adjusted error-correction
term, estimate the short-run growth model, calculate IS fitted values and OOT
backtests, and forecast Baseline and S4 fee revenue from raw monthly inputs.
Monthly forecasts are aggregated into quarterly and cumulative fee totals.

## Contents

- `commercial_card_model.py`: the complete model in one commented Python file.
- `data/Cardfee.csv`: original monthly Commercial Card and Small Business fees.
- `data/Macro_Data_201001-202803.csv`: original monthly macroeconomic levels.
- `data/S4_Macro_Path.csv`: raw S4 CPI and corporate profit scenario levels
  for Jan 2026 through Mar 2028.

## Run

Use Python 3.12. Install the numerical dependencies, then run the script from
the extracted `commercial_card_model` directory:

```bash
python -m pip install numpy==2.3.5 pandas==2.2.3 scipy==1.18.1 statsmodels==0.15.0
python commercial_card_model.py
```

Results are created in `results/`. For another run, choose a new output directory:

```bash
python commercial_card_model.py --output-dir results_run2
```

The default input and output directories are relative to the script, so it can
also be run by its full path from a different working directory. Use
`--data-dir` to specify another directory with the same input filenames and
column structure. An existing nonempty output directory is not overwritten.
No other project files, internet connection, Excel or PowerPoint are needed
after the dependencies are installed.

## Data and variables

The historical fee and Baseline macro CSV files are supplied unchanged.
`YYYYMM` is the monthly key.
`Cardfee.csv` covers Jan 2011 through Dec 2025 and contains `Commercial Card`
and `Small Business`. Fee amounts retain the original input units.

```text
Combined_t = Commercial Card_t + Small Business_t
y_t = 100 * (Combined_t / Combined_(t-12) - 1)
```

The macro CSV covers Jan 2011 through Mar 2028, despite its filename. This
script uses Jan 2011 through Dec 2025 for the historical analysis. Jan 2026
through Mar 2028 provides the Baseline forecast scenario. Future macro rows do
not enter estimation or historical backtesting.

`S4_Macro_Path.csv` contains the untransformed CPI-U and Corporate profits after
tax values from the `Macro Path` sheet of the supplied `S4_Downside_Macro_Path.xlsx`.
Only the 27 forecast months and these two scenario variables are included.
The date key and column names use the same format as the Baseline CSV:
`YYYYMM`, `M_FCPIU_B.IUSA` and `M_FZA_B.IUSA`. No interpolation or rescaling is
applied. The workbook is not needed to run this package.

| Model variable | Input column | Short-run transformation |
| --- | --- | --- |
| Unrate | M_FLBR_B.IUSA | 12-month difference, percentage points |
| CPI | M_FCPIU_B.IUSA | YoY percentage change |
| DPI | M_FYPDPIQ_B.IUSA | YoY percentage change |
| SBOpt | M_FSBINQ_B.IUSA | YoY percentage change |
| GDP_Wholesale | M_FGDP42Q_B.IUSA | YoY percentage change |
| IP | M_FIP_B.IUSA | YoY percentage change |
| CorpProfits | M_FZA_B.IUSA | YoY percentage change |
| DJ_TotalMkt | M_FDJMIIUSDD_WCFTDQ_B.IUSA | YoY percentage change |

The inputs are monthly numeric series. No interpolation or missing-value
filling is applied. Each regression uses its own available complete cases.

## Method

1. **Sample periods.** IS is Jan 2011 through Sep 2023. OOT is Oct 2023
   through Dec 2025. The final short-run estimation period starts later
   because growth transformations and lags require prior observations.

2. **Long-run model.** Regress `Combined` on an intercept and selected macro
   levels. The candidate pool is CPI, DPI, GDP_Wholesale, CorpProfits and
   DJ_TotalMkt. Forward selection requires an added-term p-value below 0.05,
   maximum VIF below 10, and ordinary residual ADF p-value below 0.05. The
   eligible candidate with the highest adjusted R-squared is added each round.

3. **Scaled error correction and overlay.** Calculate the long-run residual
   as `EC = Combined - fitted_lr`, then `EC_scaled = 100 * EC / fitted_lr`.
   Estimate `EC_scaled = a + b*t` over the 27 OOT months, with `t = 1,...,27`.
   Set the overlay to zero in IS and to `a + b*t` in OOT. Subtract it before
   taking the 12-month lag: `EC_scaled_adj = EC_scaled - overlay`.
   The end-of-OOT overlay value, `a + 27*b`, is also calculated.

4. **Macro screening.** Evaluate transformed macro families using IS ADF and
   KPSS tests. A family is eligible when ADF p < 0.05 or KPSS p > 0.05.
   For lags 0 through 12, regress both growth and the candidate on an intercept
   and adjusted lagged EC, then correlate the two residual series. Screening
   uses a two-sided t probability with `n - 2` degrees of freedom after this
   residualization. Retain terms with p < 0.20 in both windows and matching
   correlation signs.

5. **Short-run model.** Keep `EC_scaled_adj_lag12` as a fixed regressor.
   Apply forward selection to all screened macro terms and own-growth lags 1
   through 12, requiring added-term p < 0.05 and maximum VIF < 10. Rank eligible
   additions by adjusted R-squared. Coefficients are estimated from IS only.

6. **Model statistics.** Calculate coefficient t statistics, p-values and
   95% confidence intervals, VIF, R-squared, adjusted R-squared, AIC,
   Durbin-Watson, Jarque-Bera and Ljung-Box at lag 12. OLS inference uses
   nonrobust standard errors. Ljung-Box uses `model_df=0`. ADF includes a
   constant with AIC lag selection; KPSS includes a constant with automatic
   bandwidth selection. KPSS boundary probabilities are labeled as bounds.
   Ordinary residual ADF is not an Engle-Granger-calibrated cointegration test.

7. **IS and OOT fee levels.** Reconstruct fees as the observed year-ago fee
   level multiplied by `1 + predicted_y / 100`. Static OOT uses observed
   own-growth lags. Dynamic OOT recursively substitutes predicted own-growth
   lags, but retains observed year-ago fee anchors and observed adjusted EC.
   It is not a fully recursive future fee-level forecast. Both windows
   contribute to macro screening, and OOT also determines the overlay, so
   the OOT results describe a fitted backtest.

8. **Future scenario forecasts.** Start both paths from Dec 2025 actuals and
   recursively forecast Jan 2026 through Mar 2028. Use the IS-estimated
   coefficients without refitting. Baseline uses the future macro CSV rows;
   S4 replaces only future CPI and corporate profit levels. Calculate macro
   growth after joining each scenario to the shared historical macro levels.
   For each month, predict YoY fee growth, convert it into a fee level using
   the year-ago actual or predicted fee level, and update own-growth lags and
   adjusted EC. Hold the overlay at its Dec 2025 value rather than extending
   the fitted trend. No future actual fee observations enter either path.

9. **Quarterly and cumulative totals.** Sum the three monthly fee predictions
   in each calendar quarter, from 2026Q1 through 2028Q1. `2026 total` is the
   sum of 2026Q1 through 2026Q4. `9-quarter total` is the sum of all nine
   quarters, covering Jan 2026 through Mar 2028. These are revenue sums in the
   original fee units, not averages, quarter-end values, or sums of YoY rates.
   Dec 2025 is excluded. All aggregation uses unrounded predictions.

## Generated results

Running the script creates CSV tables for long-run and short-run selection,
coefficients, stationarity, the overlay, macro screening, residual diagnostics,
IS fitted values, OOT static and dynamic predictions, and fee-level accuracy
(MAPE, RMSE, MAE and mean error). It also exports the transformed monthly data,
the short-run estimation sample and long-run history. `summary.json` contains
the main computed model statistics. None of these generated files is needed
as an input.

The forecast outputs are:

- `forecast_monthly.csv`: 27 monthly predictions for each of Baseline and S4,
  together with predicted YoY growth, year-ago fee anchors and recursive inputs.
- `forecast_quarterly_summary.csv`: nine quarterly rows followed by
  `2026 total` and `9-quarter total`. `Baseline` and `S4` are separate columns.
  The `months` column is 3 for each quarter, 12 for 2026 and 27 for the full
  horizon.
- `summary.json`: includes the same quarterly and cumulative forecast summary,
  as well as model statistics. This summary is also printed when the script runs.
