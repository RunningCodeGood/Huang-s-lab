#!/usr/bin/env python3
"""Estimate the Commercial Card and Small Business two-step model.

Run: python commercial_card_model.py
Inputs are read from data/ and computed results are written to results/.
All coefficients, transformations, selections and statistics are calculated
from the raw input data during each run.
"""

from __future__ import annotations

import argparse
import json
import sys
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats
import statsmodels.api as sm
from statsmodels.stats.diagnostic import acorr_ljungbox
from statsmodels.stats.outliers_influence import variance_inflation_factor
from statsmodels.stats.stattools import durbin_watson, jarque_bera
from statsmodels.tools.sm_exceptions import InterpolationWarning
from statsmodels.tsa.stattools import adfuller, kpss


# Monthly estimation periods and selection thresholds.
ROOT = Path(__file__).resolve().parent
START = pd.Timestamp("2011-01-01")
IS_END = pd.Timestamp("2023-09-01")
OOT_START = pd.Timestamp("2023-10-01")
END = pd.Timestamp("2025-12-01")
ALPHA = 0.05
SCREEN_ALPHA = 0.20
VIF_LIMIT = 10.0
EC_TERM = "EC_scaled_adj_lag12"

CARD_FILE = "Cardfee.csv"
MACRO_FILE = "Macro_Data_201001-202803.csv"
MAPPING = {
    "Unrate": "M_FLBR_B.IUSA",
    "CPI": "M_FCPIU_B.IUSA",
    "DPI": "M_FYPDPIQ_B.IUSA",
    "SBOpt": "M_FSBINQ_B.IUSA",
    "GDP_Wholesale": "M_FGDP42Q_B.IUSA",
    "IP": "M_FIP_B.IUSA",
    "CorpProfits": "M_FZA_B.IUSA",
    "DJ_TotalMkt": "M_FDJMIIUSDD_WCFTDQ_B.IUSA",
}
LONG_RUN_POOL = ["CPI", "DPI", "GDP_Wholesale", "CorpProfits", "DJ_TotalMkt"]


def load_data(data_dir: Path) -> pd.DataFrame:
    """Align monthly revenue and macro levels without interpolation or filling."""
    frames = []
    for filename, columns in [
        (CARD_FILE, ["Commercial Card", "Small Business"]),
        (MACRO_FILE, list(MAPPING.values())),
    ]:
        frame = pd.read_csv(data_dir / filename, encoding="utf-8-sig")
        frame["date"] = pd.to_datetime(frame.pop("YYYYMM").astype(str), format="%Y%m")
        frame = frame.set_index("date").sort_index()[columns]
        frames.append(frame.apply(pd.to_numeric, errors="raise"))

    card, macro = frames
    card["Combined"] = card["Commercial Card"] + card["Small Business"]
    macro = macro.rename(columns={value: key for key, value in MAPPING.items()})
    # Later macro rows remain in the raw file but do not enter this analysis.
    dates = pd.date_range(START, END, freq="MS")
    data = macro.reindex(dates).join(card, how="left")
    data.index.name = "date"
    return data


def stationarity(series: pd.Series) -> dict:
    """Run constant-only ADF and KPSS tests on the available observations."""
    values = series.dropna()
    adf = adfuller(values, regression="c", autolag="AIC", maxlag=None,
                  result_object=False)
    # KPSS uses tabulated probabilities; retain the bound in the output.
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", InterpolationWarning)
        kp = kpss(values, regression="c", nlags="auto", result_object=False)
    return {
        "n": len(values),
        "ADF_stat": float(adf[0]), "ADF_p": float(adf[1]),
        "ADF_lags": int(adf[2]), "ADF_effective_n": int(adf[3]),
        "ADF_critical_5pct": float(adf[4]["5%"]),
        "KPSS_stat": float(kp[0]), "KPSS_p": float(kp[1]),
        "KPSS_lags": int(kp[2]), "KPSS_critical_5pct": float(kp[3]["5%"]),
        "KPSS_p_bound": (
            ">=0.10" if kp[1] == 0.1 else "<=0.01" if kp[1] == 0.01
            else "interpolated"
        ),
        # A macro family is eligible if either test supports stationarity.
        "stationary": bool(adf[1] < ALPHA or kp[1] > ALPHA),
    }


def fit(frame: pd.DataFrame, target: str, terms: list[str]):
    """Estimate OLS with an intercept on candidate-specific complete cases."""
    sample = frame[[target] + terms].dropna()
    regressors = sm.add_constant(sample[terms], has_constant="add")
    return sm.OLS(sample[target], regressors).fit()


def vifs(model) -> dict:
    """Calculate regressor VIFs with the intercept included in the design."""
    return {
        name: float(variance_inflation_factor(model.model.exog, column))
        for column, name in enumerate(model.params.index) if name != "const"
    }


def coefficients(model, name: str) -> pd.DataFrame:
    """Return coefficients, nonrobust OLS inference and collinearity measures."""
    vif = vifs(model)
    intervals = model.conf_int(alpha=ALPHA)
    return pd.DataFrame([{
        "model": name, "term": term, "coefficient": float(model.params[term]),
        "SE": float(model.bse[term]), "t": float(model.tvalues[term]),
        "p": float(model.pvalues[term]), "VIF": vif.get(term, np.nan),
        "CI_lower_95": float(intervals.loc[term, 0]),
        "CI_upper_95": float(intervals.loc[term, 1]),
        "df_resid": float(model.df_resid), "covariance": "nonrobust OLS",
    } for term in model.params.index])


def forward_select(frame, target, candidates, base_terms=None, residual_adf_gate=False):
    """Add the eligible term giving the highest adjusted R-squared each round.

    New terms require p < 0.05 and maximum VIF < 10. Long-run selection also
    requires ordinary residual ADF p < 0.05. Base terms are retained throughout.
    """
    selected = list(base_terms or [])
    pending = list(candidates)
    trials, rounds = [], []
    for round_number in range(1, len(candidates) + 1):
        current = []
        for candidate in pending:
            model = fit(frame, target, selected + [candidate])
            max_vif = max(vifs(model).values())
            residual_p = (
                float(adfuller(model.resid, regression="c", autolag="AIC",
                               result_object=False)[1])
                if residual_adf_gate else np.nan
            )
            eligible = model.pvalues[candidate] < ALPHA and max_vif < VIF_LIMIT
            if residual_adf_gate:
                eligible = eligible and residual_p < ALPHA
            current.append({
                "round": round_number, "candidate": candidate,
                "selected_before": " + ".join(selected),
                "coefficient": float(model.params[candidate]),
                "p_added": float(model.pvalues[candidate]),
                "max_VIF": float(max_vif), "residual_ADF_p": residual_p,
                "eligible": bool(eligible), "R2": float(model.rsquared),
                "adj_R2": float(model.rsquared_adj), "n": int(model.nobs),
            })

        eligible = [row for row in current if row["eligible"]]
        # Resolve exact adjusted R-squared ties by candidate name.
        winner = min(eligible, key=lambda row: (-row["adj_R2"], row["candidate"])) if eligible else None
        for row in current:
            row["chosen"] = bool(winner and row["candidate"] == winner["candidate"])
        trials.extend(current)
        rounds.append({
            "round": round_number, "added": winner["candidate"] if winner else "none",
            "adj_R2_after": winner["adj_R2"] if winner else np.nan,
            "p_added": winner["p_added"] if winner else np.nan,
            "n": winner["n"] if winner else np.nan,
        })
        if winner is None:
            break
        selected.append(winner["candidate"])
        pending.remove(winner["candidate"])
    return selected, pd.DataFrame(trials), pd.DataFrame(rounds)


def engineer(data, long_run):
    """Construct scaled EC, the OOT trend overlay, growth rates and lags."""
    frame = data.copy()
    terms = [term for term in long_run.params.index if term != "const"]
    frame["fitted_lr"] = long_run.predict(sm.add_constant(frame[terms], has_constant="add"))
    frame["EC"] = frame["Combined"] - frame["fitted_lr"]
    frame["EC_scaled"] = 100 * frame["EC"] / frame["fitted_lr"]

    # Fit the overlay to OOT scaled EC using t = 1, ..., 27.
    oot = frame.loc[OOT_START:END]
    time = pd.Series(np.arange(1, len(oot) + 1), index=oot.index, name="t")
    trend_model = sm.OLS(oot["EC_scaled"], sm.add_constant(time)).fit()
    intercept = float(trend_model.params["const"])
    slope = float(trend_model.params["t"])
    frame["overlay"] = 0.0
    frame.loc[oot.index, "overlay"] = intercept + slope * time
    frame["EC_scaled_adj"] = frame["EC_scaled"] - frame["overlay"]
    # Subtract the contemporaneous overlay before applying the 12-month lag.
    frame[EC_TERM] = frame["EC_scaled_adj"].shift(12)

    # Growth is expressed in percentage units, so 10 denotes 10 percent.
    features = {"y": frame["Combined"].pct_change(12, fill_method=None) * 100}
    for lag in range(1, 13):
        features[f"y_lag{lag}"] = features["y"].shift(lag)
    for family in MAPPING:
        # Unemployment uses a 12-month percentage-point difference.
        change = (frame[family].diff(12) if family == "Unrate"
                  else frame[family].pct_change(12, fill_method=None) * 100)
        features[f"{family}_change"] = change
        for lag in range(13):
            features[f"{family}_lag{lag}"] = change.shift(lag)
    frame = pd.concat([frame, pd.DataFrame(features, index=frame.index)], axis=1)
    trend = {
        "a": intercept, "b": slope, "b_p": float(trend_model.pvalues["t"]),
        "R2": float(trend_model.rsquared), "n": int(trend_model.nobs),
        "held_value": intercept + slope * len(oot),
    }
    return frame, trend, trend_model


def partial_correlation(frame, candidate):
    """Correlate residuals after controlling for an intercept and lagged EC."""
    sample = frame[["y", EC_TERM, candidate]].dropna()
    controls = sm.add_constant(sample[[EC_TERM]], has_constant="add")
    y_residual = sm.OLS(sample["y"], controls).fit().resid
    x_residual = sm.OLS(sample[candidate], controls).fit().resid
    rho = float(stats.pearsonr(y_residual, x_residual).statistic)
    # The screening rule uses n - 2 degrees of freedom after residualization.
    degrees = len(sample) - 2
    statistic = rho * np.sqrt(degrees / max(1 - rho * rho, np.finfo(float).eps))
    probability = float(2 * stats.t.sf(abs(statistic), degrees))
    return {"rho": rho, "n": len(sample), "p": probability, "df": degrees}


def screen_macros(frame):
    """Screen macro lags for stationarity, significance and matching IS/OOT signs."""
    stationarity_table = pd.DataFrame([
        {"family": family, **stationarity(frame.loc[START:IS_END, f"{family}_change"])}
        for family in MAPPING
    ])
    eligible_families = set(stationarity_table.loc[stationarity_table["stationary"], "family"])
    rows = []
    for family in MAPPING:
        for lag in range(13):
            term = f"{family}_lag{lag}"
            in_sample = partial_correlation(frame.loc[START:IS_END], term)
            oot = partial_correlation(frame.loc[OOT_START:END], term)
            same_sign = bool(np.sign(in_sample["rho"]) == np.sign(oot["rho"]))
            row = {"candidate": term, "family": family, "lag": lag}
            for suffix, result in [("IS", in_sample), ("OOT", oot)]:
                row.update({f"{key}_{suffix}": value for key, value in result.items()})
            row.update(
                same_sign=same_sign, stationarity_pass_IS=family in eligible_families,
                passed=bool(family in eligible_families and same_sign
                            and in_sample["p"] < SCREEN_ALPHA and oot["p"] < SCREEN_ALPHA),
            )
            rows.append(row)
    screen = pd.DataFrame(rows)
    candidates = screen.loc[screen["passed"], "candidate"].tolist()
    candidates += [f"y_lag{lag}" for lag in range(1, 13)]
    return screen, candidates, stationarity_table


def model_diagnostics(model):
    """Calculate residual diagnostics and descriptive goodness-of-fit measures."""
    jb, jb_p, _, _ = jarque_bera(model.resid)
    lb = acorr_ljungbox(model.resid, lags=[12], model_df=0, return_df=True).iloc[0]
    return {
        "n": int(model.nobs), "R2": float(model.rsquared),
        "adj_R2": float(model.rsquared_adj), "AIC": float(model.aic),
        "Durbin_Watson": float(durbin_watson(model.resid)),
        "Jarque_Bera": float(jb), "Jarque_Bera_p": float(jb_p),
        "Ljung_Box_12": float(lb.lb_stat), "Ljung_Box_12_p": float(lb.lb_pvalue),
        "Ljung_Box_model_df": 0, "max_VIF": max(vifs(model).values()),
    }


def score(predictions):
    """Summarize fee-level errors; MAPE is expressed as a percentage."""
    actual = predictions["actual"].to_numpy()
    predicted = predictions["prediction"].to_numpy()
    error = predicted - actual
    return {
        "n": len(actual), "RMSE": float(np.sqrt(np.mean(error ** 2))),
        "MAE": float(np.mean(abs(error))),
        "MAPE": float(np.mean(abs(error / actual)) * 100),
        "bias": float(np.mean(error)),
    }


def oot_path(frame, model, dynamic):
    """Construct static or growth-lag-recursive OOT fee-level predictions.

    Both modes use observed year-ago fee levels and observed adjusted EC.
    Dynamic mode substitutes predicted growth into subsequent own-growth lags.
    """
    growth = frame["y"].copy()
    if dynamic:
        growth.loc[OOT_START:END] = np.nan
    rows = []
    for date in pd.date_range(OOT_START, END, freq="MS"):
        inputs = {}
        for term in model.params.index:
            if term == "const":
                value = 1.0
            elif term.startswith("y_lag"):
                lag = int(term.removeprefix("y_lag"))
                value = growth.at[date - pd.DateOffset(months=lag)]
            else:
                value = frame.at[date, term]
            inputs[term] = float(value)
        predicted_growth = float(sum(model.params[term] * inputs[term] for term in model.params.index))
        anchor_date = date - pd.DateOffset(months=12)
        anchor = frame.at[anchor_date, "Combined"]
        prediction = float(anchor * (1 + predicted_growth / 100))
        long_run = float(frame.at[date, "fitted_lr"])
        overlay = float(frame.at[date, "overlay"])
        predicted_ec = 100 * (prediction - long_run) / long_run
        rows.append({
            "date": date, "mode": "dynamic_y_only" if dynamic else "static",
            "actual": frame.at[date, "Combined"], "prediction": prediction,
            "y_actual": frame.at[date, "y"], "y_prediction": predicted_growth,
            "anchor_date": anchor_date, "anchor_level": anchor,
            "fitted_lr": long_run, "overlay": overlay,
            "predicted_EC_scaled": predicted_ec,
            "predicted_EC_scaled_adj": predicted_ec - overlay,
            **{f"{term}_used": value for term, value in inputs.items() if term != "const"},
        })
        if dynamic:
            growth.at[date] = predicted_growth
    return pd.DataFrame(rows)


def run(data_dir: Path, output_dir: Path):
    """Estimate both stages and save the resulting model analysis."""
    output_dir = output_dir.resolve()
    # Protect source files and previous results from accidental replacement.
    if output_dir.exists() and any(output_dir.iterdir()):
        raise ValueError(f"Output directory is not empty: {output_dir}. Use a new --output-dir.")
    data = load_data(data_dir)
    tables = {}

    # Step 1: estimate the long-run relationship using IS observations only.
    lr_terms, tables["long_run_trials"], tables["long_run_rounds"] = forward_select(
        data.loc[START:IS_END], "Combined", LONG_RUN_POOL, residual_adf_gate=True)
    if not lr_terms:
        raise ValueError("No long-run candidate meets the selection criteria.")
    long_run = fit(data.loc[START:IS_END], "Combined", lr_terms)
    tables["long_run_coefficients"] = coefficients(long_run, "long_run")
    tables["long_run_residual_stationarity"] = pd.DataFrame([stationarity(long_run.resid)])
    frame, trend, trend_model = engineer(data, long_run)
    tables["ec_scaled_stationarity"] = pd.DataFrame([
        {"window": "2011-01 to 2023-09", **stationarity(frame.loc[START:IS_END, "EC_scaled"])}])
    tables["overlay_trend"] = pd.DataFrame([trend])
    tables["overlay_coefficients"] = coefficients(trend_model, "overlay")

    # Step 2: screen macro terms, then select the short-run growth regressors.
    screen, candidates, tables["macro_stationarity"] = screen_macros(frame)
    tables["short_run_screen_all"] = screen
    tables["short_run_screen_passed"] = screen.loc[screen["passed"]]
    sr_terms, tables["short_run_trials"], tables["short_run_rounds"] = forward_select(
        frame.loc[START:IS_END], "y", candidates, base_terms=[EC_TERM])
    short_run = fit(frame.loc[START:IS_END], "y", sr_terms)
    tables["short_run_coefficients"] = coefficients(short_run, "short_run")
    diagnostics = model_diagnostics(short_run)
    tables["short_run_diagnostics"] = pd.DataFrame([diagnostics])

    # Reconstruct IS fee levels from predicted YoY growth and observed anchors.
    dates = short_run.resid.index
    level_fit = frame["Combined"].shift(12).loc[dates] * (1 + short_run.fittedvalues / 100)
    tables["in_sample_predictions"] = pd.DataFrame({
        "date": dates, "actual": frame.loc[dates, "Combined"].to_numpy(),
        "prediction": level_fit.to_numpy(),
    })
    tables["oot_static"] = oot_path(frame, short_run, dynamic=False)
    tables["oot_dynamic"] = oot_path(frame, short_run, dynamic=True)
    tables["accuracy"] = pd.DataFrame([
        {"sample": name, **score(tables[table])} for name, table in [
            ("in_sample_fitted", "in_sample_predictions"),
            ("OOT_static", "oot_static"),
            ("OOT_dynamic_recursive_y_lags", "oot_dynamic"),
        ]
    ])
    tables["prepared_monthly_data"] = frame.reset_index()
    tables["short_run_estimation_sample"] = frame.loc[dates, ["y"] + sr_terms].assign(
        y_fitted=short_run.fittedvalues, residual=short_run.resid).reset_index()
    tables["long_run_history"] = frame[["Combined"] + lr_terms + ["fitted_lr", "EC"]].reset_index()

    output_dir.mkdir(parents=True, exist_ok=True)
    for name, table in tables.items():
        table.to_csv(output_dir / f"{name}.csv", index=False, encoding="utf-8",
                     float_format="%.15g", date_format="%Y-%m-%d")
    summary = {
        "periods": {"IS": "2011-01 to 2023-09", "OOT": "2023-10 to 2025-12"},
        "long_run_terms": lr_terms, "long_run_R2": float(long_run.rsquared),
        "long_run_adjusted_R2": float(long_run.rsquared_adj),
        "long_run_residual_ADF_p": float(tables["long_run_residual_stationarity"].iloc[0]["ADF_p"]),
        "overlay": trend, "short_run_terms": sr_terms,
        "screen_pass_count": int(screen["passed"].sum()),
        "diagnostics": diagnostics, "accuracy": tables["accuracy"].to_dict("records"),
    }
    summary_text = json.dumps(summary, indent=2, ensure_ascii=True, allow_nan=False)
    (output_dir / "summary.json").write_text(summary_text + "\n", encoding="utf-8")
    print(summary_text)
    print(f"Results saved to: {output_dir}")


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--data-dir", type=Path, default=ROOT / "data",
                        help="Directory containing the two raw input CSV files.")
    parser.add_argument("--output-dir", type=Path, default=ROOT / "results",
                        help="New or empty directory for computed results.")
    args = parser.parse_args()
    try:
        run(args.data_dir, args.output_dir)
    except (ValueError, OSError, KeyError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
