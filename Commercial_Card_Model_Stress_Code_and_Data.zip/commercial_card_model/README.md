# Commercial Card and Small Business Model

This standalone script estimates a long-run fee relationship, constructs a scaled error-correction term and trend overlay, fits a short-run growth model, and produces historical fitted results, Baseline/S4 forecasts and one-at-a-time macro stress sensitivities. All coefficients, screening statistics, overlays, shock standard deviations and predictions are calculated from the input data during each run. The four input files are unchanged from the standardized code package.

## Run

Use Python 3.12:

```bash
python -m pip install numpy==2.3.5 pandas==2.2.3 scipy==1.18.1 statsmodels==0.15.0
python commercial_card_model.py
```

Paths are relative to the script. Use `--data-dir` for another folder with the same input schema and `--output-dir` for a new or empty results directory. The default output is `results/`. A nonempty output directory is not overwritten. No Excel, network connection or other project files are needed after the numerical dependencies are installed.

The default run includes four CPI-level shocks and four corporate-profit YoY-growth shocks, with sigma multiples `-2 -1 1 2`. To choose different multiples without editing any input file:

```bash
python commercial_card_model.py --stress-sigma-multipliers -1.5 -0.5 0.5 1.5 --output-dir results_custom
```

Multipliers must be finite, unique and nonzero. Each multiplier is applied independently to each driver; it does not create a combined shock. The existing Baseline and S4 forecasts are always retained.

## Input files

| File | Period | Purpose |
| --- | --- | --- |
| `data/fee_history.csv` | Jan 2011 to Dec 2025 | Original Commercial Card and Small Business fees |
| `data/macro_history.csv` | Jan 2011 to Dec 2025 | Historical levels of all eight candidate macro series |
| `data/macro_baseline.csv` | Jan 2026 to Mar 2028 | Baseline macro scenario levels |
| `data/macro_s4.csv` | Jan 2026 to Mar 2028 | S4 CPI and corporate-profits scenario levels |

The monthly date key is `date`, formatted as `YYYY-MM-DD` using the first day of the month. History and future scenarios are separate files. Macro CSV column names retain the original Moody's codes. `MACRO_COLUMNS` in Python maps them to descriptive business names.

Revenue source fields `Commercial Card` and `Small Business` map to `commercial_card_fee` and `small_business_card_fee`. Their sum is `commercial_small_business_fee`. QualPay and Sponsorships are not included. Fees retain their original source units without currency-scale conversion.

| Moody's CSV header | Internal variable | Level units |
| --- | --- | --- |
| `M_FLBR_B.IUSA` | `unemployment_rate` | Percent |
| `M_FCPIU_B.IUSA` | `consumer_price_index` | Index |
| `M_FYPDPIQ_B.IUSA` | `disposable_personal_income` | Original source units |
| `M_FSBINQ_B.IUSA` | `small_business_optimism` | Index |
| `M_FGDP42Q_B.IUSA` | `wholesale_trade_gdp` | Original source units |
| `M_FIP_B.IUSA` | `industrial_production` | Index |
| `M_FZA_B.IUSA` | `corporate_profits` | Original source units |
| `M_FDJMIIUSDD_WCFTDQ_B.IUSA` | `dow_jones_total_market_index` | Index |

Historical and Baseline macro values come from the supplied macro CSV; its actual coverage starts in January 2011. S4 CPI and corporate profits come from the `Macro Path` sheet of the supplied `S4_Downside_Macro_Path.xlsx`. Raw numeric values are retained without interpolation, rescaling or missing-value filling. Monthly rows describe the supplied observation frequency, not necessarily each series' native publication frequency.

The supplied Baseline file has blank disposable-income, wholesale-GDP, industrial-production and market-index values for January 2027 through March 2028. S4 contains only CPI and corporate profits. Current selected drivers have the required paths. Different selected variables would require the corresponding future inputs and a review of the scenario-driver setup. Macroeconomic scenarios are external inputs, not estimated by this fee model.

## Variable naming

| Variable | Meaning |
| --- | --- |
| `commercial_small_business_fee_pct_change_12m` | `100 * (fee_t / fee_t_minus_12m - 1)` |
| `commercial_small_business_fee_pct_change_12m_lag_1m` | Annual fee growth lagged one month |
| `corporate_profits_pct_change_12m_lag_2m` | Annual corporate-profit growth lagged two months |
| `unemployment_rate_diff_12m_pp_lag_0m` | Contemporaneous annual unemployment change, in percentage points |
| `long_run_fitted_fee` | Macro-implied long-run fee level |
| `ec_residual` | Actual fee less the fitted long-run level |
| `ec_scaled_pct` | `100 * ec_residual / long_run_fitted_fee` |
| `ec_trend_overlay_pct` | Estimated trend adjustment on the scaled EC scale |
| `ec_scaled_adjusted_pct` | Scaled EC less the contemporaneous overlay |
| `ec_scaled_adjusted_pct_lag_12m` | Adjusted EC lagged 12 months |

`pct_change_12m` means annual percentage growth, while `lag_2m` means a two-month lag of that growth rate. These horizons are independent. `pp` denotes percentage points. The suffix `_input` identifies a value used by a particular prediction. Source CSV files contain levels; transformations and lags are generated in Python.

## Estimation method

1. In-sample estimation covers January 2011 through September 2023; OOT covers October 2023 through December 2025.
2. Long-run forward selection considers CPI, disposable income, wholesale GDP, corporate profits and the total-market index in levels. Added-term Student-t p < 0.05, maximum VIF < 10 and ordinary residual ADF p < 0.05 are required. Candidates are ranked by adjusted R-squared and fixed tie order.
3. Scale the long-run residual by the fitted long-run fee. Estimate a trend on the 27 realized OOT scaled residuals using `month_index` from 1 to 27. The overlay is zero in-sample, follows the fitted trend in OOT, and is held at its December 2025 value for future forecasts. Subtract the overlay before constructing the 12-month adjusted-EC lag.
4. Screen transformed macro families using in-sample ADF and KPSS. A family passes if ADF p < 0.05 or KPSS p > 0.05. Evaluate monthly lags 0-12 using partial correlations controlling for the intercept and lagged adjusted EC. Require p < 0.20 in both IS and OOT with matching signs. The implemented correlation probability uses a Student-t reference with n minus 2 degrees of freedom after residualization.
5. Keep adjusted EC at lag 12 in the short-run model. Forward selection considers all passing macro terms and target lags 1-12, using added-term Student-t p < 0.05 and maximum VIF < 10. Rank additions by adjusted R-squared and fixed tie order. Coefficients use in-sample observations only.

OLS inference is classical and nonrobust. ADF includes an intercept and AIC lag selection. KPSS includes an intercept and automatic bandwidth selection, with boundary probabilities labeled as bounds. Ordinary residual ADF is not an Engle-Granger-calibrated cointegration test. Both windows inform screening and OOT also estimates the overlay, so OOT errors describe a fitted backtest rather than untouched validation.

## Predictions and scenarios

Static historical predictions use observed own-growth lags and observed year-ago fee levels. Dynamic OOT recursively updates own-growth lags but retains observed year-ago fee anchors and observed adjusted EC. The output mode `dynamic_y_only` denotes that limited recursion.

Future Baseline and S4 forecasts run from January 2026 through March 2028, starting from December 2025 actuals. Both use fixed in-sample coefficients without a production refit. The future forecast recursively updates fee levels, target lags and adjusted EC. The overlay remains fixed at its final estimated value. S4 replaces only future CPI and corporate-profit levels; historical inputs are shared. Growth rates are calculated after joining each future scenario to that history.

Monthly predictions are converted to levels using the actual or previously predicted year-ago fee. Each quarterly forecast sums its three monthly revenue levels. `2026 total` sums the four 2026 quarters; `9-quarter total` sums all nine quarters from 2026Q1 through 2028Q1. All aggregation uses unrounded predictions.

## One-at-a-time stress sensitivities

These are deterministic input-path sensitivities around Baseline, not additional S4 paths, statistical confidence bands or forecast probability intervals. Positive and negative shocks are both reported without presuming that every negative macro shock must lower fees in every month.

### Calibration and scope

- Calculate each driver's historical YoY percentage growth as `100 * (level_t / level_(t-12) - 1)` within the original IS history, January 2011 through September 2023.
- Estimate its sample standard deviation with `ddof=1`, dropping only unavailable growth observations. With the supplied input coverage, the usable calibration period is January 2012 through September 2023 (141 monthly observations). Neither OOT observations nor future scenario values enter sigma.
- Apply `k = -2, -1, +1, +2` by default to all 27 forecast months, January 2026 through March 2028. No ramp, early expiry or post-horizon projection is assumed.
- Estimate and select the model once from the original inputs per run. All sensitivity forecasts reuse the same long-run and short-run model objects, coefficients, historical fee starting conditions and fixed estimated overlay. There is no scenario-specific refit or variable screening.
- Each path changes only one driver's future levels in memory. The other macro paths remain at Baseline. History, S4 and all source CSV files are untouched. No combined CPI/profits scenario is added.

### CPI level shock

Use the standard deviation of historical CPI YoY percentage growth as a calibration scale for a **relative CPI level adjustment**, not as the standard deviation of CPI levels:

```text
sigma_CPI = sample_std(IS CPI YoY percentage growth, ddof=1)
shock_pct = k * sigma_CPI
CPI_stress_t = CPI_baseline_t * (1 + shock_pct / 100)
```

For example, if the estimated sigma were 2, a `+1 sigma` scenario would raise each future CPI level by 2 percent. This is a level-path shift; it does not impose a persistent 2-percentage-point inflation increase. The percentage gap in CPI levels persists across all forecast months. Recompute the long-run fitted fee and each recursive adjusted EC from the shocked CPI path.

### Corporate Profits YoY growth shock

Add the calibrated shock in **percentage points** to each future Baseline YoY growth rate, then reconstruct profit levels using historical or already stressed year-ago levels:

```text
sigma_profits = sample_std(IS Corporate Profits YoY percentage growth, ddof=1)
shock_pp = k * sigma_profits
profits_baseline_yoy_t = 100 * (profits_baseline_t / profits_baseline_(t-12) - 1)
profits_stress_yoy_t = profits_baseline_yoy_t + shock_pp
profits_stress_t = profits_stress_(t-12) * (1 + profits_stress_yoy_t / 100)
```

Baseline YoY growth is calculated after joining Baseline levels to unchanged history. In 2026, the stressed reconstruction uses actual 2025 anchors; from 2027 onward, it uses the corresponding previously stressed future anchors. This preserves the specified YoY growth gap throughout all 27 months rather than mechanically losing it after one year. A shock that implies missing or nonpositive levels is rejected, not clipped.

### Recursive propagation and comparison

Pass each reconstructed level path through the existing forecast function. Recompute macro transformations and lags; recursively update predicted fee levels, own growth lags and adjusted EC. Do not edit a final regression input directly and do not use future actual fees.

Under the model selected by the supplied inputs, CPI enters only through the long-run relationship and adjusted EC lagged 12 months. Thus a January 2026 CPI shock first changes fee forecasts in January 2027, although its long-run fitted fee and contemporaneous EC change immediately. Corporate Profits YoY enters at lag 2, so a January 2026 profit-growth shock first changes fee forecasts in March 2026. These timings are consequences of the selected model, not hardcoded output delays.

Monthly and aggregated impacts use the unchanged Baseline as the reference:

```text
fee_impact = stressed_fee - baseline_fee
fee_impact_pct = 100 * fee_impact / baseline_fee
```

For quarterly or cumulative impacts, first sum the unrounded fee levels for that period and then calculate the difference and percentage. Do not average monthly impact percentages. Outputs include each quarter, the 2026 total, the nine-quarter total, the largest absolute monthly impact and its date, the largest absolute percentage impact and its date, and the March 2028 terminal impact. Amounts retain source fee units; no currency rescaling is applied.

## Generated results

| File | Content |
| --- | --- |
| `long_run_trials.csv`, `long_run_rounds.csv`, `long_run_coefficients.csv` | Long-run selection and estimation |
| `long_run_residual_stationarity.csv`, `ec_scaled_stationarity.csv` | Stationarity statistics |
| `overlay_trend.csv`, `overlay_coefficients.csv` | Estimated overlay parameters and inference |
| `macro_stationarity.csv`, `short_run_screen_all.csv`, `short_run_screen_passed.csv` | Macro screening |
| `short_run_trials.csv`, `short_run_rounds.csv`, `short_run_coefficients.csv` | Short-run selection and estimation |
| `short_run_diagnostics.csv` | R-squared, AIC, DW, JB, Ljung-Box and VIF |
| `static_in_sample.csv`, `static_oot.csv`, `dynamic_oot.csv` | Historical fee-level predictions |
| `forecast_accuracy.csv` | Historical MAPE, RMSE, MAE and mean error |
| `historical_data_and_features.csv`, `short_run_estimation_sample.csv`, `long_run_history.csv` | Model data and calculated features |
| `forecast_monthly.csv` | Baseline and S4 monthly fee forecasts and inputs |
| `forecast_quarterly_summary.csv` | Quarterly and cumulative scenario totals |
| `stress_calibration.csv` | Historical sigma estimates, effective sample, count, units and ddof |
| `stress_scenarios.csv` | One-variable shock definitions, magnitudes, dates and fixed-model assumptions |
| `stress_macro_paths.csv` | Baseline and stressed CPI/profit levels and recalculated YoY growth for each future month |
| `stress_forecast_monthly.csv` | Each sensitivity's recursive monthly fee forecast, model inputs and Baseline impacts |
| `stress_forecast_quarterly_summary.csv` | Nine quarters, 2026 total and nine-quarter total for each sensitivity, with Baseline impacts |
| `stress_summary.csv` | Annual/cumulative totals, maximum monthly impacts and terminal impacts by sensitivity |
| `summary.json` | Model statistics, existing quarterly forecast summary and stress-test configuration |

Monthly outputs use `date`, `scenario`, `predicted_fee` and `predicted_pct_change_12m`. Quarterly summaries use `period`, `months`, `baseline_total` and `s4_total`, with quarter labels such as `2026Q1`. Coefficient tables use `standard_error`, `t_stat` and `p_student_t`. Overlay parameters are `intercept_pct`, `slope_pct_per_month`, `slope_p_student_t` and `held_value_pct`. CSV exports retain 15 significant digits, matching the existing numerical export convention. No pre-generated results are included in this package.

Stress outputs use a long format with one `scenario` per row. `shock_size` is a percent-of-Baseline-level adjustment for CPI and a YoY percentage-point adjustment for profits; `shock_unit` distinguishes them. In the stress quarterly output, `forecast_total` is the shocked total and `baseline_total` is its matching unshocked total. A negative `fee_impact` denotes lower fee revenue. Scenario names such as `CPI_level_minus_1sigma` and `Corporate_Profits_YoY_plus_2sigma` identify the driver and magnitude explicitly. The existing result file schemas remain unchanged; stress results are written to separate files.
