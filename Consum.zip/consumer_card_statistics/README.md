# Consumer Card 统计检验与模型验证

本包对应 `Consumer_Card_Model_Baseline_S4_Connected_Forecast_Final.pptx`。
所有计算集中在 `consumer_card_statistics.py`。数据为独立 CSV，运行时不需要 Excel、网络、原电脑目录或其他项目代码。

## 运行

建议 Python 3.12。在解压后的文件夹打开终端：

```bash
python -m pip install -r requirements.txt
python consumer_card_statistics.py --self-test
python consumer_card_statistics.py --verify-deck
```

结果写入新建的 `results/`。包内的 `example_results/` 是随包执行结果，供直接查看。
再次运行请指定一个新的空目录，例如：

```bash
python consumer_card_statistics.py --verify-deck --output-dir results_second_run
```

脚本拒绝覆盖非空目录。可通过 `--data-dir` 使用同结构的数据；修改数据后，不应期待 `--verify-deck` 仍匹配原 deck。

## 检验范围与页码

| Deck 页码 | 内容 | 输出 |
|---|---|---|
| P3、P5、P7 | 10个宏观候选变量的逐轮筛选，显著性、VIF、DW、JB门槛 | `macro_screening.csv` |
| P6、P7、P10 | OLS系数、标准误、显著性、R²、调整R²、DW、JB、VIF | `coefficients.csv`, `model_diagnostics.csv` |
| P2、P6、P8 | Static In-sample、Static OOT、Recursive OOT 的 MAPE；同时输出RMSE | `validation_metrics.csv` |
| P8 | 样本内拟合和OOT预测逐月值 | `static_in_sample.csv`, `static_oot.csv`, `recursive_oot.csv` |
| P9 | 60个月窗口的系数与标准化系数、正负号稳定性 | `rolling_coefficients.csv`, `rolling_summary.csv` |
| P10 | 截至2025年12月的 Production refit | `coefficients.csv`, `model_diagnostics.csv` |
| P11–P13 | Baseline/S4递归路径及年度、27个月汇总 | `scenario_forecasts.csv`, `scenario_summary.csv` |
| P3–P7 | 可检查的原始值及全部候选特征 | `historical_data_and_features.csv` |

MAPE、RMSE、R²、VIF和滚动系数不是同一种意义上的假设检验，包内按各自用途分别标明。
当前 deck 未列出 ADF、KPSS、CUSUM 或 Chow，本包不将这些额外项目混入当前检验范围。

## 统计口径

1. `y = 100 × [log(fee_t) − log(fee_{t−1})]`。
2. 基础项为 `y_lag1`、`y_lag2`、January、December和截距。
3. Unemployment 使用月度百分点差；其他宏观变量使用月度百分比变化。MA3包含当月与前两个月。
4. 只在 In-sample 选择宏观项。门槛为候选项 p < 0.05、最大 VIF < 10、1.5 ≤ DW ≤ 2.5、JB p > 0.05。同一宏观家族最多选一个变换。符合门槛者按最小 p、最大调整R²、变量名排序。
5. **为保持当前 deck 的计算口径，筛选使用双侧正态近似 p 值**，列名为 `p_normal_deck`。系数统计量是 coefficient/standard error。`p_student_t` 另外提供传统 Student-t 双侧 p 值，残差自由度为 n−k；它不改变本次筛选。标准误为普通非稳健 OLS 标准误，不是HAC。
6. JB使用残差偏度和峰度以及渐近 χ²(2)尾概率。DW仅给出统计量及配置区间，不输出未经定义的DW p值。存在滞后因变量时，DW区间不能单独证明不存在自相关。
7. VIF的辅助回归包含截距，最大VIF不包含截距。
8. 先选择再检验的p值不包含变量选择的不确定性；这些诊断不能单独等同于模型整体有效。

## 时间划分与无未来实际值更新

- In-sample：2011年1月至2023年9月。由于目标的差分和两阶滞后，实际可估计样本为2011年4月至2023年9月，共150个月。
- OOT：2023年10月至2025年12月，共27个月。两种OOT方法均保持In-sample系数固定。
- Static：使用真实历史滞后变化和前一个月真实fee作为基数。
- Recursive OOT：从2023年9月的历史状态一次性启动，之后使用预测值更新滞后项和fee基数。实际值仅用于计算误差。
- Production refit：保留相同模型结构，用截至2025年12月的数据重新估计，实际可用样本177个月。
- 滚动系数：60个月窗口、逐月移动，共118个窗口。范围覆盖OOT月份，是回顾性稳定性分析，不是独立OOT检验。
- 正式预测：从2025年12月一次性启动，预测2026年1月至2028年3月，共27个月。包内没有2026年及之后的实际Consumer fee。
- S4与Baseline共享截至2025年12月的宏观历史和生产系数。仅从2026年1月替换S4 retail sales路径。2025年的S4历史修订不进入本次情景对比。
- P11连接线额外展示2025年12月实际值作为连接点。该点不计入27个月预测或任何预测汇总。

## 数据

| 文件 | 覆盖期 | 内容 |
|---|---|---|
| `data/consumer_fee_history.csv` | 2011 Jan–2025 Dec | Consumer Card fee实际值，180行 |
| `data/baseline_macro.csv` | 2010 Jan–2026 Dec | 五个原始宏观变量，204行 |
| `data/baseline_macro_extension.csv` | 2027 Jan–2028 Mar | 用户更新图片中的retail sales和consumer confidence，15行 |
| `data/s4_retail_sales.csv` | 2026 Jan–2028 Mar | S4已选宏观驱动，27行 |

日期统一为月初，原始数字保留精度。未对金额单位做转换。
原文件名、工作表/列、原文件哈希、数据哈希和单位定义统一记录在 `data/source_provenance.json`。
包内只保留本模型使用的数据，不携带其他卡业务数据或未使用的S4变量。

## 与 deck 的核对

`reference/deck_content.json` 是直接从本次最新PPTX提取的文本、表格和图表数值。
`reference/deck_values.json` 保存该模型运行的高精度对照值，只供验证；拟合和预测不读取其中的系数或预测结果。
`--verify-deck` 比较重新计算的系数、诊断值、MAPE、滚动系数及54个情景月度预测。
`verification/deck_comparison.csv` 另将运行结果直接与PPTX中显示的数字、图表序列比较。
`verification/verification_summary.md` 汇总核对结论，区分显示精度差异与数值不一致。

本包不修改PPTX。若以后修改deck或输入数据，需要重新执行对应核对。
