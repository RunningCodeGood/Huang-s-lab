# Consumer Card Model

One Python script estimates the Consumer Card fee model, calculates statistical diagnostics and forecast accuracy, performs rolling coefficient analysis, and generates Baseline and S4 conditional forecasts.

## Requirements and execution

Use Python 3.12 with NumPy and pandas:

```bash
python -m pip install numpy==2.3.5 pandas==2.2.3
python consumer_card_model.py
```

Run the command from the extracted package folder. The script also works from another directory when invoked with its full path. Input and default output locations are relative to the script.

The script creates CSV result tables in `results/`. To run again, select a new or empty output folder:

```bash
python consumer_card_model.py --output-dir results_new
```

Use `--data-dir` to specify another folder containing the same four input filenames and column structure.

## Input data

All input files contain monthly source levels, not precomputed model features. Dates use the first day of each month in `YYYY-MM-DD` format.

| File | Period | Columns |
|---|---|---|
| `data/consumer_fee_history.csv` | Jan 2011 to Dec 2025 | `date`, `fee` |
| `data/baseline_macro.csv` | Jan 2010 to Dec 2026 | `date`, `Unemployment`, `CPI`, `DPI`, `RetailSales`, `ConsumerConfidence` |
| `data/baseline_macro_extension.csv` | Jan 2027 to Mar 2028 | `date`, `RetailSales`, `ConsumerConfidence` |
| `data/s4_retail_sales.csv` | Jan 2026 to Mar 2028 | `date`, `RetailSales` |

`fee` retains its original source units. `Unemployment` is a percentage level. `CPI` and `ConsumerConfidence` are index levels. `DPI` retains its source disposable-income units. `RetailSales` retains the original retail-sales level in billions of USD with the source label `CDASAAR`.

Fee history comes from the Consumer Card column of the fee source file. Baseline macro levels through December 2026 come from the original macro workbook. The extension contains the supplied retail-sales and consumer-confidence updates. S4 retail-sales levels come from the June 2026 S4 scenario file. All transformations occur in the Python script.

## Model specification

The dependent variable is the monthly log change in fee revenue, multiplied by 100:

```text
y(t) = 100 * [log(fee(t)) - log(fee(t-1))]
```

The base equation includes an intercept, two lags of `y`, and January and December indicators. Ten macro candidates come from five macro families, each with a current monthly change and a trailing three-month average.

- Unemployment uses the monthly percentage-point difference.
- Other macro series use the monthly percentage change.
- The trailing average includes the current month and the prior two months.
- Forward selection uses only in-sample observations.
- Candidate eligibility requires p < 0.05, maximum VIF < 10, Durbin-Watson between 1.5 and 2.5 inclusive, and Jarque-Bera p > 0.05.
- At most one feature from each macro family can enter the equation.
- The eligible candidate with the smallest p-value enters next. Adjusted R-squared breaks ties.

Coefficient standard errors use classical, non-robust OLS covariance. `p_normal` is the two-sided normal-approximation p-value used for selection. `p_student_t` separately uses the Student-t distribution with residual degrees of freedom equal to n minus the number of parameters, including the intercept.

Jarque-Bera uses the asymptotic chi-squared distribution with two degrees of freedom. Durbin-Watson is a residual statistic, not a standalone significance conclusion for a model with lagged dependent variables. VIF calculations include an intercept in each auxiliary regression. MAPE and RMSE measure prediction accuracy rather than hypothesis significance.

## Estimation and forecast periods

| Stage | Period | Method |
|---|---|---|
| In-sample | Jan 2011 to Sep 2023 | Feature selection and initial coefficient estimation |
| OOT | Oct 2023 to Dec 2025 | Fixed in-sample coefficients, static and recursive predictions |
| Production refit | Data through Dec 2025 | Same selected equation with newly estimated coefficients |
| Rolling coefficients | Effective historical sample through Dec 2025 | Fixed 60-month windows, advanced one month at a time |
| Conditional forecast | Jan 2026 to Mar 2028 | Fixed production coefficients and a December 2025 origin |

The first effective regression month is April 2011 because the target transformation and two lags require three prior fee observations. The effective in-sample and production samples contain 150 and 177 observations, respectively. The rolling analysis contains 118 windows and is retrospective, including months in the OOT period.

Static predictions use observed lagged target changes and the observed prior-month fee. Recursive predictions begin with the historical state at the origin and then update target changes and fee levels using prior predictions. No Consumer Card fee observations after December 2025 enter the production model or conditional forecasts.

Baseline and S4 use the same production equation and the same historical macro values through December 2025. S4 replaces future retail-sales levels beginning in January 2026. Forecast summaries cover exactly 27 months.

## Result tables generated by the script

| File | Content |
|---|---|
| `model_diagnostics.csv` | Sample sizes, R-squared, adjusted R-squared, residual diagnostics, and maximum VIF |
| `coefficients.csv` | Base, selected in-sample, and production coefficients with standard errors and p-values |
| `macro_screening.csv` | Candidate statistics and selection decisions by round |
| `forecast_accuracy.csv` | Static In-sample, Static OOT, and Recursive OOT MAPE and RMSE |
| `static_in_sample.csv` | Monthly in-sample fitted fees |
| `static_oot.csv` | Monthly static OOT predictions |
| `recursive_oot.csv` | Monthly recursive OOT predictions |
| `rolling_coefficients.csv` | Raw and standardized coefficients for each 60-month window |
| `rolling_summary.csv` | Coefficient ranges and sign frequencies |
| `scenario_forecasts.csv` | Baseline and S4 monthly forecasts and model inputs |
| `scenario_summary.csv` | Annual and 27-month scenario averages, totals, and percentage differences |
| `historical_data_and_features.csv` | Historical levels and calculated model features |
