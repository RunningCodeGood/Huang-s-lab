#!/usr/bin/env python3
"""Consumer Card estimation, statistical diagnostics, and scenario forecasts.

Run from any directory. All inputs are relative to this file unless --data-dir
is supplied. Only NumPy and pandas are required. No network or Excel is needed.
Macro selection uses two-sided normal-approximation coefficient p-values.
Student-t p-values are included as a separate measure of coefficient inference.
"""
from __future__ import annotations

import argparse
import math
from pathlib import Path

import numpy as np
import pandas as pd

# Monthly sample boundaries and fixed model settings.
ROOT = Path(__file__).resolve().parent
IN_SAMPLE_START = pd.Timestamp("2011-01-01")
IN_SAMPLE_END = pd.Timestamp("2023-09-01")
OOT_START = pd.Timestamp("2023-10-01")
ORIGIN = pd.Timestamp("2025-12-01")
FORECAST_START = pd.Timestamp("2026-01-01")
FORECAST_END = pd.Timestamp("2028-03-01")
BASE_TERMS = ["y_lag1", "y_lag2", "January", "December"]
MACROS = ["CPI", "DPI", "RetailSales", "ConsumerConfidence", "Unemployment"]
ROLLING_WINDOW = 60
P_LIMIT, VIF_LIMIT, DW_LOW, DW_HIGH, JB_LIMIT = 0.05, 10.0, 1.5, 2.5, 0.05


def save_csv(frame, path):
    """Write a calculated table without rounding its numerical values."""
    frame.to_csv(path, index=False, date_format="%Y-%m-%d", float_format="%.17g")


def read_monthly(path):
    """Read raw monthly levels and arrange observations chronologically."""
    frame = pd.read_csv(path, parse_dates=["date"], float_precision="round_trip")
    return frame.sort_values("date").reset_index(drop=True)


def load_data(data_dir):
    """Combine fee history with the baseline macro path and its extension."""
    fee = read_monthly(data_dir / "consumer_fee_history.csv")
    baseline = read_monthly(data_dir / "baseline_macro.csv")
    extension = read_monthly(data_dir / "baseline_macro_extension.csv")
    stress = read_monthly(data_dir / "s4_retail_sales.csv")
    macro = pd.concat([baseline, extension], ignore_index=True)
    data = macro.merge(fee, on="date", how="left")
    return engineer(data), stress


def engineer(data):
    """Create target log changes, target lags, seasonality, and macro features."""
    frame = data.copy().sort_values("date").reset_index(drop=True)
    # No fee observations after the production origin are available to this run.
    frame.loc[frame.date > ORIGIN, "fee"] = np.nan
    frame["y"] = 100.0 * np.log(frame.fee).diff()
    frame["y_lag1"], frame["y_lag2"] = frame.y.shift(1), frame.y.shift(2)
    frame["January"] = (frame.date.dt.month == 1).astype(int)
    frame["December"] = (frame.date.dt.month == 12).astype(int)
    for name in MACROS:
        # Unemployment changes are in percentage points. Other changes are in percent.
        change = frame[name].diff() if name == "Unemployment" else 100.0 * frame[name].pct_change(fill_method=None)
        frame[name + "_chg"] = change
        frame[name + "_chg_MA3"] = change.rolling(3, min_periods=3).mean()
    return frame


def _beta_fraction(a, b, x):
    """Continued fraction for the regularized incomplete beta function."""
    tiny, eps = 1e-300, 3e-14
    qab, qap, qam = a + b, a + 1.0, a - 1.0
    c, d = 1.0, 1.0 - qab * x / qap
    if abs(d) < tiny:
        d = tiny
    d = 1.0 / d
    result = d
    for m in range(1, 10001):
        m2 = 2 * m
        for aa in [m * (b - m) * x / ((qam + m2) * (a + m2)),
                   -(a + m) * (qab + m) * x / ((a + m2) * (qap + m2))]:
            d = 1.0 + aa * d
            c = 1.0 + aa / c
            if abs(d) < tiny:
                d = tiny
            if abs(c) < tiny:
                c = tiny
            d = 1.0 / d
            delta = d * c
            result *= delta
        if abs(delta - 1.0) < eps:
            return result
    raise ArithmeticError("Incomplete beta continued fraction did not converge")


def student_t_two_sided(t_stat, df):
    """Two-sided Student-t p = I_[df/(df+t^2)](df/2, 1/2)."""
    if df <= 0:
        raise ValueError("Student-t requires positive residual degrees of freedom")
    x = df / (df + float(t_stat) ** 2)
    if x <= 0:
        return 0.0
    if x >= 1:
        return 1.0
    a, b = df / 2.0, 0.5
    front = math.exp(math.lgamma(a + b) - math.lgamma(a) - math.lgamma(b) + a * math.log(x) + b * math.log1p(-x))
    p = front * _beta_fraction(a, b, x) / a if x < (a + 1.0) / (a + b + 2.0) else 1.0 - front * _beta_fraction(b, a, 1.0 - x) / b
    return min(1.0, max(0.0, p))


def vif_values(sample, terms):
    """Calculate each feature's VIF using an auxiliary regression with an intercept."""
    values = sample[terms].to_numpy(dtype=float)
    result = {}
    for j, term in enumerate(terms):
        target = values[:, j]
        others = np.column_stack([np.ones(len(values)), np.delete(values, j, axis=1)])
        beta = np.linalg.lstsq(others, target, rcond=None)[0]
        residual = target - others @ beta
        tss = float(np.sum((target - target.mean()) ** 2))
        r2 = 1.0 - float(residual @ residual) / tss
        result[term] = 1.0 / (1.0 - r2)
    return result


def fit_ols(frame, terms):
    """Estimate OLS and calculate coefficient inference and residual diagnostics."""
    # Differencing and lag construction leave the first three fee months unavailable.
    sample = frame[["date", "fee", "y", *terms]].dropna().copy()
    y = sample.y.to_numpy(dtype=float)
    x = np.column_stack([np.ones(len(sample)), sample[terms].to_numpy(dtype=float)])
    n, k = x.shape
    beta = np.linalg.lstsq(x, y, rcond=None)[0]
    fitted = x @ beta
    residual = y - fitted
    rss = float(residual @ residual)
    r2 = 1.0 - rss / float(np.sum((y - y.mean()) ** 2))
    # Classical OLS standard errors use residual variance RSS / (n - k).
    se = np.sqrt(np.diag((rss / (n - k)) * np.linalg.pinv(x.T @ x)))
    t_stats = beta / se
    # Normal-approximation p-values determine macro eligibility.
    normal_p = [math.erfc(abs(t) / math.sqrt(2.0)) for t in t_stats]
    student_p = [student_t_two_sided(t, n - k) for t in t_stats]
    z = residual / np.std(residual, ddof=0)
    skew, kurtosis = float(np.mean(z ** 3)), float(np.mean(z ** 4))
    # Jarque-Bera uses the asymptotic chi-squared distribution with two degrees of freedom.
    jb = n / 6.0 * (skew ** 2 + (kurtosis - 3.0) ** 2 / 4.0)
    vifs = vif_values(sample, terms)
    names = ["const", *terms]
    coefficients = pd.DataFrame({"term": names, "coefficient": beta, "standard_error": se,
        "t_stat": t_stats, "p_normal": normal_p, "p_student_t": student_p,
        "vif": [np.nan] + [vifs[t] for t in terms]})
    diagnostics = {"n": n, "parameters_including_constant": k, "df_resid": n-k,
        "r_squared": r2, "adjusted_r_squared": 1.0-(1.0-r2)*(n-1)/(n-k),
        "durbin_watson": float(np.diff(residual) @ np.diff(residual) / rss),
        "jarque_bera": jb, "jarque_bera_p": math.exp(-jb/2.0),
        "residual_skewness": skew, "residual_kurtosis": kurtosis,
        "max_vif": max(vifs.values()), "rss": rss,
        "first_effective_month": sample.date.iloc[0].strftime("%Y-%m-%d"),
        "last_effective_month": sample.date.iloc[-1].strftime("%Y-%m-%d")}
    return {"params": dict(zip(names, beta)), "coefficients": coefficients,
            "diagnostics": diagnostics, "sample": sample, "residual": residual, "fitted": fitted}


def forward_selection(frame):
    """Select macro features using only the fixed in-sample estimation period."""
    sample = frame.loc[frame.date.between(IN_SAMPLE_START, IN_SAMPLE_END)]
    remaining = [name + suffix for name in MACROS for suffix in ["_chg", "_chg_MA3"]]
    selected, trials = [], []
    round_no = 1
    while remaining:
        current = []
        for candidate in remaining:
            model = fit_ols(sample, BASE_TERMS + selected + [candidate])
            c = model["coefficients"].set_index("term").loc[candidate]
            d = model["diagnostics"]
            family_allowed = candidate.split("_chg")[0] not in {t.split("_chg")[0] for t in selected}
            row = {"round": round_no, "candidate": candidate, "coefficient": c.coefficient,
                "p_normal": c.p_normal, "p_student_t": c.p_student_t,
                "adjusted_r_squared": d["adjusted_r_squared"], "max_vif": d["max_vif"],
                "durbin_watson": d["durbin_watson"], "jarque_bera_p": d["jarque_bera_p"],
                "p_gate": c.p_normal < P_LIMIT, "vif_gate": d["max_vif"] < VIF_LIMIT,
                "dw_gate": DW_LOW <= d["durbin_watson"] <= DW_HIGH,
                "jb_gate": d["jarque_bera_p"] > JB_LIMIT, "family_allowed": family_allowed}
            row["statistical_gates_pass"] = all(row[key] for key in ["p_gate", "vif_gate", "dw_gate", "jb_gate"])
            row["eligible"] = row["statistical_gates_pass"] and family_allowed
            row["selected"] = False
            current.append(row)
        # Select the smallest eligible p-value; adjusted R-squared breaks ties.
        passing = sorted([r for r in current if r["eligible"]], key=lambda r: (r["p_normal"], -r["adjusted_r_squared"], r["candidate"]))
        if passing:
            winner = passing[0]
            winner["selected"] = True
            selected.append(winner["candidate"])
            remaining.remove(winner["candidate"])
        trials.extend(current)
        if not passing:
            break
        round_no += 1
    return selected, pd.DataFrame(trials)


def static_predictions(frame, model, terms, start, end):
    """Use observed target lags and the observed prior-month fee for each prediction."""
    sample = frame.loc[frame.date.between(start, end), ["date", "fee", "y", *terms]].dropna().copy()
    x = np.column_stack([np.ones(len(sample)), sample[terms].to_numpy(dtype=float)])
    predicted_y = x @ np.asarray([model["params"][t] for t in ["const", *terms]])
    prior = frame.set_index("date").fee.shift(1).reindex(sample.date).to_numpy(dtype=float)
    return pd.DataFrame({"date": sample.date, "actual_fee": sample.fee,
        "actual_log_change": sample.y, "predicted_log_change": predicted_y,
        "predicted_fee": prior * np.exp(predicted_y / 100.0),
        "fee_base_input": prior, "residual_log_change": sample.y - predicted_y})


def recursive_predictions(frame, model, terms, start, end, include_actual=False):
    """Follow a fixed-origin path, updating target lags and fee levels with predictions."""
    source = frame.set_index("date")
    # Only observations strictly before the origin enter the recursive states.
    history = source.loc[source.index < start]
    changes, levels = history.y.dropna().to_dict(), history.fee.dropna().to_dict()
    rows = []
    for date in pd.date_range(start, end, freq="MS"):
        inputs = {}
        for term in terms:
            inputs[term] = changes[date-pd.DateOffset(months=int(term[-1]))] if term in ["y_lag1", "y_lag2"] else float(source.at[date, term])
        predicted_y = float(model["params"]["const"] + sum(model["params"][t]*inputs[t] for t in terms))
        prior = levels[date-pd.DateOffset(months=1)]
        prediction = float(prior * math.exp(predicted_y/100.0))
        row = {"date": date, "predicted_log_change": predicted_y, "predicted_fee": prediction,
               "fee_base_input": prior, **{t + "_input": v for t, v in inputs.items()}}
        if include_actual:
            # Actual OOT fees are attached only for calculating forecast errors.
            row["actual_fee"] = float(source.at[date, "fee"])
        rows.append(row)
        changes[date], levels[date] = predicted_y, prediction
    return pd.DataFrame(rows)


def accuracy(frame, name):
    """Calculate level-based MAPE in percent and RMSE in fee source units."""
    error = frame.actual_fee - frame.predicted_fee
    return {"method": name, "n": len(frame),
        "mape_pct": float(np.mean(np.abs(error/frame.actual_fee))*100),
        "rmse": float(np.sqrt(np.mean(error**2)))}


def rolling_coefficients(frame, terms):
    """Refit the same equation in fixed 60-month windows, moving one month at a time."""
    sample = frame.loc[frame.date.between(IN_SAMPLE_START, ORIGIN), ["date", "fee", "y", *terms]].dropna().reset_index(drop=True)
    rows = []
    for stop in range(ROLLING_WINDOW, len(sample)+1):
        window = sample.iloc[stop-ROLLING_WINDOW:stop]
        model = fit_ols(window, terms)
        row = {"window_start": window.date.iloc[0], "date": window.date.iloc[-1], "n": len(window)}
        for term in terms:
            row[term] = model["params"][term]
            row[term+"_standardized"] = row[term]*window[term].std(ddof=1)/window.y.std(ddof=1)
        rows.append(row)
    result = pd.DataFrame(rows)
    summary = pd.DataFrame([{"term": term, "windows": len(result), "minimum": result[term].min(),
        "maximum": result[term].max(), "positive_windows": int((result[term]>0).sum()),
        "negative_windows": int((result[term]<0).sum()),
        "sign_changes": int(np.count_nonzero(np.diff(np.sign(result[term]))))} for term in terms])
    return result, summary


def scenario_predictions(frame, stress, production, terms):
    """Apply one production equation to the baseline and S4 retail-sales paths."""
    scenarios = []
    for name in ["Baseline", "S4"]:
        current = frame.copy()
        if name == "S4":
            # Common history ends at December 2025. Only future macro levels differ.
            mask = current.date.between(FORECAST_START, FORECAST_END)
            current.loc[mask, "RetailSales"] = stress.set_index("date").loc[current.loc[mask, "date"], "RetailSales"].to_numpy()
            current["RetailSales_chg"] = 100*current.RetailSales.pct_change(fill_method=None)
            current["RetailSales_chg_MA3"] = current.RetailSales_chg.rolling(3).mean()
        prediction = recursive_predictions(current, production, terms, FORECAST_START, FORECAST_END)
        prediction.insert(1, "scenario", name)
        prediction["retail_sales"] = current.set_index("date").loc[prediction.date, "RetailSales"].to_numpy()
        scenarios.append(prediction)
    forecasts = pd.concat(scenarios, ignore_index=True)
    wide = forecasts.pivot(index="date", columns="scenario", values="predicted_fee")
    rows = []
    for label, start, end in [("2026","2026-01-01","2026-12-01"), ("2027","2027-01-01","2027-12-01"),
            ("2028 Jan-Mar","2028-01-01","2028-03-01"), ("27-month total","2026-01-01","2028-03-01")]:
        part = wide.loc[start:end]
        b, s = part.Baseline, part.S4
        rows.append({"period": label, "months": len(part), "baseline_average": float(b.mean()), "s4_average": float(s.mean()),
            "baseline_total": float(b.sum()), "s4_total": float(s.sum()), "s4_vs_baseline_pct": float(100*(s.sum()/b.sum()-1))})
    return forecasts, pd.DataFrame(rows)


def quarterly_scenario_summary(forecasts):
    """Sum monthly fee forecasts into calendar quarters and cumulative totals."""
    monthly = forecasts.loc[forecasts.date.between(FORECAST_START, FORECAST_END)]
    wide = monthly.pivot(index="date", columns="scenario", values="predicted_fee")
    # Fee revenue is an additive flow. Sum levels, not log changes or monthly averages.
    quarters = wide.groupby(wide.index.to_period("Q-DEC")).sum(min_count=3)
    rows = [{"period": f"{quarter.year} Q{quarter.quarter}", "months": 3,
             "baseline_total": float(totals.Baseline), "s4_total": float(totals.S4)}
            for quarter, totals in quarters.iterrows()]
    # Sum only the quarterly detail, so subtotal rows are never counted twice.
    first_year = quarters.loc[quarters.index.year == FORECAST_START.year]
    for label, part in [(f"{FORECAST_START.year} total", first_year),
                        (f"{len(quarters)}-quarter total", quarters)]:
        rows.append({"period": label, "months": 3 * len(part),
                     "baseline_total": float(part.Baseline.sum()),
                     "s4_total": float(part.S4.sum())})
    return pd.DataFrame(rows)


def analyze(frame, stress):
    """Run selection, estimation, forecast accuracy, rolling analysis, and scenarios."""
    selected, screening = forward_selection(frame)
    terms = BASE_TERMS + selected
    base = fit_ols(frame.loc[frame.date.between(IN_SAMPLE_START, IN_SAMPLE_END)], BASE_TERMS)
    development = fit_ols(frame.loc[frame.date.between(IN_SAMPLE_START, IN_SAMPLE_END)], terms)
    production = fit_ols(frame.loc[frame.date.between(IN_SAMPLE_START, ORIGIN)], terms)
    in_sample = static_predictions(frame, development, terms, IN_SAMPLE_START, IN_SAMPLE_END)
    static_oot = static_predictions(frame, development, terms, OOT_START, ORIGIN)
    recursive_oot = recursive_predictions(frame, development, terms, OOT_START, ORIGIN, include_actual=True)
    rolling, rolling_summary = rolling_coefficients(frame, terms)
    forecasts, scenario_summary = scenario_predictions(frame, stress, production, terms)
    metrics = pd.DataFrame([accuracy(in_sample,"Static In-sample"), accuracy(static_oot,"Static OOT"), accuracy(recursive_oot,"Recursive OOT")])
    models = [("Base In-sample",base),("Selected In-sample",development),("Production refit",production)]
    diagnostics = pd.DataFrame([{"model": name, **model["diagnostics"]} for name, model in models])
    coefficients = pd.concat([model["coefficients"].assign(model=name) for name, model in models], ignore_index=True)
    tables = {"model_diagnostics":diagnostics, "coefficients":coefficients, "macro_screening":screening,
        "forecast_accuracy":metrics, "static_in_sample":in_sample, "static_oot":static_oot,
        "recursive_oot":recursive_oot, "rolling_coefficients":rolling, "rolling_summary":rolling_summary,
        "scenario_forecasts":forecasts, "scenario_summary":scenario_summary,
        "scenario_quarterly_summary":quarterly_scenario_summary(forecasts),
        "historical_data_and_features":frame.loc[frame.date.between(IN_SAMPLE_START,ORIGIN)].copy()}
    return {"tables":tables,"selected":selected,"terms":terms,"development":development,"production":production}


def main():
    """Read the input files, calculate the model, and save statistical result tables."""
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-dir",type=Path,default=ROOT/"data")
    parser.add_argument("--output-dir",type=Path,default=ROOT/"results")
    args=parser.parse_args()
    data_dir,output=args.data_dir.resolve(),args.output_dir.resolve()
    # Keep previous result files intact when choosing an output folder.
    if output.exists() and any(output.iterdir()):
        raise FileExistsError(f"Choose a new or empty output directory: {output}")
    frame,stress=load_data(data_dir)
    result=analyze(frame,stress)
    output.mkdir(parents=True,exist_ok=True)
    for name,table in result["tables"].items():
        save_csv(table,output/(name+".csv"))
    print(result["tables"]["forecast_accuracy"].to_string(index=False))
    print("\nQuarterly fee forecasts (totals in original fee source units):")
    print(result["tables"]["scenario_quarterly_summary"].to_string(
        index=False, float_format=lambda value: f"{value:,.2f}"))
    print(f"Selected macro: {', '.join(result['selected'])}")
    print(f"Rolling windows: {len(result['tables']['rolling_coefficients'])}")
    print(f"Results saved to: {output}")


if __name__=="__main__":
    main()
