# Consumer Card Model

This standalone script estimates Consumer Card fee growth, evaluates historical predictions, measures rolling coefficient stability, and produces Baseline, S4 and Retail Sales growth-sensitivity forecasts. All coefficients and results are calculated from the input observations when the script runs.

## Run

Use Python 3.12 with NumPy and pandas:

```bash
python -m pip install numpy==2.3.5 pandas==2.2.3
python consumer_card_model.py
```

Paths are relative to the script, so it can also be launched from another directory. Use `--data-dir` for a folder with the same input schema and `--output-dir` for a new or empty results directory. A nonempty results directory is not overwritten. The default output is `results/`.

## Input files

| File | Period | Purpose |
| --- | --- | --- |
| `data/fee_history.csv` | Jan 2011 to Dec 2025 | Original Consumer Card fee observations |
| `data/macro_history.csv` | Jan 2010 to Dec 2025 | Historical levels of all five candidate macro series |
| `data/macro_baseline.csv` | Jan 2026 to Mar 2028 | Baseline macro scenario levels |
| `data/macro_s4.csv` | Jan 2026 to Mar 2028 | S4 retail-sales scenario levels |

Every row is monthly and keyed by `date`, formatted as `YYYY-MM-DD` using the first day of the month. Each file has a single purpose: historical observations and future scenarios are separate. The previous baseline extension is part of `macro_baseline.csv`.

All CSV macro headers retain the Moody's source field names. The explanatory text originally attached to the retail-sales and consumer-confidence headers is also retained exactly. `MACRO_COLUMNS` in the script maps source headers to business names once the data is read. Revenue uses the source field `Consumer Card`, mapped to `consumer_card_fee`.

| Moody's CSV header | Internal variable | Level units |
| --- | --- | --- |
| `M_FLBR_B.IUSA` | `unemployment_rate` | Percent |
| `M_FCPIU_B.IUSA` | `consumer_price_index` | Index |
| `M_FYPDPIQ_B.IUSA` | `disposable_personal_income` | Original source units |
| `M_FRT_B.IUSA (Retail Sales Total_Bil.USD,CDASAAR)` | `retail_sales` | Billions of USD; source label CDASAAR |
| `M_FCBC_B.IUSA(Consumer confidence index)` | `consumer_confidence` | Index |

Fee revenue retains its original source units; the script does not apply a currency conversion or assume that the amounts are dollars, thousands, or millions. The monthly frequency describes the supplied observations, not necessarily the native publication frequency of each underlying series. No interpolation, rescaling, or missing-value filling is applied.

The historical and Baseline values through December 2026 originate from the supplied macro workbook. The supplied extension provides retail sales and consumer confidence for January 2027 through March 2028. Consequently, CPI, disposable income and unemployment are blank in those last 15 Baseline rows. S4 contains only the supplied retail-sales path from the June 2026 scenario file. These are external scenario assumptions, not forecasts estimated by this model. If another macro family is selected with different input history, its required future scenario values must also be supplied and the scenario-driver setup reviewed.

## Variable naming and transformations

Internal variables and result columns use lower-case `snake_case`:

| Feature | Definition |
| --- | --- |
| `consumer_card_fee_log_change_1m_pct` | `100 * (log(fee_t) - log(fee_t_minus_1m))` |
| `consumer_card_fee_log_change_1m_pct_lag_1m` | Target log change lagged one month |
| `consumer_card_fee_log_change_1m_pct_lag_2m` | Target log change lagged two months |
| `retail_sales_pct_change_1m` | `100 * (retail_sales_t / retail_sales_t_minus_1m - 1)` |
| `retail_sales_pct_change_1m_ma_3m` | Average of the current and previous two monthly percentage changes |
| `unemployment_rate_diff_1m_pp` | Current unemployment rate minus the previous month's rate, in percentage points |
| `is_january`, `is_december` | Calendar-month indicators |

`pct_change` is percentage growth, `log_change` is a log difference multiplied by 100, and `diff...pp` is a percentage-point difference. `lag_1m` means a one-month lag. `ma_3m` averages the already transformed series over three months. Derived features are calculated in memory and never supplied as raw inputs.

## Estimation and forecasts

- In-sample estimation and macro selection: January 2011 through September 2023. The first effective regression month is April 2011, giving 150 observations.
- Base equation: intercept, two target lags, and January and December indicators.
- Macro pool: five families, each with a current monthly change and its trailing three-month average. Unemployment uses differences in percentage points; the other series use percentage changes.
- Forward selection requires the added term's normal-approximation p-value below 0.05, maximum VIF below 10, DW from 1.5 to 2.5 inclusive, and JB p-value above 0.05. At most one feature from each macro family is allowed. Candidates are ranked by p-value, adjusted R-squared and a fixed deterministic tie order.
- OOT assessment: October 2023 through December 2025, using fixed in-sample coefficients. Static predictions use observed history; recursive predictions update fee levels and target lags with prior predictions.
- Production refit: retain the selected structure and re-estimate through December 2025, using 177 effective observations. Rolling analysis uses 118 overlapping 60-month windows.
- Scenario forecasts: January 2026 through March 2028, from a single December 2025 origin. Baseline and S4 use the same production equation and history. S4 replaces future retail-sales levels only. Coefficients remain fixed during each recursive path.

OLS covariance is classical and nonrobust. `p_normal` determines selection; `p_student_t` separately reports Student-t inference. JB uses an asymptotic chi-squared reference. DW and VIF are diagnostic statistics. Forecasts are conditional point estimates.

## Retail Sales growth sensitivity

The default run adds 12 one-variable sensitivity cases: monthly Retail Sales growth shocks of -1.0, -0.5, +0.5 and +1.0 percentage points, each lasting 3, 6 or 12 months. Every shock begins in January 2026. These magnitudes are explicit sensitivity assumptions, not estimated parameters, probabilities or a replacement for the supplied S4 scenario.

The four input CSV files are never modified. Each case is built in memory from the original Baseline path:

1. Calculate Baseline monthly growth as `g_baseline(t) = 100 * (RS_baseline(t) / RS_baseline(t-1) - 1)`.
2. Add the specified percentage-point shock during its active months. For example, Baseline growth of 0.3% plus a -0.5 pp shock becomes -0.2%, not 0.2985%.
3. Starting from the unchanged December 2025 Retail Sales level, rebuild every future level as `RS_shocked(t) = RS_shocked(t-1) * (1 + g_shocked(t) / 100)`.
4. Recalculate monthly growth from the rebuilt levels, then calculate its trailing three-month average using the current and prior two months. Historical months needed for the initial MA3 remain unchanged.
5. Run the full January 2026 to March 2028 recursive fee forecast using the production coefficients already estimated from unchanged history. Do not reselect variables or re-estimate coefficients for individual sensitivity cases.

After the active shock ends, monthly growth returns to that month's original Baseline growth rate. The accumulated Retail Sales level difference remains; the code does not reset the level to Baseline or add an offsetting catch-up shock. The MA3 growth difference then fades over the following two months. Fee growth can continue responding through its two autoregressive lags, and an accumulated fee-level difference can persist even after the growth effects fade.

All cases retain the same fee history, December 2025 fee anchor, calendar indicators, other macro paths and model structure. The existing Baseline and S4 outputs are unchanged. Sensitivity requires `retail_sales_pct_change_1m_ma_3m` in the selected equation; if different raw history selects another specification, review the sensitivity setup rather than forcing Retail Sales into the model.

Use command-line options to choose another test grid without editing input data:

```bash
python consumer_card_model.py --output-dir results_sensitivity --sensitivity-shocks-pp -0.5 0.5 --sensitivity-durations-months 6
```

Each requested duration must be an integer from 1 to 27 months, and shocked monthly growth must remain greater than -100%. A zero shock is allowed as a Baseline-equivalent case, subject to numerical roundoff when rebuilding levels.

`sensitivity_monthly.csv` contains each case's rebuilt Retail Sales levels, recomputed MoM growth and MA3 alongside their Baseline values, applied growth shocks, recursive fee predictions and lag inputs. `fee_impact` is sensitivity minus Baseline; `fee_impact_pct` divides that difference by Baseline and multiplies by 100. There are 324 rows in the default grid: 12 cases times 27 months.

`sensitivity_quarterly_summary.csv` provides nine calendar-quarter totals, `2026 total` and `9-quarter total` for each case, alongside the corresponding Baseline totals and absolute and percentage impacts. It contains 132 rows in the default grid. Aggregate percentage impacts use the ratio of summed unrounded fee levels, not the average of monthly percentage impacts.

`sensitivity_summary.csv` contains one row per case: 2026 and full-horizon totals and impacts, peak absolute monthly fee and percentage impacts with their dates, and the March 2028 terminal-month impact. `year` identifies 2026; `horizon_months` identifies the 27-month nine-quarter horizon. All monetary outputs retain the original fee source units. Only console display is rounded to two decimal places.

## Generated results

| File | Content |
| --- | --- |
| `model_diagnostics.csv` | Fit statistics and residual diagnostics |
| `coefficients.csv` | Base, selected in-sample and production coefficients |
| `macro_screening.csv` | Candidate statistics and selection decisions |
| `forecast_accuracy.csv` | Static in-sample, static OOT and recursive OOT accuracy |
| `static_in_sample.csv`, `static_oot.csv`, `recursive_oot.csv` | Historical prediction detail |
| `rolling_coefficients.csv`, `rolling_summary.csv` | Raw and standardized coefficient paths and summaries |
| `historical_data_and_features.csv` | Historical levels and calculated features |
| `forecast_monthly.csv` | Baseline and S4 monthly fee forecasts and model inputs |
| `forecast_summary.csv` | Annual and 27-month scenario averages, totals and differences |
| `forecast_quarterly_summary.csv` | Nine quarterly fee totals, 2026 total and nine-quarter total |
| `sensitivity_monthly.csv` | Rebuilt Retail Sales paths, transformations, recursive forecasts and monthly impacts |
| `sensitivity_quarterly_summary.csv` | Quarterly, 2026 and nine-quarter sensitivity totals and impacts |
| `sensitivity_summary.csv` | Annual and full-horizon totals, peak impacts and terminal-month impacts by case |

Monthly forecasts use `date`, `scenario`, `predicted_fee` and `predicted_log_change_1m_pct`, with the required inputs alongside them. Quarterly summaries use `period`, `months`, `baseline_total` and `s4_total`. Quarterly labels follow `2026Q1`; each quarterly amount sums three monthly revenue levels. Totals use unrounded predictions. CSV exports retain 17 significant digits; console summaries display two decimal places. Results are generated at runtime and are not included as inputs.
