#!/usr/bin/env python3
"""Consumer Card estimation, statistical diagnostics, and scenario forecasts.

Run from any directory. All inputs are relative to this file unless --data-dir
is supplied. Only NumPy and pandas are required. No network or Excel is needed.
Macro selection uses two-sided normal-approximation coefficient p-values.
Student-t p-values are included as a separate measure of coefficient inference.
Retail-sales sensitivity paths are generated in memory; input files are unchanged.
"""
from __future__ import annotations

import argparse
import math
from pathlib import Path

import numpy as np
import pandas as pd

# Monthly sample boundaries and fixed model settings.
ROOT = Path(__file__).resolve().parent
IN_SAMPLE_START = pd.Timestamp("2011-01-01")
IN_SAMPLE_END = pd.Timestamp("2023-09-01")
OOT_START = pd.Timestamp("2023-10-01")
ORIGIN = pd.Timestamp("2025-12-01")
FORECAST_START = pd.Timestamp("2026-01-01")
FORECAST_END = pd.Timestamp("2028-03-01")
BASE_TERMS = [
    "consumer_card_fee_log_change_1m_pct_lag_1m",
    "consumer_card_fee_log_change_1m_pct_lag_2m",
    "is_january",
    "is_december",
]
MACRO_COLUMNS = {
    "M_FCPIU_B.IUSA": "consumer_price_index",
    "M_FYPDPIQ_B.IUSA": "disposable_personal_income",
    "M_FRT_B.IUSA (Retail Sales Total_Bil.USD,CDASAAR)": "retail_sales",
    "M_FCBC_B.IUSA(Consumer confidence index)": "consumer_confidence",
    "M_FLBR_B.IUSA": "unemployment_rate",
}
MACROS = list(MACRO_COLUMNS.values())
ROLLING_WINDOW = 60
P_LIMIT, VIF_LIMIT, DW_LOW, DW_HIGH, JB_LIMIT = 0.05, 10.0, 1.5, 2.5, 0.05
# Additive percentage-point shocks to Baseline monthly growth, not level multipliers.
SENSITIVITY_SHOCKS_PP = (-1.0, -0.5, 0.5, 1.0)
SENSITIVITY_DURATIONS_MONTHS = (3, 6, 12)


# Feature metadata separates business meaning from string parsing.
TARGET_LAGS = {
    "consumer_card_fee_log_change_1m_pct_lag_1m": 1,
    "consumer_card_fee_log_change_1m_pct_lag_2m": 2,
}
MACRO_FEATURES = {}
for family in MACROS:
    change_name = (
        f"{family}_diff_1m_pp" if family == "unemployment_rate" else f"{family}_pct_change_1m"
    )
    MACRO_FEATURES[change_name] = (family, 1)
    MACRO_FEATURES[change_name + "_ma_3m"] = (family, 3)
# Keep the established deterministic tie order when labels change.
SELECTION_PRIORITY = {
    name: position
    for position, name in enumerate(
        [
            "consumer_price_index_pct_change_1m",
            "consumer_price_index_pct_change_1m_ma_3m",
            "consumer_confidence_pct_change_1m",
            "consumer_confidence_pct_change_1m_ma_3m",
            "disposable_personal_income_pct_change_1m",
            "disposable_personal_income_pct_change_1m_ma_3m",
            "retail_sales_pct_change_1m",
            "retail_sales_pct_change_1m_ma_3m",
            "unemployment_rate_diff_1m_pp",
            "unemployment_rate_diff_1m_pp_ma_3m",
        ]
    )
}


def save_csv(frame, path):
    """Write a calculated table without rounding its numerical values."""
    frame.to_csv(path, index=False, date_format="%Y-%m-%d", float_format="%.17g")


def read_monthly(path):
    """Read raw monthly levels and arrange observations chronologically."""
    frame = pd.read_csv(path, parse_dates=["date"], float_precision="round_trip")
    return frame.sort_values("date").reset_index(drop=True)


def load_data(data_dir):
    """Read fee history and distinct historical, Baseline and S4 macro levels."""
    revenue = read_monthly(data_dir / "fee_history.csv").rename(
        columns={"Consumer Card": "consumer_card_fee"}
    )
    history = read_monthly(data_dir / "macro_history.csv").rename(columns=MACRO_COLUMNS)
    baseline = read_monthly(data_dir / "macro_baseline.csv").rename(columns=MACRO_COLUMNS)
    stress = read_monthly(data_dir / "macro_s4.csv").rename(columns=MACRO_COLUMNS)
    macro = pd.concat([history, baseline], ignore_index=True)
    return engineer(macro.merge(revenue, on="date", how="left")), stress


def engineer(data):
    """Calculate log changes, monthly lags, calendar indicators and macro changes."""
    frame = data.copy().sort_values("date").reset_index(drop=True)
    frame.loc[frame.date > ORIGIN, "consumer_card_fee"] = np.nan
    frame["consumer_card_fee_log_change_1m_pct"] = 100.0 * np.log(frame.consumer_card_fee).diff()
    for feature, lag_months in TARGET_LAGS.items():
        frame[feature] = frame.consumer_card_fee_log_change_1m_pct.shift(lag_months)
    frame["is_january"] = (frame.date.dt.month == 1).astype(int)
    frame["is_december"] = (frame.date.dt.month == 12).astype(int)
    for feature, (family, average_months) in MACRO_FEATURES.items():
        change = (
            frame[family].diff()
            if family == "unemployment_rate"
            else 100.0 * frame[family].pct_change(fill_method=None)
        )
        frame[feature] = change if average_months == 1 else change.rolling(3, min_periods=3).mean()
    return frame


def _beta_fraction(a, b, x):
    """Continued fraction for the regularized incomplete beta function."""
    tiny, eps = 1e-300, 3e-14
    qab, qap, qam = a + b, a + 1.0, a - 1.0
    c, d = 1.0, 1.0 - qab * x / qap
    if abs(d) < tiny:
        d = tiny
    d = 1.0 / d
    result = d
    for m in range(1, 10001):
        m2 = 2 * m
        for aa in [
            m * (b - m) * x / ((qam + m2) * (a + m2)),
            -(a + m) * (qab + m) * x / ((a + m2) * (qap + m2)),
        ]:
            d = 1.0 + aa * d
            c = 1.0 + aa / c
            if abs(d) < tiny:
                d = tiny
            if abs(c) < tiny:
                c = tiny
            d = 1.0 / d
            delta = d * c
            result *= delta
        if abs(delta - 1.0) < eps:
            return result
    raise ArithmeticError("Incomplete beta continued fraction did not converge")


def student_t_two_sided(t_stat, df):
    """Two-sided Student-t p = I_[df/(df+t^2)](df/2, 1/2)."""
    if df <= 0:
        raise ValueError("Student-t requires positive residual degrees of freedom")
    x = df / (df + float(t_stat) ** 2)
    if x <= 0:
        return 0.0
    if x >= 1:
        return 1.0
    a, b = df / 2.0, 0.5
    front = math.exp(
        math.lgamma(a + b) - math.lgamma(a) - math.lgamma(b) + a * math.log(x) + b * math.log1p(-x)
    )
    p = (
        front * _beta_fraction(a, b, x) / a
        if x < (a + 1.0) / (a + b + 2.0)
        else 1.0 - front * _beta_fraction(b, a, 1.0 - x) / b
    )
    return min(1.0, max(0.0, p))


def vif_values(sample, terms):
    """Calculate each feature's VIF using an auxiliary regression with an intercept."""
    values = sample[terms].to_numpy(dtype=float)
    result = {}
    for j, term in enumerate(terms):
        target = values[:, j]
        others = np.column_stack([np.ones(len(values)), np.delete(values, j, axis=1)])
        beta = np.linalg.lstsq(others, target, rcond=None)[0]
        residual = target - others @ beta
        tss = float(np.sum((target - target.mean()) ** 2))
        r2 = 1.0 - float(residual @ residual) / tss
        result[term] = 1.0 / (1.0 - r2)
    return result


def fit_ols(frame, terms):
    """Estimate OLS and calculate coefficient inference and residual diagnostics."""
    # Differencing and two monthly lags require three prior revenue observations.
    sample = (
        frame[["date", "consumer_card_fee", "consumer_card_fee_log_change_1m_pct", *terms]]
        .dropna()
        .copy()
    )
    consumer_card_fee_log_change_1m_pct = sample.consumer_card_fee_log_change_1m_pct.to_numpy(
        dtype=float
    )
    x = np.column_stack([np.ones(len(sample)), sample[terms].to_numpy(dtype=float)])
    n, k = x.shape
    beta = np.linalg.lstsq(x, consumer_card_fee_log_change_1m_pct, rcond=None)[0]
    fitted = x @ beta
    residual = consumer_card_fee_log_change_1m_pct - fitted
    rss = float(residual @ residual)
    r2 = 1.0 - rss / float(
        np.sum(
            (consumer_card_fee_log_change_1m_pct - consumer_card_fee_log_change_1m_pct.mean()) ** 2
        )
    )
    # Classical OLS standard errors use residual variance RSS / (n - k).
    se = np.sqrt(np.diag((rss / (n - k)) * np.linalg.pinv(x.T @ x)))
    t_stats = beta / se
    # Normal-approximation p-values determine macro eligibility.
    normal_p = [math.erfc(abs(t) / math.sqrt(2.0)) for t in t_stats]
    student_p = [student_t_two_sided(t, n - k) for t in t_stats]
    z = residual / np.std(residual, ddof=0)
    skew, kurtosis = float(np.mean(z ** 3)), float(np.mean(z ** 4))
    # Jarque-Bera uses the asymptotic chi-squared distribution with two degrees of freedom.
    jb = n / 6.0 * (skew ** 2 + (kurtosis - 3.0) ** 2 / 4.0)
    vifs = vif_values(sample, terms)
    names = ["const", *terms]
    coefficients = pd.DataFrame(
        {
            "term": names,
            "coefficient": beta,
            "standard_error": se,
            "t_stat": t_stats,
            "p_normal": normal_p,
            "p_student_t": student_p,
            "vif": [np.nan] + [vifs[t] for t in terms],
        }
    )
    diagnostics = {
        "n": n,
        "parameters_including_constant": k,
        "df_resid": n - k,
        "r_squared": r2,
        "adjusted_r_squared": 1.0 - (1.0 - r2) * (n - 1) / (n - k),
        "durbin_watson": float(np.diff(residual) @ np.diff(residual) / rss),
        "jarque_bera": jb,
        "jarque_bera_p": math.exp(-jb / 2.0),
        "residual_skewness": skew,
        "residual_kurtosis": kurtosis,
        "max_vif": max(vifs.values()),
        "rss": rss,
        "first_effective_month": sample.date.iloc[0].strftime("%Y-%m-%d"),
        "last_effective_month": sample.date.iloc[-1].strftime("%Y-%m-%d"),
    }
    return {
        "params": dict(zip(names, beta)),
        "coefficients": coefficients,
        "diagnostics": diagnostics,
        "sample": sample,
        "residual": residual,
        "fitted": fitted,
    }


def forward_selection(frame):
    """Select macro features using only the fixed in-sample estimation period."""
    sample = frame.loc[frame.date.between(IN_SAMPLE_START, IN_SAMPLE_END)]
    remaining = list(MACRO_FEATURES)
    selected, trials = [], []
    round_no = 1
    while remaining:
        current = []
        for candidate in remaining:
            model = fit_ols(sample, BASE_TERMS + selected + [candidate])
            c = model["coefficients"].set_index("term").loc[candidate]
            d = model["diagnostics"]
            family_allowed = MACRO_FEATURES[candidate][0] not in {
                MACRO_FEATURES[t][0] for t in selected
            }
            row = {
                "round": round_no,
                "candidate": candidate,
                "coefficient": c.coefficient,
                "p_normal": c.p_normal,
                "p_student_t": c.p_student_t,
                "adjusted_r_squared": d["adjusted_r_squared"],
                "max_vif": d["max_vif"],
                "durbin_watson": d["durbin_watson"],
                "jarque_bera_p": d["jarque_bera_p"],
                "p_gate": c.p_normal < P_LIMIT,
                "vif_gate": d["max_vif"] < VIF_LIMIT,
                "dw_gate": DW_LOW <= d["durbin_watson"] <= DW_HIGH,
                "jb_gate": d["jarque_bera_p"] > JB_LIMIT,
                "family_allowed": family_allowed,
            }
            row["statistical_gates_pass"] = all(
                row[key] for key in ["p_gate", "vif_gate", "dw_gate", "jb_gate"]
            )
            row["eligible"] = row["statistical_gates_pass"] and family_allowed
            row["selected"] = False
            current.append(row)
        # Select the smallest eligible p-value; adjusted R-squared breaks ties.
        passing = sorted(
            [r for r in current if r["eligible"]],
            key=lambda r: (
                r["p_normal"],
                -r["adjusted_r_squared"],
                SELECTION_PRIORITY[r["candidate"]],
            ),
        )
        if passing:
            winner = passing[0]
            winner["selected"] = True
            selected.append(winner["candidate"])
            remaining.remove(winner["candidate"])
        trials.extend(current)
        if not passing:
            break
        round_no += 1
    return selected, pd.DataFrame(trials)


def static_predictions(frame, model, terms, start, end):
    """Use observed target lags and the observed prior-month fee for each prediction."""
    sample = (
        frame.loc[
            frame.date.between(start, end),
            ["date", "consumer_card_fee", "consumer_card_fee_log_change_1m_pct", *terms],
        ]
        .dropna()
        .copy()
    )
    x = np.column_stack([np.ones(len(sample)), sample[terms].to_numpy(dtype=float)])
    predicted_y = x @ np.asarray([model["params"][t] for t in ["const", *terms]])
    prior = (
        frame.set_index("date")
        .consumer_card_fee.shift(1)
        .reindex(sample.date)
        .to_numpy(dtype=float)
    )
    return pd.DataFrame(
        {
            "date": sample.date,
            "actual_fee": sample.consumer_card_fee,
            "actual_log_change_1m_pct": sample.consumer_card_fee_log_change_1m_pct,
            "predicted_log_change_1m_pct": predicted_y,
            "predicted_fee": prior * np.exp(predicted_y / 100.0),
            "fee_lag_1m_input": prior,
            "residual_log_change_1m_pct": sample.consumer_card_fee_log_change_1m_pct - predicted_y,
        }
    )


def recursive_predictions(frame, model, terms, start, end, include_actual=False):
    """Follow a fixed-origin path, updating target lags and fee levels with predictions."""
    source = frame.set_index("date")
    # Only observations strictly before the origin enter the recursive states.
    history = source.loc[source.index < start]
    changes, levels = (
        history.consumer_card_fee_log_change_1m_pct.dropna().to_dict(),
        history.consumer_card_fee.dropna().to_dict(),
    )
    rows = []
    for date in pd.date_range(start, end, freq="MS"):
        inputs = {}
        for term in terms:
            inputs[term] = (
                changes[date - pd.DateOffset(months=TARGET_LAGS[term])]
                if term in TARGET_LAGS
                else float(source.at[date, term])
            )
        predicted_y = float(
            model["params"]["const"] + sum(model["params"][t] * inputs[t] for t in terms)
        )
        prior = levels[date - pd.DateOffset(months=1)]
        prediction = float(prior * math.exp(predicted_y / 100.0))
        row = {
            "date": date,
            "predicted_log_change_1m_pct": predicted_y,
            "predicted_fee": prediction,
            "fee_lag_1m_input": prior,
            **{t + "_input": v for t, v in inputs.items()},
        }
        if include_actual:
            # Actual OOT fees are attached only for calculating forecast errors.
            row["actual_fee"] = float(source.at[date, "consumer_card_fee"])
        rows.append(row)
        changes[date], levels[date] = predicted_y, prediction
    return pd.DataFrame(rows)


def accuracy(frame, name):
    """Calculate level-based MAPE in percent and RMSE in fee source units."""
    error = frame.actual_fee - frame.predicted_fee
    return {
        "method": name,
        "n": len(frame),
        "mape_pct": float(np.mean(np.abs(error / frame.actual_fee)) * 100),
        "rmse": float(np.sqrt(np.mean(error ** 2))),
    }


def rolling_coefficients(frame, terms):
    """Refit the same equation in fixed 60-month windows, moving one month at a time."""
    sample = (
        frame.loc[
            frame.date.between(IN_SAMPLE_START, ORIGIN),
            ["date", "consumer_card_fee", "consumer_card_fee_log_change_1m_pct", *terms],
        ]
        .dropna()
        .reset_index(drop=True)
    )
    rows = []
    for stop in range(ROLLING_WINDOW, len(sample) + 1):
        window = sample.iloc[stop - ROLLING_WINDOW : stop]
        model = fit_ols(window, terms)
        row = {"window_start": window.date.iloc[0], "date": window.date.iloc[-1], "n": len(window)}
        for term in terms:
            row[term] = model["params"][term]
            row[term + "_standardized"] = (
                row[term]
                * window[term].std(ddof=1)
                / window.consumer_card_fee_log_change_1m_pct.std(ddof=1)
            )
        rows.append(row)
    result = pd.DataFrame(rows)
    summary = pd.DataFrame(
        [
            {
                "term": term,
                "windows": len(result),
                "minimum": result[term].min(),
                "maximum": result[term].max(),
                "positive_windows": int((result[term] > 0).sum()),
                "negative_windows": int((result[term] < 0).sum()),
                "sign_changes": int(np.count_nonzero(np.diff(np.sign(result[term])))),
            }
            for term in terms
        ]
    )
    return result, summary


def scenario_predictions(frame, stress, production, terms):
    """Apply one production equation to the baseline and S4 retail-sales paths."""
    scenarios = []
    for name in ["Baseline", "S4"]:
        current = frame.copy()
        if name == "S4":
            # Common history ends at December 2025. Only future macro levels differ.
            mask = current.date.between(FORECAST_START, FORECAST_END)
            current.loc[mask, "retail_sales"] = (
                stress.set_index("date").loc[current.loc[mask, "date"], "retail_sales"].to_numpy()
            )
            current["retail_sales_pct_change_1m"] = 100 * current.retail_sales.pct_change(
                fill_method=None
            )
            current[
                "retail_sales_pct_change_1m_ma_3m"
            ] = current.retail_sales_pct_change_1m.rolling(3).mean()
        prediction = recursive_predictions(current, production, terms, FORECAST_START, FORECAST_END)
        prediction.insert(1, "scenario", name)
        prediction["retail_sales"] = (
            current.set_index("date").loc[prediction.date, "retail_sales"].to_numpy()
        )
        scenarios.append(prediction)
    forecasts = pd.concat(scenarios, ignore_index=True)
    wide = forecasts.pivot(index="date", columns="scenario", values="predicted_fee")
    rows = []
    for label, start, end in [
        ("2026", "2026-01-01", "2026-12-01"),
        ("2027", "2027-01-01", "2027-12-01"),
        ("2028 Jan-Mar", "2028-01-01", "2028-03-01"),
        ("27-month total", "2026-01-01", "2028-03-01"),
    ]:
        part = wide.loc[start:end]
        b, s = part.Baseline, part.S4
        rows.append(
            {
                "period": label,
                "months": len(part),
                "baseline_average": float(b.mean()),
                "s4_average": float(s.mean()),
                "baseline_total": float(b.sum()),
                "s4_total": float(s.sum()),
                "s4_vs_baseline_pct": float(100 * (s.sum() / b.sum() - 1)),
            }
        )
    return forecasts, pd.DataFrame(rows)


def quarterly_scenario_summary(forecasts):
    """Sum monthly fee forecasts into calendar quarters and cumulative totals."""
    monthly = forecasts.loc[forecasts.date.between(FORECAST_START, FORECAST_END)]
    wide = monthly.pivot(index="date", columns="scenario", values="predicted_fee")
    # Fee revenue is an additive flow. Sum levels, not log changes or monthly averages.
    quarters = wide.groupby(wide.index.to_period("Q-DEC")).sum(min_count=3)
    rows = [
        {
            "period": str(quarter),
            "months": 3,
            "baseline_total": float(totals.Baseline),
            "s4_total": float(totals.S4),
        }
        for quarter, totals in quarters.iterrows()
    ]
    # Sum only the quarterly detail, so subtotal rows are never counted twice.
    first_year = quarters.loc[quarters.index.year == FORECAST_START.year]
    for label, part in [
        (f"{FORECAST_START.year} total", first_year),
        (f"{len(quarters)}-quarter total", quarters),
    ]:
        rows.append(
            {
                "period": label,
                "months": 3 * len(part),
                "baseline_total": float(part.Baseline.sum()),
                "s4_total": float(part.S4.sum()),
            }
        )
    return pd.DataFrame(rows)


def retail_sales_growth_shock(frame, shock_pp, duration_months):
    """Rebuild future retail-sales levels from a temporary MoM growth shock.

    The shock starts in January 2026. Once it ends, growth returns to Baseline,
    but the accumulated level difference is retained. No level reset is applied.
    """
    dates = pd.date_range(FORECAST_START, FORECAST_END, freq="MS")
    if not np.isfinite(shock_pp):
        raise ValueError("The growth shock must be a finite number of percentage points")
    if (isinstance(duration_months, bool)
            or not isinstance(duration_months, (int, np.integer))
            or not 1 <= duration_months <= len(dates)):
        raise ValueError(f"Shock duration must be an integer from 1 to {len(dates)} months")
    source = frame.set_index("date").sort_index()
    if not source.index.is_unique:
        raise ValueError("Sensitivity inputs require unique monthly dates")
    required = pd.date_range(FORECAST_START - pd.DateOffset(months=1), FORECAST_END, freq="MS")
    levels = source.retail_sales.reindex(required)
    if not np.isfinite(levels).all() or (levels <= 0).any():
        raise ValueError("Sensitivity requires positive retail-sales levels from the origin through the horizon")

    # Derive each Baseline growth rate from the unchanged source levels.
    baseline_growth = 100.0 * levels.pct_change(fill_method=None).loc[dates]
    shocked_growth = baseline_growth.copy()
    shocked_growth.iloc[:duration_months] += float(shock_pp)
    if (shocked_growth <= -100.0).any():
        raise ValueError("Shocked monthly growth must remain greater than -100 percent")
    previous = float(levels.iloc[0])
    future_levels = []
    for growth in shocked_growth:
        previous *= 1.0 + float(growth) / 100.0
        if not math.isfinite(previous) or previous <= 0:
            raise ValueError("The growth shock produced an invalid retail-sales level")
        future_levels.append(previous)
    source.loc[dates, "retail_sales"] = future_levels
    # Recompute growth and MA3 from rebuilt levels, including unchanged history.
    return engineer(source.reset_index())


def sensitivity_summaries(monthly):
    """Aggregate fee levels and describe each sensitivity relative to Baseline."""
    quarterly_rows, summary_rows = [], []
    metadata = ["scenario", "shock_pp", "shock_duration_months", "shock_start", "shock_end"]
    for _, group in monthly.groupby("scenario", sort=False):
        group = group.sort_values("date")
        info = {name: group.iloc[0][name] for name in metadata}
        quarters = list(group.groupby(group.date.dt.to_period("Q-DEC"), sort=True))
        periods = [(str(quarter), part) for quarter, part in quarters]
        periods += [
            (f"{FORECAST_START.year} total", group.loc[group.date.dt.year == FORECAST_START.year]),
            (f"{len(quarters)}-quarter total", group),
        ]
        totals = []
        for label, part in periods:
            baseline = float(part.baseline_predicted_fee.sum())
            sensitivity = float(part.predicted_fee.sum())
            row = {
                **info, "period": label, "months": len(part),
                "baseline_total": baseline, "sensitivity_total": sensitivity,
                "fee_impact": sensitivity - baseline,
                "fee_impact_pct": 100.0 * (sensitivity / baseline - 1.0),
            }
            quarterly_rows.append(row)
            totals.append(row)
        year, horizon = totals[-2:]
        peak = group.loc[group.fee_impact.abs().idxmax()]
        peak_pct = group.loc[group.fee_impact_pct.abs().idxmax()]
        terminal = group.iloc[-1]
        summary_rows.append({
            **info, "year": FORECAST_START.year,
            "year_baseline_total": year["baseline_total"],
            "year_sensitivity_total": year["sensitivity_total"],
            "year_fee_impact": year["fee_impact"],
            "year_fee_impact_pct": year["fee_impact_pct"],
            "horizon_months": horizon["months"],
            "horizon_baseline_total": horizon["baseline_total"],
            "horizon_sensitivity_total": horizon["sensitivity_total"],
            "horizon_fee_impact": horizon["fee_impact"],
            "horizon_fee_impact_pct": horizon["fee_impact_pct"],
            "peak_absolute_fee_impact_month": peak.date,
            "peak_absolute_fee_impact": abs(float(peak.fee_impact)),
            "fee_impact_at_peak": peak.fee_impact,
            "fee_impact_pct_at_peak": peak.fee_impact_pct,
            "peak_absolute_pct_impact_month": peak_pct.date,
            "peak_absolute_pct_impact": abs(float(peak_pct.fee_impact_pct)),
            "terminal_month": terminal.date,
            "terminal_baseline_fee": terminal.baseline_predicted_fee,
            "terminal_sensitivity_fee": terminal.predicted_fee,
            "terminal_fee_impact": terminal.fee_impact,
            "terminal_fee_impact_pct": terminal.fee_impact_pct,
        })
    return pd.DataFrame(quarterly_rows), pd.DataFrame(summary_rows)


def retail_sales_sensitivities(frame, production, terms, baseline_forecast,
                               shocks_pp=SENSITIVITY_SHOCKS_PP,
                               durations_months=SENSITIVITY_DURATIONS_MONTHS):
    """Forecast growth-shock cases using one already-estimated production model."""
    if "retail_sales_pct_change_1m_ma_3m" not in terms:
        raise ValueError("Retail-sales MA3 is not selected; review the sensitivity setup for this model")
    if not len(shocks_pp) or not len(durations_months):
        raise ValueError("Supply at least one shock magnitude and one duration")
    if len(set(shocks_pp)) != len(shocks_pp) or len(set(durations_months)) != len(durations_months):
        raise ValueError("Sensitivity magnitudes and durations must not contain duplicates")
    source = frame.set_index("date")
    baseline = baseline_forecast.set_index("date")
    paths = []
    for shock_pp in shocks_pp:
        for duration in durations_months:
            current = retail_sales_growth_shock(frame, shock_pp, duration)
            # No selection or refit occurs here. Every case shares the production coefficients.
            prediction = recursive_predictions(current, production, terms, FORECAST_START, FORECAST_END)
            if not np.isfinite(prediction.predicted_fee).all() or (prediction.predicted_fee <= 0).any():
                raise ValueError("Sensitivity forecast requires finite, positive fee predictions")
            prediction.insert(1, "scenario", f"retail_sales_mom_{shock_pp:+g}pp_{duration}m")
            prediction["shock_pp"] = float(shock_pp)
            prediction["shock_duration_months"] = int(duration)
            prediction["shock_start"] = FORECAST_START
            prediction["shock_end"] = FORECAST_START + pd.DateOffset(months=int(duration) - 1)
            prediction["applied_growth_shock_pp"] = np.where(
                prediction.date <= prediction.shock_end, float(shock_pp), 0.0
            )
            rebuilt = current.set_index("date")
            for feature in ["retail_sales", "retail_sales_pct_change_1m", "retail_sales_pct_change_1m_ma_3m"]:
                prediction["baseline_" + feature] = source.loc[prediction.date, feature].to_numpy()
                prediction[feature] = rebuilt.loc[prediction.date, feature].to_numpy()
            prediction["baseline_predicted_fee"] = baseline.loc[prediction.date, "predicted_fee"].to_numpy()
            prediction["baseline_predicted_log_change_1m_pct"] = baseline.loc[
                prediction.date, "predicted_log_change_1m_pct"
            ].to_numpy()
            prediction["fee_impact"] = prediction.predicted_fee - prediction.baseline_predicted_fee
            prediction["fee_impact_pct"] = 100.0 * prediction.fee_impact / prediction.baseline_predicted_fee
            paths.append(prediction)
    monthly = pd.concat(paths, ignore_index=True)
    quarterly, summary = sensitivity_summaries(monthly)
    return {"sensitivity_monthly": monthly, "sensitivity_quarterly_summary": quarterly,
            "sensitivity_summary": summary}


def analyze(frame, stress, sensitivity_shocks_pp=SENSITIVITY_SHOCKS_PP,
            sensitivity_durations_months=SENSITIVITY_DURATIONS_MONTHS):
    """Run selection, estimation, forecast accuracy, rolling analysis, and scenarios."""
    selected, screening = forward_selection(frame)
    terms = BASE_TERMS + selected
    base = fit_ols(frame.loc[frame.date.between(IN_SAMPLE_START, IN_SAMPLE_END)], BASE_TERMS)
    development = fit_ols(frame.loc[frame.date.between(IN_SAMPLE_START, IN_SAMPLE_END)], terms)
    production = fit_ols(frame.loc[frame.date.between(IN_SAMPLE_START, ORIGIN)], terms)
    in_sample = static_predictions(frame, development, terms, IN_SAMPLE_START, IN_SAMPLE_END)
    static_oot = static_predictions(frame, development, terms, OOT_START, ORIGIN)
    recursive_oot = recursive_predictions(
        frame, development, terms, OOT_START, ORIGIN, include_actual=True
    )
    rolling, rolling_summary = rolling_coefficients(frame, terms)
    forecasts, forecast_summary = scenario_predictions(frame, stress, production, terms)
    metrics = pd.DataFrame(
        [
            accuracy(in_sample, "Static In-sample"),
            accuracy(static_oot, "Static OOT"),
            accuracy(recursive_oot, "Recursive OOT"),
        ]
    )
    models = [
        ("Base In-sample", base),
        ("Selected In-sample", development),
        ("Production refit", production),
    ]
    diagnostics = pd.DataFrame([{"model": name, **model["diagnostics"]} for name, model in models])
    coefficients = pd.concat(
        [model["coefficients"].assign(model=name) for name, model in models], ignore_index=True
    )
    tables = {
        "model_diagnostics": diagnostics,
        "coefficients": coefficients,
        "macro_screening": screening,
        "forecast_accuracy": metrics,
        "static_in_sample": in_sample,
        "static_oot": static_oot,
        "recursive_oot": recursive_oot,
        "rolling_coefficients": rolling,
        "rolling_summary": rolling_summary,
        "forecast_monthly": forecasts,
        "forecast_summary": forecast_summary,
        "forecast_quarterly_summary": quarterly_scenario_summary(forecasts),
        "historical_data_and_features": frame.loc[
            frame.date.between(IN_SAMPLE_START, ORIGIN)
        ].copy(),
    }
    tables.update(retail_sales_sensitivities(
        frame, production, terms, forecasts.loc[forecasts.scenario == "Baseline"],
        sensitivity_shocks_pp, sensitivity_durations_months,
    ))
    return {
        "tables": tables,
        "selected": selected,
        "terms": terms,
        "development": development,
        "production": production,
    }


def main():
    """Read the input files, calculate the model, and save statistical result tables."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-dir", type=Path, default=ROOT / "data")
    parser.add_argument("--output-dir", type=Path, default=ROOT / "results")
    parser.add_argument("--sensitivity-shocks-pp", type=float, nargs="+", default=SENSITIVITY_SHOCKS_PP,
                        help="Additive Retail Sales MoM growth shocks in percentage points")
    parser.add_argument("--sensitivity-durations-months", type=int, nargs="+",
                        default=SENSITIVITY_DURATIONS_MONTHS, help="Shock durations from January 2026")
    args = parser.parse_args()
    data_dir, output = args.data_dir.resolve(), args.output_dir.resolve()
    # Keep previous result files intact when choosing an output folder.
    if output.exists() and any(output.iterdir()):
        raise FileExistsError(f"Choose a new or empty output directory: {output}")
    frame, stress = load_data(data_dir)
    result = analyze(frame, stress, args.sensitivity_shocks_pp, args.sensitivity_durations_months)
    output.mkdir(parents=True, exist_ok=True)
    for name, table in result["tables"].items():
        save_csv(table, output / (name + ".csv"))
    print(result["tables"]["forecast_accuracy"].to_string(index=False))
    print("\nQuarterly fee forecasts (totals in original fee source units):")
    print(
        result["tables"]["forecast_quarterly_summary"].to_string(
            index=False, float_format=lambda value: f"{value:,.2f}"
        )
    )
    print("\nRetail Sales growth sensitivities (totals in original fee source units):")
    print(result["tables"]["sensitivity_summary"][[
        "scenario", "year_sensitivity_total", "year_fee_impact_pct",
        "horizon_sensitivity_total", "horizon_fee_impact_pct",
    ]].to_string(index=False, float_format=lambda value: f"{value:,.2f}"))
    print(f"Selected macro: {', '.join(result['selected'])}")
    print(f"Rolling windows: {len(result['tables']['rolling_coefficients'])}")
    print(f"Results saved to: {output}")


if __name__ == "__main__":
    main()
