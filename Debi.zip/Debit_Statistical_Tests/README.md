# Debit deck 统计检验代码与数据

本包对应 `Debit_Qualitative_Model_Jan2013_NoNotes.pptx` 的当前 14 页版本。只有一个独立的 Python 主程序，不依赖原工作目录、不需要 Excel，也不会修改 deck。

## 运行

建议 Python 3.10 或更新版本。在解压目录打开终端：

```bash
python -m pip install -r requirements.txt
python debit_statistical_tests.py
```

运行结果写入 `results/`。为保护已有结果，程序不会覆盖非空目录。再次运行可指定新目录：

```bash
python debit_statistical_tests.py --output-dir results_second_run
```

`example_results/` 是本次实际运行生成的结果，可直接查看。测试环境的确切版本见其中的 `run_manifest.json`。依赖文件给出兼容范围，不要求使用项目内环境或特定本机路径。

## 包含内容

- `debit_statistical_tests.py`：数据处理、四条回归筛选路径、检验、描述性统计和核对代码。
- `data/monthly_fee_and_macro.csv`：2011.1–2025.12 的 180 个月原始 Debit 收入及 14 个宏观候选变量。包括建模所需的全部观测，不需要另外下载数据。
- `data/data_dictionary.csv`：字段含义和原始工作簿列名。原表未明确收入金额的数量级，代码沿用原单位。
- `data/document_reference_values.csv`：按《Debit Card Fee Model》记录的展示值和采用值。
- `data/deck_reference_values.csv`：从当前 deck 核对的 70 个数字展示项，含重复出现在不同页的指标。
- `data/deck_chart_series.json`：当前 deck 的 11 条原生图表序列，共 506 个数据点及其日期/月份标签。
- `data/regression_reference_summary.csv`：与第 6 页对应的既有筛选结果，用于复跑核对，不参与模型选择。
- `data/source_manifest.json`：来源文件、提取规则、版本指纹和输入文件 SHA-256。

## 统计检验与 deck 对应

| 页码 | 检验或统计量 | 代码函数 | 口径 |
|---|---|---|---|
| 6 | 新增项双侧 t 检验 | `fit_candidate` / `forward_screen` | 经典 OLS 标准误，p < 0.05 |
| 6 | Durbin–Watson | `fit_candidate` | 残差 DW ∈ [1.5, 2.5]，端点包含 |
| 6 | Jarque–Bera | `fit_candidate` | 残差正态性，p > 0.05 |
| 6 | VIF | `fit_candidate` | 所有非截距项 VIF < 10 |
| 11 | Shapiro–Wilk | `descriptive_statistics` | 2015 Q1–2025 Q4 的 44 个季度收入 |
| 8–12 | 均值、标准差、偏度、最小值、跌幅 | `descriptive_statistics` | 标准差主口径 ddof=1，偏度主口径 bias=True |
| 3–5、7 | 样本范围、异常值替换、月度变化 | `clean_revenue` / `descriptive_statistics` | 业务确认的两次异常值替换，其他观测不变 |

DW、VIF 和描述性统计不是有 p 值的假设检验。程序另外输出总体标准差（ddof=0）和修正偏度（bias=False），避免混淆统计定义。Shapiro–Wilk 检验的是季度收入，不是某个回归的残差。

## 回归复现规则

先删除全部 2011 年，再计算增长率和滞后。March 2012 从 1,650 替换为 (694 + 1,013) / 2 = 853.5。December 2012 从 2,916 替换为 (912 + 649) / 2 = 780.5。保留 2014 年数据，不添加 2015 年事件虚拟变量，也不额外季调。

训练及选择截止 2023.9，初始训练池共 141 个月。2023.10–2025.12 只用于历史展示和 qualitative model 的统计，不进入回归选择。每条路径使用所有候选项共同可用的固定样本：

| 路径 | 候选项 | 有效样本 | 有效区间 |
|---|---:|---:|---|
| Level ARDL | 收入 lag 1–12，14 个宏观 lag 0–12，共 194 项 | 129 月 | 2013.1–2023.9 |
| YoY 静态前置筛选 | 14 个当期宏观项 | 129 月 | 2013.1–2023.9 |
| MoM ARDL | 收入 lag 1–12，14 个宏观 lag 0–12，共 194 项 | 128 月 | 2013.2–2023.9 |
| QoQ ARDL | 收入 lag 1–4，14 个宏观 lag 0–4，共 74 项 | 42 季 | 2013 Q2–2023 Q3 |

Level 使用水平值。MoM/YoY 分别使用 1/12 个月百分比变化。QoQ 先加总季度收入，宏观量取季末月，再计算季度百分比变化。失业率始终取相应期间的百分点差值。

各路径从只有截距的模型开始，逐个试加一个候选项，四项门槛必须同时满足。多个合格候选按新增项 p 值升序、调整 R² 降序、名称升序排序。没有强制 AR(1)、联合加入多个变量或后向删除。每条路径首轮均无合格项，因此没有最终回归。

这是 deck 第 6 页所使用研究方案的复现。宏观池、最大滞后、共同样本及季度末宏观口径来自该研究方案，并非声称原模型文档明确规定了全部搜索细节。YoY 未进入 EG、ECT 或 ECM 阶段，不能写成这些后续检验失败。当前 deck 未报告 ADF/KPSS、Chow、BG、ARCH 或 RESET，本包不将它们混入 deck 结果。

## 运行结果与 deck 的差异

先看 `example_results/RECONCILIATION.md` 和 `deck_differences_only.csv`，完整逐项核对在 `deck_reconciliation.csv`。

- 四条路径的候选数、零入选结果和失败原因均与 deck 一致。共复算 476 个候选回归。
- Shapiro–Wilk p = 0.053409775，与 deck 的 0.053 一致。偏度 0.526425508，与 0.53 一致。Baseline 4,747.625，与 4,747.6 一致。
- 文档/展示值与底层收入重算值存在差异：post-2015 均值为 4,553.9 对 4,553.090909；标准差 369.0 对 369.718738；季度 stress floor 3,815.9 对 3,813.653434；2019 H2 均值 4,264 对 4,246。派生跌幅和倍数也因此不同。
- `document_adopted_values.csv` 保留文档参数及据此计算的结果。`recomputed_statistics.csv` 保留原始数据直接重算结果。代码不调整原始数据以匹配文档，不把文档提供的 p 值当成新运行的检验结果。Deck 没有被修改。
- 70 个数字展示项中有 14 处超出展示精度容差，其中包含同一指标在不同页的重复展示。11 条图表序列均与其明确的数据依据一致：收入线使用原始/处理后观测，baseline 和 stress floor 水平线使用文档采用值。

核对使用显示小数位的半个末位单位作为容差，保留原始差值。季度均值和 stress floor 不因展示值而重新定义。

## 结果文件

`regression_summary.csv` 给出各门槛通过数量；`candidate_trials/` 保留每个候选的系数、标准误、t、p、DW、JB、偏度、峰度、VIF 和拒绝原因；`design_matrices/` 保留实际建模矩阵。单项门槛计数会重叠，不能相加。

`monthly_raw_and_adjusted.csv`、`quarterly_fee.csv` 和 `outlier_chart_2012_01_to_2013_01.csv` 保留处理后数据。`chart_data_reconciliation.csv` 和 `deck_narrative_checks.csv` 分别核对图表和失败原因文字。

## 解释边界与验证

OLS 和 JB p 值没有针对变量搜索做多重比较或选择后调整。首步未找到模型，不等于所有多变量组合均失败。DW 区间不能证明含滞后因变量的模型没有自相关。首轮只有一个解释项时 VIF 为 1，不能据此断言多变量模型没有共线性。

Shapiro–Wilk 在 5% 下未拒绝正态性，不等于证明正态分布、独立性或均值减两倍标准差具有某个保证覆盖率。2014 异常与 2015 水平变化只做描述性核对，不宣称已通过正式结构突变检验或查明因果。

程序验证输入哈希、连续日期、两处替换、门槛边界和参考结果；对全部候选独立复算最小二乘拟合值、DW 和 JB。将 2011 年及训练截止后的数据放大 100 倍不会改变任何回归设计矩阵，以检查数据泄漏。完整环境版本和检查记录见 `run_manifest.json`。
