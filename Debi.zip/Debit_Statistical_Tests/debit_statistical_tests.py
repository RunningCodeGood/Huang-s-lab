#!/usr/bin/env python3
"""Reproduce statistical work in the Debit Card qualitative-model deck.

One executable file. No imports from the original workspace and no network or
Excel dependency. Run: python debit_statistical_tests.py

Statistical scope: classical OLS coefficient t tests, Durbin-Watson statistic,
Jarque-Bera residual normality, VIF, and Shapiro-Wilk on 44 quarterly revenues.
Descriptive statistics and every numerical deck comparison are also exported.
Reported model-document values are preserved separately from recalculations.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import platform
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd
import scipy
from scipy.stats import chi2, shapiro, skew
import statsmodels
from statsmodels.regression.linear_model import OLS
from statsmodels.tools.tools import add_constant
from statsmodels.stats.stattools import durbin_watson, jarque_bera
from statsmodels.stats.outliers_influence import variance_inflation_factor

BASE = Path(__file__).resolve().parent
TRAIN_START = '2012-01-01'
TRAIN_END = '2023-09-30'
HISTORY_END = '2025-12-31'
MACROS = ['Unrate', 'CPI', 'DPI', 'RetailSalesTotal', 'ConsumerConfidence',
          'SBOpt', 'GDP_Wholesale', 'IP', 'CorpProfits', 'DJ_TotalMkt',
          'GrocerySales', 'GasolineSales', 'NonstoreSales', 'PrivateEmployment']
ROUTES = ('Level', 'YoY_static_screen', 'MoM', 'QoQ_quarterly')


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save_json(value, path):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2,
                                   allow_nan=False) + '\n', encoding='utf-8')


def save_csv(frame, path, indexed=False):
    frame.to_csv(path, index=indexed, index_label='date' if indexed else None,
                 date_format='%Y-%m-%d', encoding='utf-8-sig')


def require(condition, message):
    if not condition:
        raise ValueError(message)


def load_inputs(data_dir):
    manifest = json.loads((data_dir / 'source_manifest.json').read_text(encoding='utf-8'))
    for name, expected in manifest['data_files'].items():
        require(sha256(data_dir / name) == expected, f'Input checksum mismatch: {name}')
    raw = pd.read_csv(data_dir / 'monthly_fee_and_macro.csv', parse_dates=['date'],
                      float_precision='round_trip').set_index('date')
    require(list(raw.columns) == ['Debit_raw', *MACROS], 'Unexpected input columns')
    require(raw.index.equals(pd.date_range('2011-01-01', '2025-12-01', freq='MS')),
            'Input must contain exactly one row per month from 2011-01 to 2025-12')
    require(np.isfinite(raw.to_numpy()).all(), 'Missing or non-finite input value')
    reported = pd.read_csv(data_dir / 'document_reference_values.csv')
    return raw, reported, manifest


def clean_revenue(raw):
    """Only the two business-confirmed expense reversals are replaced."""
    clean = raw.copy()
    clean['Debit'] = clean.Debit_raw
    replacements = []
    for date in ('2012-03-01', '2012-12-01'):
        t = pd.Timestamp(date)
        previous = float(raw.at[t - pd.offsets.MonthBegin(1), 'Debit_raw'])
        following = float(raw.at[t + pd.offsets.MonthBegin(1), 'Debit_raw'])
        replacement = (previous + following) / 2
        clean.at[t, 'Debit'] = replacement
        replacements.append(dict(date=date, raw_fee=float(raw.at[t, 'Debit_raw']),
                                 previous_month=previous, next_month=following,
                                 adjusted_fee=replacement))
    require(clean.at[pd.Timestamp('2012-03-01'), 'Debit'] == 853.5, 'March replacement')
    require(clean.at[pd.Timestamp('2012-12-01'), 'Debit'] == 780.5, 'December replacement')
    changed = clean.index[clean.Debit != clean.Debit_raw]
    require(list(changed.strftime('%Y-%m-%d')) == ['2012-03-01', '2012-12-01'],
            'Unexpected revenue modification')
    return clean, pd.DataFrame(replacements)


def make_design(frame, horizon, lagmax, static=False):
    """Transform only after excluding 2011 and the post-2023Q3 observations.

    All candidates in a route use the same complete-case dates. For percentage
    changes, unemployment uses a difference in percentage points instead.
    """
    data = frame[['Debit', *MACROS]].copy()
    transformed = data.copy() if horizon == 0 else 100 * data.pct_change(horizon, fill_method=None)
    if horizon:
        transformed['Unrate'] = data.Unrate.diff(horizon)
    target = transformed.Debit.rename('target')
    columns = {}
    if not static:
        for lag in range(1, lagmax + 1):
            columns[f'y_L{lag}'] = target.shift(lag)
    for macro in MACROS:
        for lag in range(1 if static else lagmax + 1):
            columns[f'{macro}_L{lag}'] = transformed[macro].shift(lag)
    design = pd.concat([target, pd.DataFrame(columns)], axis=1).dropna()
    require(design.index.max() <= pd.Timestamp(TRAIN_END), 'Post-cutoff data in fit')
    require(np.isfinite(design.to_numpy()).all(), 'Invalid transformed value')
    return design, list(columns)


def all_designs(clean):
    # There is no 2011 warm-up for lags or growth-rate denominators.
    train = clean.loc[TRAIN_START:TRAIN_END].copy()
    require(len(train) == 141, 'Training pool must have 141 months')
    quarterly = train.resample('QE').last()
    quarterly['Debit'] = train.Debit.resample('QE').sum(min_count=3)
    # Revenue is additive. Macro rates/indices use the quarter-end observation.
    return {
        'Level': make_design(train, 0, 12),
        'YoY_static_screen': make_design(train, 12, 0, static=True),
        'MoM': make_design(train, 1, 12),
        'QoQ_quarterly': make_design(quarterly, 1, 4),
    }


def gate_flags(p_new, dw, jb_p, max_vif):
    """DW and VIF are diagnostic cutoffs, not p-value tests."""
    return dict(significance_pass=bool(p_new < .05),
                DW_pass=bool(1.5 <= dw <= 2.5),
                JB_pass=bool(jb_p > .05), VIF_pass=bool(max_vif < 10))


def fit_candidate(frame, terms):
    x = add_constant(frame[terms], has_constant='add')
    require(np.linalg.matrix_rank(x.to_numpy()) == x.shape[1], 'Rank-deficient design')
    model = OLS(frame.target, x, missing='raise').fit()
    require(model.df_resid > 0, 'No residual degrees of freedom')
    jb, jb_p, residual_skew, residual_kurtosis = jarque_bera(model.resid)
    vifs = [variance_inflation_factor(model.model.exog, i)
            for i in range(1, len(model.params))]
    stats = dict(n=int(model.nobs), df_resid=float(model.df_resid),
                 R2=float(model.rsquared), adj_R2=float(model.rsquared_adj),
                 DW=float(durbin_watson(model.resid)), JB=float(jb), JB_p=float(jb_p),
                 residual_skew=float(residual_skew), residual_kurtosis=float(residual_kurtosis),
                 max_VIF=float(max(vifs, default=1.0)))
    # Independent checks, for every candidate rather than only an accepted one.
    fitted = model.model.exog @ np.linalg.lstsq(model.model.exog, frame.target, rcond=None)[0]
    np.testing.assert_allclose(fitted, model.fittedvalues, rtol=1e-8, atol=1e-7)
    residual = frame.target.to_numpy() - fitted
    dw_manual = np.sum(np.diff(residual)**2) / np.sum(residual**2)
    centered = residual - residual.mean()
    m2 = np.mean(centered**2)
    jb_manual = len(centered) / 6 * ((np.mean(centered**3) / m2**1.5)**2
                  + (np.mean(centered**4) / m2**2 - 3)**2 / 4)
    np.testing.assert_allclose(dw_manual, stats['DW'], rtol=1e-9)
    np.testing.assert_allclose(jb_manual, stats['JB'], rtol=1e-7, atol=1e-8)
    np.testing.assert_allclose(chi2.sf(jb_manual, 2), stats['JB_p'], rtol=1e-7, atol=1e-250)
    return model, stats


def forward_screen(frame, pool, approach):
    """Reproduce the deck's single-term forward protocol, including failures.

    Intercept-only seed. No forced AR term, joint additions or backward removal.
    Each step ranks passing candidates by new-term p, then adjusted R2, then name.
    No accepted first addition means no final regression, not an intercept model.
    """
    selected, remaining, trials = [], list(pool), []
    while remaining:
        rows = []
        for candidate in remaining:
            model, stats = fit_candidate(frame, selected + [candidate])
            row = dict(approach=approach, round=len(selected)+1, candidate=candidate,
                       existing_terms=';'.join(selected),
                       coefficient=float(model.params[candidate]),
                       coefficient_se=float(model.bse[candidate]),
                       t_stat=float(model.tvalues[candidate]), p_new=float(model.pvalues[candidate]),
                       **stats)
            flags = gate_flags(row['p_new'], row['DW'], row['JB_p'], row['max_VIF'])
            row.update(flags)
            row['passes'] = all(flags.values())
            row['failed_gates'] = ';'.join(k.removesuffix('_pass') for k,v in flags.items() if not v)
            rows.append(row)
        passing = sorted((r for r in rows if r['passes']),
                         key=lambda r: (r['p_new'], -r['adj_R2'], r['candidate']))
        winner = passing[0]['candidate'] if passing else None
        for row in rows:
            row['chosen'] = row['candidate'] == winner
        trials.extend(rows)
        if winner is None:
            break
        selected.append(winner)
        remaining.remove(winner)
    trial_frame = pd.DataFrame(trials)
    first = trial_frame.loc[trial_frame['round'] == 1]
    summary = dict(approach=approach, n=len(frame), start=str(frame.index.min().date()),
                   end=str(frame.index.max().date()), candidate_count=len(pool),
                   selected_terms=';'.join(selected), final_model_found=bool(selected),
                   **{k:int(first[k].sum()) for k in
                      ('significance_pass','DW_pass','JB_pass','VIF_pass','passes')})
    return trial_frame, summary


def descriptive_statistics(clean, reported):
    retained = clean.loc[TRAIN_START:HISTORY_END]
    q = retained.Debit.resample('QE').sum(min_count=3)
    pre, post, recent = q.loc['2012':'2014'], q.loc['2015':'2025'], q.loc['2024':'2025']
    require((len(pre), len(post), len(recent)) == (12,44,8), 'Unexpected quarterly windows')
    sw = shapiro(post.to_numpy())
    mean, sd, baseline = float(post.mean()), float(post.std(ddof=1)), float(recent.mean())
    floor = mean - 2*sd
    covid_reference, covid_trough = float(q.loc['2019-07':'2019-12'].mean()), float(q.loc['2020-06-30'])
    stress_decline = 100*(1-floor/baseline)
    covid_decline = 100*(1-covid_trough/covid_reference)
    metrics = dict(full_monthly_n=len(clean),retained_monthly_n=len(retained),
       sep2011_fee=float(clean.loc['2011-09-01','Debit_raw']),
       oct2011_fee=float(clean.loc['2011-10-01','Debit_raw']),
       regulatory_monthly_decline_pct=100*(1-clean.loc['2011-10-01','Debit_raw']/clean.loc['2011-09-01','Debit_raw']),
       march2012_raw=float(clean.loc['2012-03-01','Debit_raw']),
       march2012_adjusted=float(clean.loc['2012-03-01','Debit']),
       december2012_raw=float(clean.loc['2012-12-01','Debit_raw']),
       december2012_adjusted=float(clean.loc['2012-12-01','Debit']),
       feb2012_fee=float(clean.loc['2012-02-01','Debit']),apr2012_fee=float(clean.loc['2012-04-01','Debit']),
       nov2012_fee=float(clean.loc['2012-11-01','Debit']),jan2013_fee=float(clean.loc['2013-01-01','Debit']),
       pre2015_n=len(pre),pre2015_mean=float(pre.mean()),post2015_n=len(post),
       post2015_mean=mean,post2015_sd_sample=sd,post2015_sd_population=float(post.std(ddof=0)),
       post2015_skew_biased=float(skew(post,bias=True)),
       post2015_skew_unbiased=float(skew(post,bias=False)),
       post2015_shapiro_w=float(sw.statistic),post2015_shapiro_p=float(sw.pvalue),
       post2015_min=float(post.min()),baseline_n=len(recent),baseline_quarterly=baseline,
       level_shift_pct=100*(mean/pre.mean()-1),older_mean_below_baseline_pct=100*(1-mean/baseline),
       stress_floor_quarterly=floor,stress_floor_monthly=floor/3,
       baseline_to_floor_decline_pct=stress_decline,covid_reference_2019h2=covid_reference,
       covid_decline_pct=covid_decline,severity_multiple=stress_decline/covid_decline,
       observed_quarters_below_floor=int((post<floor).sum()))
    for t in ['2014-03-01','2014-04-01','2014-06-01','2014-07-01']:
        key=t[:7].replace('-','_')
        ts=pd.Timestamp(t)
        metrics[f'fee_{key}']=float(clean.loc[t,'Debit'])
        metrics[f'mom_{key}']=float(100*(clean.loc[t,'Debit']/clean.loc[ts-pd.offsets.MonthBegin(1),'Debit']-1))
    for t,value in recent.items():
        metrics[f'fee_{t.to_period("Q")}']=float(value)
    # Document inputs are not estimated parameters. These calculations preserve
    # the user's adopted values without changing any raw monthly observations.
    adopted=reported.set_index('metric').reported_value.to_dict()
    adopted['stress_floor_quarterly']=adopted['post2015_mean']-2*adopted['post2015_sd_sample']
    adopted['stress_floor_monthly']=adopted['stress_floor_quarterly']/3
    adopted['baseline_to_floor_decline_pct']=100*(1-adopted['stress_floor_quarterly']/adopted['baseline_quarterly'])
    adopted['covid_decline_pct']=100*(1-adopted['post2015_min']/adopted['covid_reference_2019h2'])
    adopted['severity_multiple']=adopted['baseline_to_floor_decline_pct']/adopted['covid_decline_pct']
    adopted['observed_quarters_below_floor']=int((post<adopted['stress_floor_quarterly']).sum())
    q_frame=q.to_frame('Debit_quarterly')
    q_frame['quarter']=q_frame.index.to_period('Q').astype(str)
    q_frame['in_post2015_window']=q_frame.index.year>=2015
    q_frame['in_baseline_window']=q_frame.index.year>=2024
    return {k:float(v) for k,v in metrics.items()},adopted,q_frame


def reconcile(reference, metrics, adopted, value_column):
    rows=[]
    for row in reference.to_dict('records'):
        value=float(metrics[row['metric']])
        reported=float(row[value_column])
        tolerance=.5*10**(-int(row['display_decimals']))+1e-12
        from_document=adopted.get(row['metric'])
        rows.append({**row,'recomputed_from_raw':value,'difference_raw_minus_reported':value-reported,
                     'matches_display_precision':abs(value-reported)<=tolerance,
                     'document_input_or_calculation':from_document,
                     'document_matches_display':None if from_document is None else abs(from_document-reported)<=tolerance})
    return pd.DataFrame(rows)


def check_chart_data(data_dir, clean, quarterly, adopted):
    """Check cached native chart points, including the 13-month outlier chart."""
    series=json.loads((data_dir/'deck_chart_series.json').read_text(encoding='utf-8'))
    rows=[]
    for item in series:
        slide,name=item['slide'],item['series']
        basis='raw/adjusted source observations'
        if slide==3:
            expected=clean.Debit_raw
        elif slide==4:
            expected=clean.Debit_raw.loc['2011']
        elif slide==5:
            column='Debit_raw' if name.startswith('Raw') else 'Debit'
            expected=clean.loc['2012-01':'2013-01',column]
        elif slide==7:
            expected=clean.Debit.loc['2014']
        elif slide==8:
            expected=quarterly.Debit_quarterly
        elif slide in (10,11):
            expected=quarterly.Debit_quarterly.loc['2015':].copy()
            if name.startswith('Baseline'):
                expected[:]=adopted['baseline_quarterly']
                basis='document adopted baseline, 4747.6'
            elif name=='Stress floor':
                expected[:]=adopted['stress_floor_quarterly']
                basis='document adopted stress floor, 3815.9'
        else:
            raise ValueError(f'Unexpected chart owner slide {slide}')
        require(len(expected)==len(item['y']),f'Chart point count on slide {slide}')
        errors=np.abs(expected.to_numpy()-np.asarray(item['y']))
        if slide==5:
            months=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']
            x=[months[t.month-1]+' '+str(t.year)[2:] for t in expected.index]
            x_matches=x==item['x']
        else:
            x=list(range(1,13)) if slide in (4,7) else [t.year+(t.month-1)/12 for t in expected.index]
            x_matches=bool(np.allclose(x,np.asarray(item['x'],dtype=float),rtol=0,atol=1e-8))
        rows.append(dict(slide=slide,series=name,points=len(expected),basis=basis,
                         max_absolute_value_difference=float(errors.max()),
                         values_match=bool(np.all(errors<1e-8)),dates_match=x_matches))
    result=pd.DataFrame(rows)
    require(result.values_match.all() and result.dates_match.all(),'A native chart differs from its stated input data')
    return result


def self_checks(clean, designs):
    for args in ((.049,1.5,.051,9.99),(.049,2.5,.051,9.99)):
        require(all(gate_flags(*args).values()), 'Inclusive DW boundary test')
    for args in ((.05,2,.06,1),(.01,2,.05,1),(.01,2,.06,10),(.01,1.49,.06,1),(.01,2.51,.06,1)):
        require(not all(gate_flags(*args).values()), 'Strict entry boundary test')
    poisoned=clean.copy()
    poisoned.loc['2023-10':, ['Debit',*MACROS]] *= 100
    poisoned.loc[:'2011-12', ['Debit',*MACROS]] *= 100
    for label,(matrix,pool) in all_designs(poisoned).items():
        pd.testing.assert_frame_equal(matrix,designs[label][0])
        require(pool==designs[label][1], 'Candidate pool changed')


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--data-dir',type=Path,default=BASE/'data')
    parser.add_argument('--output-dir',type=Path,default=BASE/'results',
                        help='New or empty destination; existing results are never overwritten')
    args=parser.parse_args()
    out=args.output_dir.resolve()
    require(not out.exists() or not any(out.iterdir()), f'Output is not empty: {out}. Choose another --output-dir.')
    raw,reported,source_manifest=load_inputs(args.data_dir.resolve())
    clean,replacements=clean_revenue(raw)
    designs=all_designs(clean)
    self_checks(clean,designs)
    out.mkdir(parents=True,exist_ok=True)
    (out/'candidate_trials').mkdir()
    (out/'design_matrices').mkdir()
    summaries=[]
    for label,(matrix,pool) in designs.items():
        trials,summary=forward_screen(matrix,pool,label)
        summaries.append(summary)
        save_csv(trials,out/'candidate_trials'/f'{label}.csv')
        save_csv(matrix,out/'design_matrices'/f'{label}.csv',indexed=True)
        print(f'{label}: {summary["passes"]}/{summary["candidate_count"]} eligible first additions',flush=True)
    summary=pd.DataFrame(summaries)
    reference=pd.read_csv(args.data_dir/'regression_reference_summary.csv')
    for row in reference.to_dict('records'):
        current=summary.loc[summary.approach==row['approach']].iloc[0]
        for key,value in row.items():
            require(current[key]==value, f'Regression result differs from reference: {row["approach"]} / {key}')
    metrics,adopted,quarterly=descriptive_statistics(clean,reported)
    chart_checks=check_chart_data(args.data_dir,clean,quarterly,adopted)
    for row in summaries:
        for key in ('candidate_count','passes','DW_pass','JB_pass'):
            metrics[f'{row["approach"]}_{key}']=float(row[key])
    deck_reference=pd.read_csv(args.data_dir/'deck_reference_values.csv')
    deck_audit=reconcile(deck_reference,metrics,adopted,'deck_value')
    doc_audit=reconcile(reported,metrics,adopted,'reported_value')
    save_csv(summary,out/'regression_summary.csv')
    save_csv(replacements,out/'outlier_replacements.csv')
    save_csv(clean,out/'monthly_raw_and_adjusted.csv',indexed=True)
    save_csv(clean.loc['2012-01':'2013-01',['Debit_raw','Debit']],out/'outlier_chart_2012_01_to_2013_01.csv',indexed=True)
    save_csv(quarterly,out/'quarterly_fee.csv',indexed=True)
    save_csv(pd.DataFrame([dict(metric=k,value=v) for k,v in metrics.items()]),out/'recomputed_statistics.csv')
    save_csv(pd.DataFrame([dict(metric=k,document_input_or_calculation=v) for k,v in adopted.items()]),out/'document_adopted_values.csv')
    save_csv(deck_audit,out/'deck_reconciliation.csv')
    save_csv(doc_audit,out/'document_reconciliation.csv')
    save_csv(chart_checks,out/'chart_data_reconciliation.csv')
    differences=deck_audit.loc[~deck_audit.matches_display_precision]
    save_csv(differences,out/'deck_differences_only.csv')
    narrative_checks=[
        dict(slide=6,claim='No first candidate passes all four gates in any route',passed=bool((summary.passes==0).all())),
        dict(slide=6,claim='Level: exactly one candidate passes DW and it fails normality',passed=bool(summary.iloc[0].DW_pass==1 and summary.iloc[0].passes==0)),
        dict(slide=6,claim='YoY/MoM/QoQ: every first candidate fails JB',passed=bool((summary.iloc[1:].JB_pass==0).all())),
        dict(slide=6,claim='YoY stops before any EG test, ECT construction or ECM fit',passed=bool(summary.iloc[1].passes==0)),
        dict(slide=11,claim='Minimum quarter is 2020Q2',passed=bool(quarterly.Debit_quarterly.loc['2015':].idxmin()==pd.Timestamp('2020-06-30'))),
        dict(slide=11,claim='None of 44 quarters is below the document stress floor',passed=bool(adopted['observed_quarters_below_floor']==0)),
    ]
    # Verify the actual DW-passing Level candidate, not merely the aggregate counts.
    level=pd.read_csv(out/'candidate_trials/Level.csv')
    narrative_checks[1]['passed']=bool(level.DW_pass.sum()==1 and not level.loc[level.DW_pass,'JB_pass'].any())
    require(all(r['passed'] for r in narrative_checks), 'A deck narrative check failed')
    save_csv(pd.DataFrame(narrative_checks),out/'deck_narrative_checks.csv')
    notes=[
        '# Code-to-deck reconciliation', '',
        f'Reference deck: {source_manifest["reference_deck"]["name"]} ({source_manifest["reference_deck"]["slide_count"]} slides).', '',
        'All four regression screening counts and the stated failure reasons match the deck.',
        f'Shapiro-Wilk: W = {metrics["post2015_shapiro_w"]:.9f}, p = {metrics["post2015_shapiro_p"]:.9f}; matches the displayed p = 0.053.',
        f'Baseline = {metrics["baseline_quarterly"]:.6f}; matches the displayed 4,747.6.', '',
        f'All {len(chart_checks)} native chart series ({int(chart_checks.points.sum())} points) match their stated source or document-input basis, including dates/categories.', '',
        f'{len(differences)} numerical display occurrences differ from raw-data recalculation. Repeated metrics on different slides are separate occurrences.', '',
        'Document inputs remain authoritative for the adopted baseline/stress calculation. The raw observations and statistical-test outputs have not been changed to force agreement.', '',
        '## Differences', '',
        '| Slide | Metric | Deck | From raw data | Difference |',
        '|---|---|---:|---:|---:|',
    ]
    for row in differences.to_dict('records'):
        notes.append(f'| {row["slide"]} | {row["metric"]} | {row["deck_value"]:g} | {row["recomputed_from_raw"]:.6f} | {row["difference_raw_minus_reported"]:+.6f} |')
    notes+=['','## Interpretation limits','',
        'DW is a cutoff on a statistic, not proof of no autocorrelation, particularly with lagged dependent variables. VIF is a collinearity diagnostic.',
        'OLS and JB p-values are nominal and not adjusted for searching many candidates. The search stopping at the first step does not rule out every multivariate combination.',
        'Shapiro-Wilk non-rejection at 5% does not prove normality or independence. Mean minus two standard deviations is an adopted stress assumption, not a guaranteed lower bound.',
        'The current deck does not report ADF, KPSS, Chow, BG, ARCH, RESET or an estimated ECM. Those tests are not relabelled as deck results. The 2014 anomalies and 2015 level shift are descriptive observations, not causal or formal break-test findings.','']
    (out/'RECONCILIATION.md').write_text('\n'.join(notes),encoding='utf-8')
    save_json(dict(
        created_utc=datetime.now(timezone.utc).isoformat(),script_sha256=sha256(__file__),
        versions=dict(python=platform.python_version(),numpy=np.__version__,pandas=pd.__version__,
                      scipy=scipy.__version__,statsmodels=statsmodels.__version__),
        source_manifest_sha256=sha256(args.data_dir/'source_manifest.json'),
        reference_deck=source_manifest['reference_deck'],
        training=dict(start=TRAIN_START,end=TRAIN_END,months=141,exclude_2011_before_transforms=True),
        gates=dict(new_term_t_p_lt=.05,DW_inclusive=[1.5,2.5],JB_p_gt=.05,VIF_lt=10),
        shapiro=dict(n=44,start='2015Q1',end='2025Q4',W=metrics['post2015_shapiro_w'],p=metrics['post2015_shapiro_p']),
        skew_convention='Fisher-Pearson moment coefficient, scipy.stats.skew(bias=True). Also exports the bias-corrected coefficient.',
        standard_deviation='Sample standard deviation, ddof=1. Also exports population ddof=0.',
        numerical_deck_occurrences_checked=len(deck_audit),numerical_deck_occurrences_different=len(differences),
        native_chart_series_checked=len(chart_checks),native_chart_points_checked=int(chart_checks.points.sum()),
        regression_reference_checks='passed',narrative_checks='passed',
        safeguards=['Input SHA-256 checks','Only two outlier replacements','Independent OLS/DW/JB calculations',
                    'Boundary tests','No 2011 warm-up','Poisoned future data cannot change any design matrix']),out/'run_manifest.json')
    print(f'Shapiro-Wilk p = {metrics["post2015_shapiro_p"]:.9f}')
    print(f'Deck check: {len(deck_audit)} values checked, {len(differences)} display occurrences differ.')
    print(f'Output: {out}')


if __name__ == '__main__':
    main()
