# Code-to-deck reconciliation

Reference deck: Debit_Qualitative_Model_Jan2013_NoNotes.pptx (14 slides).

All four regression screening counts and the stated failure reasons match the deck.
Shapiro-Wilk: W = 0.949652355, p = 0.053409775; matches the displayed p = 0.053.
Baseline = 4747.625000; matches the displayed 4,747.6.

All 11 native chart series (506 points) match their stated source or document-input basis, including dates/categories.

14 numerical display occurrences differ from raw-data recalculation. Repeated metrics on different slides are separate occurrences.

Document inputs remain authoritative for the adopted baseline/stress calculation. The raw observations and statistical-test outputs have not been changed to force agreement.

## Differences

| Slide | Metric | Deck | From raw data | Difference |
|---|---|---:|---:|---:|
| 8 | post2015_mean | 4554 | 4553.090909 | -0.909091 |
| 9 | stress_floor_quarterly | 3815.9 | 3813.653434 | -2.246566 |
| 9 | baseline_to_floor_decline_pct | 19.6 | 19.672395 | +0.072395 |
| 10 | post2015_mean | 4553.9 | 4553.090909 | -0.809091 |
| 11 | post2015_mean | 4553.9 | 4553.090909 | -0.809091 |
| 11 | post2015_sd_sample | 369 | 369.718738 | +0.718738 |
| 11 | stress_floor_quarterly | 3815.9 | 3813.653434 | -2.246566 |
| 11 | stress_floor_monthly | 1272 | 1271.217811 | -0.782189 |
| 12 | stress_floor_quarterly | 3815.9 | 3813.653434 | -2.246566 |
| 12 | baseline_to_floor_decline_pct | 19.6 | 19.672395 | +0.072395 |
| 12 | covid_reference_2019h2 | 4264 | 4246.000000 | -18.000000 |
| 12 | covid_decline_pct | 7.3 | 6.877061 | -0.422939 |
| 12 | severity_multiple | 2.7 | 2.860582 | +0.160582 |
| 13 | stress_floor_quarterly | 3815.9 | 3813.653434 | -2.246566 |

## Interpretation limits

DW is a cutoff on a statistic, not proof of no autocorrelation, particularly with lagged dependent variables. VIF is a collinearity diagnostic.
OLS and JB p-values are nominal and not adjusted for searching many candidates. The search stopping at the first step does not rule out every multivariate combination.
Shapiro-Wilk non-rejection at 5% does not prove normality or independence. Mean minus two standard deviations is an adopted stress assumption, not a guaranteed lower bound.
The current deck does not report ADF, KPSS, Chow, BG, ARCH, RESET or an estimated ECM. Those tests are not relabelled as deck results. The 2014 anomalies and 2015 level shift are descriptive observations, not causal or formal break-test findings.
