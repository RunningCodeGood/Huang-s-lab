# Debit Card Fee Model

## Contents

- `debit_card_model.py`: data preparation, four regression approaches, statistical diagnostics, historical analysis, and qualitative scenario levels.
- `data/monthly_fee_and_macro.csv`: original monthly input observations from January 2011 through December 2025. Revenue outliers have not been adjusted in this file.

## Run

Use Python 3.10 or later. Install the numerical dependencies:

```bash
python -m pip install "numpy>=1.26,<3" "pandas>=2.2,<3" "scipy>=1.11,<2" "statsmodels>=0.14,<0.16"
python debit_card_model.py
```

Results are created in `results/` next to the script. To choose another output directory:

```bash
python debit_card_model.py --output-dir path/to/results
```

The optional `--data` argument selects another input CSV with the same columns and required historical periods. Each input row must contain one month's actual observations, not forecasts. Append new actual months to extend the qualitative model's historical window. The regression estimation cutoff remains September 2023. Running the script again replaces result files with the same names. The input CSV is never modified.

## Input fields

`date` is the monthly observation date. `Debit_raw` is debit card fee revenue in its original source units. The source input does not specify a currency scale, and no currency or scale conversion is applied. The macroeconomic columns retain the units and values supplied in the source series:

| Column | Series |
| --- | --- |
| Unrate | Unemployment rate |
| CPI | Consumer price index |
| DPI | Disposable personal income |
| RetailSalesTotal | Total retail sales |
| ConsumerConfidence | Consumer confidence |
| SBOpt | Small business optimism |
| GDP_Wholesale | Wholesale trade GDP |
| IP | Industrial production |
| CorpProfits | Corporate profits |
| DJ_TotalMkt | Dow Jones total market index |
| GrocerySales | Grocery sales |
| GasolineSales | Gasoline sales |
| NonstoreSales | Nonstore retail sales |
| PrivateEmployment | Private employment |

## Data preparation

The full input history is retained. Model estimation starts in January 2012, following the 2011 debit interchange regulation change. Excluded 2011 observations are not used to construct lags or growth-rate denominators.

March and December 2012 purchase purse expense outliers are replaced, in memory, by the arithmetic mean of their respective preceding and following raw monthly revenues. This produces 853.5 for March and 780.5 for December. No other revenue observations are changed. The 2014 anomalies and the sustained level shift beginning in Q1 2015 remain in the estimation data. No seasonal adjustment or level-shift dummy is applied.

## Regression approaches

The estimation pool runs from January 2012 through September 2023. Transformations and lags are formed after this date filter. Each approach uses a single complete-case sample across its full candidate pool.

| Approach | Target and macro transformation | Candidate terms |
| --- | --- | --- |
| Level | Monthly levels | Revenue lags 1-12; macro lags 0-12 |
| YoY_static_screen | 12-month percentage changes | Contemporaneous macros only |
| MoM | 1-month percentage changes | Revenue lags 1-12; macro lags 0-12 |
| QoQ_quarterly | 1-quarter percentage changes | Revenue lags 1-4; macro lags 0-4 |

For transformed approaches, unemployment uses percentage-point differences over the corresponding horizon. Quarterly revenue is the sum of three monthly observations. Quarterly macroeconomic inputs use the quarter-end monthly observation.

Each approach starts with an intercept-only seed and tries one new term at a time. An addition must satisfy all four rules:

- Classical two-sided coefficient t-test p-value below 0.05 for the proposed term.
- Durbin-Watson statistic between 1.5 and 2.5, inclusive.
- Jarque-Bera residual normality p-value above 0.05.
- Maximum non-intercept variance inflation factor below 10.

Durbin-Watson and VIF are diagnostic cutoffs, not p-value tests. Passing additions are ranked by the proposed term's p-value, then adjusted R-squared, then name. There are no forced autoregressive terms, joint additions, or backward deletions. If no first term qualifies, no final model is accepted. The YoY approach is a static screen only; the script does not estimate a subsequent error-correction model.

## Historical analysis and qualitative scenarios

Adjusted monthly revenue is summed to calendar quarters. Only quarters with all three monthly revenue observations are used. The script derives both qualitative scenario levels from these quarterly totals:

- Baseline: the arithmetic mean of the latest eight complete actual quarters (`quarterly.tail(8).mean()`). The supplied data use Q1 2024 through Q4 2025.
- Stress floor: the mean minus two sample standard deviations (`ddof=1`) of all complete actual quarters from Q1 2015 through the latest available quarter. The supplied data use Q1 2015 through Q4 2025.

Both levels are recalculated whenever the script runs. A new complete actual quarter advances the eight-quarter baseline window and extends the post-2015 stress window. An incomplete latest quarter does not enter either calculation. Baseline, stress mean, standard deviation, and stress floor are not hardcoded from a document. Intermediate calculations and CSV results are not rounded to a prescribed number of decimal places.

Historical distribution statistics also include skewness, Shapiro-Wilk normality, and the historical minimum. The script calculates the pre/post-2015 mean change and the decline from the second-half 2019 quarterly average to Q2 2020. Historical analysis and scenario outputs use the same calculated statistics.

Scenario amounts are quarterly revenue in the same units as the input revenue. Dividing the stress floor by three gives a monthly equivalent, not a separate monthly forecast. The script calculates scenario levels, not a dated forecast trajectory or a macroeconomic response function.

## Generated results

Running the script creates:

- `regression_summary.csv`: sample sizes, selected terms, and first-round diagnostic pass counts by approach.
- `regression_candidates.csv`: candidate coefficients, standard errors, t statistics, p-values, residual diagnostics, VIFs, and selection decisions.
- `historical_statistics.csv`: statistics calculated from the historical observations.
- `monthly_revenue.csv`: raw revenue and the working revenue series after outlier treatment.
- `quarterly_revenue.csv`: quarterly totals from January 2012 onward.
- `qualitative_scenarios.csv`: quarterly baseline and stress levels calculated from the input data, together with the estimated stress mean and sample standard deviation.

No generated results are included in the package.
