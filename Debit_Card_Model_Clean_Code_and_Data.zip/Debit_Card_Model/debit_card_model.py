#!/usr/bin/env python3
"""Debit card fee regression screening and qualitative model calculations."""

from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd
from scipy.stats import shapiro, skew
from statsmodels.regression.linear_model import OLS
from statsmodels.stats.outliers_influence import variance_inflation_factor
from statsmodels.stats.stattools import durbin_watson, jarque_bera
from statsmodels.tools.tools import add_constant


BASE_DIR = Path(__file__).resolve().parent
TRAIN_START = "2012-01-01"
TRAIN_END = "2023-09-30"
POST_SHIFT_START = "2015-01-01"
BASELINE_WINDOW_QUARTERS = 8
MACROS = [
    "Unrate", "CPI", "DPI", "RetailSalesTotal", "ConsumerConfidence",
    "SBOpt", "GDP_Wholesale", "IP", "CorpProfits", "DJ_TotalMkt",
    "GrocerySales", "GasolineSales", "NonstoreSales", "PrivateEmployment",
]

# The stress severity multiplier is a model rule, not an estimated revenue level.
STRESS_SD_MULTIPLE = 2.0


def load_data(path: Path) -> pd.DataFrame:
    """Read monthly fee revenue and macroeconomic inputs without changing them."""
    return pd.read_csv(
        path, parse_dates=["date"], float_precision="round_trip"
    ).set_index("date")


def prepare_revenue(raw: pd.DataFrame) -> pd.DataFrame:
    """Replace the two purchase purse expense outliers in a working copy."""
    monthly = raw.copy()
    monthly["Debit"] = monthly["Debit_raw"]
    for date in ("2012-03-01", "2012-12-01"):
        month = pd.Timestamp(date)
        previous = raw.at[month - pd.offsets.MonthBegin(1), "Debit_raw"]
        following = raw.at[month + pd.offsets.MonthBegin(1), "Debit_raw"]
        monthly.at[month, "Debit"] = (previous + following) / 2
    return monthly


def make_design(frame, horizon, max_lag, static=False):
    """Create one common complete-case sample for each candidate pool."""
    data = frame[["Debit", *MACROS]]
    transformed = (
        data.copy() if horizon == 0
        else 100 * data.pct_change(horizon, fill_method=None)
    )
    if horizon:
        # Unemployment changes are percentage-point differences, not growth rates.
        transformed["Unrate"] = data["Unrate"].diff(horizon)
    target = transformed["Debit"].rename("target")
    candidates = {}
    if not static:
        for lag in range(1, max_lag + 1):
            candidates[f"y_L{lag}"] = target.shift(lag)
    for macro in MACROS:
        for lag in range(1 if static else max_lag + 1):
            candidates[f"{macro}_L{lag}"] = transformed[macro].shift(lag)
    design = pd.concat([target, pd.DataFrame(candidates)], axis=1).dropna()
    return design, list(candidates)


def regression_designs(monthly):
    # Exclude 2011 before transformation: it is not used as lag history.
    train = monthly.loc[TRAIN_START:TRAIN_END]
    quarterly = train.resample("QE").last()
    quarterly["Debit"] = train["Debit"].resample("QE").sum(min_count=3)
    # Quarterly revenue is summed; each macro uses its quarter-end observation.
    return {
        "Level": make_design(train, horizon=0, max_lag=12),
        "YoY_static_screen": make_design(train, horizon=12, max_lag=0, static=True),
        "MoM": make_design(train, horizon=1, max_lag=12),
        "QoQ_quarterly": make_design(quarterly, horizon=1, max_lag=4),
    }


def fit_candidate(frame, terms):
    """Fit classical OLS and calculate residual and collinearity diagnostics."""
    regressors = add_constant(frame[terms], has_constant="add")
    model = OLS(frame["target"], regressors, missing="raise").fit()
    jb, jb_p, residual_skew, residual_kurtosis = jarque_bera(model.resid)
    # The intercept is included in each VIF regression but has no reported VIF.
    vifs = [
        variance_inflation_factor(model.model.exog, position)
        for position in range(1, len(model.params))
    ]
    statistics = {
        "n": int(model.nobs),
        "df_resid": float(model.df_resid),
        "R2": float(model.rsquared),
        "adj_R2": float(model.rsquared_adj),
        "DW": float(durbin_watson(model.resid)),
        "JB": float(jb),
        "JB_p": float(jb_p),
        "residual_skew": float(residual_skew),
        "residual_kurtosis": float(residual_kurtosis),
        "max_VIF": float(max(vifs, default=1.0)),
    }
    return model, statistics


def diagnostic_gates(p_value, dw, jb_p, max_vif):
    """Apply the model selection rules; DW and VIF are diagnostic cutoffs."""
    return {
        "significance_pass": bool(p_value < 0.05),
        "DW_pass": bool(1.5 <= dw <= 2.5),
        "JB_pass": bool(jb_p > 0.05),
        "VIF_pass": bool(max_vif < 10),
    }


def forward_screen(frame, pool, approach):
    """Try one new term at a time, starting with an intercept-only seed.

    All four gates must pass. Rank eligible additions by their coefficient
    p-value, then adjusted R-squared, then name. Do not force autoregressive
    terms, add terms jointly, or remove terms in a backward step.
    """
    selected, remaining, trials = [], list(pool), []
    while remaining:
        rows = []
        for candidate in remaining:
            model, statistics = fit_candidate(frame, selected + [candidate])
            row = {
                "approach": approach,
                "round": len(selected) + 1,
                "candidate": candidate,
                "existing_terms": ";".join(selected),
                "coefficient": float(model.params[candidate]),
                "coefficient_se": float(model.bse[candidate]),
                "t_stat": float(model.tvalues[candidate]),
                "p_new": float(model.pvalues[candidate]),
                **statistics,
            }
            gates = diagnostic_gates(
                row["p_new"], row["DW"], row["JB_p"], row["max_VIF"]
            )
            row.update(gates)
            row["passes"] = all(gates.values())
            row["failed_gates"] = ";".join(
                name.removesuffix("_pass")
                for name, passed in gates.items() if not passed
            )
            rows.append(row)
        passing = sorted(
            (row for row in rows if row["passes"]),
            key=lambda row: (row["p_new"], -row["adj_R2"], row["candidate"]),
        )
        winner = passing[0]["candidate"] if passing else None
        for row in rows:
            row["chosen"] = row["candidate"] == winner
        trials.extend(rows)
        if winner is None:
            break
        selected.append(winner)
        remaining.remove(winner)

    trial_frame = pd.DataFrame(trials)
    first_round = trial_frame.loc[trial_frame["round"] == 1]
    summary = {
        "approach": approach,
        "n": len(frame),
        "start": str(frame.index.min().date()),
        "end": str(frame.index.max().date()),
        "candidate_count": len(pool),
        "selected_terms": ";".join(selected),
        # An intercept-only seed is not an accepted final regression model.
        "final_model_found": bool(selected),
        **{name: int(first_round[name].sum()) for name in (
            "significance_pass", "DW_pass", "JB_pass", "VIF_pass", "passes"
        )},
    }
    return trial_frame, summary


def historical_statistics(monthly):
    """Estimate quarterly distribution statistics and historical movements."""
    retained = monthly.loc[TRAIN_START:]
    # Use actual observations only. A quarter needs all three monthly revenues.
    quarterly = retained["Debit"].resample("QE").sum(min_count=3).dropna()
    pre_shift = quarterly.loc["2012":"2014"]
    post_shift = quarterly.loc[POST_SHIFT_START:]
    # The trailing window advances when another complete actual quarter arrives.
    recent = quarterly.tail(BASELINE_WINDOW_QUARTERS)
    normality = shapiro(post_shift.to_numpy())
    mean = float(post_shift.mean())
    sd = float(post_shift.std(ddof=1))
    baseline = float(recent.mean())
    historical_floor = mean - STRESS_SD_MULTIPLE * sd
    covid_reference = float(quarterly.loc["2019-07":"2019-12"].mean())
    covid_trough = float(quarterly.loc["2020-06-30"])
    covid_decline = 100 * (1 - covid_trough / covid_reference)
    historical_floor_decline = 100 * (1 - historical_floor / baseline)
    statistics = {
        "full_monthly_n": len(monthly),
        "retained_monthly_n": len(retained),
        "regulatory_monthly_decline_pct": 100 * (
            1 - monthly.at[pd.Timestamp("2011-10-01"), "Debit_raw"]
            / monthly.at[pd.Timestamp("2011-09-01"), "Debit_raw"]
        ),
        "pre2015_n": len(pre_shift),
        "pre2015_mean": float(pre_shift.mean()),
        "post2015_n": len(post_shift),
        "post2015_mean": mean,
        "post2015_sd_sample": sd,
        "post2015_sd_population": float(post_shift.std(ddof=0)),
        "post2015_skew_biased": float(skew(post_shift, bias=True)),
        "post2015_skew_unbiased": float(skew(post_shift, bias=False)),
        "post2015_shapiro_w": float(normality.statistic),
        "post2015_shapiro_p": float(normality.pvalue),
        "post2015_min": float(post_shift.min()),
        "baseline_n": len(recent),
        "recent_eight_quarter_mean": baseline,
        "level_shift_pct": 100 * (mean / pre_shift.mean() - 1),
        "older_mean_below_recent_mean_pct": 100 * (1 - mean / baseline),
        "historical_mean_minus_two_sd": historical_floor,
        "historical_floor_monthly_equivalent": historical_floor / 3,
        "historical_floor_decline_pct": historical_floor_decline,
        "covid_reference_2019h2": covid_reference,
        "covid_trough_2020q2": covid_trough,
        "covid_decline_pct": covid_decline,
        "historical_floor_severity_multiple": historical_floor_decline / covid_decline,
        "observed_quarters_below_historical_floor": int((post_shift < historical_floor).sum()),
    }
    # Retain the 2014 fee anomalies and the Q1 2015 level shift without adjustment.
    for date in ("2014-03-01", "2014-04-01", "2014-06-01", "2014-07-01"):
        month = pd.Timestamp(date)
        key = date[:7].replace("-", "_")
        fee = float(monthly.at[month, "Debit"])
        previous = float(monthly.at[month - pd.offsets.MonthBegin(1), "Debit"])
        statistics[f"fee_{key}"] = fee
        statistics[f"mom_{key}"] = 100 * (fee / previous - 1)
    return statistics, quarterly


def qualitative_scenarios(statistics):
    """Use the full-precision revenue statistics calculated from the input data."""
    baseline = statistics["recent_eight_quarter_mean"]
    floor = statistics["historical_mean_minus_two_sd"]
    values = {
        "baseline_quarterly": baseline,
        "stress_mean": statistics["post2015_mean"],
        "stress_sd_sample": statistics["post2015_sd_sample"],
        "stress_sd_multiple": STRESS_SD_MULTIPLE,
        "stress_floor_quarterly": floor,
        # This conversion is not a separately estimated monthly forecast.
        "stress_floor_monthly_equivalent": floor / 3,
        "baseline_to_stress_decline_pct": statistics["historical_floor_decline_pct"],
    }
    return pd.DataFrame(values.items(), columns=["metric", "value"])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--data", type=Path,
        default=BASE_DIR / "data" / "monthly_fee_and_macro.csv",
        help="Monthly input CSV.",
    )
    parser.add_argument(
        "--output-dir", type=Path, default=BASE_DIR / "results",
        help="Directory for calculated results.",
    )
    args = parser.parse_args()
    output = args.output_dir
    output.mkdir(parents=True, exist_ok=True)
    monthly = prepare_revenue(load_data(args.data))

    summaries, trial_tables = [], []
    for approach, (design, candidates) in regression_designs(monthly).items():
        trials, summary = forward_screen(design, candidates, approach)
        summaries.append(summary)
        trial_tables.append(trials)
        print(f"{approach}: {len(design)} observations, "
              f"{len(candidates)} candidates, "
              f"final model found: {summary['final_model_found']}")
    pd.DataFrame(summaries).to_csv(output / "regression_summary.csv", index=False)
    pd.concat(trial_tables, ignore_index=True).to_csv(
        output / "regression_candidates.csv", index=False
    )

    statistics, quarterly = historical_statistics(monthly)
    pd.DataFrame(statistics.items(), columns=["metric", "value"]).to_csv(
        output / "historical_statistics.csv", index=False
    )
    monthly[["Debit_raw", "Debit"]].to_csv(
        output / "monthly_revenue.csv", index_label="date", date_format="%Y-%m-%d"
    )
    quarterly.rename("Debit_quarterly").to_csv(
        output / "quarterly_revenue.csv", index_label="date", date_format="%Y-%m-%d"
    )
    qualitative_scenarios(statistics).to_csv(
        output / "qualitative_scenarios.csv", index=False
    )
    print(f"Results saved to {output.resolve()}")


if __name__ == "__main__":
    main()
