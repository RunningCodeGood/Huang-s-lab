# Merchant Card Model

This package estimates the Merchant fee revenue model from original monthly observations. One command performs data preparation, macro screening, long-run and short-run estimation, historical evaluation, S1/S4 forecasting, individual macro sensitivities, all six report figures, and the complete English Word report.

## Run

Use Python 3.12. Create an environment and install the dependencies:

```bash
python -m venv .venv
```

Activate it with `source .venv/bin/activate` on macOS/Linux or `.venv\Scripts\activate` on Windows, then run:

```bash
python -m pip install -r requirements.txt
python merchant_card_model.py
```

The default destination is `results/` beside the main script. Inputs and configuration are also resolved relative to the script, so launching from a different working directory is supported. To run again, choose a new or empty output directory:

```bash
python merchant_card_model.py --output-dir results_new
```

The program does not overwrite a nonempty results directory. Alternative data and settings can be supplied without editing Python code:

```bash
python merchant_card_model.py --data-dir /path/to/input_data --config /path/to/config.json --output-dir /path/to/new_results
```

## Package structure

```text
merchant_card_model/
  merchant_card_model.py       Main entry point and model calculations
  merchant_charts.py           All six figures in PNG and SVG
  merchant_report.py           Complete English Word report
  report_layout.py             Word styles, tables and native equations
  config.json                 Method settings and sensitivity assumptions
  requirements.txt            Python dependencies
  README.md
  data/
    fee_history.csv
    macro_history.csv
    macro_s1.csv
    macro_s4.csv
    macro_dictionary.csv
    sources.json
```

The archive contains code, method settings and input data. The `results/` directory is created by execution. No existing Word document, image, coefficient file or forecast file is an input.

## Input data

Every CSV row is monthly and keyed by a first-of-month `date` in `YYYY-MM-DD` format. Macro columns preserve the source Moody's mnemonics. The program maps `M_<code>_B.IUSA` and `M_<code>_S4.IUSA` to the internal code after reading the files.

| File | Default coverage | Contents and source |
| --- | --- | --- |
| `fee_history.csv` | Jan 2011–Dec 2025 | Original Merchant revenue from the `Nonll_MER` sheet of `merchant_data_Nonll_MER_SNV_interpolated.xlsx`. The source `Month_Actual_num` column is named `Month_actual_num` in this CSV. No adjusted values or derived features are supplied. |
| `macro_history.csv` | Jan 2009–Dec 2025 | All 17 macro level candidates from the `Candidates` sheet of `Merchant_Macro_Candidates_Combined.xlsx`, August 2026 vintage. |
| `macro_s1.csv` | Jan 2026–Mar 2028 | S1 monthly levels from the same supplied workbook, August 2026 Scenario Consistent Baseline. |
| `macro_s4.csv` | Jan 2026–Mar 2028 | Supplied June 2026 Alternative Scenario 4 Downside 96th Percentile levels for FRTFS and FETP, from the S4 transcription. The original two-decimal precision is retained. |
| `macro_dictionary.csv` | Not time indexed | Mnemonics, descriptions and units from the macro workbook's `Dictionary` sheet. |
| `sources.json` | Not time indexed | Input provenance and scenario vintage descriptions. |

Dates have been normalized to month starts; observation values are retained. Revenue remains in its original source units. The code does not assume that revenue is denominated in dollars, thousands of dollars or millions of dollars. Charts labelled “millions of source units” divide the values by one million for display only. Macro units are listed in the dictionary. Monthly frequency describes the supplied observations, which may differ from a macro series' native publication frequency.

The S1 and S4 paths are external scenario assumptions. The code estimates Merchant revenue conditional on these paths. Different release vintages affect the S1/S4 comparison.

## Historical preparation

The program applies the intervals in `historical_interpolations` to original revenue. For original anchors at months `a` and `b`, each intervening month receives:

```text
Y[a + k] = original[a] + k / (b - a) * (original[b] - original[a])
```

The default intervals replace June–August 2019 using May and September 2019; May 2021 using April and June 2021; July–August 2023 using June and September 2023; and October 2024 using September and November 2024. All other observations remain original. The code then derives monthly changes, fitted long-run levels and error-correction terms. It does not read pre-adjusted revenue from a separate input.

## Estimation

Sample boundaries, thresholds and lags are explicit method assumptions in `config.json`.

1. **Development window:** January 2011 through September 2023. OOT runs from October 2023 through December 2025. Future scenarios run from January 2026 through March 2028.
2. **Long-run stationarity screen:** test revenue and each macro in levels with a constant, levels with a constant and trend, and first differences with a constant. ADF uses maximum lag 12 with AIC. KPSS uses automatic bandwidth. A macro passes the I1 screen if constant-only level ADF p ≥ 0.05 and KPSS p < 0.05, and first-difference ADF p < 0.05 and KPSS p ≥ 0.05. Trend tests are supplementary. Long-run first differences are formed within the development window.
3. **Long-run forward selection:** start with an intercept. A trial's added coefficient must have OLS p < 0.05, maximum nonconstant VIF < 10, and ordinary residual ADF p < 0.05. The residual ADF uses the default maximum lag with AIC. Choose the passing trial with highest adjusted R squared; alphabetical candidate name breaks ties. No additional improvement threshold is imposed. Stop when no candidate qualifies.
4. **Economic sign rule:** after statistical selection, a configured macro in `long_run_negative_coefficient_exclusions` is removed if its jointly estimated coefficient is negative. The default applies to FCBC, Consumer Confidence. The retained terms are then jointly re-estimated. The statistical and economic decisions are separately exported. This rule is explicit; the program does not prescribe the other winning macro terms or their coefficients.
5. **Monthly ECM preparation:** define `long_run = L`, `ec = Y - L`, `y = ΔY`, and `ECT1 = ec.shift(1)`. Long-run coefficients are held fixed. Each macro uses its arithmetic monthly first difference. The short-run stationarity gate is ADF p < 0.05 **or** KPSS p > 0.05, using pre-development macro history for the initial change.
6. **Macro-lag screen:** only lags 1, 2, 3, 6 and 12 months may be used. Residualize both the target change and each candidate on an intercept and ECT1. Require partial-correlation p < 0.20 in both development and OOT, with the same sign. The test uses `t = r * sqrt((N - 3) / (1 - r*r))`, with `N - 3` degrees of freedom.
7. **Short-run forward selection:** combine passing macro-lag features with revenue-change own lags 1–12. Use one common complete-case development sample for all trials. Force an intercept and ECT1. The added coefficient must have OLS p < 0.05 and every nonconstant VIF < 10. Choose the passing trial with highest adjusted R squared, using alphabetical tie order, and stop when none qualifies. Residual ADF is diagnostic at this stage. Previously selected terms are not removed by a subsequent significance test.

OLS and HAC coefficient statistics are calculated at runtime. HAC uses 12 covariance lags, a finite-sample correction and Student t inference. Regression degrees of freedom equal N minus the rank of the design matrix. Diagnostic outputs include R squared, adjusted R squared, AIC, Durbin Watson, Jarque Bera, Ljung Box, Breusch Godfrey and ordinary residual ADF. KPSS probabilities at 0.01 and 0.10 are bounds.

The ordinary residual ADF screen is not a formal Engle Granger cointegration test. Macro screening uses OOT information, so reported OOT accuracy is selection-informed validation, not a fully untouched holdout assessment. The input macro vintage does not recreate historical release availability.

## Historical evaluation and forecasts

The model reconstructs revenue as prior revenue plus predicted monthly change. In-sample fitted revenue uses observed lagged revenue. One-step OOT predictions refresh observed history each month; an interpolated observation is used only after its right-hand anchor month is available. Until then, the original observation is used. Recursive OOT predictions start at the development endpoint and feed their own revenue predictions forward, without subsequent observed revenue.

Accuracy metrics compare model predictions with the supplied revenue observations. The main metrics score adjusted revenue; separate metrics score original revenue. They include MAPE, RMSE, MAE and bias, with bias defined as prediction minus observation.

S1 and S4 start from the same December 2025 history. Each uses the development-estimated long-run and short-run equations. There is no production refit through the end of OOT. At each future month, the code calculates the scenario-specific long-run level, required lagged macro changes, lagged revenue changes and prior error-correction term. The predicted monthly change is added to prior revenue and the resulting level is carried forward. Future innovations are zero.

The code derives the required scenario drivers from the selected model. If changed historical data selects a macro missing from the S4 input, it raises a clear missing-input error. Supply that macro's future S4 levels to run the revised specification; it does not silently substitute another scenario. S1 must also provide finite future values for all selected drivers.

## Individual macro sensitivities

The default grid applies −5%, −1%, +1% and +5% to each selected macro driver separately. For macro `j` and shock `s`:

```text
X_test[j,t] = X_S1[j,t] * (1 + s / 100)
```

The multiplier applies to every month of the forecast horizon. Other macros and all historical inputs remain unchanged. These are relative **level** shocks, with no monthly compounding and no percentage-point growth adjustment. Each case uses the same estimated coefficients and full monthly recursion. Variables and coefficients are not reselected for individual cases.

Monthly effects subtract S1 revenue. Quarterly, annual and full-horizon percentage effects first sum unrounded monthly revenue, subtract the matching S1 sum, and divide by that S1 sum. The terminal-month effect uses the final monthly S1 forecast. Peak impacts are derived from each calculated monthly path.

## Generated figures and report

| Figure | Contents | Calculated data |
| --- | --- | --- |
| 1 | Development revenue and long-run fitted level | `historical_data_and_features.csv` |
| 2 | In-sample long-run gap `e_t = Y_t - L_t` only | `historical_data_and_features.csv` |
| 3 | In-sample fit, one-step OOT and recursive OOT | `monthly_predictions.csv` |
| 4 | S1/S4 macro paths at monthly frequency with monthly points and labels | `scenario_comparison.csv` |
| 5 | Quarterly revenue summed from monthly forecasts | `forecast_periods.csv` |
| 6 | Individual macro shocks and cumulative revenue impacts in a signed horizontal bar chart | `sensitivity_summary.csv` |

Level charts start their numerical vertical axes at zero. Figure 2 displays positive and negative in-sample residuals with a zero reference line. Figure 6 has a categorical vertical axis and signed horizontal values; every bar starts at zero. All figures are created by Matplotlib during the same run and saved as PNG and SVG. No image files are bundled as inputs.

`Merchant_Long_Run_ECM_Report_EN_S1_S4_9Q_Revised.docx` is built from scratch with `python-docx`. Its tables, numerical equations, result descriptions, captions and six figures use the current model run. It includes historical preparation, screening, coefficients, diagnostics, evaluation, scenario forecasts, sensitivity tests, and detailed candidate-trial appendices. Word is not needed to generate the file.

## Generated data files

| Files | Contents |
| --- | --- |
| `adjustments.csv`, `historical_data_and_features.csv`, `estimation_sample.csv` | Original/adjusted history, transformations and estimation rows |
| `stationarity.csv`, `short_run_stationarity.csv`, `macro_lag_screen.csv` | Full stationarity results and all tested macro-lag combinations |
| `long_run_trials.csv`, `short_run_trials.csv` | Every candidate trial and selection decision |
| `long_run_rounds.csv`, `short_run_rounds.csv` | Forward-selection sequence and model diagnostics after each round |
| `long_run_round_coefficients.csv`, `short_run_round_coefficients.csv` | Joint coefficient estimates after retained rounds |
| `coefficients.csv`, `diagnostics.csv`, `model_summary.json` | Final estimated models and numerical diagnostics |
| `monthly_predictions.csv`, `performance.csv` | Historical fitted/predicted revenue and accuracy against observations |
| `forecast_monthly.csv`, `scenario_comparison.csv`, `forecast_periods.csv` | Monthly S1/S4 recursions, macro paths, driver contributions and period totals |
| `sensitivity_monthly.csv`, `sensitivity_periods.csv`, `sensitivity_summary.csv` | Shocked macro paths, monthly recursions and aggregated effects |
| `run_manifest.json` | Configuration, input hashes, source metadata, Python/library versions and generated file inventory |
| `figures/*.png`, `figures/*.svg` | The six generated report figures |

Each monthly forecast exports its lagged inputs and the contribution of every equation term. CSV outputs use 17 significant digits. Report tables and chart labels round values only for presentation. All intermediate and final calculations flow from the input observations, configuration and supplied scenario assumptions.
