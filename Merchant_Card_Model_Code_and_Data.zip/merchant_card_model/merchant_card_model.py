"""Estimate the Merchant ECM and generate forecasts, sensitivities and a report.

Run: python merchant_card_model.py
All paths default to this script's directory. Only data/ and config.json are inputs.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.metadata
import json
import platform
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats
import statsmodels.api as sm
from statsmodels.stats.diagnostic import acorr_breusch_godfrey, acorr_ljungbox
from statsmodels.stats.outliers_influence import variance_inflation_factor
from statsmodels.stats.stattools import durbin_watson, jarque_bera
from statsmodels.tools.sm_exceptions import InterpolationWarning
from statsmodels.tsa.stattools import adfuller, kpss

HERE = Path(__file__).resolve().parent


def periods(start, end):
    return pd.period_range(start, end, freq='M')


def read_monthly(path):
    frame = pd.read_csv(path, encoding='utf-8-sig')
    if 'date' not in frame or frame.empty:
        raise ValueError(f'{path.name}: a date column and monthly observations are required')
    dt = pd.to_datetime(frame.pop('date'), errors='raise')
    if not dt.dt.is_month_start.all():
        raise ValueError(f'{path.name}: dates must be first-of-month YYYY-MM-DD')
    frame.index = pd.PeriodIndex(dt, freq='M', name='date')
    if frame.index.has_duplicates or not frame.index.is_monotonic_increasing:
        raise ValueError(f'{path.name}: dates must be unique and sorted')
    if not frame.index.equals(periods(frame.index[0], frame.index[-1])):
        raise ValueError(f'{path.name}: missing monthly rows')
    return frame.apply(pd.to_numeric, errors='raise')


def macro_codes(frame):
    names = {}
    for name in frame:
        parts = name.split('_')
        if len(parts) != 3 or parts[0] != 'M' or parts[2] not in ('B.IUSA', 'S4.IUSA'):
            raise ValueError(f'Unsupported macro column: {name}')
        names[name] = parts[1]
    result = frame.rename(columns=names)
    if result.columns.has_duplicates:
        raise ValueError('Duplicate macro mnemonics')
    return result


def require_values(frame, dates, columns, label):
    missing = set(columns) - set(frame.columns)
    if missing or not dates.isin(frame.index).all():
        raise ValueError(f'{label}: missing dates or columns {sorted(missing)}')
    if not np.isfinite(frame.loc[dates, columns].to_numpy(dtype=float)).all():
        raise ValueError(f'{label}: required values must be finite')


def load_inputs(data_dir, config):
    dev = periods(config['development_start'], config['development_end'])
    history = periods(dev[0], config['history_end'])
    future = periods(config['forecast_start'], config['forecast_end'])
    if future[0] != history[-1] + 1 or dev[-1] >= history[-1]:
        raise ValueError('Development, OOT and future periods must be consecutive')
    fee = read_monthly(data_dir / 'fee_history.csv')
    require_values(fee, history, ['Month_actual_num'], 'Fee history')
    if not fee.index.equals(history) or (fee.Month_actual_num <= 0).any():
        raise ValueError('Fee history must exactly cover development and OOT with positive values')
    mh = macro_codes(read_monthly(data_dir / 'macro_history.csv'))
    s1 = macro_codes(read_monthly(data_dir / 'macro_s1.csv'))
    s4 = macro_codes(read_monthly(data_dir / 'macro_s4.csv'))
    if mh.index[-1] != history[-1] or not s1.index.equals(future) or not s4.index.equals(future):
        raise ValueError('Macro history must end at history_end; scenarios must cover the forecast horizon')
    if list(mh) != list(s1):
        raise ValueError('S1 and historical macro headers must match in the same order')
    needed_history = periods(dev[0] - max(config['macro_lags']) - 1, history[-1])
    require_values(mh, needed_history, list(mh), 'Macro history')
    dictionary = pd.read_csv(data_dir / 'macro_dictionary.csv', encoding='utf-8-sig')
    if dictionary.code.duplicated().any() or set(dictionary.code) != set(mh):
        raise ValueError('Macro dictionary must contain exactly one entry for each candidate')
    sources = json.loads((data_dir / 'sources.json').read_text())
    return dict(fee=fee.Month_actual_num.rename('original'), macro_history=mh,
                s1=s1, s4=s4, dictionary=dictionary, sources=sources)


def adjust_history(original, rules):
    fee = original.to_frame()
    fee['Merchant'] = original.astype(float)
    changes = []
    touched = set()
    for rule in rules:
        left, right = pd.Period(rule['left'], 'M'), pd.Period(rule['right'], 'M')
        if left not in fee.index or right not in fee.index or right <= left + 1:
            raise ValueError(f'Invalid interpolation anchors: {rule}')
        distance = right.ordinal - left.ordinal
        for step in range(1, distance):
            month = left + step
            if month in touched:
                raise ValueError('Overlapping historical interpolation rules')
            touched.add(month)
            value = float(original[left] + step / distance * (original[right] - original[left]))
            fee.at[month, 'Merchant'] = value
            changes.append(dict(month=str(month), original=float(original[month]), adjusted=value,
                                left_anchor=str(left), right_anchor=str(right),
                                available_from=str(right),
                                rule=f'Linear interpolation from {left} to {right}'))
    return fee, pd.DataFrame(changes)


def adf_test(series, regression='c', maxlag=None):
    result = adfuller(series.dropna(), regression=regression, maxlag=maxlag, autolag='AIC')
    return dict(adf_stat=float(result[0]), adf_p=float(result[1]), adf_lag=int(result[2]))


def kpss_test(series, regression='c'):
    with warnings.catch_warnings():
        warnings.simplefilter('ignore', InterpolationWarning)
        result = kpss(series.dropna(), regression=regression, nlags='auto')
    return dict(kpss_stat=float(result[0]), kpss_p=float(result[1]), kpss_bandwidth=int(result[2]))


def fit(frame, target, terms):
    return sm.OLS(frame[target], sm.add_constant(frame[terms], has_constant='add')).fit()


def vifs(model):
    return {name: float(variance_inflation_factor(model.model.exog, j))
            for j, name in enumerate(model.params.index) if name != 'const'}


def diagnostics(model, config):
    lag = config['diagnostic_lags']
    jb = jarque_bera(model.resid)
    lb = acorr_ljungbox(model.resid, lags=[lag], return_df=True).iloc[0]
    adf = adf_test(model.resid)
    return dict(n=int(model.nobs), df_resid=int(model.df_resid), R2=float(model.rsquared),
                adj_R2=float(model.rsquared_adj), AIC=float(model.aic),
                DW=float(durbin_watson(model.resid)), JB_p=float(jb[1]),
                LB_p=float(lb.lb_pvalue), BG_p=float(acorr_breusch_godfrey(model, nlags=lag)[1]),
                residual_ADF_p=adf['adf_p'], residual_ADF_lag=adf['adf_lag'],
                max_VIF=max(vifs(model).values(), default=None))


def coefficients(model, config, stage, round_number=None):
    hac = model.get_robustcov_results(cov_type='HAC', maxlags=config['diagnostic_lags'],
                                    use_correction=True, use_t=True)
    vf = vifs(model)
    return [dict(stage=stage, round=round_number, term=term, coefficient=float(beta),
                 OLS_SE=float(model.bse[term]), OLS_t=float(model.tvalues[term]),
                 OLS_p=float(model.pvalues[term]), HAC_p=float(hac.pvalues[i]), VIF=vf.get(term))
            for i, (term, beta) in enumerate(model.params.items())]


def forward_select(frame, target, candidates, config, base=(), adf_gate=False, stage=''):
    selected, pending, trials, rounds, round_coefs = list(base), list(candidates), [], [], []
    base_model = fit(frame, target, selected)
    rounds.append(dict(round=0, added='Base', candidates_tried=0, eligible_candidates=0,
                       **diagnostics(base_model, config)))
    round_coefs.extend(coefficients(base_model, config, stage, 0))
    alpha = config['significance_level']
    for round_number in range(1, len(candidates) + 1):
        current = []
        for candidate in pending:
            model = fit(frame, target, selected + [candidate])
            diag = diagnostics(model, config)
            eligible = bool(model.pvalues[candidate] < alpha and diag['max_VIF'] < config['vif_limit']
                            and (not adf_gate or diag['residual_ADF_p'] < alpha))
            current.append(dict(round=round_number, candidate=candidate,
                                selected_before=' + '.join(selected),
                                coefficient=float(model.params[candidate]),
                                p_added=float(model.pvalues[candidate]),
                                candidate_VIF=vifs(model)[candidate], eligible=eligible, **diag))
        passing = [r for r in current if r['eligible']]
        winner = min(passing, key=lambda r: (-r['adj_R2'], r['candidate'])) if passing else None
        for row in current:
            row['chosen'] = bool(winner and row['candidate'] == winner['candidate'])
        trials.extend(current)
        if winner:
            selected.append(winner['candidate'])
            pending.remove(winner['candidate'])
        model = fit(frame, target, selected)
        rounds.append(dict(round=round_number, added=winner['candidate'] if winner else 'Stop',
                           candidates_tried=len(current), eligible_candidates=len(passing),
                           **diagnostics(model, config)))
        if winner:
            round_coefs.extend(coefficients(model, config, stage, round_number))
        else:
            break
    return selected, pd.DataFrame(trials), pd.DataFrame(rounds), pd.DataFrame(round_coefs)


def partial_correlation(frame, term):
    z = frame[['y', 'ECT1', term]].dropna()
    if len(z) <= 3:
        raise ValueError('Insufficient observations for partial correlation')
    control = sm.add_constant(z[['ECT1']], has_constant='add')
    a = sm.OLS(z.y, control).fit().resid
    b = sm.OLS(z[term], control).fit().resid
    rho = float(stats.pearsonr(a, b).statistic)
    df = len(z) - 3
    t = rho * np.sqrt(df / max(1 - rho**2, np.finfo(float).eps))
    return dict(rho=rho, p=float(2 * stats.t.sf(abs(t), df)), n=len(z), df=df)


def estimate(inputs, config):
    dev = periods(config['development_start'], config['development_end'])
    oot = periods(dev[-1] + 1, config['history_end'])
    macro = inputs['macro_history']
    codes = list(macro)
    fee, adjustments = adjust_history(inputs['fee'], config['historical_interpolations'])
    development = fee[['Merchant']].join(macro).loc[dev]
    stationarity, eligible = [], []
    alpha = config['significance_level']
    for name in ['Merchant', *codes]:
        tests = {}
        for transform, det in [('level', 'c'), ('level', 'ct'), ('diff1', 'c')]:
            values = development[name] if transform == 'level' else development[name].diff().dropna()
            row = dict(variable=name, transform=transform, det=det, n=len(values),
                       **adf_test(values, det, config['level_stationarity_adf_maxlag']),
                       **kpss_test(values, det))
            tests[(transform, det)] = row
            stationarity.append(row)
        level, change = tests[('level', 'c')], tests[('diff1', 'c')]
        if (level['adf_p'] >= alpha and level['kpss_p'] < alpha
                and change['adf_p'] < alpha and change['kpss_p'] >= alpha and name != 'Merchant'):
            eligible.append(name)
    statistical, lr_trials, lr_rounds, lr_rc = forward_select(
        development, 'Merchant', eligible, config, adf_gate=True, stage='long_run')
    statistical_model = fit(development, 'Merchant', statistical)
    exclusions = [term for term in config['long_run_negative_coefficient_exclusions']
                  if term in statistical and statistical_model.params[term] < 0]
    final = [term for term in statistical if term not in exclusions]
    lr = fit(development, 'Merchant', final)
    fee['long_run'] = lr.predict(sm.add_constant(macro.loc[fee.index, final], has_constant='add'))
    fee['ec'] = fee.Merchant - fee.long_run
    fee['y'] = fee.Merchant.diff()
    fee['ECT1'] = fee.ec.shift(1)
    features, short_stationarity = {}, []
    for code in codes:
        changes = macro[code].diff()
        values = changes.loc[dev]
        row = dict(code=code, n=len(values), **adf_test(values), **kpss_test(values))
        row['stationary_OR'] = row['adf_p'] < alpha or row['kpss_p'] > alpha
        short_stationarity.append(row)
        for lag in config['macro_lags']:
            features[f'D_{code}_L{lag}'] = changes.shift(lag).reindex(fee.index)
    for lag in config['own_lags']:
        features[f'DY_L{lag}'] = fee.y.shift(lag)
    fee = pd.concat([fee, pd.DataFrame(features, index=fee.index)], axis=1)
    stationary = {r['code'] for r in short_stationarity if r['stationary_OR']}
    screen = []
    for code in codes:
        for lag in config['macro_lags']:
            term = f'D_{code}_L{lag}'
            row = dict(code=code, lag=lag, term=term, stationary=code in stationary)
            for label, dates in [('IS', dev), ('OOT', oot)]:
                row.update({f'{key}_{label}': value for key, value in partial_correlation(fee.loc[dates], term).items()})
            row['same_sign'] = bool(np.sign(row['rho_IS']) == np.sign(row['rho_OOT']))
            row['eligible'] = bool(row['stationary'] and row['same_sign'] and
                                   max(row['p_IS'], row['p_OOT']) < config['partial_correlation_p_limit'])
            screen.append(row)
    screen = pd.DataFrame(screen)
    pool = screen.loc[screen.eligible, 'term'].tolist() + [f'DY_L{lag}' for lag in config['own_lags']]
    sample = fee.loc[dev].dropna(subset=['y', 'ECT1', *pool])
    selected, sr_trials, sr_rounds, sr_rc = forward_select(
        sample, 'y', pool, config, base=['ECT1'], stage='short_run')
    short = fit(sample, 'y', selected)
    return dict(config=config, inputs=inputs, development=dev, oot=oot, fee=fee, adjustments=adjustments,
                stationarity=pd.DataFrame(stationarity), long_run_eligible=eligible,
                long_run_statistical=statistical, long_run_exclusions=exclusions,
                long_run_terms=final, long_model=lr, short_model=short, sample=sample,
                selected=selected, long_run_trials=lr_trials, long_run_rounds=lr_rounds,
                long_run_round_coefficients=lr_rc, macro_lag_screen=screen,
                short_run_stationarity=pd.DataFrame(short_stationarity),
                short_run_trials=sr_trials, short_run_rounds=sr_rounds,
                short_run_round_coefficients=sr_rc,
                coefficients=pd.DataFrame(coefficients(lr, config, 'long_run') +
                                          coefficients(short, config, 'short_run')),
                diagnostics=pd.DataFrame([dict(stage='long_run', **diagnostics(lr, config)),
                                          dict(stage='short_run', **diagnostics(short, config))]))


def available_history(run, asof):
    """Use an interpolated observation only once its right anchor is available."""
    fee = run['fee']
    history = fee.original.loc[:asof].to_dict()
    for row in run['adjustments'].to_dict('records'):
        t = pd.Period(row['month'], 'M')
        if t <= asof and pd.Period(row['available_from'], 'M') <= asof:
            history[t] = float(fee.at[t, 'Merchant'])
    return history


def forecast(run, path, dates, mode='recursive'):
    origin = dates[0] - 1
    history = available_history(run, origin)
    lr, sr = run['long_model'].params, run['short_model'].params
    long_run = pd.Series(float(lr['const']), index=path.index)
    for code in run['long_run_terms']:
        long_run += lr[code] * path[code]
    records = []
    for t in dates:
        if mode == 'one_step':
            history = available_history(run, t - 1)
        values = {}
        for term in sr.index:
            if term == 'const':
                value = 1.0
            elif term == 'ECT1':
                value = history[t - 1] - long_run[t - 1]
            elif term.startswith('DY_L'):
                lag = int(term[4:])
                value = history[t - lag] - history[t - lag - 1]
            else:
                code, lag = term[2:].rsplit('_L', 1)
                lag = int(lag)
                value = path.at[t - lag, code] - path.at[t - lag - 1, code]
            values[term] = float(value)
        contributions = {term: float(sr[term] * value) for term, value in values.items()}
        change = sum(contributions.values())
        predicted = history[t - 1] + change
        records.append(dict(date=str(t), revenue=predicted, prior_revenue=history[t - 1],
                            delta_revenue=change, long_run=float(long_run[t]),
                            **{key: value for key, value in values.items() if key != 'const'},
                            **{f'contribution_{key}': value for key, value in contributions.items()}))
        history[t] = predicted
    return pd.DataFrame(records)


def accuracy(actual, prediction):
    error = np.asarray(prediction) - np.asarray(actual)
    return dict(n=len(error), MAPE=float(np.mean(np.abs(error / actual)) * 100),
                RMSE=float(np.sqrt(np.mean(error**2))), MAE=float(np.mean(np.abs(error))),
                bias=float(np.mean(error)))


def evaluate(run):
    fee, sample = run['fee'], run['sample']
    predictions, performance = [], []
    for mode, dates in [('in_sample', sample.index), ('one_step', run['oot']), ('recursive', run['oot'])]:
        if mode == 'in_sample':
            ecm = (fee.Merchant.shift(1).loc[dates] + run['short_model'].fittedvalues).to_numpy()
        else:
            ecm = forecast(run, run['inputs']['macro_history'], dates, mode).revenue.to_numpy()
        for name, prediction in [('ecm', ecm), ('long_run_only', fee.long_run.loc[dates].to_numpy())]:
            for t, value in zip(dates, prediction):
                predictions.append(dict(model=name, mode=mode, date=str(t),
                                        actual=float(fee.at[t, 'Merchant']), raw_actual=float(fee.at[t, 'original']),
                                        prediction=float(value), long_run=float(fee.at[t, 'long_run'])))
            for target, values in [('adjusted', fee.Merchant.loc[dates]), ('original', fee.original.loc[dates])]:
                performance.append(dict(model=name, mode=mode, scored_against=target,
                                        **accuracy(values.to_numpy(), prediction)))
    run['monthly_predictions'] = pd.DataFrame(predictions)
    run['performance'] = pd.DataFrame(performance)
    dev = run['development']
    run['long_run_accuracy'] = accuracy(fee.Merchant.loc[dev].to_numpy(), fee.long_run.loc[dev].to_numpy())


def aggregate_periods(dates):
    groups = [(str(q), 'quarter', dates.asfreq('Q') == q) for q in dates.asfreq('Q').unique()]
    for year in sorted(set(dates.year)):
        mask = dates.year == year
        label = str(year) if mask.sum() == 12 else f'{year} partial year'
        groups.append((label, 'year', mask))
    groups.append(('Full horizon', 'horizon', np.ones(len(dates), dtype=bool)))
    return groups


def scenario_forecasts(run):
    cfg, inputs = run['config'], run['inputs']
    future = periods(cfg['forecast_start'], cfg['forecast_end'])
    required = list(run['long_run_terms'])
    for term in run['selected']:
        if term.startswith('D_'):
            code = term[2:].rsplit('_L', 1)[0]
            if code not in required:
                required.append(code)
    for scenario in ['s1', 's4']:
        require_values(inputs[scenario], future, required, scenario.upper())
    s1 = pd.concat([inputs['macro_history'], inputs['s1']])
    s4 = s1.copy()
    for code in required:
        s4.loc[future, code] = inputs['s4'][code]
    frames = {name: forecast(run, path, future) for name, path in [('S1', s1), ('S4', s4)]}
    comparison = pd.DataFrame(dict(date=future.astype(str), S1_revenue=frames['S1'].revenue,
                                   S4_revenue=frames['S4'].revenue))
    comparison['S4_minus_S1'] = comparison.S4_revenue - comparison.S1_revenue
    comparison['S4_vs_S1_pct'] = 100 * comparison.S4_minus_S1 / comparison.S1_revenue
    for code in required:
        hybrid = s1.copy()
        hybrid.loc[future, code] = s4.loc[future, code]
        comparison[f'{code}_gap_contribution'] = forecast(run, hybrid, future).revenue - frames['S1'].revenue
        comparison[f'S1_{code}'] = s1.loc[future, code].to_numpy()
        comparison[f'S4_{code}'] = s4.loc[future, code].to_numpy()
    period_rows = []
    for label, kind, mask in aggregate_periods(future):
        a, b = float(comparison.loc[mask, 'S1_revenue'].sum()), float(comparison.loc[mask, 'S4_revenue'].sum())
        period_rows.append(dict(period=label, kind=kind, months=int(mask.sum()), S1_total=a, S4_total=b,
                                gap=b-a, gap_pct=100*(b-a)/a))
    run.update(future=future, required_macros=required, s1_path=s1, s4_path=s4,
               forecast_monthly=pd.concat([f.assign(scenario=name) for name, f in frames.items()], ignore_index=True),
               scenario_comparison=comparison, forecast_periods=pd.DataFrame(period_rows))
    sensitivity, summaries, sensitivity_periods = [], [], []
    for code in required:
        for shock in cfg['sensitivity_shocks_pct']:
            path = s1.copy()
            path.loc[future, code] *= 1 + shock / 100
            case = f'{code}_level_{shock:+g}pct'
            frame = forecast(run, path, future)
            frame['scenario'], frame['driver'], frame['shock_pct'] = case, code, shock
            frame['baseline_revenue'] = frames['S1'].revenue
            frame['revenue_impact'] = frame.revenue - frame.baseline_revenue
            frame['revenue_impact_pct'] = 100 * frame.revenue_impact / frame.baseline_revenue
            for driver in required:
                frame[driver] = path.loc[future, driver].to_numpy()
                frame[f'S1_{driver}'] = s1.loc[future, driver].to_numpy()
            sensitivity.append(frame)
            for label, kind, mask in aggregate_periods(future):
                a, b = float(frame.loc[mask, 'baseline_revenue'].sum()), float(frame.loc[mask, 'revenue'].sum())
                row = dict(scenario=case, driver=code, shock_pct=shock, period=label, kind=kind,
                           months=int(mask.sum()), baseline_total=a, forecast_total=b,
                           revenue_impact=b-a, revenue_impact_pct=100*(b-a)/a)
                sensitivity_periods.append(row)
                if kind == 'horizon':
                    peak = frame.loc[frame.revenue_impact.abs().idxmax()]
                    summaries.append(dict(**row, terminal_impact=float(frame.revenue_impact.iloc[-1]),
                                          terminal_impact_pct=float(frame.revenue_impact_pct.iloc[-1]),
                                          peak_absolute_impact=float(abs(peak.revenue_impact)), peak_month=peak.date))
    run['sensitivity_monthly'] = pd.concat(sensitivity, ignore_index=True) if sensitivity else pd.DataFrame()
    run['sensitivity_periods'] = pd.DataFrame(sensitivity_periods)
    run['sensitivity_summary'] = pd.DataFrame(summaries)


def serializable(value):
    if isinstance(value, dict):
        return {str(k): serializable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [serializable(v) for v in value]
    if isinstance(value, np.generic):
        return serializable(value.item())
    if isinstance(value, float) and not np.isfinite(value):
        return None
    return value


def save_json(path, value):
    path.write_text(json.dumps(serializable(value), indent=2, allow_nan=False) + '\n', encoding='utf-8')


def export_results(run, output_dir):
    names = ['adjustments', 'stationarity', 'long_run_trials', 'long_run_rounds',
             'long_run_round_coefficients', 'short_run_stationarity', 'macro_lag_screen',
             'short_run_trials', 'short_run_rounds', 'short_run_round_coefficients',
             'coefficients', 'diagnostics', 'monthly_predictions', 'performance',
             'forecast_monthly', 'scenario_comparison', 'forecast_periods',
             'sensitivity_monthly', 'sensitivity_periods', 'sensitivity_summary']
    for name in names:
        run[name].to_csv(output_dir / f'{name}.csv', index=False, float_format='%.17g')
    for name, frame in [('historical_data_and_features', run['fee']), ('estimation_sample', run['sample'])]:
        frame.rename_axis('date').to_csv(output_dir / f'{name}.csv', float_format='%.17g')
    fitted = dict(long_run=dict(run['long_model'].params), short_run=dict(run['short_model'].params))
    save_json(output_dir / 'model_summary.json', dict(
        long_run_eligible=run['long_run_eligible'], long_run_statistical=run['long_run_statistical'],
        long_run_economic_exclusions=run['long_run_exclusions'], long_run_terms=run['long_run_terms'],
        short_run_terms=run['selected'], parameters=fitted, long_run_accuracy=run['long_run_accuracy'],
        diagnostics=run['diagnostics'].to_dict('records')))


def validate_config(cfg):
    if not cfg['macro_lags'] or any(lag not in (1, 2, 3, 6, 12) for lag in cfg['macro_lags']):
        raise ValueError('Monthly macro lags must be chosen from 1, 2, 3, 6, 12')
    if not cfg['own_lags'] or any(not isinstance(lag, int) or lag < 1 for lag in cfg['own_lags']):
        raise ValueError('Own lags must be positive integers')
    if len(set(cfg['macro_lags'])) != len(cfg['macro_lags']) or len(set(cfg['own_lags'])) != len(cfg['own_lags']):
        raise ValueError('Lag grids must not contain duplicates')
    shocks = cfg['sensitivity_shocks_pct']
    if not shocks or not all(np.isfinite(s) and s > -100 for s in shocks) or len(set(shocks)) != len(shocks):
        raise ValueError('Sensitivity shocks must be unique finite percentages above -100')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--data-dir', type=Path, default=HERE / 'data')
    parser.add_argument('--config', type=Path, default=HERE / 'config.json')
    parser.add_argument('--output-dir', type=Path, default=HERE / 'results')
    args = parser.parse_args()
    data_dir, config_path, output_dir = args.data_dir.resolve(), args.config.resolve(), args.output_dir.resolve()
    cfg = json.loads(config_path.read_text(encoding='utf-8'))
    validate_config(cfg)
    if output_dir.exists() and any(output_dir.iterdir()):
        parser.error('Use a new or empty --output-dir; existing results are never overwritten')
    inputs = load_inputs(data_dir, cfg)
    run = estimate(inputs, cfg)
    evaluate(run)
    scenario_forecasts(run)
    output_dir.mkdir(parents=True, exist_ok=True)
    export_results(run, output_dir)
    from merchant_charts import create_figures
    from merchant_report import create_report
    figures = create_figures(run, output_dir / 'figures')
    report = create_report(run, figures, output_dir)
    input_files = [config_path, *sorted(data_dir.glob('*.csv')), data_dir / 'sources.json']
    versions = {name: importlib.metadata.version(name) for name in
                ['numpy', 'pandas', 'scipy', 'statsmodels', 'matplotlib', 'python-docx']}
    save_json(output_dir / 'run_manifest.json', dict(
        config=cfg, python=platform.python_version(), libraries=versions,
        inputs=[dict(file=p.name, sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in input_files],
        sources=inputs['sources'], outputs=[str(p.relative_to(output_dir)) for p in sorted(output_dir.rglob('*')) if p.is_file()],
        figure_sources={name: meta['source'] for name, meta in figures.items()}))
    print('Long-run terms:', ', '.join(run['long_run_terms']) or 'Intercept only')
    print('Short-run terms:', ', '.join(run['selected']))
    print('Generated results:', output_dir)
    print('Generated Word report:', report.name)


if __name__ == '__main__':
    main()
