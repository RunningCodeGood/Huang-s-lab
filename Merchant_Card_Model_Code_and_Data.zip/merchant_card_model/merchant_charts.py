"""Generate every report figure from the current model run."""
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from matplotlib.ticker import FuncFormatter, MaxNLocator

COLORS = dict(actual='#182B3A', long='#A56429', fitted='#007F87', recursive='#B34E68',
              S1='#226B9B', S4='#B9443C')


def style(ax, ylabel, zero=True):
    ax.set_ylabel(ylabel, fontsize=9)
    ax.grid(axis='y', color='#E2E6EA', linewidth=.7)
    ax.set_axisbelow(True)
    ax.yaxis.set_major_locator(MaxNLocator(nbins=6))
    ax.tick_params(labelsize=9)
    if zero:
        ax.set_ylim(bottom=0)


def create_figures(run, output_dir):
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 10,
                         'axes.spines.top': False, 'axes.spines.right': False,
                         'axes.edgecolor': '#ADB8C0', 'figure.facecolor': 'white',
                         'axes.facecolor': 'white', 'svg.hashsalt': 'merchant-model'})
    figures = {}

    def save(fig, key, source, alt, zero_axes=()):
        for ax in zero_axes:
            ax.set_ylim(bottom=0)
        path = output_dir / (key + '.png')
        fig.savefig(path, dpi=220, facecolor='white')
        fig.savefig(path.with_suffix('.svg'), facecolor='white', metadata={'Date': None})
        figures[key] = dict(path=path, source=source, alt=alt)
        plt.close(fig)

    dev = run['fee'].loc[run['development']]
    x = dev.index.to_timestamp()
    fig, ax = plt.subplots(figsize=(9.7, 3.6))
    ax.plot(x, dev.Merchant/1e6, color=COLORS['actual'], lw=1.6, label='Adjusted actual revenue')
    ax.plot(x, dev.long_run/1e6, color=COLORS['long'], lw=1.7, label='Long-run fitted level')
    style(ax, 'Revenue\nMillions of source units')
    ax.legend(loc='upper left', ncol=2, frameon=False, fontsize=9)
    ax.xaxis.set_major_locator(mdates.YearLocator(2))
    ax.xaxis.set_major_formatter(mdates.DateFormatter('%Y'))
    ax.set_xlim(x.min(), x.max())
    ax.set_ylim(top=max(dev.Merchant.max(), dev.long_run.max())/1e6*1.22)
    fig.tight_layout()
    save(fig, 'figure_1_long_run_fit', 'historical_data_and_features.csv',
         'Adjusted revenue and long-run fitted level over the development sample.', [ax])

    fig, ax = plt.subplots(figsize=(9.7, 4.4))
    ax.plot(x, dev.ec/1e6, color=COLORS['fitted'], lw=1.6)
    ax.axhline(0, color='#555555', lw=1)
    style(ax, 'Long-run gap Y minus L\nMillions of source units', zero=False)
    ax.xaxis.set_major_locator(mdates.YearLocator(2))
    ax.xaxis.set_major_formatter(mdates.DateFormatter('%Y'))
    ax.set_xlim(x.min(), x.max())
    fig.tight_layout()
    save(fig, 'figure_2_in_sample_gap', 'historical_data_and_features.csv',
         'In-sample long-run gap e equals Y minus L, with positive and negative values and a zero reference line.')

    fig, axes = plt.subplots(2, 1, figsize=(9.7, 7.0))
    predictions = run['monthly_predictions']
    for ax, mode, title in zip(axes, ['in_sample', 'one_step'], ['In-sample fitted revenue', 'OOT revenue']):
        f = predictions[(predictions.model == 'ecm') & (predictions['mode'] == mode)]
        dates = pd.to_datetime(f.date)
        ax.plot(dates, f.actual/1e6, color=COLORS['actual'], lw=1.6, label='Adjusted actual revenue')
        ax.plot(dates, f.prediction/1e6, color=COLORS['fitted'], lw=1.5,
                label='ECM fitted revenue' if mode == 'in_sample' else 'One-step OOT prediction')
        ax.plot(dates, f.long_run/1e6, color=COLORS['long'], lw=1.4, ls='--', label='Long-run fitted level')
        if mode == 'one_step':
            rec = predictions[(predictions.model == 'ecm') & (predictions['mode'] == 'recursive')]
            ax.plot(dates, rec.prediction/1e6, color=COLORS['recursive'], lw=1.5, label='Recursive OOT prediction')
        style(ax, 'Revenue\nMillions of source units')
        ax.set_title(title, loc='left', fontsize=12, pad=10)
        ax.set_ylim(top=max(f.actual.max(), f.prediction.max(), f.long_run.max())/1e6*1.28)
        ax.legend(loc='upper left', ncol=2, frameon=False, fontsize=8.5)
        ax.xaxis.set_major_locator(mdates.YearLocator(2) if mode == 'in_sample' else mdates.MonthLocator(interval=4))
        ax.xaxis.set_major_formatter(mdates.DateFormatter('%Y' if mode == 'in_sample' else '%b %Y'))
        ax.set_xlim(dates.min(), dates.max())
    fig.tight_layout(pad=1.2, h_pad=2.2)
    save(fig, 'figure_3_ecm_fit_oot', 'monthly_predictions.csv',
         'Monthly in-sample revenue fit, one-step OOT and recursive OOT forecasts.', axes)

    codes = run['required_macros']
    dictionary = run['inputs']['dictionary'].set_index('code')
    monthly = run['scenario_comparison']
    dates = pd.to_datetime(monthly.date)
    fig, axes = plt.subplots(max(1, len(codes)), 1, figsize=(10.5, max(3, 2.5*len(codes)+1)),
                             sharex=True, squeeze=False)
    for ax, code in zip(axes[:, 0], codes):
        for scenario in ['S1', 'S4']:
            ax.plot(dates, monthly[f'{scenario}_{code}'], color=COLORS[scenario], lw=1.7,
                    marker='o', ms=2.8, label=scenario)
        style(ax, dictionary.at[code, 'unit'])
        ax.set_title(f'{code}  {dictionary.at[code, "description"]}', loc='left', fontsize=10.5, pad=9)
        ax.yaxis.set_major_formatter(FuncFormatter(lambda v, pos: f'{v:,.0f}'))
        ax.set_ylim(top=monthly[[f'S1_{code}', f'S4_{code}']].max().max()*1.20)
        ax.legend(loc='lower left', ncol=2, frameon=False, fontsize=9)
    axes[-1, 0].set_xticks(dates)
    axes[-1, 0].set_xticklabels(dates.dt.strftime('%b %Y'), rotation=90, fontsize=8)
    axes[-1, 0].set_xlim(dates.min(), dates.max())
    fig.tight_layout(pad=1.2, h_pad=1.7)
    save(fig, 'figure_4_monthly_macro_paths', 'scenario_comparison.csv',
         'S1 and S4 scenario macro levels, with every forecast month plotted and labelled.', axes[:, 0])

    quarterly = run['forecast_periods'].query('kind == "quarter"')
    fig, ax = plt.subplots(figsize=(10.5, 3.6))
    for scenario in ['S1', 'S4']:
        ax.plot(quarterly.period, quarterly[f'{scenario}_total']/1e6, marker='o', ms=4,
                color=COLORS[scenario], lw=2, label=f'{scenario} ECM forecast')
    style(ax, 'Quarterly revenue\nMillions of source units')
    ax.set_ylim(top=quarterly[['S1_total', 'S4_total']].max().max()/1e6*1.20)
    ax.legend(loc='lower left', ncol=2, frameon=False, fontsize=9)
    fig.tight_layout(pad=1.2)
    save(fig, 'figure_5_quarterly_revenue', 'forecast_periods.csv',
         'Quarterly totals summed from the monthly recursive S1 and S4 revenue forecasts.', [ax])

    summary = run['sensitivity_summary']
    fig, ax = plt.subplots(figsize=(10.5, max(4, .58*len(summary)+1.35)))
    positions, labels = [], []
    prior, gap = None, 0.0
    for i, row in summary.iterrows():
        if prior is not None and row.driver != prior:
            gap += .6
        positions.append(i+gap)
        labels.append(f'{row.driver} level {row.shock_pct:+g}%'.replace('-', '−'))
        prior = row.driver
    values = summary.revenue_impact_pct.to_numpy()
    limit = max(1, float(np.max(np.abs(values)))) * 1.34
    ax.barh(positions, values, height=.69, color=['#AD6237' if v < 0 else '#305A73' for v in values])
    ax.set_yticks(positions, labels, fontsize=11)
    ax.invert_yaxis()
    ax.set_xlim(-limit, limit)
    ax.axvline(0, color='#555555', lw=1)
    ax.grid(axis='x', color='#D7D7D7', lw=.8, alpha=.65)
    ax.set_axisbelow(True)
    for y, value in zip(positions, values):
        ax.text(value + (limit*.02 if value >= 0 else -limit*.02), y,
                f'{value:+.2f}%'.replace('-', '−'), va='center',
                ha='left' if value >= 0 else 'right', fontsize=10.5)
    n_quarters = len(quarterly)
    ax.set_xlabel(f'{n_quarters}-quarter revenue impact versus S1 (%)', labelpad=10)
    fig.subplots_adjust(left=.25, right=.97, top=.96, bottom=.14)
    save(fig, 'figure_6_sensitivity_impacts', 'sensitivity_summary.csv',
         'Individual macro percentage level shocks and their cumulative revenue impacts relative to S1; bars start at zero.')
    return figures
