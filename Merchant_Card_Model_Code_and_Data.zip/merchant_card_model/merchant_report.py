"""Build the complete English report using the current run's calculated objects."""
import numpy as np
import pandas as pd

from report_layout import Writer, sub, power, fraction, square_root, number as nf, probability as pf, kpss_probability as kp, term_name


def records(frame):
    return frame.to_dict('records')


def percent(value):
    if value == 0:
        return '0.00%'
    digits = 4 if abs(value) < .005 else 2
    return f'{value:+.{digits}f}%'.replace('-', '−')


def coefficient(value):
    return nf(value, 6 if abs(value) < 1 else 2)


def month_label(period):
    return period.to_timestamp().strftime('%b %Y')


def create_report(run, figures, output_dir):
    w = Writer()
    cfg = run['config']
    dev, oot, future = run['development'], run['oot'], run['future']
    fee = run['fee']
    lr, sr = run['long_model'], run['short_model']
    dictionary = run['inputs']['dictionary'].set_index('code')
    diag = run['diagnostics'].set_index('stage')
    screen = run['macro_lag_screen']
    passing = screen.loc[screen.eligible]
    sample = run['sample']
    alpha, vif_limit = cfg['significance_level'], cfg['vif_limit']
    period_totals = run['forecast_periods']
    total = period_totals.query('kind == "horizon"').iloc[0]
    monthly = run['scenario_comparison']
    end = monthly.iloc[-1]
    codes = run['required_macros']

    def coefficient_table(frame, round_column=False):
        headers = (['Round'] if round_column else []) + ['Parameter', 'Coefficient', 'OLS p', 'HAC p', 'VIF']
        rows = []
        for r in records(frame):
            vif = r['VIF']
            rows.append(([int(r['round'])] if round_column else []) +
                        [term_name(r['term']), coefficient(r['coefficient']), pf(r['OLS_p']),
                         pf(r['HAC_p']), '—' if pd.isna(vif) else nf(vif, 3)])
        w.table(headers, rows, ([.5] if round_column else []) + [2.5, 1.3, 1.1, 1.1, .7], font=9.2,
                left=(0, 1) if round_column else (0,))

    def equation(model, lhs, long_run=False):
        terms = list(model.params.items())
        pieces = [sub(lhs, 't'), ' = ', coefficient(terms[0][1])]
        for term, beta in terms[1:]:
            sign = ' + ' if beta >= 0 else ' − '
            if long_run:
                symbol = sub(term, 't')
            elif term == 'ECT1':
                symbol = sub('e', 't−1')
            elif term.startswith('DY_L'):
                symbol = sub('ΔY', 't−' + term[4:])
            else:
                code, lag = term[2:].rsplit('_L', 1)
                symbol = sub('Δ' + code, 't−' + lag)
            if len(pieces) > 8:
                w.equation(pieces)
                pieces = ['        ']
            pieces.extend([sign + coefficient(abs(beta)) + ' ', symbol])
        if not long_run:
            pieces.extend([' + ', sub('ε', 't')])
        w.equation(pieces)

    def fit_diagnostics(stage):
        d = diag.loc[stage]
        lag = cfg['diagnostic_lags']
        w.table(['Statistic', 'Value', 'Statistic', 'Value'], [
            ['Observations', int(d.n), 'Residual degrees of freedom', int(d.df_resid)],
            ['R squared', nf(d.R2, 4), 'Adjusted R squared', nf(d.adj_R2, 4)],
            ['Durbin Watson', nf(d.DW, 3), 'Maximum VIF', nf(d.max_VIF, 3)],
            [f'Ljung Box {lag} lag p', pf(d.LB_p), f'Breusch Godfrey {lag} lag p', pf(d.BG_p)],
            ['Jarque Bera p', pf(d.JB_p), 'Ordinary residual ADF p', pf(d.residual_ADF_p)],
            ['Residual ADF lag', int(d.residual_ADF_lag), 'AIC', nf(d.AIC, 2)]
        ], [2.05, 1.05, 2.75, 1.25], left=(0, 2), font=9.2)

    def round_table(frame):
        w.table(['Round', 'Added term', 'Tried', 'Passed', 'Adj R²', 'Max VIF', 'Residual ADF p'],
                [[r['round'], term_name(r['added']), r['candidates_tried'], r['eligible_candidates'],
                  nf(r['adj_R2'], 4), nf(r['max_VIF'], 3), pf(r['residual_ADF_p'])] for r in records(frame)],
                [.5, 1.65, .5, .55, .8, 1.05, 1.35], font=9.1, left=(0, 1))

    def performance(model, mode, target='adjusted'):
        f = run['performance']
        return f[(f.model == model) & (f['mode'] == mode) & (f.scored_against == target)].iloc[0]

    w.doc.add_paragraph('Merchant Card Fee Revenue Model', style='Title')
    w.doc.add_paragraph('Monthly ECM and S1 S4 scenario forecasts', style='Subtitle')
    w.text(f'The long-run equation uses {", ".join(run["long_run_terms"]) or "an intercept"}. '
           f'The monthly error-correction equation retains {", ".join(term_name(t) for t in run["selected"])}. '
           f'Scenario forecasts cover {month_label(future[0])} to {month_label(future[-1])}, '
           f'with {len(future)} monthly forecasts per scenario.')
    w.heading('1 Historical adjustments')
    w.text('The dependent variable is the original Merchant fee observation, Month_actual_num. '
           'Let Y denote the adjusted series. Each replacement is calculated by linear interpolation '
           'between the original left and right anchor observations before monthly differences are taken.', small=True)
    w.table(['Month', 'Original', 'Adjusted', 'Interpolation anchors'],
            [[r['month'], nf(r['original']), nf(r['adjusted'], 2),
              f'{r["left_anchor"]} to {r["right_anchor"]}'] for r in records(run['adjustments'])],
            [.8, 1.3, 1.3, 3.7])
    w.text(f'{len(run["adjustments"])} observations are adjusted. All other revenue observations retain their original values. '
           'Revenue remains in the source series units.', small=True)
    w.heading('2 Revenue stationarity')
    w.text(f'Development covers {month_label(dev[0])} to {month_label(dev[-1])}; '
           f'OOT covers {month_label(oot[0])} to {month_label(oot[-1])}.', small=True)
    station = run['stationarity']
    target = station[station.variable == 'Merchant']
    w.table(['Series', 'N', 'ADF p', 'ADF lag', 'KPSS p'],
            [[r['transform'] + ' ' + r['det'], r['n'], pf(r['adf_p']), r['adf_lag'], kp(r['kpss_p'])]
             for r in records(target)], [2.7, .45, 1.4, 1.1, 1.45])
    w.text(f'Level tests use a constant (c) or a constant and linear trend (ct). ADF uses a maximum lag of '
           f'{cfg["level_stationarity_adf_maxlag"]} with AIC; KPSS uses automatic bandwidth. '
           'KPSS endpoint probabilities are bounds.', small=True)

    w.heading('3 Long run screening and selection', page=True)
    w.text(f'All {len(dictionary)} macro candidates are screened on {len(dev)} development observations. '
           f'The I1 rule requires level ADF p ≥ {alpha:g} and KPSS p < {alpha:g}, '
           f'with first-difference ADF p < {alpha:g} and KPSS p ≥ {alpha:g}. '
           'Constant-only tests determine eligibility; trend tests provide supplementary evidence.')
    w.heading('Eligible macro candidates', 2)
    w.table(['Mnemonic', 'Description'],
            [[dictionary.at[c, 'mnemonic'], dictionary.at[c, 'description']] for c in run['long_run_eligible']],
            [2.2, 4.9], left=(0, 1))
    w.heading('Forward selection', 2)
    w.text(f'Start with an intercept. Each trial adds one eligible macro level. The added OLS p-value must '
           f'be below {alpha:g}, maximum nonconstant VIF below {vif_limit:g}, and ordinary residual ADF '
           f'p-value below {alpha:g}. Among passing trials, retain the highest adjusted R squared; '
           'ties use alphabetical candidate order. Stop when no candidate passes.', small=True)
    round_table(run['long_run_rounds'])
    w.text('Economic sign rule: after statistical selection, remove any configured '
           f'negative-coefficient exclusion ({", ".join(cfg["long_run_negative_coefficient_exclusions"]) or "none"}) '
           'whose jointly estimated coefficient is negative, then jointly re-estimate the retained terms. '
           f'Terms removed in this run: {", ".join(run["long_run_exclusions"]) or "none"}. '
           'This is an explicit specification rule.', small=True)

    w.heading('4 Final long run equation', page=True)
    equation(lr, 'L', True)
    w.equation([sub('e', 't'), ' = ', sub('Y', 't'), ' − ', sub('L', 't')])
    coefficient_table(run['coefficients'].query('stage == "long_run"'))
    w.text('Macro units: ' + '; '.join(f'{c}: {dictionary.at[c, "unit"]}' for c in run['long_run_terms']) + '.', small=True)
    m = run['long_run_accuracy']
    w.text(f'Over all {m["n"]} development months, long-run MAPE is {m["MAPE"]:.2f}%, '
           f'RMSE is {nf(m["RMSE"])} and MAE is {nf(m["MAE"])} source units.', small=True)
    w.figure(figures['figure_1_long_run_fit'], 'Figure 1  Long run fitted revenue over the development period')
    w.text(f'OLS coefficients are estimated jointly from adjusted revenue and macro levels. '
           f'HAC inference uses {cfg["diagnostic_lags"]} covariance lags, a finite-sample correction and a Student t reference. '
           'Displayed coefficients are rounded; computations use full precision.', small=True)

    w.heading('In sample long run residuals', page=True)
    w.figure(figures['figure_2_in_sample_gap'], 'Figure 2  In sample long run residual e equals Y minus L')
    w.text(f'The figure includes only the {len(dev)} development months. Positive values indicate revenue above '
           'the estimated long-run level; negative values indicate revenue below it. The horizontal line marks zero. '
           'This is the long-run gap used in the ECM, distinct from the short-run regression innovation.', small=True)
    fit_diagnostics('long_run')
    w.text('The ordinary residual ADF is a screening statistic. The two-step empirical specification and '
           'this residual test do not by themselves establish formal Engle Granger cointegration.', small=True)

    w.heading('5 Monthly short run screening', page=True)
    w.equation([sub('ECT1', 't'), ' = ', sub('e', 't−1'), ' = ', sub('Y', 't−1'), ' − ', sub('L', 't−1')])
    w.text('Freeze the estimated long-run coefficients and model the arithmetic monthly change ΔY. '
           'An intercept and the prior-month gap ECT1 enter every trial.')
    w.text(f'Transform all {len(dictionary)} macro levels to monthly first differences, then test macro lags '
           f'{", ".join(map(str, cfg["macro_lags"]))}. This creates {len(screen)} macro-lag combinations. '
           f'Revenue-change own lags are {", ".join(map(str, cfg["own_lags"]))}. '
           'Long-run regressors remain contemporaneous levels.', small=True)
    w.heading('Stationarity and partial correlation rules', 2)
    w.text(f'A macro difference is eligible for screening when ADF p < {alpha:g} or KPSS p > {alpha:g}. '
           f'{int(run["short_run_stationarity"].stationary_OR.sum())} of {len(dictionary)} macro differences pass. '
           'These tests include the pre-development macro history needed to calculate the initial change. '
           'ADF selects its lag by AIC with the default maximum; KPSS uses automatic bandwidth.')
    w.text('Residualize both ΔY and the lagged macro difference on an intercept and ECT1. '
           'The partial-correlation statistic uses N − 3 degrees of freedom. '
           f'Require p < {cfg["partial_correlation_p_limit"]:g} in both development and OOT and the same correlation sign.')
    w.equation(['t = r ', square_root(fraction('N − 3', ['1 − ', power('r', '2')])), '     df = N − 3'])
    w.heading('Passing macro lag combinations', 2)
    w.table(['Term', 'IS r', 'IS p', 'IS N', 'OOT r', 'OOT p', 'OOT N'],
            [[term_name(r['term']), nf(r['rho_IS'], 4), pf(r['p_IS']), r['n_IS'], nf(r['rho_OOT'], 4),
              pf(r['p_OOT']), r['n_OOT']] for r in records(passing)],
            [1.55, .85, .95, .5, .85, 1.15, .6], font=9)
    w.heading('Common regression sample', 2)
    w.text(f'Combine the {len(passing)} passing macro features with {len(cfg["own_lags"])} own-lag candidates. '
           f'All short-run trials use {len(sample)} complete observations from {month_label(sample.index[0])} '
           f'to {month_label(sample.index[-1])}. A trial passes when the added OLS p-value is below {alpha:g} '
           f'and maximum nonconstant VIF is below {vif_limit:g}. Select the highest adjusted R squared. '
           'Residual ADF is diagnostic at this stage; regression degrees of freedom are N minus rank of X.')
    w.text('The lag restriction concerns macro regressors. Diagnostic and covariance lag settings are separate. '
           'Previously retained terms are not re-screened for significance after each addition.', small=True)

    w.heading('6 Short run forward selection', page=True)
    round_table(run['short_run_rounds'])
    w.heading('Coefficients after each retained round', 2)
    for rnd, frame in run['short_run_round_coefficients'].groupby('round', sort=True):
        w.heading(f'Round {int(rnd)}', 2)
        coefficient_table(frame)
    w.text('Round zero is the intercept and ECT1 baseline. Each successful addition is estimated jointly '
           'with all retained terms. A stop round leaves the preceding equation unchanged.', small=True)

    w.heading('7 Final monthly error correction model', page=True)
    equation(sr, 'ΔY')
    coefficient_table(run['coefficients'].query('stage == "short_run"'))
    fit_diagnostics('short_run')
    w.text(f'The ECT1 coefficient is {coefficient(sr.params["ECT1"])}. '
           'It measures the monthly response to the prior revenue gap, conditional on the other regressors. '
           'Inference is conditional on variable selection and the estimated long-run relation.')
    w.heading('Reconstruction and recursion', 2)
    w.equation([sub('Ŷ', 't'), ' = ', sub('Y', 't−1'), ' + ', sub('ΔŶ', 't')])
    w.text('One-step evaluation refreshes observed revenue history each month. Recursive forecasts carry '
           'predicted revenue forward after the forecast origin, updating its change and its gap from the '
           'scenario-specific long-run level. Future innovations are set to zero. The development coefficients '
           'remain fixed for OOT, S1, S4 and sensitivity forecasts; there is no end-of-history refit.')

    w.heading('8 In sample and OOT performance', page=True)
    modes = [('in_sample', 'In sample'), ('one_step', 'OOT one step'), ('recursive', 'OOT recursive')]
    rows = []
    for mode, label in modes:
        for model, model_label in [('long_run_only', 'Long run only'), ('ecm', 'ECM')]:
            r = performance(model, mode)
            rows.append([label, model_label, f'{r.MAPE:.2f}%', nf(r.RMSE), nf(r.MAE), nf(r.bias)])
    w.table(['Evaluation', 'Model', 'MAPE', 'RMSE', 'MAE', 'Bias'], rows,
            [1.2, 1.35, .85, 1.3, 1.2, 1.2], left=(0, 1))
    w.text(f'The main table scores adjusted revenue. The in-sample comparison contains {len(sample)} months; '
           f'OOT contains {len(oot)} months. RMSE, MAE and bias retain source units. Bias is prediction minus observation.', small=True)
    w.heading('Scores against original revenue observations', 2)
    w.table(['ECM evaluation', 'N', 'MAPE', 'RMSE', 'MAE'],
            [[label, int(r.n), f'{r.MAPE:.2f}%', nf(r.RMSE), nf(r.MAE)]
             for mode, label in modes for r in [performance('ecm', mode, 'original')]],
            [2.3, .5, 1.1, 1.6, 1.6])
    w.heading('Interpretation of OOT evidence', 2)
    w.text('The OOT macro partial correlations participate in selection. These are therefore selection-informed '
           'validation scores. A new untouched period is needed for an independent forecast assessment. '
           'The supplied macro vintage does not represent historical release availability.')
    w.text('An interpolated revenue observation becomes available only when its right anchor month has been observed. '
           'Before that date, one-step history uses the original observation. Recursive OOT starts with available '
           'development history and does not consume subsequent observed revenue.', small=True)

    w.heading('9 Monthly revenue paths', page=True)
    w.figure(figures['figure_3_ecm_fit_oot'], 'Figure 3  In sample fit and monthly OOT predictions')
    w.text('The upper panel shows the fitted monthly ECM alongside adjusted observations and the long-run level. '
           'The lower panel shows one-step and recursive OOT paths. Both revenue axes start at zero.', small=True)
    w.heading('Calculation outputs', 2)
    w.text('Historical adjustments, stationarity tests, candidate trials, coefficients, model diagnostics and '
           'prediction detail are exported as CSV files. Figures and Word tables use these same current-run '
           'calculations. CSV values retain full numerical precision.', small=True)

    w.heading('10 S1 and S4 scenario forecasts', page=True)
    w.text(f'Across {len(future)} months, S1 revenue totals {nf(total.S1_total)} source units and S4 totals '
           f'{nf(total.S4_total)}. The S4 change relative to S1 is {percent(total.gap_pct)}. '
           f'In {month_label(future[-1])}, the forecast is {nf(end.S1_revenue)} under S1 and '
           f'{nf(end.S4_revenue)} under S4.')
    w.heading('External macro assumptions', 2)
    source = run['inputs']['sources']
    w.text(f'S1 uses {source["macro_s1.csv"]["vintage"]}. S4 uses '
           f'{source["macro_s4.csv"]["vintage"]}. Scenario inputs are supplied macro level assumptions; '
           'they are not forecasts estimated by the Merchant equation. The two vintages differ, so the revenue '
           'gap combines scenario and release effects.', small=True)
    origin = future[0] - 1
    w.heading('Common initial conditions', 2)
    w.table(['Initial condition at ' + month_label(origin), 'Value'],
            [['Adjusted revenue', nf(fee.at[origin, 'Merchant'], 2)],
             ['Monthly revenue change', nf(fee.at[origin, 'y'], 2)],
             ['Long-run level', nf(fee.at[origin, 'long_run'], 2)],
             ['Revenue gap', nf(fee.at[origin, 'ec'], 2)]], [4.8, 2.3])
    w.heading('Revenue by forecast period', 2)
    w.table(['Period', 'S1 total', 'S4 total', 'S4 minus S1', 'Change'],
            [[r['period'], nf(r['S1_total']), nf(r['S4_total']), nf(r['gap']), percent(r['gap_pct'])]
             for r in records(period_totals[period_totals.kind != 'quarter'])],
            [1.5, 1.45, 1.45, 1.45, 1.25])
    w.text('Each scenario uses the same historical starting conditions. At each month, the code calculates '
           'the lagged gap and selected differences, predicts ΔY, and adds it to prior revenue. The resulting '
           'revenue enters the next monthly calculation. Totals sum unrounded monthly forecasts.', small=True)

    w.heading('Monthly macro paths and quarterly revenue', page=True)
    w.figure(figures['figure_4_monthly_macro_paths'],
             'Figure 4  S1 and S4 monthly paths for ' + ' and '.join(codes))
    w.figure(figures['figure_5_quarterly_revenue'], 'Figure 5  S1 and S4 quarterly Merchant revenue forecasts')
    w.text('All macro observations and recursions are monthly. Quarterly revenue sums the monthly forecasts '
           'within each calendar quarter. Numerical level axes start at zero.', small=True)

    w.heading('Monthly scenario results', page=True)
    w.table(['Month', 'S1 ECM', 'S4 ECM', 'S4 minus S1', 'Change'],
            [[r['date'], nf(r['S1_revenue']), nf(r['S4_revenue']), nf(r['S4_minus_S1']), percent(r['S4_vs_S1_pct'])]
             for r in records(monthly)], [1.1, 1.5, 1.5, 1.65, 1.35], font=9)
    w.heading('Terminal month gap by macro driver', 2)
    w.table(['Driver replaced by S4', 'Revenue contribution'],
            [[c, nf(end[f'{c}_gap_contribution'], 2)] for c in codes], [4.8, 2.3])
    w.text('Each contribution reruns the monthly model with one S4 macro path and all remaining drivers at S1. '
           'The fixed linear ECM makes these contributions additive.', small=True)

    w.heading('11 Macro sensitivity tests', page=True)
    shocks = ', '.join(f'{x:+g}%' for x in cfg['sensitivity_shocks_pct'])
    w.text(f'Change one future macro at a time by {shocks}. Other macros remain at S1. '
           f'The test grid contains {len(run["sensitivity_summary"])} cases for the selected model drivers.')
    w.equation([power(sub('X', 'j,t'), 'test'), ' = ', power(sub('X', 'j,t'), 'S1'),
                ' × (1 + ', fraction('s', '100'), ')'])
    w.text(f'Each multiplier applies to every future monthly macro level from {month_label(future[0])} '
           f'to {month_label(future[-1])}. The percentage adjustment is constant relative to each S1 monthly '
           'level. It does not compound monthly and is not a percentage-point growth shock. Historical levels, '
           'coefficients, selected terms, lag choices and starting revenue remain fixed.')
    w.text('For each case, regenerate the long-run level and macro first differences, then recurse the complete '
           'monthly ECM. Effects equal test revenue minus S1 revenue. Period percentages divide the difference '
           'in summed revenue by the matching S1 total; they do not average monthly percentages.')
    w.heading('Cumulative and terminal effects', 2)
    sensitivity = run['sensitivity_summary']
    w.table(['Driver', 'Level shock', 'Horizon revenue\nchange millions', 'Horizon\nchange', 'Terminal\nchange'],
            [[r['driver'], percent(r['shock_pct']), nf(r['revenue_impact']/1e6, 3),
              percent(r['revenue_impact_pct']), percent(r['terminal_impact_pct'])] for r in records(sensitivity)],
            [1.1, 1.05, 1.75, 1.6, 1.6], font=9.2)
    w.text('Amounts in the table are millions of source units. The signed responses are conditional model '
           'sensitivities. The linear equation and proportional level shocks imply proportional responses; '
           'these paths do not represent probability intervals.', small=True)

    w.heading('Sensitivity impacts over the forecast horizon', page=True)
    w.figure(figures['figure_6_sensitivity_impacts'],
             'Figure 6  Merchant sensitivity impacts from individual macro level changes')
    w.text('The horizontal axis is the percentage change in cumulative forecast revenue relative to S1. '
           'The categorical vertical axis identifies the driver and input shock. Every bar starts at zero; '
           'brown denotes reductions and blue denotes increases.', small=True)
    yearly = run['sensitivity_periods'].query('kind == "year"')
    years = yearly.period.drop_duplicates().tolist()
    lookup = yearly.set_index(['scenario', 'period'])
    w.table(['Sensitivity', *years],
            [[f'{r["driver"]} {r["shock_pct"]:+g}%',
              *[percent(lookup.at[(r['scenario'], year), 'revenue_impact_pct']) for year in years]]
             for r in records(sensitivity)], [2.0, *([1.7]*len(years))], font=9.1)

    w.heading('Appendix A Macro stationarity results', page=True)
    rows = []
    indexed = station.set_index(['variable', 'transform', 'det'])
    for code in dictionary.index:
        lv, trend, diff = [indexed.loc[(code, t, d)] for t, d in [('level', 'c'), ('level', 'ct'), ('diff1', 'c')]]
        rows.append([code, pf(lv.adf_p), kp(lv.kpss_p), pf(trend.adf_p), kp(trend.kpss_p),
                     pf(diff.adf_p), kp(diff.kpss_p), 'Pass' if code in run['long_run_eligible'] else 'Fail'])
    w.table(['Macro', 'Level c\nADF p', 'Level c\nKPSS p', 'Level ct\nADF p', 'Level ct\nKPSS p',
             'Diff\nADF p', 'Diff\nKPSS p', 'I1'], rows, [1.2, .85, .9, .85, .9, .85, .9, .6], font=8.2)
    w.heading('Short run monthly first differences', 2)
    w.table(['Macro', 'N', 'ADF p', 'KPSS p', 'OR rule'],
            [[r['code'], r['n'], pf(r['adf_p']), kp(r['kpss_p']), 'Pass' if r['stationary_OR'] else 'Fail']
             for r in records(run['short_run_stationarity'])], [1.9, .5, 1.5, 1.5, 1.7], font=8.8)

    for stage, title in [('long_run', 'Appendix B Long run candidate trials'),
                         ('short_run', 'Appendix C Short run candidate trials')]:
        trials = run[f'{stage}_trials']
        for start in range(0, len(trials), 22):
            part = trials.iloc[start:start+22]
            w.heading(title + ('' if start == 0 else ' continued'), page=True)
            w.text('Rows show the added-term coefficient and OLS p-value, maximum nonconstant VIF, '
                   'adjusted R squared, ordinary residual ADF p-value and selection decision. '
                   'All candidates within a stage use a common sample.', small=True)
            def trial_status(row):
                if row['chosen']:
                    return 'Selected'
                if row['eligible']:
                    return 'Pass'
                fails = []
                if row['p_added'] >= alpha:
                    fails.append('p')
                if row['max_VIF'] >= vif_limit:
                    fails.append('VIF')
                if stage == 'long_run' and row['residual_ADF_p'] >= alpha:
                    fails.append('ADF')
                return ', '.join(fails)
            w.table(['Rd', 'Candidate', 'Coefficient', 'OLS p', 'Max VIF', 'Adj R²', 'ADF p', 'Decision'],
                    [[r['round'], term_name(r['candidate']), coefficient(r['coefficient']), pf(r['p_added']),
                      nf(r['max_VIF'], 2), nf(r['adj_R2'], 4), pf(r['residual_ADF_p']), trial_status(r)]
                     for r in records(part)], [.35, 1.35, 1.05, .9, .8, .7, .9, 1.05], font=8.5, left=(0, 1, 7))
            if stage == 'long_run' and start + 22 >= len(trials):
                w.heading('Statistical long run round coefficients', 2)
                coefficient_table(run['long_run_round_coefficients'], round_column=True)

    w.heading('Appendix D Inputs and runtime outputs', page=True)
    w.table(['Input', 'Purpose'], [
        ['fee_history.csv', 'Original monthly revenue observations'],
        ['macro_history.csv', 'Historical levels for every macro candidate'],
        ['macro_s1.csv', 'External S1 monthly macro level assumptions'],
        ['macro_s4.csv', 'External S4 monthly macro level assumptions'],
        ['macro_dictionary.csv', 'Candidate names, descriptions and units'],
        ['sources.json', 'Source descriptions and scenario vintages'],
        ['config.json', 'Sample dates, screening rules, lags and shock grid']
    ], [2.3, 4.8], left=(0, 1))
    w.text('The source observation and external scenario files are separate from derived features. '
           'The program calculates adjusted revenue, differenced and lagged features, fitted coefficients, '
           'diagnostics and forecasts at runtime. Each execution writes to a new or empty results directory.')
    w.table(['Figure', 'Calculated data source'],
            [[name.replace('figure_', '').replace('_', ' '), meta['source']] for name, meta in figures.items()],
            [3.4, 3.7], left=(0, 1), font=9)
    w.text('The run manifest records the input file hashes, configuration and library versions. '
           'Data exports retain unrounded calculations; report tables and chart labels round only for display. '
           'The signed long-run residual and horizontal sensitivity bars use zero reference lines. '
           'Other numerical level axes start at zero.', small=True)
    dest = output_dir / 'Merchant_Long_Run_ECM_Report_EN_S1_S4_9Q_Revised.docx'
    w.doc.save(dest)
    return dest
