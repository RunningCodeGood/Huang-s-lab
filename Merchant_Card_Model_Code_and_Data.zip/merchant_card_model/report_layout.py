"""Word typography, tables and native equations used by the report builder."""
import math
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn


def number(value, dp=0):
    if value is None or not math.isfinite(value):
        return '—'
    if abs(value) < .5 * 10**(-dp):
        value = 0.0
    return f'{value:,.{dp}f}'.replace('-', '−')


def probability(value):
    if value is None or not math.isfinite(value):
        return '—'
    if value == 0:
        return '<1e−300'
    if value < .001:
        a, b = f'{value:.2e}'.split('e')
        return f'{a}e{int(b)}'.replace('-', '−')
    return f'{value:.4f}'


def kpss_probability(value):
    return '≤0.0100' if value <= .01 else '≥0.1000' if value >= .1 else probability(value)


def term_name(term):
    if term == 'const':
        return 'Intercept'
    if term.startswith('DY_L'):
        return 'ΔY L' + term[4:]
    if term.startswith('D_'):
        code, lag = term[2:].rsplit('_L', 1)
        return f'Δ{code} L{lag}'
    return term


def _math_text(text):
    run = OxmlElement('m:r')
    prop = OxmlElement('w:rPr')
    font = OxmlElement('w:rFonts')
    font.set(qn('w:ascii'), 'Cambria Math')
    font.set(qn('w:hAnsi'), 'Cambria Math')
    prop.append(font)
    size = OxmlElement('w:sz')
    size.set(qn('w:val'), '22')
    prop.append(size)
    run.append(prop)
    node = OxmlElement('m:t')
    node.text = str(text)
    node.set(qn('xml:space'), 'preserve')
    run.append(node)
    return run


def sub(base, index):
    element = OxmlElement('m:sSub')
    a, b = OxmlElement('m:e'), OxmlElement('m:sub')
    a.append(_math_text(base))
    b.append(_math_text(index))
    element.extend([a, b])
    return element


def power(base, index):
    element = OxmlElement('m:sSup')
    a, b = OxmlElement('m:e'), OxmlElement('m:sup')
    a.append(_math_text(base) if isinstance(base, str) else base)
    b.append(_math_text(index))
    element.extend([a, b])
    return element


def fraction(top, bottom):
    element = OxmlElement('m:f')
    for name, content in [('num', top), ('den', bottom)]:
        part = OxmlElement('m:' + name)
        for item in content if isinstance(content, list) else [content]:
            part.append(_math_text(item) if isinstance(item, str) else item)
        element.append(part)
    return element


def square_root(content):
    element = OxmlElement('m:rad')
    prop = OxmlElement('m:radPr')
    hide = OxmlElement('m:degHide')
    hide.set(qn('m:val'), '1')
    prop.append(hide)
    element.append(prop)
    element.append(OxmlElement('m:deg'))
    body = OxmlElement('m:e')
    body.append(content)
    element.append(body)
    return element


class Writer:
    width = 7.1

    def __init__(self):
        self.doc = Document()
        for border in self.doc.styles.element.xpath('.//w:pBdr'):
            border.getparent().remove(border)
        section = self.doc.sections[0]
        section.page_width, section.page_height = Inches(8.5), Inches(11)
        section.top_margin = section.bottom_margin = Inches(.7)
        section.left_margin = section.right_margin = Inches(.7)
        section.header_distance = section.footer_distance = Inches(.3)
        for name in ['Normal', 'Title', 'Subtitle', 'Heading 1', 'Heading 2', 'Caption']:
            st = self.doc.styles[name]
            st.font.name = 'Arial'
            st.font.color.rgb = RGBColor(0, 0, 0)
            st.element.get_or_add_rPr().rFonts.set(qn('w:eastAsia'), 'Arial')
        st = self.doc.styles['Normal']
        st.font.size = Pt(10.5)
        st.paragraph_format.line_spacing = 1.06
        st.paragraph_format.space_after = Pt(6)
        self.doc.styles['Title'].font.size = Pt(23)
        self.doc.styles['Title'].font.bold = True
        self.doc.styles['Subtitle'].font.size = Pt(12)
        for name, size in [('Heading 1', 15), ('Heading 2', 11.5)]:
            st = self.doc.styles[name]
            st.font.size = Pt(size)
            st.font.bold = True
            st.paragraph_format.space_before = Pt(9)
            st.paragraph_format.space_after = Pt(6)
            st.paragraph_format.keep_with_next = True
        self.doc.styles['Caption'].font.size = Pt(9)
        self.doc.styles['Caption'].font.italic = False
        self.doc.styles['Caption'].paragraph_format.space_after = Pt(8)
        p = section.header.paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
        p.add_run('MERCHANT CARD FEE REVENUE').font.size = Pt(8)
        p = section.footer.paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
        p.add_run('Merchant model   |   ').font.size = Pt(8)
        field = OxmlElement('w:fldSimple')
        field.set(qn('w:instr'), 'PAGE')
        p._p.append(field)
        self.doc.core_properties.title = 'Merchant Card Fee Revenue Model'
        self.doc.core_properties.author = 'Card Fee Research'

    def text(self, text, small=False):
        p = self.doc.add_paragraph(str(text))
        if small:
            for run in p.runs:
                run.font.size = Pt(9.5)
        return p

    def heading(self, text, level=1, page=False):
        p = self.doc.add_paragraph(text, style=f'Heading {level}')
        p.paragraph_format.page_break_before = page
        return p

    def equation(self, parts):
        p = self.doc.add_paragraph()
        p.paragraph_format.space_after = Pt(8)
        outer = OxmlElement('m:oMathPara')
        prop = OxmlElement('m:oMathParaPr')
        align = OxmlElement('m:jc')
        align.set(qn('m:val'), 'left')
        prop.append(align)
        outer.append(prop)
        math = OxmlElement('m:oMath')
        for part in parts:
            math.append(_math_text(part) if isinstance(part, str) else part)
        outer.append(math)
        p._p.append(outer)

    def table(self, headers, rows, widths, font=9.2, left=(0,)):
        widths = [w * self.width / sum(widths) for w in widths]
        table = self.doc.add_table(rows=1, cols=len(headers))
        table.alignment = WD_TABLE_ALIGNMENT.CENTER
        table.autofit = False
        borders = OxmlElement('w:tblBorders')
        for side in ['top', 'left', 'bottom', 'right', 'insideH', 'insideV']:
            el = OxmlElement(f'w:{side}')
            for key, value in [('val', 'single'), ('sz', '4'), ('color', 'D9D9D9')]:
                el.set(qn('w:' + key), value)
            borders.append(el)
        table._tbl.tblPr.append(borders)
        for column, width in zip(table.columns, widths):
            column.width = Inches(width)
        for i, values in enumerate([headers, *rows]):
            row = table.rows[0] if i == 0 else table.add_row()
            prop = row._tr.get_or_add_trPr()
            prop.append(OxmlElement('w:cantSplit'))
            if i == 0:
                prop.append(OxmlElement('w:tblHeader'))
            for j, (cell, value, width) in enumerate(zip(row.cells, values, widths)):
                cell.width = Inches(width)
                cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
                tc = cell._tc.get_or_add_tcPr()
                margins = OxmlElement('w:tcMar')
                for side, pad in [('top', 48), ('bottom', 48), ('left', 65), ('right', 65)]:
                    e = OxmlElement('w:' + side)
                    e.set(qn('w:w'), str(pad))
                    e.set(qn('w:type'), 'dxa')
                    margins.append(e)
                tc.append(margins)
                shade = OxmlElement('w:shd')
                shade.set(qn('w:fill'), '254359' if i == 0 else 'F2F5F7' if i % 2 == 0 else 'FFFFFF')
                tc.append(shade)
                p = cell.paragraphs[0]
                p.paragraph_format.space_before = p.paragraph_format.space_after = Pt(0)
                p.paragraph_format.line_spacing = 1.03
                p.paragraph_format.keep_with_next = i == 0
                p.alignment = WD_ALIGN_PARAGRAPH.LEFT if j in left else WD_ALIGN_PARAGRAPH.RIGHT
                r = p.add_run(str(value))
                r.font.size = Pt(font)
                r.bold = i == 0
                r.font.color.rgb = RGBColor.from_string('FFFFFF' if i == 0 else '172B3A')
        p = self.doc.add_paragraph()
        p.paragraph_format.space_after = Pt(2)
        p.paragraph_format.line_spacing = Pt(2)
        return table

    def figure(self, metadata, caption):
        p = self.doc.add_paragraph()
        p.paragraph_format.keep_with_next = True
        shape = p.add_run().add_picture(str(metadata['path']), width=Inches(self.width))
        shape._inline.docPr.set('descr', metadata['alt'])
        self.doc.add_paragraph(caption, style='Caption')
