# Noncomp EF model

This standalone Python package runs the complete quarterly Efficiency Ratio analysis from raw CSV data. It estimates the level-and-trend break regression, screens 22 macro candidates, estimates an ARDL with trend, evaluates removal of the trend, and calculates final-model diagnostics and forecasts. All numeric outputs are CSV. No Excel files, Word files, credentials or local machine paths are required.

## Quick start

Use Python 3.10 or newer. Python 3.12 was used for verification. From the extracted package directory:

```bash
python -m pip install -r requirements.txt
python noncomp_ef_model.py
python -m unittest discover -s tests -v
```

The script also works when launched from another working directory. Default paths are relative to the script, not the terminal's current directory. The first run creates `results/`. The included `reference_outputs/` contains the results of the verified run and is never read by the model.

For another run, use a new output directory. Existing nonempty output directories are protected unless `--overwrite` is supplied. That option replaces same-named CSV results but does not delete other files or modify inputs.

```bash
python noncomp_ef_model.py --output-dir results_second_run
python noncomp_ef_model.py --input-dir inputs --scenario-dir scenarios --output-dir results --overwrite
python noncomp_ef_model.py --history-only --output-dir historical_results
```

`--history-only` requires only the two historical input CSVs. It does not read the scenario files. Do not mix historical-only and full runs in one output directory. The package is calibrated to the stated 2011–2025 historical calendar and nine-quarter forecast horizon. Changing the calendar requires changing the documented constants and reviewing the validation split.

## Inputs

There are exactly two main input files. Future scenario assumptions remain separate.

| File | Columns | Period |
| --- | --- | --- |
| `inputs/macro.csv` | `Quarter` plus the 22 original provider codes | 2011Q1–2025Q4 |
| `inputs/ef.csv` | `Quarter`, `EF` | 2011Q1–2025Q4 |
| `scenarios/S1.csv` | `Quarter`, `FLBR_B.IUSA` | 2026Q1–2028Q1 |
| `scenarios/S4.csv` | `Quarter`, `FLBR_B.IUSA` | 2026Q1–2028Q1 |

`Quarter` is a calendar quarter-end date in `YYYY-MM-DD` format, starting with `2011-03-31` for historical data. Inputs have one header row. Descriptions, units, internal names and transformations appear in the generated `macro_dictionary.csv`, not in a second data row. `S1` is the original Baseline path. Scenario values are supplied assumptions, not forecasts of unemployment produced by this model.

EF is a decimal ratio: `0.55` means 55%. Unemployment is in percent units: `4.45` means 4.45%, not `0.0445`. EF at 2020Q3 is `0.634`. The input remains raw. No observations are removed. Historical inputs are complete, chronological and quarterly. The code rejects duplicate periods, missing or nonnumeric values, nonpositive values required for log changes, and unexpected columns. It does not fill missing values or add pre-2011 observations.

### EF smoothing

The script calculates both replacements from the original EF values:

```text
EF_2017Q3 = mean(raw EF_2017Q2, raw EF_2017Q3, raw EF_2017Q4) = 0.586
EF_2017Q4 = mean(raw EF_2017Q3, raw EF_2017Q4, raw EF_2018Q1) = 0.5796666666666667
```

The second calculation never uses the first smoothed replacement. The two affected quarters remain in estimation. All other EF values are unchanged. `ef_smoothing.csv` and `historical_data_and_features.csv` expose the calculation.

### Macro transformations and naming

CSV headers retain the provider codes, including `FLBR_B.IUSA`, `FGDP$_B.IUSA` and `FGAP_B.IUSA`. Internal features use descriptive lower-case `snake_case`, following the Cardfee convention. Coefficient and screening outputs include the source code so that each feature can be traced to its input.

The six log-change variables are `FAHEFI_B.IUSA`, `FPCNBULC_B.IUSA`, `FECICPQ_B.IUSA`, `FGDP$_B.IUSA`, `FBBACBQ_B.IUSA` and `FBBABLLCBQ_B.IUSA`. They use `ln(X_t) - ln(X_t-1)` without multiplication by 100. The other 16 variables use `X_t - X_t-1`. Every candidate transformation is lagged one quarter. There is one transformed feature per source variable. No extra spread variable is generated.

For example, `unemployment_rate_diff_1q_pp_lag_1q` means `FLBR_B.IUSA_(t-1) - FLBR_B.IUSA_(t-2)`. All candidates share the same effective start, 2011Q3. Neither 2011Q1 nor 2011Q2 has an available lagged quarterly change. No candidate receives a pre-sample advantage.

## Estimation sequence

### 1. Level-and-trend break analysis

```text
EF_t = constant + theta * D_t + beta * t + gamma * D_t * t + residual_t
D_t = 0 before 2014Q1, 1 from 2014Q1 onward
t = 1 in 2011Q1, 13 in 2014Q1, ... , 60 in 2025Q4
```

The full-history regression uses all 60 smoothed observations. A separate development-period regression uses the 51 observations through 2023Q3. The prebreak slope is beta. The postbreak slope is beta + gamma. Theta is the difference between the two line intercepts. The vertical difference between the two lines at 2014Q1 is theta + 13 * gamma. It is not the adjacent-quarter change in EF. Coefficients, slope contrasts, classical Student-t p-values, fitted values and residual ADF/KPSS results are exported.

ADF uses no deterministic term, AIC lag selection and a maximum of four lags. KPSS uses a constant and automatic bandwidth. Bounded KPSS p-values are stored with a separate `p_relation` field, so `> 0.10` is not presented as an exact p-value. These are ordinary residual diagnostics. Their reference distributions are not recalibrated for an estimated break regression, so they are not a formal Perron test p-value. The code does not label them as such.

### 2. Forward selection with trend

The fixed starting regressors are an intercept, `post_tarp`, `time_index` and `ef_lag_1q`. There is no transition pulse. Development estimation uses 49 observations from 2011Q3 to 2023Q3. All candidates use exactly the same rows.

Each round fits every remaining macro conditional on the already selected terms. A candidate is eligible only when all four Cardfee conditions hold:

- Its two-sided Student-t p-value is below 0.05.
- The maximum VIF across all nonconstant regressors is below 10.
- DW is between 1.5 and 2.5 inclusive.
- The Jarque–Bera p-value is above 0.05.

Eligible candidates are ranked by ascending coefficient p-value, descending adjusted R-squared and fixed source-column order. The winner enters. Selection stops when no remaining candidate passes all four conditions. There is no backward macro deletion. DW is a screening heuristic, not a formal serial-correlation test for a model with a lagged dependent variable.

The current inputs select `FLBR_B.IUSA` with trend. The full trial log is exported, including failed gates. The with-trend model is reported through its parameter estimates and significance.

### 3. Trend removal and final ARDL

The code checks the selected with-trend model's trend p-value. If it is at least 0.05, the trend is removed and the same selected macro structure is re-estimated. If it is below 0.05, the trend stays. The current trend p-value is approximately 0.171909. The resulting equation is:

```text
EF_t = constant + theta * D_t + phi * EF_(t-1)
       + lambda * [U_(t-1) - U_(t-2)] + error_t
```

Here `U` denotes the unemployment rate in provider column `FLBR_B.IUSA`. The final model has neither a linear trend nor a pulse. Macro selection and trend removal are recalculated on every run. No desired coefficient, p-value or selected variable is forced.

A separate no-trend forward screen is exported as an alternative analysis. With these inputs it selects `FGAP_B.IUSA`. That alternative does not overwrite the sequential with-trend-then-remove-trend specification. The three single-macro comparisons for unemployment, gap and GDP expose their estimation and OOT results. Unemployment has the lowest one-step OOT RMSE of these three. GDP has the lowest recursive OOT RMSE. Unemployment's economic interpretation also supports its use in scenario analysis. OOT comparisons are therefore model-development evidence, not a wholly untouched final holdout.

All estimation uses ordinary, nonrobust OLS covariance and Student-t inference. No HAC calculation is included.

## Diagnostics and robustness

Final-model diagnostic files contain only Ljung–Box at lags 4 and 8, Jarque–Bera, OLS-residual CUSUM and DW. Ljung–Box uses `model_df=1`, giving reference degrees of freedom 3 and 7. DW has no reported p-value. VIF is exported separately. Residual ADF/KPSS is also separate. Diagnostics are calculated for the development model and for the fixed-specification full-history refit.

Other outputs include all conditional second-macro trials, fitted values and residuals, influence statistics, leave-one-observation-out coefficients, and a raw-EF sensitivity fit. Leave-one-out is a coefficient-influence exercise with the design matrix fixed, not a reconstruction of the time series after deleting a quarter. Cook's distance flags are descriptive and never trigger observation deletion.

## Forecasts and sensitivity

- OOT is 2023Q4–2025Q4. Development coefficients remain fixed.
- One-step predictions use actual preceding-quarter EF.
- Recursive OOT predictions start from actual 2023Q3 EF and then use preceding predictions.
- Both OOT methods use observed historical macro changes. RMSE, MAE and mean error are exported.
- Benchmarks are one-step persistence, recursive persistence and the development mean.
- The final specification is re-estimated on all 58 eligible historical observations through 2025Q4. Its coefficients drive the main nine-quarter forecasts.
- S1 and S4 forecast 2026Q1–2028Q1 recursively from actual 2025Q4 EF. Development-coefficient scenario forecasts are also exported for comparison.
- Future unemployment levels are shifted by -1 or +1 percentage point separately under S1 and S4. Historical anchors do not change. This is not a relative 1% shock and not a new +1 pp change every quarter.
- Because the unemployment change is lagged one quarter, 2026Q1 uses the historical 2025Q4 minus 2025Q3 change. All scenarios and sensitivity cases therefore share the first EF forecast. A future level shock first affects 2026Q2 and then decays through phi.
- The 2028Q1 unemployment level is supplied but first affects EF in 2028Q2, outside the forecast horizon.
- A separate one-standard-deviation change shock uses the development-sample standard deviation of the lagged unemployment change and the full-history coefficients. Horizon 0 is the quarter when the shock enters the equation.

Forecasts are conditional point forecasts. No clipping, coefficient override or forecast rounding is applied in calculations. If changed input data select a different macro, the code stops scenario forecasting with an explicit error instead of substituting unemployment. Use `--history-only` to review such a changed specification. Future paths for any newly selected macro must be supplied and its forecasting logic reviewed before scenario production.

## Output guide

| Output | Contents |
| --- | --- |
| `run_summary.csv` | Selected terms, trend decision, sample sizes and software versions |
| `macro_dictionary.csv`, `ef_smoothing.csv`, `historical_data_and_features.csv` | Provider mapping, raw/smoothed EF and all calculated features |
| `coefficients_static_*.csv`, `static_contrasts.csv` | Break-regression estimates and slope/jump tests |
| `static_fitted_*.csv`, `static_fit_comparison.csv` | Segmented and common-slope fits |
| `static_residual_stationarity_*.csv` | Static-regression residual ADF/KPSS |
| `selection_*.csv`, `conditional_additions_after_final.csv` | Complete screening logs and four eligibility gates |
| `coefficients_ardl_with_trend.csv`, `coefficients_no_trend_alternative.csv` | With-trend and separate no-trend-selection estimates |
| `coefficients_final_*.csv`, `fit_statistics.csv`, `fitted_values_*.csv` | Final development and full-history estimates and fitted values |
| `candidate_comparison.csv`, `comparison_coefficients.csv`, `comparison_oot_forecasts.csv`, `candidate_selection_checks.csv` | Unemployment, gap and GDP comparisons |
| `diagnostics_*.csv`, `variance_inflation_factors.csv`, `final_residual_stationarity_*.csv` | Final-model diagnostics |
| `oot_forecasts.csv`, `oot_metrics.csv`, `oot_benchmarks.csv`, `benchmark_metrics.csv` | Nine-quarter OOT forecasts, errors and benchmarks |
| `influence.csv`, `leave_one_out.csv`, `coefficients_raw_ef_sensitivity.csv`, `raw_ef_sensitivity_metrics.csv` | Influence and preprocessing sensitivity |
| `scenario_macro_paths.csv`, `scenario_ef_forecasts.csv`, `scenario_summary.csv` | Separate labeled S1/S4 paths and forecasts |
| `scenario_sensitivity.csv`, `one_sd_macro_shock.csv` | +/-1 pp paths and one-SD shock response |
| `input_manifest.csv`, `output_manifest.csv` | SHA-256 input and output checksums |

CSV numbers retain 17 significant digits. Blank p-values in the DW rows mean not applicable. Missing features in the first two historical rows are required by differencing and lagging, not imputed data. Scenario files use long format with explicit `scenario` and `coefficient_sample` columns to prevent S1/S4 or development/production confusion. This output format does not merge the scenario input files.

## Verification

Included tests check raw-data preservation, both smoothing formulas, the common calendar, independent OLS coefficients and Student-t inference, forward selection and trend removal, diagnostics, report reference values, recursive forecast algebra, and the +/-1 pp response. They also check malformed input and output-directory protection. `reference_outputs/` is a reproducibility snapshot, not an input to estimation. `verification/` records the package's numerical comparison with the 19 October 2026 report analysis.

Current reference values are development n=49, full-history n=58, one-step OOT RMSE 0.0278300462 and recursive OOT RMSE 0.0372750347. Full-history 2026Q1 EF is 0.5539529304 in both S1 and S4. Small floating-point differences across supported numerical library versions are expected. Exact software versions used for the supplied snapshot are recorded in its `run_summary.csv`.
