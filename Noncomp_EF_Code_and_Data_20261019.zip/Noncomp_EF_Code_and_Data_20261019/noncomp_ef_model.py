"""Quarterly Noncomp EF model. Run from any working directory; see README.md."""
from __future__ import annotations

import argparse
import csv
import hashlib
import importlib.metadata
import inspect
import platform
import sys
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
import statsmodels.api as sm
from statsmodels.stats.diagnostic import acorr_ljungbox, breaks_cusumolsresid
from statsmodels.stats.outliers_influence import variance_inflation_factor
from statsmodels.stats.stattools import durbin_watson, jarque_bera
from statsmodels.tsa.stattools import adfuller, kpss

ROOT = Path(__file__).resolve().parent
START = '2011Q1'
DEVELOPMENT_END = '2023Q3'
HISTORY_END = '2025Q4'
FUTURE = pd.period_range('2026Q1', '2028Q1', freq='Q')
HISTORY = pd.period_range(START, HISTORY_END, freq='Q')
P_LIMIT, VIF_LIMIT, DW_LOW, DW_HIGH, JB_P_LIMIT = .05, 10., 1.5, 2.5, .05
D, T, DT, LAG = 'post_tarp', 'time_index', 'post_tarp_x_time_index', 'ef_lag_1q'
# Source column, readable internal family, description, level unit, transformation.
# Fixed order is also the last tie breaker in forward selection.
MACROS = [
    ('FAHEFI_B.IUSA', 'financial_activities_earnings', 'Financial activities average hourly earnings', 'USD per hour', 'log_change'),
    ('FPCNBULC_B.IUSA', 'unit_labor_costs', 'Nonfarm business unit labor costs', 'Index 2017=100', 'log_change'),
    ('FECICPQ_B.IUSA', 'private_compensation_eci', 'Private industry total compensation ECI', 'Index Dec 2005=100', 'log_change'),
    ('FRFED_B.IUSA', 'federal_funds_rate', 'Federal funds rate', 'Percent per annum', 'diff_pp'),
    ('FRGT2Y_B.IUSA', 'treasury_2y_rate', 'Two year Treasury constant maturity rate', 'Percent per annum', 'diff_pp'),
    ('FRGT10Y_B.IUSA', 'treasury_10y_rate', 'Ten year Treasury constant maturity rate', 'Percent per annum', 'diff_pp'),
    ('FLBR_B.IUSA', 'unemployment_rate', 'Unemployment rate', 'Percent', 'diff_pp'),
    ('FCBC_B.IUSA', 'consumer_confidence', 'Consumer confidence index', 'Index 1985=100', 'diff'),
    ('FSBINQ_B.IUSA', 'small_business_optimism', 'Small business normalized optimism index', 'Index 1986=100', 'diff'),
    ('FGDP$_B.IUSA', 'real_gdp', 'Real gross domestic product', 'Billion chained 2017 USD', 'log_change'),
    ('FGAP_B.IUSA', 'output_gap', 'Real GDP versus potential GDP output gap', 'Percent', 'diff_pp'),
    ('FBBACBQ_B.IUSA', 'bank_assets', 'Commercial banks total assets', 'Billion USD', 'log_change'),
    ('FBBABLLCBQ_B.IUSA', 'bank_loans', 'Commercial banks loans and leases in bank credit', 'Billion USD', 'log_change'),
    ('FCBOEVIXQ_B.IUSA', 'vix', 'CBOE S&P 500 volatility index period average', 'Index', 'diff'),
    ('FIRHYBOASQ_B.IUSA', 'high_yield_oas', 'High yield bond option adjusted spread', 'Percentage points', 'diff_pp'),
    ('FPCNBCPH_B.IUSA', 'hourly_compensation', 'Nonfarm business hourly compensation', 'Index 2017=100', 'diff'),
    ('FLBOPQ_B.IUSA', 'job_openings', 'Total nonfarm job openings', 'Million jobs', 'diff'),
    ('FYPEW52Q_B.IUSA', 'finance_insurance_wages', 'Finance and insurance wages and salaries', 'Billion USD', 'diff'),
    ('FGDP52Q_B.IUSA', 'finance_insurance_gdp', 'Finance and insurance gross product originating', 'Billion USD', 'diff'),
    ('FE52_B.IUSA', 'finance_insurance_employment', 'Finance and insurance employment', 'Million', 'diff'),
    ('FYPCPIQ_B.IUSA', 'per_capita_income', 'Per capita income', 'USD', 'diff'),
    ('FECICCQ_B.IUSA', 'civilian_compensation_eci', 'All civilian workers total compensation ECI', 'Index Dec 2005=100', 'diff'),
]


def feature_name(row):
    code, family, _, _, transform = row
    suffix = {'log_change': 'log_change_1q_lag_1q', 'diff_pp': 'diff_1q_pp_lag_1q',
              'diff': 'diff_1q_lag_1q'}[transform]
    return f'{family}_{suffix}'


CODES = [r[0] for r in MACROS]
FEATURES = [feature_name(r) for r in MACROS]
CODE_TO_FEATURE = dict(zip(CODES, FEATURES))
FEATURE_TO_CODE = dict(zip(FEATURES, CODES))
U = CODE_TO_FEATURE['FLBR_B.IUSA']


def read_quarterly(path, columns, expected):
    """Strict single-header CSV schema; no filling, rescaling or implicit sorting."""
    with Path(path).open(encoding='utf-8-sig', newline='') as stream:
        header = next(csv.reader(stream))
    if len(header) != len(set(header)):
        raise ValueError(f'{path.name}: duplicate CSV column names')
    if set(header) != {'Quarter', *columns}:
        raise ValueError(f'{path.name}: expected Quarter and {columns}')
    frame = pd.read_csv(path, encoding='utf-8-sig', float_precision='round_trip')
    dates = pd.to_datetime(frame.pop('Quarter'), format='%Y-%m-%d', errors='raise')
    if not dates.dt.is_quarter_end.all():
        raise ValueError(f'{path.name}: Quarter must be a calendar quarter-end date')
    index = pd.PeriodIndex(dates, freq='Q')
    if not index.equals(expected):
        raise ValueError(f'{path.name}: expected each quarter once, in order, '
                         f'from {expected[0]} through {expected[-1]}')
    frame = frame[columns].apply(pd.to_numeric, errors='raise')
    frame.index = index
    frame.index.name = 'quarter'
    if not np.isfinite(frame.to_numpy()).all():
        raise ValueError(f'{path.name}: numeric values must be finite and complete')
    return frame


def load_inputs(input_dir, scenario_dir, history_only=False):
    macro = read_quarterly(input_dir / 'macro.csv', CODES, HISTORY)
    ef = read_quarterly(input_dir / 'ef.csv', ['EF'], HISTORY)['EF']
    if (ef <= 0).any() or (ef > 2).any():
        raise ValueError('EF must be in decimal ratio units, not whole percent')
    for code, _, _, _, kind in MACROS:
        if kind == 'log_change' and (macro[code] <= 0).any():
            raise ValueError(f'{code}: strictly positive levels required for log changes')
    if not macro['FLBR_B.IUSA'].between(0, 100).all():
        raise ValueError('Unemployment must be in percent units, from 0 to 100')
    paths = {} if history_only else {
        case: read_quarterly(scenario_dir / f'{case}.csv', ['FLBR_B.IUSA'], FUTURE)
        for case in ['S1', 'S4']}
    for case, frame in paths.items():
        if not frame['FLBR_B.IUSA'].between(0, 100).all():
            raise ValueError(f'{case}: unemployment must be between 0 and 100 percent')
    return macro, ef, paths


def prepare_history(macro, raw):
    smooth = raw.copy()
    # Both replacements use ORIGINAL data, never the first smoothed replacement.
    smooth.loc['2017Q3'] = raw.loc[['2017Q2', '2017Q3', '2017Q4']].mean()
    smooth.loc['2017Q4'] = raw.loc[['2017Q3', '2017Q4', '2018Q1']].mean()
    frame = pd.DataFrame({'ef_raw': raw, 'EF': smooth, LAG: smooth.shift(1)})
    frame[T] = np.arange(1, len(frame) + 1)
    frame[D] = (frame.index >= pd.Period('2014Q1')).astype(int)
    frame[DT] = frame[D] * frame[T]
    for row in MACROS:
        series = np.log(macro[row[0]]) if row[4] == 'log_change' else macro[row[0]]
        frame[feature_name(row)] = series.diff().shift(1)
    return frame


def fit(data, terms):
    x = sm.add_constant(data[terms], has_constant='add')
    if not np.isfinite(x.to_numpy()).all() or not np.isfinite(data.EF).all():
        raise ValueError('Regression data contain a missing/nonfinite value')
    if np.linalg.matrix_rank(x) != x.shape[1] or len(data) <= x.shape[1]:
        raise ValueError('Regression requires full column rank and positive residual degrees of freedom')
    return sm.OLS(data.EF, x).fit(cov_type='nonrobust', use_t=True)


def coefficient_table(model):
    ci = model.conf_int()
    return pd.DataFrame({'term': model.params.index,
                         'source_column': [FEATURE_TO_CODE.get(n, '') for n in model.params.index],
                         'coefficient': model.params.values, 'std_error': model.bse.values,
                         't_statistic': model.tvalues.values, 'p_student_t': model.pvalues.values,
                         'ci_95_low': ci[0].values, 'ci_95_high': ci[1].values,
                         'residual_df': model.df_resid})


def metrics(model):
    return dict(n=int(model.nobs), r2=model.rsquared, adj_r2=model.rsquared_adj,
                rmse=float(np.sqrt(np.mean(model.resid**2))), aic=model.aic,
                bic=model.bic, sigma=float(np.sqrt(model.mse_resid)))


def vifs(model):
    return {name: float(variance_inflation_factor(model.model.exog, i))
            for i, name in enumerate(model.params.index) if name != 'const'}


def gates(model, candidate):
    maximum = max(vifs(model).values())
    dw = float(durbin_watson(model.resid))
    jb, jb_p, _, _ = jarque_bera(model.resid)
    flags = dict(p_pass=bool(model.pvalues[candidate] < P_LIMIT),
                 vif_pass=bool(maximum < VIF_LIMIT), dw_pass=bool(DW_LOW <= dw <= DW_HIGH),
                 jb_pass=bool(jb_p > JB_P_LIMIT))
    return dict(t_statistic=model.tvalues[candidate], residual_df=model.df_resid,
                adjusted_r_squared=model.rsquared_adj, max_vif=maximum,
                durbin_watson=dw, jarque_bera=jb, jarque_bera_p=jb_p,
                **flags, eligible=all(flags.values()),
                failed_gates=';'.join(k.removesuffix('_pass') for k, v in flags.items() if not v))


def forward_selection(data, base):
    chosen, remaining, records = [], FEATURES.copy(), []
    while remaining:
        trials = []
        for feature in remaining:
            model = fit(data, base + chosen + [feature])
            trials.append(dict(round=len(chosen) + 1, candidate=FEATURE_TO_CODE[feature],
                               feature=feature, existing=';'.join(chosen),
                               coefficient=model.params[feature], p_student_t=model.pvalues[feature],
                               n=int(model.nobs), aic=model.aic, bic=model.bic,
                               selected=False, **gates(model, feature)))
        passing = [row for row in trials if row['eligible']]
        if passing:
            winner = min(passing, key=lambda r: (r['p_student_t'], -r['adjusted_r_squared'],
                                                CODES.index(r['candidate'])))
            winner['selected'] = True
            chosen.append(winner['feature'])
            remaining.remove(winner['feature'])
        records.extend(trials)
        if not passing:
            break
    return chosen, fit(data, base + chosen), pd.DataFrame(records)


def stationarity(residual):
    # Ordinary residual diagnostics, NOT a breakpoint-adjusted Perron test.
    # Support both statsmodels 0.14 and the 0.15 return-type transition.
    adf_options = {'result_object': False} if 'result_object' in inspect.signature(adfuller).parameters else {}
    kpss_options = {'result_object': False} if 'result_object' in inspect.signature(kpss).parameters else {}
    a = adfuller(residual, maxlag=4, regression='n', autolag='AIC', **adf_options)
    with warnings.catch_warnings(record=True) as notes:
        warnings.simplefilter('always')
        k = kpss(residual, regression='c', nlags='auto', **kpss_options)
    bound = '>' if any('greater than' in str(w.message) for w in notes) else (
        '<' if any('smaller than' in str(w.message) for w in notes) else '=')
    return pd.DataFrame([
        dict(test='ADF', statistic=a[0], p_value=a[1], p_relation='=',
             lags_or_bandwidth=a[2], n=a[3], null_hypothesis='Unit root',
             specification='No deterministic term; AIC selection, maximum lag 4'),
        dict(test='KPSS', statistic=k[0], p_value=k[1], p_relation=bound,
             lags_or_bandwidth=k[2], n=len(residual), null_hypothesis='Level stationarity',
             specification='Constant; automatic bandwidth')])


def diagnostics(model):
    rows = []
    lb = acorr_ljungbox(model.resid, lags=[4, 8], model_df=1, return_df=True)
    for lag, row in lb.iterrows():
        rows.append(dict(test=f'Ljung Box {lag}', statistic=row.lb_stat, p_value=row.lb_pvalue,
                         reference=f'Chi-square with {lag - 1} df; AR order adjustment 1'))
    jb = jarque_bera(model.resid)
    cu = breaks_cusumolsresid(model.resid, ddof=int(model.df_model + 1))
    rows += [dict(test='Jarque Bera', statistic=jb[0], p_value=jb[1], reference='Asymptotic chi-square, 2 df'),
             dict(test='CUSUM', statistic=cu[0], p_value=cu[1], reference='OLS-residual CUSUM'),
             dict(test='Durbin Watson', statistic=durbin_watson(model.resid), p_value=np.nan,
                  reference='Descriptive statistic; no p-value reported')]
    return pd.DataFrame(rows)


def oot_predictions(model, history):
    data = history.loc['2023Q4':HISTORY_END]
    terms = [x for x in model.params.index if x != 'const']
    one_step = model.predict(sm.add_constant(data[terms], has_constant='add'))
    previous, recursive = float(history.loc[DEVELOPMENT_END, 'EF']), []
    for _, row in data.iterrows():
        previous = float(model.params['const'] + sum(model.params[k] * (
            previous if k == LAG else row[k]) for k in terms))
        recursive.append(previous)
    result = pd.DataFrame({'actual': data.EF, 'one_step': one_step, 'recursive': recursive})
    for method in ['one_step', 'recursive']:
        result[f'{method}_error'] = result.actual - result[method]
    return result


def forecast_errors(predictions):
    result = {}
    for method in ['one_step', 'recursive']:
        e = predictions[f'{method}_error']
        result.update({f'{method}_rmse': float(np.sqrt(np.mean(e**2))),
                       f'{method}_mae': float(np.mean(abs(e))), f'{method}_bias': float(e.mean())})
    return result


def scenario_forecast(model, levels, historical_unemployment, origin_ef):
    unsupported = set(model.params.index) - {'const', D, T, LAG, U}
    if unsupported:
        raise ValueError('Scenario inputs contain only FLBR_B.IUSA. Selection now requires '
                         f'{sorted(unsupported)}. Supply appropriate scenario drivers before forecasting; '
                         'use --history-only to review historical results.')
    u = np.r_[np.asarray(historical_unemployment, dtype=float), np.asarray(levels, dtype=float)]
    if len(u) != 11 or not np.isfinite(u).all():
        raise ValueError('Scenario needs two historical anchors and nine future unemployment levels')
    previous, values, changes = float(origin_ef), [], []
    for i in range(9):
        change = float(u[i + 1] - u[i])
        previous = float(model.params['const'] + model.params[D] + model.params[LAG] * previous
                         + model.params.get(U, 0.) * change + model.params.get(T, 0.) * (61 + i))
        values.append(previous)
        changes.append(change)
    return np.asarray(values), np.asarray(changes)


class CsvOutputs:
    def __init__(self, path):
        self.path = path
        self.files = []

    def save(self, name, frame, index=False):
        # All numeric results are recalculated. Existing files require CLI approval.
        frame.to_csv(self.path / name, index=index, index_label='quarter' if index else None,
                     float_format='%.17g', encoding='utf-8', lineterminator='\n')
        self.files.append(name)


def run(input_dir, scenario_dir, output_dir, overwrite=False, history_only=False):
    output_dir = output_dir.resolve()
    if output_dir.exists() and any(output_dir.iterdir()) and not overwrite:
        raise ValueError(f'Output directory is not empty: {output_dir}. Use another directory or --overwrite.')
    if history_only and (output_dir / 'scenario_ef_forecasts.csv').exists():
        raise ValueError('Historical-only run needs a directory without earlier scenario outputs')
    # Outputs may not overwrite source files or the package root.
    if output_dir in {input_dir.resolve(), scenario_dir.resolve(), ROOT}:
        raise ValueError('Choose a separate results directory, not an input or code directory')
    macro, raw, paths = load_inputs(input_dir, scenario_dir, history_only)
    files = [input_dir / 'macro.csv', input_dir / 'ef.csv']
    if not history_only:
        files += [scenario_dir / f'{case}.csv' for case in paths]
    input_hashes = {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in files}
    history = prepare_history(macro, raw)
    development = history.loc[:DEVELOPMENT_END].dropna()
    full_history = history.dropna()
    # Selection and trend removal use development data only.
    chosen, with_trend, screening = forward_selection(development, [D, T, LAG])
    alternate, alternate_model, screening_alt = forward_selection(development, [D, LAG])
    keep_trend = bool(with_trend.pvalues[T] < P_LIMIT)
    terms = [D] + ([T] if keep_trend else []) + [LAG] + chosen
    final, full = fit(development, terms), fit(full_history, terms)
    if not history_only:
        for case, frame in paths.items():
            scenario_forecast(full, frame['FLBR_B.IUSA'], macro['FLBR_B.IUSA'].iloc[-2:], history.EF.iloc[-1])
            levels = frame['FLBR_B.IUSA'].to_numpy()
            if np.any((levels - 1 < 0) | (levels + 1 > 100)):
                raise ValueError(f'{case} sensitivity shift produces unemployment outside [0,100]')
    output_dir.mkdir(parents=True, exist_ok=True)
    out = CsvOutputs(output_dir)
    out.save('historical_data_and_features.csv', history, True)
    out.save('ef_smoothing.csv', pd.DataFrame([
        dict(quarter=q, raw_ef=raw.loc[q], smoothed_ef=history.loc[q, 'EF'],
             original_quarters_used=source)
        for q, source in [('2017Q3', '2017Q2;2017Q3;2017Q4'), ('2017Q4', '2017Q3;2017Q4;2018Q1')]]))
    out.save('macro_dictionary.csv', pd.DataFrame([
        dict(source_column=r[0], family=r[1], description=r[2], level_unit=r[3],
             feature=feature_name(r), transformation='ln(X_t)-ln(X_t-1); lag 1 quarter; no x100'
             if r[4] == 'log_change' else 'X_t-X_t-1; lag 1 quarter') for r in MACROS]))
    for name, frame in [('selection_with_trend.csv', screening),
                        ('selection_no_trend_alternative.csv', screening_alt),
                        ('coefficients_ardl_with_trend.csv', coefficient_table(with_trend)),
                        ('coefficients_no_trend_alternative.csv', coefficient_table(alternate_model)),
                        ('coefficients_final_development.csv', coefficient_table(final)),
                        ('coefficients_final_full_history.csv', coefficient_table(full))]:
        out.save(name, frame)

    static_tests, static_metrics = [], []
    for label, data in [('development', history.loc[:DEVELOPMENT_END]), ('full_history', history)]:
        segmented, common = fit(data, [D, T, DT]), fit(data, [D, T])
        out.save(f'coefficients_static_{label}.csv', coefficient_table(segmented))
        out.save(f'static_residual_stationarity_{label}.csv', stationarity(segmented.resid))
        out.save(f'static_fitted_{label}.csv', pd.DataFrame({
            'actual': data.EF, 'segmented_fit': segmented.fittedvalues,
            'common_slope_fit': common.fittedvalues, 'residual': segmented.resid}), True)
        for name, vector in [('prebreak_slope', [0, 0, 1, 0]), ('slope_change', [0, 0, 0, 1]),
                             ('postbreak_slope', [0, 0, 1, 1]), ('intercept_difference', [0, 1, 0, 0]),
                             ('break_date_jump', [0, 1, 0, 13])]:
            test = segmented.t_test(vector)
            static_tests.append(dict(sample=label, contrast=name, estimate=float(test.effect.item()),
                                     std_error=float(test.sd.item()), t_statistic=float(test.tvalue.item()),
                                     p_student_t=float(test.pvalue)))
        for name, model in [('segmented', segmented), ('common_slope', common)]:
            static_metrics.append(dict(sample=label, model=name, **metrics(model)))
    out.save('static_contrasts.csv', pd.DataFrame(static_tests))
    out.save('static_fit_comparison.csv', pd.DataFrame(static_metrics))

    comparisons, comparison_coefs, comparison_oot, model_checks = [], [], [], []
    for code in ['FLBR_B.IUSA', 'FGAP_B.IUSA', 'FGDP$_B.IUSA']:
        feature = CODE_TO_FEATURE[code]
        model = fit(development, [D, LAG, feature])
        predictions = oot_predictions(model, history)
        comparisons.append(dict(candidate=code, **metrics(model), macro_coefficient=model.params[feature],
                                macro_p=model.pvalues[feature], **forecast_errors(predictions)))
        comparison_coefs.append(coefficient_table(model).assign(candidate=code))
        comparison_oot.append(predictions.reset_index().assign(candidate=code))
        model_checks.append(dict(candidate=code, coefficient_p=model.pvalues[feature], **gates(model, feature)))
    out.save('candidate_comparison.csv', pd.DataFrame(comparisons))
    out.save('comparison_coefficients.csv', pd.concat(comparison_coefs, ignore_index=True))
    out.save('comparison_oot_forecasts.csv', pd.concat(comparison_oot, ignore_index=True))
    out.save('candidate_selection_checks.csv', pd.DataFrame(model_checks))
    conditional = []
    for feature in FEATURES:
        if feature not in chosen:
            model = fit(development, terms + [feature])
            conditional.append(dict(candidate=FEATURE_TO_CODE[feature], coefficient=model.params[feature],
                                    p_student_t=model.pvalues[feature], **gates(model, feature)))
    out.save('conditional_additions_after_final.csv', pd.DataFrame(conditional))

    fit_rows, vif_rows = [], []
    for label, data, model in [('development', development, final), ('full_history', full_history, full)]:
        fit_rows.append(dict(sample=label, **metrics(model)))
        out.save(f'diagnostics_{label}.csv', diagnostics(model))
        out.save(f'final_residual_stationarity_{label}.csv', stationarity(model.resid))
        out.save(f'fitted_values_{label}.csv', pd.DataFrame({
            'actual': data.EF, 'fitted': model.fittedvalues, 'residual': model.resid}), True)
        vif_rows += [dict(sample=label, term=key, source_column=FEATURE_TO_CODE.get(key, ''), vif=value)
                     for key, value in vifs(model).items()]
    out.save('fit_statistics.csv', pd.DataFrame(fit_rows))
    out.save('variance_inflation_factors.csv', pd.DataFrame(vif_rows))
    predictions = oot_predictions(final, history)
    out.save('oot_forecasts.csv', predictions, True)
    out.save('oot_metrics.csv', pd.DataFrame([forecast_errors(predictions)]))
    benchmarks = pd.DataFrame({'actual': predictions.actual,
                               'persistence_one_step': history.loc[predictions.index, LAG],
                               'persistence_recursive': history.loc[DEVELOPMENT_END, 'EF'],
                               'development_mean': development.EF.mean()})
    out.save('oot_benchmarks.csv', benchmarks, True)
    out.save('benchmark_metrics.csv', pd.DataFrame([
        dict(benchmark=key, rmse=float(np.sqrt(np.mean((benchmarks.actual - benchmarks[key])**2))))
        for key in benchmarks.columns if key != 'actual']))
    influence = final.get_influence()
    out.save('influence.csv', pd.DataFrame({
        'quarter': development.index.astype(str), 'residual': final.resid.to_numpy(),
        'studentized_residual': influence.resid_studentized_external,
        'leverage': influence.hat_matrix_diag, 'cooks_distance': influence.cooks_distance[0],
        'cook_flag': influence.cooks_distance[0] > 4 / len(development)}))
    leave_one_out = []
    for quarter in development.index:
        model = fit(development.drop(index=quarter), terms)
        leave_one_out.append(coefficient_table(model).assign(omitted_quarter=str(quarter)))
    out.save('leave_one_out.csv', pd.concat(leave_one_out, ignore_index=True))
    raw_history = history.copy()
    raw_history['EF'], raw_history[LAG] = raw, raw.shift(1)
    raw_model = fit(raw_history.loc[development.index], terms)
    out.save('coefficients_raw_ef_sensitivity.csv', coefficient_table(raw_model))
    out.save('raw_ef_sensitivity_metrics.csv', pd.DataFrame([
        dict(**metrics(raw_model), **forecast_errors(oot_predictions(raw_model, raw_history)))]))

    if not history_only:
        anchors, origin = macro['FLBR_B.IUSA'].iloc[-2:], history.EF.iloc[-1]
        macro_paths, forecasts, sensitivity, summaries = [], [], [], []
        for case, path in paths.items():
            levels = path['FLBR_B.IUSA'].to_numpy()
            macro_paths.append(pd.DataFrame({'quarter': FUTURE.astype(str), 'scenario': case,
                                             'source_column': 'FLBR_B.IUSA', 'level_percent': levels}))
            for label, model in [('development', final), ('full_history', full)]:
                values, changes = scenario_forecast(model, levels, anchors, origin)
                forecasts.append(pd.DataFrame({'quarter': FUTURE.astype(str), 'coefficient_sample': label,
                    'scenario': case, 'FLBR_B.IUSA': levels, 'lagged_unemployment_change_pp': changes,
                    'ef_forecast': values}))
                summaries.append(dict(coefficient_sample=label, scenario=case, mean_ef=float(values.mean()),
                                      min_ef=float(values.min()), max_ef=float(values.max()), ending_ef=values[-1]))
            base, _ = scenario_forecast(full, levels, anchors, origin)
            for shift in [-1., 0., 1.]:
                if np.any((levels + shift < 0) | (levels + shift > 100)):
                    raise ValueError(f'{case} sensitivity shift produces unemployment outside [0,100]')
                values, changes = scenario_forecast(full, levels + shift, anchors, origin)
                sensitivity.append(pd.DataFrame({'quarter': FUTURE.astype(str), 'scenario': case,
                    'unemployment_level_shift_pp': shift, 'FLBR_B.IUSA': levels + shift,
                    'lagged_unemployment_change_pp': changes, 'ef_forecast': values,
                    'ef_effect': values - base, 'ef_effect_pp': 100 * (values - base)}))
        out.save('scenario_macro_paths.csv', pd.concat(macro_paths, ignore_index=True))
        out.save('scenario_ef_forecasts.csv', pd.concat(forecasts, ignore_index=True))
        out.save('scenario_summary.csv', pd.DataFrame(summaries))
        out.save('scenario_sensitivity.csv', pd.concat(sensitivity, ignore_index=True))
        sd = float(development[U].std(ddof=1))
        out.save('one_sd_macro_shock.csv', pd.DataFrame({
            'horizon_after_shock_enters_equation': np.arange(9), 'unemployment_change_sd_pp': sd,
            'ef_effect': full.params.get(U, 0.) * sd * full.params[LAG]**np.arange(9)}))

    summary = dict(macro_count=len(CODES), macro_start=START, ef_2020q3=float(raw.loc['2020Q3']),
                   development_start=str(development.index[0]), development_end=DEVELOPMENT_END,
                   development_n=len(development), full_history_n=len(full_history),
                   selected_with_trend=';'.join(FEATURE_TO_CODE[x] for x in chosen),
                   trend_p_student_t=with_trend.pvalues[T], keep_trend=keep_trend,
                   selected_no_trend_alternative=';'.join(FEATURE_TO_CODE[x] for x in alternate),
                   final_terms=';'.join(terms), covariance='Classical OLS; Student-t inference',
                   scenario_status='not requested (--history-only)' if history_only else 'complete',
                   python=platform.python_version())
    for package in ['numpy', 'pandas', 'scipy', 'statsmodels']:
        summary[f'{package}_version'] = importlib.metadata.version(package)
    out.save('run_summary.csv', pd.DataFrame([{'setting': key, 'value': value} for key, value in summary.items()]))
    hashes = []
    for path in files:
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        if digest != input_hashes[str(path)]:
            raise RuntimeError(f'Input changed during analysis: {path.name}')
        hashes.append(dict(role='scenario' if path in [scenario_dir / 'S1.csv', scenario_dir / 'S4.csv']
                           else 'historical', file=path.name, sha256=digest, bytes=path.stat().st_size))
    out.save('input_manifest.csv', pd.DataFrame(hashes))
    output_manifest = pd.DataFrame([dict(file=name, sha256=hashlib.sha256((output_dir / name).read_bytes()).hexdigest())
                                    for name in out.files])
    out.save('output_manifest.csv', output_manifest)
    print(f'Selected with trend: {summary["selected_with_trend"] or "no macro"}')
    print(f'Trend p-value: {with_trend.pvalues[T]:.8f}; trend retained: {keep_trend}')
    print(f'No-trend alternative: {summary["selected_no_trend_alternative"] or "no macro"}')
    print(f'Final OOT RMSE: one-step {forecast_errors(predictions)["one_step_rmse"]:.8f}; '
          f'recursive {forecast_errors(predictions)["recursive_rmse"]:.8f}')
    print(f'Wrote {len(out.files)} CSV files to {output_dir}')
    return summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input-dir', type=Path, default=ROOT / 'inputs')
    parser.add_argument('--scenario-dir', type=Path, default=ROOT / 'scenarios')
    parser.add_argument('--output-dir', type=Path, default=ROOT / 'results')
    parser.add_argument('--overwrite', action='store_true', help='Replace same-named result CSVs; never change inputs')
    parser.add_argument('--history-only', action='store_true', help='Run historical analysis without reading scenario files')
    args = parser.parse_args()
    try:
        run(args.input_dir, args.scenario_dir, args.output_dir, args.overwrite, args.history_only)
    except (ValueError, FileNotFoundError) as error:
        parser.exit(2, f'Input or configuration error: {error}\n')


if __name__ == '__main__':
    main()
