"""Independent numerical and input-contract checks for the supplied data snapshot."""
import contextlib
import hashlib
import io
import sys
import tempfile
import unittest
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import chi2, t as student_t

PACKAGE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PACKAGE))
import noncomp_ef_model as m


def independent_ols(data, terms):
    x = np.column_stack([np.ones(len(data)), data[terms]])
    y = data.EF.to_numpy()
    b = np.linalg.lstsq(x, y, rcond=None)[0]
    residual = y - x @ b
    df = len(y) - len(b)
    se = np.sqrt(np.diag(np.linalg.inv(x.T @ x)) * (residual @ residual) / df)
    return b, se, 2 * student_t.sf(abs(b / se), df), x, residual


class ModelTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.macro, cls.raw, cls.paths = m.load_inputs(PACKAGE / 'inputs', PACKAGE / 'scenarios')
        cls.history = m.prepare_history(cls.macro, cls.raw)
        cls.dev = cls.history.loc[:m.DEVELOPMENT_END].dropna()
        cls.chosen, cls.trend, cls.trials = m.forward_selection(cls.dev, [m.D, m.T, m.LAG])
        cls.final = m.fit(cls.dev, [m.D, m.LAG] + cls.chosen)
        cls.full = m.fit(cls.history.dropna(), [m.D, m.LAG] + cls.chosen)

    def test_input_counts_dates_and_units(self):
        self.assertEqual(self.macro.shape, (60, 22))
        self.assertEqual(sorted(p.name for p in (PACKAGE / 'inputs').glob('*')), ['ef.csv', 'macro.csv'])
        self.assertEqual(self.raw.loc['2020Q3'], .634)
        self.assertEqual(len(self.paths['S1']), 9)
        self.assertEqual(self.macro.index[0], pd.Period('2011Q1'))

    def test_smoothing_from_raw_and_preservation(self):
        raw_copy = self.raw.copy()
        prepared = m.prepare_history(self.macro, self.raw)
        pd.testing.assert_series_equal(self.raw, raw_copy)
        self.assertAlmostEqual(prepared.loc['2017Q3', 'EF'], (.588 + .508 + .662) / 3)
        self.assertAlmostEqual(prepared.loc['2017Q4', 'EF'], (.508 + .662 + .569) / 3)
        unchanged = prepared.drop(index=[pd.Period('2017Q3'), pd.Period('2017Q4')])
        np.testing.assert_array_equal(unchanged.EF, self.raw.loc[unchanged.index])

    def test_common_start_and_no_deleted_quarters(self):
        self.assertTrue(self.history[m.FEATURES].iloc[:2].isna().all().all())
        self.assertFalse(self.history[m.FEATURES].iloc[2:].isna().any().any())
        self.assertEqual((len(self.dev), str(self.dev.index[0])), (49, '2011Q3'))
        self.assertEqual(len(self.history.dropna()), 58)
        for quarter in ['2017Q3', '2017Q4']:
            self.assertIn(pd.Period(quarter), self.dev.index)

    def test_macro_transformation_units(self):
        q = pd.Period('2012Q2')
        for code, _, _, _, kind in m.MACROS:
            now, old = self.macro.loc[q - 1, code], self.macro.loc[q - 2, code]
            expected = np.log(now) - np.log(old) if kind == 'log_change' else now - old
            self.assertAlmostEqual(self.history.loc[q, m.CODE_TO_FEATURE[code]], expected, places=14)

    def test_postbreak_interaction(self):
        self.assertEqual(self.history.loc['2013Q4', m.DT], 0)
        self.assertEqual(self.history.loc['2014Q1', m.DT], 13)
        self.assertEqual(self.history.loc['2025Q4', m.DT], 60)

    def test_selection_and_trend_decision(self):
        self.assertEqual(self.chosen, [m.U])
        self.assertAlmostEqual(self.trend.pvalues[m.T], .17190947245938515, places=10)
        self.assertGreaterEqual(self.trend.pvalues[m.T], .05)
        alt, _, _ = m.forward_selection(self.dev, [m.D, m.LAG])
        self.assertEqual(alt, [m.CODE_TO_FEATURE['FGAP_B.IUSA']])
        self.assertNotIn(m.T, self.final.params.index)
        self.assertNotIn(m.DT, self.final.params.index)

    def test_every_screening_trial_and_rank_independently(self):
        for base in [[m.D, m.T, m.LAG], [m.D, m.LAG]]:
            _, _, trials = m.forward_selection(self.dev, base)
            for row in trials.itertuples():
                selected = row.existing.split(';') if row.existing else []
                b, se, p, x, e = independent_ols(self.dev, base + selected + [row.feature])
                dw = np.diff(e) @ np.diff(e) / (e @ e)
                z = e - e.mean()
                variance = np.mean(z**2)
                skew, kurt = np.mean(z**3) / variance**1.5, np.mean(z**4) / variance**2
                jb = len(e) / 6 * (skew**2 + (kurt - 3)**2 / 4)
                jb_p = chi2.sf(jb, 2)
                vifs = []
                for col in range(1, x.shape[1]):
                    others = np.delete(x, col, axis=1)
                    y = x[:, col]
                    error = y - others @ np.linalg.lstsq(others, y, rcond=None)[0]
                    vifs.append(np.sum((y - y.mean())**2) / (error @ error))
                vif = max(vifs)
                np.testing.assert_allclose([row.p_student_t, row.max_vif, row.durbin_watson, row.jarque_bera_p],
                                           [p[-1], vif, dw, jb_p], rtol=2e-8, atol=1e-11)
                self.assertEqual(row.eligible, bool(p[-1] < .05 and vif < 10 and 1.5 <= dw <= 2.5 and jb_p > .05))
            for _, group in trials.groupby('round'):
                eligible = group[group.eligible]
                if len(eligible):
                    winner = min(eligible.itertuples(), key=lambda r: (r.p_student_t, -r.adjusted_r_squared,
                                                                       m.CODES.index(r.candidate)))
                    self.assertEqual(group[group.selected].candidate.tolist(), [winner.candidate])
                else:
                    self.assertFalse(group.selected.any())

    def test_ols_and_student_t_independently(self):
        for data, model in [(self.dev, self.final), (self.history.dropna(), self.full)]:
            b, se, p, _, _ = independent_ols(data, [m.D, m.LAG, m.U])
            np.testing.assert_allclose(model.params, b, atol=1e-11)
            np.testing.assert_allclose(model.bse, se, rtol=1e-9)
            np.testing.assert_allclose(model.pvalues, p, rtol=1e-9, atol=1e-12)

    def test_final_coefficients_and_oot_report_values(self):
        np.testing.assert_allclose(self.final.params, [.1937947413, -.0436333566, .7382915101, .006416661721], atol=5e-11)
        np.testing.assert_allclose(self.full.params, [.1946844273, -.04533766465, .73698510771, .00631374565], atol=5e-11)
        errors = m.forecast_errors(m.oot_predictions(self.final, self.history))
        self.assertAlmostEqual(errors['one_step_rmse'], .027830046154133044, places=12)
        self.assertAlmostEqual(errors['recursive_rmse'], .03727503467177018, places=12)

    def test_final_diagnostics_only_requested_tests(self):
        values = m.diagnostics(self.final).set_index('test')
        self.assertEqual(values.index.tolist(), ['Ljung Box 4', 'Ljung Box 8', 'Jarque Bera', 'CUSUM', 'Durbin Watson'])
        self.assertAlmostEqual(values.loc['Jarque Bera', 'p_value'], .27437945446, places=9)
        self.assertAlmostEqual(values.loc['CUSUM', 'p_value'], .70856262067, places=9)
        self.assertTrue(np.isnan(values.loc['Durbin Watson', 'p_value']))

    def test_adf_kpss_and_bounds(self):
        static = m.fit(self.history, [m.D, m.T, m.DT])
        result = m.stationarity(static.resid).set_index('test')
        self.assertEqual(result.loc['ADF', 'lags_or_bandwidth'], 2)
        self.assertAlmostEqual(result.loc['ADF', 'statistic'], -4.7568866563, places=8)
        self.assertAlmostEqual(result.loc['KPSS', 'statistic'], .1043992941, places=8)
        self.assertEqual(result.loc['KPSS', 'p_relation'], '>')

    def test_scenarios_by_independent_convolution(self):
        anchors, origin = self.macro['FLBR_B.IUSA'].iloc[-2:], self.history.EF.iloc[-1]
        for model in [self.final, self.full]:
            for path in self.paths.values():
                levels = path['FLBR_B.IUSA'].to_numpy()
                forecast, change = m.scenario_forecast(model, levels, anchors, origin)
                change_independent = np.diff(np.r_[anchors, levels])[:9]
                deterministic = model.params['const'] + model.params[m.D] + model.params[m.U] * change_independent
                phi = model.params[m.LAG]
                expected = [phi**(h + 1) * origin + sum(phi**(h - j) * deterministic[j] for j in range(h + 1))
                            for h in range(9)]
                np.testing.assert_allclose(change, change_independent, atol=1e-13)
                np.testing.assert_allclose(forecast, expected, atol=1e-13)

    def test_sensitivity_timing_and_last_macro_observation(self):
        anchors, origin = self.macro['FLBR_B.IUSA'].iloc[-2:], self.history.EF.iloc[-1]
        first = []
        for path in self.paths.values():
            levels = path['FLBR_B.IUSA'].to_numpy()
            base, _ = m.scenario_forecast(self.full, levels, anchors, origin)
            first.append(base[0])
            for delta in [-1, 1]:
                shock, _ = m.scenario_forecast(self.full, levels + delta, anchors, origin)
                expected = np.r_[0, delta * self.full.params[m.U] * self.full.params[m.LAG]**np.arange(8)]
                np.testing.assert_allclose(shock - base, expected, atol=1e-13)
            edited = levels.copy()
            edited[-1] += 5
            last, _ = m.scenario_forecast(self.full, edited, anchors, origin)
            np.testing.assert_allclose(last, base, atol=1e-13)
        self.assertEqual(first[0], first[1])
        self.assertAlmostEqual(first[0], .5539529304403635, places=12)

    def test_missing_scenario_driver_is_not_silently_substituted(self):
        model = m.fit(self.dev, [m.D, m.LAG, m.CODE_TO_FEATURE['FGAP_B.IUSA']])
        with self.assertRaisesRegex(ValueError, 'Scenario inputs contain only'):
            m.scenario_forecast(model, self.paths['S1']['FLBR_B.IUSA'], self.macro['FLBR_B.IUSA'].iloc[-2:], .548)

    def test_invalid_dates_missing_values_and_columns_rejected(self):
        source = pd.read_csv(PACKAGE / 'inputs/ef.csv')
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / 'bad.csv'
            for issue in ['duplicate', 'missing', 'non_quarter_end', 'extra_column']:
                frame = source.copy()
                if issue == 'duplicate': frame.loc[1, 'Quarter'] = frame.loc[0, 'Quarter']
                if issue == 'missing': frame.loc[1, 'EF'] = np.nan
                if issue == 'non_quarter_end': frame.loc[0, 'Quarter'] = '2011-03-30'
                if issue == 'extra_column': frame['unrequested'] = 0
                frame.to_csv(path, index=False)
                with self.subTest(issue=issue), self.assertRaises(ValueError):
                    m.read_quarterly(path, ['EF'], m.HISTORY)

    def test_complete_run_preserves_inputs_and_protects_outputs(self):
        paths = list((PACKAGE / 'inputs').glob('*.csv')) + list((PACKAGE / 'scenarios').glob('*.csv'))
        hashes = {p: hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
        with tempfile.TemporaryDirectory() as folder, contextlib.redirect_stdout(io.StringIO()):
            output = Path(folder) / 'results'
            m.run(PACKAGE / 'inputs', PACKAGE / 'scenarios', output)
            self.assertEqual(len(list(output.glob('*.csv'))), 46)
            self.assertFalse(list(output.glob('*.json')))
            self.assertEqual(len(pd.read_csv(output / 'scenario_ef_forecasts.csv')), 36)
            self.assertEqual(len(pd.read_csv(output / 'scenario_sensitivity.csv')), 54)
            with self.assertRaisesRegex(ValueError, 'not empty'):
                m.run(PACKAGE / 'inputs', PACKAGE / 'scenarios', output)
            with self.assertRaisesRegex(ValueError, 'earlier scenario outputs'):
                m.run(PACKAGE / 'inputs', PACKAGE / 'scenarios', output, overwrite=True, history_only=True)
            m.run(PACKAGE / 'inputs', Path(folder) / 'no_scenarios', Path(folder) / 'historical', history_only=True)
            self.assertFalse((Path(folder) / 'historical/scenario_ef_forecasts.csv').exists())
        for path in paths:
            self.assertEqual(hashlib.sha256(path.read_bytes()).hexdigest(), hashes[path])


if __name__ == '__main__':
    unittest.main()
