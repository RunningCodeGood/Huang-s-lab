# Noncomp MDD v20

Run `noncomp.py` to estimate the Other expense regression and generate the Other MDD tables, figures and detailed results. Open `output/index.html` to browse the included results.

## Run

Use Python 3.12. From the extracted Noncomp directory, run

```sh
python -m pip install -r requirements.txt
python noncomp.py
```

All generated files go directly into `output/`. A subsequent run refreshes the named outputs and removes retired numbered exhibits listed in the previous output index. Use `--data-dir PATH` or `--output-dir PATH` to select another location.

## Occupancy expense reference files

The accompanying Occupancy report and Excel 97–2003 workbook are supplied in `input/` for the qualitative component of the MDD. The Python script runs independently of both files. Figure 2.1 uses the historical series in `ooc_updated1.xls`. The original report, `Occupancy_Cost(1).docx`, documents calibration, projections and backtest results.

The Other dollar forecast uses `input/occupancy_baseline.csv`. Each row supplies a quarter, the mean of its three projected monthly asset balances in billions of dollars and its projected Occupancy expense in millions of dollars. The script applies the S1 Other ratio to the average asset balance and adds the supplied Occupancy expense for the combined baseline detail. The script reads the CSV directly.

## Other expense inputs

| Input in `input/` | Contents |
|---|---|
| `expense_history.csv` | Monthly Other and signed Card expense from January 2011 through December 2025. |
| `asset_history.csv` | Quarterly historical average assets used to scale expenses and convert backtest ratios to dollars. |
| `macro_history.csv` | Historical levels of the 15 candidate macroeconomic variables. |
| `macro_baseline.csv` | S1 baseline macroeconomic levels over the nine forecast quarters. |
| `macro_s4.csv` | S4 10-year Treasury yield levels. The forecast uses the first nine quarters. |

The Other regression uses the development sample through 2023Q3. The conditional backtest runs from 2023Q4 through 2025Q4. Its coefficients are fixed at the development cutoff. Each quarter uses the observed change in the 10-year Treasury yield and the three calendar indicators. The selected equation has no lagged expense ratio, so the nine predictions are calculated directly. The correlation sign screen also uses the nine observed backtest ratios. The reported errors therefore measure performance after variable selection. S1, S4 and the S1 sensitivity analysis use the full-history refit through 2025Q4. The first forecast change uses the observed 2025Q4 yield. S1 comes from the August 2026 vintage and S4 from the January 2026 vintage.

## Outputs

The flat `output/` directory contains the 21 numbered MDD CSV tables covering Other expense, eight numbered MDD PNG figures for Other expense, 12 detailed Other CSV files, one combined baseline forecast CSV, two additional Other sensitivity charts and two indexes. The 21 tables include the shared field dictionary in Table 11.1. Its definitions come from `input/mdd_reference.json`. Figure 6.6A plots the 10-year Treasury yield level for each scenario. Figure 6.6B plots the quarterly Other expense ratio forecast in basis points. Both figures use the nine forecast quarters in Table 6.4. Table and figure filenames follow the document numbering. The file `baseline_expense_forecasts.csv` contains the combined baseline forecast. The file `backtest_by_quarter.csv` gives quarterly Other backtest results. Open `index.html` to view the exhibits and access the detail files. Open `index.csv` for the filename inventory.
