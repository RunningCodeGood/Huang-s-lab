"""Estimate Other expense and generate its tables and figures for Noncomp MDD v21."""
import argparse
import csv
import math
import re
from dataclasses import dataclass
from pathlib import Path
from tempfile import TemporaryDirectory

from matplotlib.backends.backend_agg import FigureCanvasAgg
from matplotlib.figure import Figure
from matplotlib.ticker import FuncFormatter
import numpy as np
import pandas as pd
from scipy import stats
from statsmodels.stats.diagnostic import acorr_ljungbox, breaks_cusumolsresid
from statsmodels.stats.outliers_influence import variance_inflation_factor
from statsmodels.stats.stattools import durbin_watson


# Other expense model

ROOT = Path(__file__).resolve().parent
FIRST, TRAIN_END, LAST = "2011Q1", "2023Q3", "2025Q4"
PEAK_MONTHS = ("2011-03", "2019-01", "2020-09", "2023-07", "2023-11")
BASE = ["intercept", "post_2019q1", "is_q4", "is_2020"]
TARGET = "expense_ratio_bp"
ALPHA = 0.10
TREASURY_SHOCKS_BP = (-15, -5, 5, 15)
# Source mnemonic, business name, transformation. Lags are applied after transformation.
MACROS = [
    ("FBBACBQ", "bank_assets", "log_change_1q_pct"),
    ("FBBLDPCBQ", "bank_deposits", "log_change_1q_pct"),
    ("FBBABLLCBQ", "bank_loans_and_leases", "log_change_1q_pct"),
    ("FCCALLQ", "consumer_credit", "log_change_1q_pct"),
    ("FBCFDELLCCQ", "card_delinquency", "level_pct"),
    ("FBCFDELLIQ", "commercial_industrial_delinquency", "level_pct"),
    ("FBCFCOFCCQ", "card_charge_offs", "level_pct"),
    ("FBKBQ", "business_bankruptcies", "log_change_1q_pct"),
    ("FBKP", "personal_bankruptcies", "log_change_1q_pct"),
    ("FCBOEVIXQ", "vix", "log_change_1q_pct"),
    ("FIRHYBOASQ", "high_yield_spread", "diff_1q_pp"),
    ("FRFED", "federal_funds_rate", "diff_1q_pp"),
    ("FRGT10Y", "treasury_10y", "diff_1q_pp"),
    ("FPPIXFD42Q", "services_ppi", "log_change_1q_pct"),
    ("FCPIULIE", "core_cpi", "log_change_1q_pct"),
]


def read_periods(path, frequency):
    """Index source observations by calendar period before creating shifts or lags."""
    frame = pd.read_csv(path, float_precision="round_trip")
    dates = pd.to_datetime(frame.pop("date"), format="%Y-%m-%d", errors="raise")
    frame.index = dates.dt.to_period(frequency)
    frame.index.name = "period"
    frame = frame.sort_index()
    if frame.empty or not frame.index.equals(pd.period_range(frame.index.min(), frame.index.max(), freq=frequency)):
        raise ValueError(f"Expected continuous, unique periods in {path.name}")
    return frame.apply(pd.to_numeric, errors="raise")


def create_target(data_dir):
    """Net signed monthly card expense, smooth designated months, and scale by assets."""
    month_grid = pd.period_range(pd.Period(FIRST).asfreq("M", "start"),
                                 pd.Period(LAST).asfreq("M", "end"), freq="M")
    m = read_periods(data_dir / "expense_history.csv", "M").reindex(month_grid)
    raw = m["Other_Month_Actual_num"] - m["Card_Month_Actual_num"]
    if not np.isfinite(raw).all():
        raise ValueError("Missing or nonfinite monthly expenses in the model sample")
    peaks = pd.PeriodIndex(PEAK_MONTHS, freq="M")
    prev, nxt = raw.shift(1), raw.shift(-1)
    smooth = raw.astype(float).copy()
    smooth.loc[peaks] = ((prev + nxt) / 2).loc[peaks]
    if smooth.isna().any():
        raise ValueError("A designated peak month requires both adjacent raw observations")
    monthly = pd.DataFrame({"raw_net_expense_usd": raw, "smoothed_expense_usd": smooth})
    q = monthly.groupby(monthly.index.asfreq("Q")).sum()
    q.index.name = "quarter"
    q["average_assets_usd"] = read_periods(data_dir / "asset_history.csv", "Q")["Average Asset_SNV"]
    if not np.isfinite(q.average_assets_usd).all() or (q.average_assets_usd <= 0).any():
        raise ValueError("Every modeled quarter must have positive, finite average assets")
    q[TARGET] = q.smoothed_expense_usd / q.average_assets_usd * 10000
    adjustments = pd.DataFrame({"prior_net_usd": prev, "raw_net_usd": raw, "next_net_usd": nxt,
                          "replacement_usd": smooth, "adjustment_usd": smooth - raw}).loc[peaks]
    adjustments["quarter_ratio_impact_bp"] = adjustments.adjustment_usd * 10000 / q.average_assets_usd.reindex(peaks.asfreq("Q")).to_numpy()
    adjustments.index.name = "month"
    q["intercept"] = 1.
    q["post_2019q1"] = (q.index >= pd.Period("2019Q1")).astype(float)
    q["is_q4"] = (q.index.quarter == 4).astype(float)
    q["is_2020"] = (q.index.year == 2020).astype(float)
    return q, adjustments


@dataclass
class Regression:
    params: pd.Series
    bse: pd.Series
    pvalues: pd.Series
    resid: pd.Series
    rsquared: float
    rsquared_adj: float

    def predict(self, frame):
        return frame.loc[:, self.params.index] @ self.params


def fit(frame, terms):
    """Fit OLS and compute two-sided normal p-values from a two-lag HAC covariance."""
    x = frame[terms].to_numpy(dtype=float)
    y = frame[TARGET].to_numpy(dtype=float)
    x_inv = np.linalg.pinv(x)
    beta = x_inv @ y
    residual = y - x @ beta
    scores = x * residual[:, None]
    meat = scores.T @ scores
    for lag in (1, 2):
        cross = scores[lag:].T @ scores[:-lag]
        meat += (1 - lag / 3) * (cross + cross.T)
    bread = x_inv @ x_inv.T
    variance = np.diag(bread @ meat @ bread.T)
    se = np.sqrt(np.maximum(variance, 0))
    with np.errstate(divide="ignore", invalid="ignore"):
        z = np.abs(beta / se)
    p = [math.erfc(value / math.sqrt(2)) for value in z]
    r2 = 1 - residual @ residual / np.sum((y - y.mean()) ** 2)
    adj_r2 = 1 - (1 - r2) * (len(y) - 1) / (len(y) - np.linalg.matrix_rank(x))
    return Regression(pd.Series(beta, index=terms), pd.Series(se, index=terms),
                      pd.Series(p, index=terms), pd.Series(residual, index=frame.index),
                      r2, adj_r2)


def adf_constant(series):
    """ADF with an intercept, default Schwert lag cap and AIC lag selection."""
    y = np.asarray(series, dtype=float)
    dy = np.diff(y)
    cap = min(math.ceil(12 * (len(y) / 100) ** 0.25), len(y) // 2 - 2)

    def design(start, lags):
        columns = [np.ones(len(dy) - start), y[start:-1]]
        columns.extend(dy[start-j:len(dy)-j] for j in range(1, lags+1))
        return np.column_stack(columns)

    # Compare AIC on a common sample, then refit at the winning lag on all usable rows.
    scores = []
    for lag in range(cap+1):
        x = design(cap, lag)
        dep = dy[cap:]
        residual = dep - x @ np.linalg.lstsq(x, dep, rcond=None)[0]
        scores.append(len(dep) * np.log(np.mean(residual**2)) + 2 * np.linalg.matrix_rank(x))
    lag = int(np.argmin(scores))
    x = design(lag, lag)
    dep = dy[lag:]
    inv = np.linalg.pinv(x)
    beta = inv @ dep
    residual = dep - x @ beta
    sigma2 = residual @ residual / (len(dep) - np.linalg.matrix_rank(x))
    statistic = beta[1] / np.sqrt(sigma2 * np.sum(inv[1]**2))
    # MacKinnon (1994) reference distribution for the constant-only univariate test.
    if statistic < -18.83:
        p = 0.
    elif statistic > 2.74:
        p = 1.
    else:
        curve = ((2.1659, 1.4412, .038269) if statistic <= -1.61 else
                 (1.7339, .93202, -.12745, -.010368))
        normal_score = np.polynomial.polynomial.polyval(statistic, curve)
        p = .5 * math.erfc(-normal_score / math.sqrt(2))
    return statistic, p, lag


def kpss_level(series):
    """KPSS level statistic with four Bartlett lags and tabulated p-value bounds."""
    u = np.asarray(series, dtype=float) - np.mean(series)
    n = len(u)
    long_run = u @ u
    for lag in range(1, 5):
        long_run += 2 * (1 - lag / 5) * (u[lag:] @ u[:-lag])
    statistic = np.sum(np.cumsum(u)**2) / (n * long_run)
    # Published KPSS level-test critical values at 10%, 5%, 2.5%, and 1%.
    critical = [.347, .463, .574, .739]
    return statistic, np.interp(statistic, critical, [.10, .05, .025, .01]), critical[1]


def transform_macro(level, transform):
    if transform == "diff_1q_pp":
        return level.diff()
    if transform == "log_change_1q_pct":
        if (level.dropna() <= 0).any():
            raise ValueError(f"{level.name} must be positive for log growth")
        return 100 * np.log(level).diff()
    return level


def project_paths(model, feature, definition, q, history, paths):
    """Apply the fitted equation to each path from a common historical origin."""
    origin = q.index[-1]
    horizon = pd.period_range(origin + 1, periods=9, freq="Q")
    comparison = pd.DataFrame({"quarter": horizon, "model": feature or "indicators_only"})
    for label, path in paths.items():
        predictors = pd.DataFrame({
            "intercept": 1., "post_2019q1": (horizon >= pd.Period("2019Q1")).astype(float),
            "is_q4": (horizon.quarter == 4).astype(float), "is_2020": (horizon.year == 2020).astype(float)
        }, index=horizon)
        if feature:
            code, transform, lag = definition
            if code not in path:
                comparison[f"{label}_status"] = f"missing scenario series for {code}"
                comparison[f"{label}_expense_ratio_bp"] = np.nan
                continue
            levels = path[code].reindex(horizon)
            if not np.isfinite(levels).all():
                raise ValueError(f"{label} requires nine quarterly levels for {code}")
            joined = pd.concat([history[code].loc[:origin], levels])
            predictors[feature] = transform_macro(joined, transform).shift(lag).reindex(horizon)
            comparison[f"{label}_driver_level"] = levels.to_numpy()
            comparison[f"{label}_model_input"] = predictors[feature].to_numpy()
        if "expense_ratio_bp_lag_1q" in model.params.index:
            previous = q[TARGET].iloc[-1]
            predicted = []
            for quarter in horizon:
                row = predictors.loc[[quarter]].assign(expense_ratio_bp_lag_1q=previous)
                previous = model.predict(row).iloc[0]
                predicted.append(previous)
        else:
            predicted = model.predict(predictors).to_numpy()
        comparison[f"{label}_expense_ratio_bp"] = predicted
        comparison[f"{label}_status"] = "available"
    return comparison


def treasury_sensitivity(model, feature, definition, q, history, baseline_path, baseline_forecast):
    """Apply a fixed shock to each quarterly S1 yield change, then calculate the yield path."""
    code = "FRGT10Y_B.IUSA"
    horizon = pd.PeriodIndex(baseline_forecast.quarter, freq="Q")
    baseline_yields = baseline_path.loc[horizon, code].to_numpy()
    starting_yield = history.loc[q.index[-1], code]
    s1_changes = np.diff(np.r_[starting_yield, baseline_yields])
    if not np.isfinite(s1_changes).all():
        raise ValueError("Treasury sensitivity requires a historical origin and a complete S1 yield path")
    runs = []
    for shock_bp in TREASURY_SHOCKS_BP:
        shocked_changes = s1_changes + shock_bp / 100.0
        shocked_yields = starting_yield + np.cumsum(shocked_changes)
        path = baseline_path.copy()
        path.loc[horizon, code] = shocked_yields
        forecast = project_paths(model, feature, definition, q, history, {"shock": path})
        result = pd.DataFrame({
            "model": forecast.model, "quarter": horizon, "shock_bp": shock_bp,
            "s1_yield_pct": baseline_yields, "shocked_yield_pct": shocked_yields,
            "s1_yield_change_pp": s1_changes, "shocked_yield_change_pp": shocked_changes,
            "s1_expense_ratio_bp": baseline_forecast.s1_expense_ratio_bp,
            "shocked_expense_ratio_bp": forecast.shock_expense_ratio_bp,
        })
        result["difference_vs_s1_bp"] = result.shocked_expense_ratio_bp - result.s1_expense_ratio_bp
        runs.append(result)
    return pd.concat(runs, ignore_index=True)


def summarize_sensitivity(detail):
    rows = []
    for (model, shock), path in detail.groupby(["model", "shock_bp"]):
        last = path.sort_values("quarter").iloc[-1]
        rows.append(dict(model=model, shock_bp=shock, final_quarter=last.quarter,
                         ending_s1_yield_pct=last.s1_yield_pct, ending_shocked_yield_pct=last.shocked_yield_pct,
                         mean_s1_ratio_bp=path.s1_expense_ratio_bp.mean(),
                         mean_shocked_ratio_bp=path.shocked_expense_ratio_bp.mean(),
                         mean_difference_bp=path.difference_vs_s1_bp.mean(),
                         max_abs_difference_bp=path.difference_vs_s1_bp.abs().max()))
    return pd.DataFrame(rows)


def quarterly_sensitivity_table(detail):
    by_quarter = ["model", "quarter"]
    table = detail.drop_duplicates(by_quarter).set_index(by_quarter)[["s1_expense_ratio_bp"]].copy()
    for shock, group in detail.groupby("shock_bp"):
        group = group.set_index(by_quarter)
        prefix = f"{'minus' if shock < 0 else 'plus'}_{abs(shock)}bp"
        table[prefix + "_expense_ratio_bp"] = group.shocked_expense_ratio_bp
        table[prefix + "_difference_vs_s1_bp"] = group.difference_vs_s1_bp
    return table.sort_index().reset_index()


def plot_sensitivity(detail, output_dir):
    """Plot each model's yield and expense paths from the same values exported to CSV."""
    colors = {-15: "#177b72", -5: "#41887f", 0: "#18364a", 5: "#b36525", 15: "#9e411f"}
    muted = "#455b68"
    for model, data in detail.groupby("model"):
        baseline = data.drop_duplicates("quarter").sort_values("quarter")
        horizon = baseline.quarter.to_list()
        start = baseline.s1_yield_pct.iloc[0] - baseline.s1_yield_change_pp.iloc[0]
        for kind in ("yield", "expense"):
            is_yield = kind == "yield"
            ticks = ([horizon[0] - 1] if is_yield else []) + horizon
            x = np.arange(len(ticks))
            if is_yield:
                curves = {0: np.r_[start, baseline.s1_yield_pct]}
                title = "10-year Treasury yield paths under quarterly change shocks"
                subtitle = (f"From a common {start:.2f}% yield in {ticks[0]}, each quarter’s yield change "
                            "is shifted by ±5 or ±15 bp relative to S1.")
                units, legend = "10-year Treasury yield (%)", "Shock  /  ending yield"
            else:
                curves = {0: baseline.s1_expense_ratio_bp.to_numpy()}
                title = "Quarterly expense sensitivity to changes in the 10-year yield"
                subtitle = (f"Each quarter’s yield change is shifted by ±5 or ±15 bp relative to S1, "
                            f"from {horizon[0]} through {horizon[-1]}.")
                units, legend = "Quarterly expense / average assets (bp)", "Shock  /  ending ratio vs. S1"
            for shock, path in data.groupby("shock_bp"):
                path = path.sort_values("quarter")
                curves[shock] = (np.r_[start, path.shocked_yield_pct] if is_yield
                                 else path.shocked_expense_ratio_bp.to_numpy())
            fig = Figure(figsize=(11.5, 5.55), facecolor="white")
            FigureCanvasAgg(fig)
            fig.text(.047, .916, title, fontsize=18.5, weight="bold", color=colors[0])
            fig.text(.047, .849, subtitle, fontsize=11.4, color=muted)
            ax = fig.add_axes([.083, .135, .659, .64])
            ax.spines[:].set_visible(False)
            ax.grid(axis="y", color="#dce4e8", linewidth=.7)
            ax.set_axisbelow(True)
            ax.set_xlim(-.16, x[-1] + .17)
            ax.set_xticks(x, [str(q) for q in ticks], fontsize=9)
            ax.set_ylabel(units, fontsize=10, color=muted)
            ax.tick_params(length=0, pad=6, labelcolor=muted)
            if is_yield:
                ax.yaxis.set_major_formatter(FuncFormatter(lambda value, _: f"{value:g}%"))
            ax.text(1.045, 1, legend, transform=ax.transAxes, fontsize=9.5, color=muted)
            lo, hi = np.min(list(curves.values())), np.max(list(curves.values()))
            span = max(hi - lo, .5)
            ax.set_ylim(lo - .13 * span, hi + .13 * span)
            for shock, yy in curves.items():
                ax.plot(x, yy, color=colors[shock], ls="--" if abs(shock) == 5 else "-",
                        lw=2.4 if shock == 0 else 1.8, marker="o", ms=3.2, zorder=4 if shock == 0 else 3)
            # Spread closely spaced endpoint labels while preserving their vertical order.
            order = sorted(curves, key=lambda shock: curves[shock][-1])
            gap = .083 * span
            previous = min(curves[s][-1] - i * gap for i, s in enumerate(order)) - gap
            for shock in order:
                end = curves[shock][-1]
                label_y = max(end, previous + gap)
                previous = label_y
                label = "S1" if shock == 0 else f"{shock:+d} bp"
                diff = end - curves[0][-1]
                value = f"{end:.2f}%" if is_yield else ("0.00 bp" if abs(diff) < .005 else f"{diff:+.2f} bp")
                ax.annotate(f"{label}    {value}".replace("-", "−"), xy=(x[-1], end),
                            xytext=(1.045, label_y), textcoords=ax.get_yaxis_transform(),
                            va="center", color=colors[shock], fontsize=10.8, weight="bold",
                            arrowprops=dict(arrowstyle="-", color=colors[shock], lw=.85, shrinkA=2, shrinkB=3),
                            annotation_clip=False)
            fig.savefig(output_dir / f"treasury_sensitivity_{kind}_{model}.png", dpi=190)
            fig.clear()


def estimate_other(data_dir):
    """Estimate Other expense and return its model outputs and fitted equations."""
    model_fits = {}
    q, peaks = create_target(data_dir)
    raw = read_periods(data_dir / "macro_history.csv", "Q")
    paths = {"s1": read_periods(data_dir / "macro_baseline.csv", "Q"),
             "s4": read_periods(data_dir / "macro_s4.csv", "Q").rename(
                 columns={"FRGT10YQ_S4.IUSA": "FRGT10Y_B.IUSA"})}
    train = q.loc[:TRAIN_END]
    test = q.loc[pd.Period(TRAIN_END) + 1:]
    baseline = fit(train, BASE)
    baseline_error = test[TARGET] - baseline.predict(test[BASE])
    adjusted = fit(train, ["intercept", "post_2019q1", "is_2020"]).resid
    k_stat, k_p, k_crit = kpss_level(adjusted)
    a_stat, a_p, a_lag = adf_constant(adjusted)
    unit_tests = [dict(series="regime_adjusted_target_bp", adf_stat=a_stat, adf_p=a_p, adf_lags=a_lag,
                       kpss_stat=k_stat, kpss_lookup_p=k_p, kpss_5pct_critical=k_crit, kpss_lags=4)]
    features = {}
    definitions = {}
    comparisons = []
    sensitivities = []
    screening = []
    for mnemonic, name, transform in MACROS:
        code = mnemonic + "_B.IUSA"
        x = transform_macro(raw[code], transform)
        development_values = x.reindex(train.index)
        if not np.isfinite(development_values).all():
            raise ValueError(f"Missing or nonfinite development observations for {code} after {transform}.")
        a_stat, a_p, a_lag = adf_constant(development_values)
        unit_tests.append(dict(series=f"{name}_{transform}",adf_stat=a_stat,adf_p=a_p,adf_lags=a_lag))
        for lag in range(3):
            feature = f"{name}_{transform}_lag_{lag}q"
            v = x.shift(lag).reindex(q.index)
            if not np.isfinite(v).all():
                raise ValueError(f"Missing values for {feature} in the screening sample")
            a, b = train.assign(candidate=v), test.assign(candidate=v)
            trial = fit(a, BASE + ["candidate"])
            r1, r2 = a.candidate.corr(a[TARGET]), b.candidate.corr(b[TARGET])
            beta, p = trial.params["candidate"], trial.pvalues["candidate"]
            same = beta != 0 and np.sign(r1) == np.sign(r2) == np.sign(beta)
            features[feature] = v
            definitions[feature] = (code, transform, lag)
            screening.append(dict(feature=feature, source_code=code, lag_quarters=lag,
                                  train_correlation=r1, backtest_correlation=r2, slope=beta,
                                  hac_se=trial.bse["candidate"], hac_p=p, signs_agree=same,
                                  selected=same and p < ALPHA))
    screen = pd.DataFrame(screening)
    coefs, forward_coefs, forecasts, metrics = [], [], [], []
    # The screen evaluates each macro separately. Keep separate fits if several qualify.
    for feature in screen.loc[screen.selected, "feature"].tolist() or [None]:
        spec = feature or "indicators_only"
        data = q.copy()
        terms = BASE.copy()
        if feature:
            data[feature] = features[feature]
            terms.append(feature)
        data["expense_ratio_bp_lag_1q"] = data[TARGET].shift()
        a, b = data.loc[train.index], data.loc[test.index]
        dynamic_terms = terms + ["expense_ratio_bp_lag_1q"]
        dynamic = fit(a.iloc[1:], dynamic_terms)
        ar_p = dynamic.pvalues["expense_ratio_bp_lag_1q"]
        if ar_p < ALPHA:
            backtest_model = dynamic
            previous = a[TARGET].iloc[-1]
            predicted = []
            for quarter in b.index:
                obs = b.loc[[quarter], terms].assign(expense_ratio_bp_lag_1q=previous)
                previous = backtest_model.predict(obs).iloc[0]
                predicted.append(previous)
            prediction = pd.Series(predicted, index=b.index)
        else:
            backtest_model = fit(a, terms)
            prediction = backtest_model.predict(b[terms])
        # Refit the selected terms on the history available at the forecast origin.
        forward_terms = backtest_model.params.index.tolist()
        forward_data = data.dropna(subset=forward_terms)
        forward_model = fit(forward_data, forward_terms)
        model_fits[spec] = {
            "development": backtest_model, "full_history": forward_model,
            "lag_test": dynamic, "design": data,
        }
        definition = definitions.get(feature)
        comparison = project_paths(forward_model, feature, definition, q, raw, paths)
        comparison["s4_minus_s1_bp"] = comparison.s4_expense_ratio_bp - comparison.s1_expense_ratio_bp
        comparisons.append(comparison)
        sensitivities.append(treasury_sensitivity(forward_model, feature, definition, q, raw, paths["s1"], comparison))
        for fitted, rows in [(backtest_model, coefs), (forward_model, forward_coefs)]:
            for term in fitted.params.index:
                rows.append(dict(model=spec, term=term, estimate=fitted.params[term],
                                 hac_se=fitted.bse[term], hac_p=fitted.pvalues[term],
                                 fit_start=fitted.resid.index[0], fit_end=fitted.resid.index[-1],
                                 fit_quarters=len(fitted.resid)))
        error = b[TARGET] - prediction
        dollars = b.average_assets_usd * prediction / 10000
        forecasts.append(pd.DataFrame(dict(model=spec, quarter=b.index, actual_bp=b[TARGET],
            predicted_bp=prediction, actual_minus_predicted_bp=error, average_assets_usd=b.average_assets_usd,
            actual_expense_usd=b.smoothed_expense_usd, predicted_expense_usd=dollars)))
        metrics.append(dict(model=spec, train_quarters=len(backtest_model.resid), backtest_quarters=len(b),
            ar1_estimate=dynamic.params["expense_ratio_bp_lag_1q"], ar1_hac_p=ar_p, ar1_retained=ar_p<ALPHA,
            train_r2=backtest_model.rsquared, train_adj_r2=backtest_model.rsquared_adj, train_rmse_bp=np.sqrt(np.mean(backtest_model.resid**2)),
            backtest_rmse_bp=np.sqrt(np.mean(error**2)), backtest_mae_bp=error.abs().mean(),
            mean_actual_minus_predicted_bp=error.mean(), quarters_overpredicted=int((error < 0).sum()),
            indicators_only_rmse_bp=np.sqrt(np.mean(baseline_error**2)), actual_expense_usd=b.smoothed_expense_usd.sum(),
            predicted_expense_usd=dollars.sum(), cumulative_overprediction_pct=100*(dollars.sum()/b.smoothed_expense_usd.sum()-1)))
    sensitivity = pd.concat(sensitivities, ignore_index=True)
    return {"peak_month_adjustments":peaks.reset_index(), "quarterly_target":q.reset_index(),
            "stationarity_tests":pd.DataFrame(unit_tests), "macro_screen":screen,
            "coefficients":pd.DataFrame(coefs), "forecast_coefficients":pd.DataFrame(forward_coefs), "backtest_by_quarter":pd.concat(forecasts),
            "model_summary":pd.DataFrame(metrics),
            "scenario_quarterly_comparison":pd.concat(comparisons, ignore_index=True),
            "treasury_sensitivity_quarterly": sensitivity,
            "treasury_sensitivity_summary": summarize_sensitivity(sensitivity),
            "treasury_sensitivity_report_table": quarterly_sensitivity_table(sensitivity)}, model_fits

# Source materials and MDD tables

TREASURY = "treasury_10y_diff_1q_pp_lag_0q"
TERMS = {
    "intercept": "Intercept", "post_2019q1": "FCB acquisition indicator",
    "is_q4": "Fourth-quarter indicator", "is_2020": "2020 COVID indicator",
    TREASURY: "10-year Treasury yield change", "expense_ratio_bp_lag_1q": "Prior-quarter ratio",
}
APPENDIX_TERMS = dict(TERMS, post_2019q1="2019Q1 onward", is_q4="Fourth quarter")
APPENDIX_TERMS[TREASURY] = "10-year yield change"


def number(x, places=2, sign=False):
    spec = "+" if sign else ""
    return format(x, f"{spec},.{places}f").replace("-", "−")


def probability(p):
    return "<0.0001" if p < .0001 else number(p, 4)


def span(index):
    return f"{index[0]}–{index[-1]}"


def regression_tables(m):
    dev, full, lag = m["development"], m["full_history"], m["lag_test"]
    performance = [
        ["Measure", "Development model", "Full-history refit"],
        ["Estimation period", span(dev.resid.index), span(full.resid.index)],
        ["Observations", str(len(dev.resid)), str(len(full.resid))],
        ["Adjusted R²", number(dev.rsquared_adj, 4), number(full.rsquared_adj, 4)],
        ["Fitted RMSE in basis points", number(np.sqrt(np.mean(dev.resid**2)), 3),
         number(np.sqrt(np.mean(full.resid**2)), 3)],
    ]
    dev_table = [["Term", "Estimate", "Two-sided HAC p-value"]]
    together = [["Term", "In-sample estimate\n" + span(dev.resid.index), "Full-history estimate\n" + span(full.resid.index)]]
    for term in dev.params.index:
        dev_table.append([TERMS[term], number(dev.params[term], 4), probability(dev.pvalues[term])])
        together.append([TERMS[term], number(dev.params[term], 4), number(full.params[term], 4)])
    design = m["design"].loc[dev.resid.index, dev.params.index].to_numpy()
    vif = [["Predictor", "VIF"]]
    for i, term in enumerate(dev.params.index):
        if term != "intercept":
            vif.append([APPENDIX_TERMS[term], number(variance_inflation_factor(design, i), 3)])
    e = dev.resid.to_numpy()
    lb = acorr_ljungbox(e, lags=[4, 8], model_df=0)
    jb = stats.jarque_bera(e)
    cusum, cusum_p, _ = breaks_cusumolsresid(e, ddof=design.shape[1])
    diagnostics = [["Diagnostic", "Statistic", "p-value"], ["Durbin–Watson", number(durbin_watson(e), 3), "—"]]
    for lag_order, row in lb.iterrows():
        diagnostics.append([f"Ljung–Box Q({lag_order})", number(row.lb_stat, 3), probability(row.lb_pvalue)])
    diagnostics.extend([["Jarque–Bera", number(jb.statistic, 3), probability(jb.pvalue)],
                        ["OLS-residual CUSUM", number(cusum, 3), probability(cusum_p)]])
    result = {"1.2": performance, "3.6": dev_table, "3.7": together, "6.2": vif, "6.3": diagnostics}
    z = stats.norm.ppf(.975)
    for key, fit in [("11.4", lag), ("11.5", dev)]:
        inference = [["Term", "Estimate", "HAC SE", "p-value", "95% low", "95% high"]]
        for term, b in fit.params.items():
            se = fit.bse[term]
            inference.append([APPENDIX_TERMS[term], number(b, 4), number(se, 4), probability(fit.pvalues[term]),
                              number(b - z * se, 4), number(b + z * se, 4)])
        result[key] = inference
    return result


# Titles and descriptions for the MDD tables and figures.
EXHIBIT_TITLES = (
    ('Table', '1.5', 'Final model variable summary'),
    ('Table', '1.2', 'Key performance measures for the Other regression'),
    ('Table', '3.3', 'In-sample stationarity tests'),
    ('Table', '3.4', 'Candidate macroeconomic variables and transformations'),
    ('Table', '3.5', 'Entry rules and the retained Treasury specification'),
    ('Table', '3.6', 'Final development regression, 2011Q1–2023Q3'),
    ('Table', '3.7', 'Other regression coefficients by estimation period'),
    ('Table', '4.2', 'External data inventory'),
    ('Table', '4.3', 'Data lineage for the final Other regression'),
    ('Table', '4.4', 'Other data quality review results'),
    ('Table', '4.5', 'Adjustments to monthly net Other and quarterly ratio'),
    ('Table', '4.6', 'Business events associated with the Other expense adjustments'),
    ('Figure', '6.1', 'Actual and fitted Other expense ratios in development'),
    ('Table', '6.2', 'Development variance inflation factors'),
    ('Table', '6.3', 'Development residual and stability tests'),
    ('Figure', '6.2', 'Quarterly Other development residuals'),
    ('Figure', '6.3', 'Other residuals against fitted expense ratios'),
    ('Figure', '6.4', 'Normal quantile plot of Other development residuals'),
    ('Figure', '6.5', 'Out-of-time actual and frozen-coefficient Other forecasts'),
    ('Table', '6.4', 'Scenario Treasury inputs and Other expense ratios'),
    ('Figure', '6.6A', '10-year Treasury yield paths under S1 and S4'),
    ('Figure', '6.6B', 'Nine-quarter Other expense ratio forecasts under S1 and S4'),
    ('Table', '6.5', 'Other expense sensitivity to changes in the S1 Treasury path'),
    ('Figure', '6.7', 'Other expense ratios under shocks to the quarterly S1 Treasury yield change'),
    ('Table', '11.1', 'Model inputs, derived variables and units'),
    ('Table', '11.2', 'Other input files and coverage'),
    ('Table', '11.3', 'Complete candidate screen, two-sided HAC p-values'),
    ('Table', '11.4', 'Test of the prior quarter’s Other expense ratio'),
    ('Table', '11.5', 'Final in-sample estimates used for the historical backtest'),
)

MACRO_DESCRIPTIONS = {
    'FBBACBQ': ('Commercial bank assets', 'Commercial bank assets'),
    'FBBLDPCBQ': ('Commercial bank deposits', 'Commercial bank deposits'),
    'FBBABLLCBQ': ('Commercial bank loans and leases', 'Bank loans and leases'),
    'FCCALLQ': ('Consumer credit outstanding', 'Consumer credit outstanding'),
    'FBCFDELLCCQ': ('Consumer credit card delinquency rate', 'Consumer card delinquency'),
    'FBCFDELLIQ': ('Commercial and industrial loan delinquency rate', 'Commercial and industrial delinquency'),
    'FBCFCOFCCQ': ('Consumer credit card charge-off rate', 'Consumer card charge-offs'),
    'FBKBQ': ('Business bankruptcies', 'Business bankruptcies'),
    'FBKP': ('Personal bankruptcies', 'Personal bankruptcies'),
    'FCBOEVIXQ': ('CBOE Volatility Index (VIX)', 'VIX'),
    'FIRHYBOASQ': ('High-yield option-adjusted spread', 'High-yield option-adjusted spread'),
    'FRFED': ('Federal funds rate', 'Federal funds rate'),
    'FRGT10Y': ('10-year Treasury yield', '10-year Treasury yield'),
    'FPPIXFD42Q': ('Producer Price Index for final-demand services', 'Final-demand services PPI'),
    'FCPIULIE': ('Consumer Price Index excluding food and energy', 'Core CPI'),
}

MDD_TABLE_TEXT = {
    '1.5': (
        ('Variable', 'Description', 'Construction'),
        (
            'ΔYₜ\n10-year Treasury yield change',
            'Current-quarter change in the 10-year Treasury yield, in percentage points',
            'Yield in quarter t less yield in quarter t−1',
        ),
        (
            'Pₜ\nPost-acquisition indicator',
            'Adjustment for the change in the expense ratio after the FCB acquisition',
            '0 through 2018Q4 and 1 from 2019Q1 onward',
        ),
        (
            'Qₜ\nFourth-quarter indicator',
            'Recurring fourth-quarter expense effect',
            '1 in each fourth quarter and 0 otherwise',
        ),
        (
            'Cₜ\n2020 COVID indicator',
            'Adjustment to the expense ratio during the 2020 COVID period',
            '1 in 2020Q1–2020Q4 and 0 otherwise',
        ),
    ),
    '4.2': (
        ('Economic Theme', 'Representative Variables', 'Business Purpose'),
        (
            'Banking activity',
            'Bank assets, deposits, loans and leases, consumer credit',
            'Measure the scale of banking and credit activity.',
        ),
        (
            'Credit conditions',
            'Card and commercial delinquency, card charge-offs, bankruptcies',
            'Describe credit conditions that can affect professional services and regulatory expenses.',
        ),
        (
            'Prices',
            'Final-demand services PPI, core CPI',
            'Describe changes in the cost of services and other operating inputs.',
        ),
        ('Market conditions', 'VIX, high-yield spread', 'Describe market volatility and the cost of credit.'),
        (
            'Interest rates',
            'Federal funds rate, 10-year Treasury yield',
            'Measure changes in the interest rate environment.',
        ),
        (
            'Forward scenarios',
            'S1 and S4 10-year Treasury yield paths',
            'Supply quarterly yield changes for the Other forecasts.',
        ),
    ),
    '4.3': (
        (
            'Final Variable',
            'Source Files',
            'Description',
            'Transformation Steps',
            'Final Formula',
            'Model Role',
        ),
        (
            'Other ratio (R)',
            'expense_history.csv\nasset_history.csv',
            'Adjusted expense divided by average assets',
            'Subtract signed Card. Smooth the five designated months. Sum each quarter.',
            '10,000 × adjusted quarterly expense / average assets',
            'Dependent variable (bp)',
        ),
        (
            'FCB indicator (P)',
            'Quarter date',
            'Post-acquisition period',
            'Identify quarters from 2019Q1 onward.',
            '1 from 2019Q1, else 0',
            'Level change',
        ),
        (
            'Q4 indicator (Q)',
            'Quarter date',
            'Fourth quarter',
            'Identify the last quarter of each year.',
            '1 in Q4, else 0',
            'Seasonality',
        ),
        (
            '2020 COVID indicator (C)',
            'Quarter date',
            '2020 COVID period',
            'Identify the four quarters of 2020.',
            '1 in 2020, else 0',
            'Period effect',
        ),
        (
            'Treasury change (ΔY)',
            'macro_history.csv',
            '10-year Treasury yield',
            'Subtract the previous quarter’s yield.',
            'Y(t) − Y(t−1)',
            'Historical macro driver',
        ),
        (
            'Scenario Treasury change',
            'macro_history.csv\nmacro_baseline.csv\nmacro_s4.csv',
            'S1 or S4 yield',
            'Start from the 2025Q4 yield. Difference each path separately.',
            'Y(t) − Y(t−1) on each path',
            'Forecast input',
        ),
    ),
    '4.6': (
        ('Adjustment month', 'Business explanation'),
        (
            'March 2011',
            '$20 million restructuring charge, $8 million open commitment reserve and $2 million in NPL expense.',
        ),
        ('January 2019', 'FCB merger in Jan 2019.'),
        ('September 2020', '$45 million goodwill impairment in Sept 2020.'),
        (
            'July 2023',
            '$35 million loan loss write-down for a medical office and $18.5 million restructuring for early retirement in Jul 2023.',
        ),
        ('November 2023', 'A special FDIC assessment in Nov 2023.'),
    ),
    '11.1': (
        ('Field', 'Units', 'Definition'),
        ('date_ym', 'YYYYMM', 'Quarter-end month'),
        ('Month_Actual_num', 'USD per quarter', 'Quarterly Occupancy expense E'),
        ('BS_Month_Actual_num', 'USD, three-month sum', 'Sum of monthly balances B'),
        ('BS', 'USD, quarterly average', 'Average assets A = B/3'),
        ('pct', 'Annualized decimal', '12 × E / B'),
        ('h', 'Quarter number', '1 through 9 following 2025Q4'),
        ('Haircut', 'Decimal share', '0.12 in Q1–Q6, then 0.09, 0.06, 0.03'),
        (
            'Adjusted Other',
            'USD per quarter',
            'Sum of three monthly Other amounts after signed Card removal and the specified peak-month replacements.',
        ),
        ('R', 'Unannualized bp', '10,000 × quarterly adjusted Other / A.'),
        (
            'ΔY',
            'Percentage points',
            'Current 10-year Treasury yield less its preceding quarterly level on the same path.',
        ),
        (
            'P, Q, C',
            '0 or 1',
            'P marks 2019Q1 onward, Q marks each fourth quarter, and C is the 2020 COVID indicator for 2020Q1–2020Q4.',
        ),
    ),
}


def screening_tables(t):
    tests = t["stationarity_tests"].set_index("series")
    target = tests.loc["regime_adjusted_target_bp"]
    treasury = tests.loc["treasury_10y_diff_1q_pp"]
    def adf_row(label, test):
        op = "< 0.0001" if test.adf_p < .0001 else f"= {number(test.adf_p, 4)}"
        return [label, number(test.adf_stat, 4), "p " + op]
    stationarity = [["Series and test", "Statistic", "Result"], adf_row("Adjusted Other target, ADF", target),
                    ["Adjusted Other target, KPSS", number(target.kpss_stat, 4),
                     f"5% critical value {number(target.kpss_5pct_critical, 3)}"],
                    adf_row("Quarterly Treasury change, ADF", treasury)]
    screen = t["macro_screen"]
    selected = screen.set_index("feature").loc[TREASURY]
    rules = [
        ["Entry measure", "Requirement", "Current Treasury change"],
        ["Training correlation", "Common nonzero sign", number(selected.train_correlation, 3)],
        ["Evaluation correlation", "Common nonzero sign", number(selected.backtest_correlation, 3)],
        ["Partial regression slope", "Same sign as both correlations", number(selected.slope, 4) + " bp per pp"],
        ["Two-sided HAC test", f"p < {ALPHA:.2f}", "p = " + number(selected.hac_p, 4)],
    ]
    transforms = {"log_change_1q_pct": "Quarterly log growth", "diff_1q_pp": "Quarterly change in percentage points",
                  "level_pct": "Level"}
    universe = [["Variable Name", "Description", "Transformation"]]
    grid = [["Candidate", "Current", "Lag 1", "Lag 2"]]
    for code, name, transform in MACROS:
        desc, short = MACRO_DESCRIPTIONS[code]
        universe.append([code, desc, transforms[transform]])
        trials = screen.loc[screen.source_code == code + "_B.IUSA"].sort_values("lag_quarters")
        grid.append([short] + [number(v.hac_p, 4) + (" +" if v.signs_agree else "") + (" *" if v.selected else "")
                               for v in trials.itertuples()])
    return {"3.3": stationarity, "3.4": universe, "3.5": rules, "11.3": grid}


def expense_tables(t):
    peaks = t["peak_month_adjustments"]
    adjusted = [["Month", "Prior ($m)", "Original ($m)", "Next ($m)", "Revised ($m)", "Impact (bp)"]]
    for r in peaks.itertuples():
        adjusted.append([str(r.month), number(r.prior_net_usd/1e6, 3), number(r.raw_net_usd/1e6, 3),
                         number(r.next_net_usd/1e6, 3), number(r.replacement_usd/1e6, 3),
                         number(r.quarter_ratio_impact_bp)])
    forecast = t["scenario_quarterly_comparison"].set_index("quarter")
    scenarios = [["Quarter", "S1 yield (%)", "S4 yield (%)", "S1 change (pp)", "S4 change (pp)", "S1 ratio (bp)", "S4 ratio (bp)"]]
    for r in forecast.itertuples():
        scenarios.append([str(r.Index), number(r.s1_driver_level, 3), number(r.s4_driver_level, 3),
                          number(r.s1_model_input, 4), number(r.s4_model_input, 4),
                          number(r.s1_expense_ratio_bp), number(r.s4_expense_ratio_bp)])
    sensitivity = [["Shock to each quarterly yield change (bp)", f"{forecast.index[-1]} Treasury yield (%)",
                    "Nine-quarter mean expense ratio (bp)", "Quarterly difference from S1 (bp)"]]
    summary = t["treasury_sensitivity_summary"].set_index("shock_bp")
    for shock in sorted([0, *summary.index]):
        if shock == 0:
            sensitivity.append(["0 (S1 baseline)", number(forecast.s1_driver_level.iloc[-1]),
                                number(forecast.s1_expense_ratio_bp.mean()), "0.00"])
        else:
            r = summary.loc[shock]
            sensitivity.append([number(shock, 0, True), number(r.ending_shocked_yield_pct),
                                number(r.mean_shocked_ratio_bp), number(r.mean_difference_bp, sign=True)])
    return {"4.5": adjusted, "6.4": scenarios, "6.5": sensitivity}


def combined_baseline(data_dir, scenarios):
    """Convert Other to dollars using the supplied occupancy baseline handoff."""
    baseline = pd.read_csv(data_dir / "occupancy_baseline.csv", float_precision="round_trip")
    baseline.index = pd.PeriodIndex(baseline.pop("quarter"), freq="Q")
    inputs = baseline[["average_assets_bn", "occupancy_expense_m"]]
    if not np.isfinite(inputs).all().all() or (baseline.average_assets_bn <= 0).any():
        raise ValueError("The baseline handoff requires finite dollar amounts and positive average assets.")
    forecast = scenarios.set_index("quarter")
    if not baseline.index.equals(forecast.index):
        raise ValueError("The Occupancy baseline and Other scenario quarters differ.")
    # The shared asset input is already the average of the three projected monthly balances, in billions.
    other_m = baseline.average_assets_bn * forecast.s1_expense_ratio_bp / 10
    subtotal_m = other_m + baseline.occupancy_expense_m
    combined = [["Quarter", "Average assets ($bn)", "Occupancy expense ($m)", "Adjusted Other ($m)", "Baseline subtotal ($m)"]]
    for q in forecast.index:
        combined.append([str(q), number(baseline.at[q, "average_assets_bn"]), number(baseline.at[q, "occupancy_expense_m"]),
                         number(other_m[q]), number(subtotal_m[q])])
    combined.append(["Nine quarters", "—", number(baseline.occupancy_expense_m.sum()), number(other_m.sum()), number(subtotal_m.sum())])
    return combined


def input_tables(data_dir, t):
    inputs = {}
    for name, freq in [("expense_history", "M"), ("asset_history", "Q"), ("macro_history", "Q"),
                       ("macro_baseline", "Q"), ("macro_s4", "Q")]:
        inputs[name] = read_periods(data_dir / (name + ".csv"), freq)
    monthly = inputs["expense_history"]
    q = t["quarterly_target"].set_index("quarter")
    scenarios = t["scenario_quarterly_comparison"].set_index("quarter")
    screen = t["macro_screen"]
    # Check the monthly observations and forecast paths reported in the data quality table.
    valid_pair = np.isfinite(monthly[["Other_Month_Actual_num", "Card_Month_Actual_num"]]).all(axis=1)
    monthly = monthly.loc[q.index[0].asfreq("M", "start"):q.index[-1].asfreq("M", "end")]
    counts = monthly.groupby(monthly.index.asfreq("Q")).size().reindex(q.index)
    if not counts.eq(3).all() or not valid_pair.loc[monthly.index].all():
        raise ValueError("Expected three complete monthly expense pairs in every modeled quarter.")
    if not scenarios[["s1_status", "s4_status"]].eq("available").all().all():
        raise ValueError("The MDD scenario exhibits require complete Treasury paths.")
    before, after = q.loc["2018Q4"], q.loc["2019Q1"]
    asset_direction = "rose" if after.average_assets_usd > before.average_assets_usd else "fell" if after.average_assets_usd < before.average_assets_usd else "were unchanged"
    rate_direction = "declined" if after.expense_ratio_bp < before.expense_ratio_bp else "rose" if after.expense_ratio_bp > before.expense_ratio_bp else "was unchanged"
    peaks = t["peak_month_adjustments"]
    if set(peaks.month.astype(str)) != set(PEAK_MONTHS):
        raise ValueError("Adjustment records and designated dates differ.")
    for r in peaks.itertuples():
        if not np.isclose((r.prior_net_usd + r.next_net_usd) / 2, r.replacement_usd, rtol=0, atol=.001):
            raise ValueError(f"Missing or inconsistent neighbors for {r.month}.")
    check = [
        ["Review Area", "Assessment Performed", "Result"],
        ["Completeness", "Checked monthly Other and Card amounts and quarterly average assets.",
         f"All {len(monthly)} monthly pairs and all {len(q)} asset balances are present."],
        ["Consistency", "Checked dates, numeric fields, signed Card amounts and asset denominators.",
         "Dates are unique within each input file. Each asset denominator is positive."],
        ["Time-series alignment", "Aligned quarterly macroeconomic variables and lags with the target. Checked S1 and S4 coverage.",
         f"All {len(screen)} candidate series cover the {len(q)} target quarters. Both Treasury paths cover the nine forecast quarters."],
        ["Trend reasonableness", "Reviewed the quarterly expense ratio around the FCB acquisition.",
         f"Average assets {asset_direction} in 2019Q1 and the adjusted expense ratio {rate_direction}."],
        ["Data preparation", "Reviewed the inputs to each monthly adjustment and the quarterly aggregation.",
         "Each designated month has an original net expense value on both sides. Each quarterly total uses three monthly amounts."],
        ["Outlier review", "Reviewed the five months with documented one-time items.",
         "All five months remain in the history. Each uses the mean of its two original neighboring net expenses."],
    ]
    descriptions = [f"{len(monthly)} raw Other and signed Card pairs", f"{len(q)} SNV average asset balances",
                    f"{len(MACROS)} macro series in source levels", "S1 future macro levels", "S4 Treasury levels, first nine used"]
    inventory = [["File", "Coverage", "Use"]]
    for (name, frame), description in zip(inputs.items(), descriptions):
        inventory.append([name + ".csv", span(frame.index), description])
    return {"4.4": check, "11.2": inventory}


def build_tables(data_dir, results, fits):
    # These exhibits document the v21 specification. A change of selected variables requires new labels and definitions.
    if set(fits) != {TREASURY} or list(fits[TREASURY]["development"].params.index) != [*BASE, TREASURY]:
        raise ValueError("The selected equation differs from the v21 Treasury specification. Review the MDD exhibit definitions.")
    tables = MDD_TABLE_TEXT.copy()
    tables.update(regression_tables(fits[TREASURY]))
    tables.update(screening_tables(results))
    tables.update(expense_tables(results))
    tables.update(input_tables(data_dir, results))
    return tables

# MDD figures

def time_series(ax, labels, series, ylabel, step=1, merger_index=None):
    labels = list(map(str, labels))
    for i, (name, values) in enumerate(series):
        ax.plot(range(len(labels)), values, label=name, color=["#275575", "#ac642e"][i],
                linestyle=["-", "--"][i], marker="o" if len(labels) < 15 else None,
                markersize=3, lw=1.7)
    ticks = list(range(0, len(labels), step))
    ax.set_xticks(ticks, [labels[j] for j in ticks], fontsize=8)
    ax.set_ylabel(ylabel, fontsize=9)
    if merger_index is not None:
        ax.axvline(merger_index - .5, color="#666", ls=":", lw=1)


def diagnostic_plot(output, number, draw, height=2.55):
    fig = Figure(figsize=(6.45, height))
    FigureCanvasAgg(fig)
    ax = fig.subplots()
    draw(ax)
    ax.tick_params(axis="both", labelsize=8)
    ax.grid(axis="y", color="#dedede", lw=.5)
    ax.spines[["top", "right"]].set_visible(False)
    handles, names = ax.get_legend_handles_labels()
    if names:
        ax.legend(fontsize=8, frameon=False, ncol=min(3, len(names)), loc="best")
    fig.tight_layout(pad=.65)
    fig.savefig(output / f"figure_{number}.png", dpi=220)


def forward_plot(output, number, quarters, curves, ylabel="Quarterly expense ratio (bp)"):
    fig = Figure(figsize=(6.45, 2.55))
    FigureCanvasAgg(fig)
    ax = fig.subplots()
    for label, values, color, style, marker in curves:
        ax.plot(range(len(quarters)), values, label=label, color=color, ls=style, lw=1.4, marker=marker, ms=3)
    ax.set_xticks(range(len(quarters)), list(map(str, quarters)), fontsize=8)
    ax.set_ylabel(ylabel, fontsize=9)
    ax.tick_params(axis="y", labelsize=8)
    ax.spines[["top", "right"]].set_visible(False)
    ax.grid(axis="y", color="#dfdfdf", lw=.5)
    ax.legend(fontsize=8, frameon=False, ncol=len(curves), loc="upper center", bbox_to_anchor=(.5, 1.28))
    fig.subplots_adjust(left=.1, right=.98, bottom=.15, top=.77)
    fig.savefig(output / f"figure_{number}.png", dpi=240)


def draw_figures(output, fit, results):
    dev = fit["development"]
    train = fit["design"].loc[dev.resid.index]
    fitted = dev.predict(train)
    res = dev.resid
    diagnostic_plot(output, "6_1", lambda ax: time_series(
        ax, train.index, [("Actual adjusted ratio", train[TARGET]), ("Fitted ratio", fitted)],
        "Quarterly ratio (bp)", 8, list(train.index.astype(str)).index("2019Q1")))
    diagnostic_plot(output, "6_2", lambda ax: time_series(
        ax, train.index, [("Actual less fitted", res)], "Residual (bp)", 8))

    def fitted_scatter(ax):
        ax.scatter(fitted, res, s=17, color="#2c607a")
        ax.axhline(0, color="#786b61", lw=.85)
        ax.set_xlabel("Fitted expense ratio (bp)", fontsize=9)
        ax.set_ylabel("Residual (bp)", fontsize=9)

    def normal_plot(ax):
        (theoretical, ordered), (slope, intercept, _) = stats.probplot(np.asarray(res), dist="norm")
        ax.scatter(theoretical, ordered, s=15, color="#2c607a")
        ax.plot(theoretical, intercept + slope * theoretical, color="#a35d31", lw=1)
        ax.set_xlabel("Standard normal quantile", fontsize=9)
        ax.set_ylabel("Ordered residual (bp)", fontsize=9)

    diagnostic_plot(output, "6_3", fitted_scatter, 2.45)
    diagnostic_plot(output, "6_4", normal_plot, 2.45)
    oot = results["backtest_by_quarter"]
    diagnostic_plot(output, "6_5", lambda ax: time_series(
        ax, oot.quarter, [("Actual adjusted ratio", oot.actual_bp), ("Frozen forecast", oot.predicted_bp)],
        "Quarterly ratio (bp)"))
    scenario = results["scenario_quarterly_comparison"]
    forward_plot(output, "6_6A", scenario.quarter, [
        ("S1 baseline", scenario.s1_driver_level, "#275575", "-", "o"),
        ("S4 downside", scenario.s4_driver_level, "#a9652c", "--", "s"),
    ], ylabel="10-year Treasury yield (%)")
    forward_plot(output, "6_6B", scenario.quarter, [
        ("S1 baseline", scenario.s1_expense_ratio_bp, "#275575", "-", "o"),
        ("S4 downside", scenario.s4_expense_ratio_bp, "#a9652c", "--", "s"),
    ])
    curves = [("S1 baseline", scenario.s1_expense_ratio_bp, "#172e40", "-", "o")]
    paths = results["treasury_sensitivity_quarterly"]
    for shock, color, style in [(-15, "#a2551c", "-"), (-5, "#c98952", "--"),
                                (5, "#568493", "--"), (15, "#2e6378", "-")]:
        path = paths.loc[paths.shock_bp == shock].set_index("quarter").loc[scenario.quarter]
        curves.append((f"{shock:+d} bp", path.shocked_expense_ratio_bp, color, style, ""))
    forward_plot(output, "6_7", scenario.quarter, curves)

# Output files and command-line entry point

def write_csv(filename, rows):
    with filename.open("w", encoding="utf-8-sig", newline="") as handle:
        csv.writer(handle).writerows(rows)


def write_exhibits(folder, data_dir):
    results, fits = estimate_other(data_dir)
    tables = build_tables(data_dir, results, fits)
    combined = combined_baseline(data_dir, results["scenario_quarterly_comparison"])
    write_csv(folder / "baseline_expense_forecasts.csv", combined)
    draw_figures(folder, fits[TREASURY], results)
    for name, detail in results.items():
        detail.to_csv(folder / (name + ".csv"), index=False)
    plot_sensitivity(results["treasury_sensitivity_quarterly"], folder)
    detail_files = sorted(file.name for file in folder.iterdir() if not file.name.startswith("figure_"))
    index = [["Type", "Number", "Title", "File"]]
    for kind, number, title in EXHIBIT_TITLES:
        stem = kind.lower() + "_" + number.replace(".", "_")
        if kind == "Table":
            filename = stem + ".csv"
            write_csv(folder / filename, tables.pop(number))
        else:
            filename = stem + ".png"
            if not (folder / filename).is_file():
                raise ValueError(f"Figure {number} is missing.")
        index.append([kind, number, title, filename])
    if tables:
        raise ValueError(f"Missing captions for tables {list(tables)}")
    index.extend([["Model detail", "", name.rsplit(".", 1)[0], name] for name in detail_files])
    write_csv(folder / "index.csv", index)


def obsolete_exhibits(output_dir, current_names):
    """Identify retired, numbered files listed in this output directory's previous MDD index."""
    index = output_dir / "index.csv"
    if not index.is_file() or index.is_symlink():
        return []
    retired = []
    with index.open(encoding="utf-8-sig", newline="") as handle:
        for row in csv.DictReader(handle):
            kind, number = row.get("Type"), row.get("Number") or ""
            if kind not in ("Table", "Figure") or not re.fullmatch(r"[0-9]+\.[0-9]+[A-Z]?", number):
                continue
            suffix = ".csv" if kind == "Table" else ".png"
            name = kind.lower() + "_" + number.replace(".", "_") + suffix
            if row.get("File") == name and name not in current_names:
                target = output_dir / name
                if target.is_file() and not target.is_symlink():
                    retired.append(target)
    return sorted(set(retired))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-dir", type=Path, default=ROOT / "input")
    parser.add_argument("--output-dir", type=Path, default=ROOT / "output")
    args = parser.parse_args()
    data_dir, dest = args.data_dir.resolve(), args.output_dir.resolve()
    if data_dir == dest or dest in data_dir.parents or data_dir in dest.parents:
        parser.error("Input and output need separate directories.")
    dest.parent.mkdir(parents=True, exist_ok=True)
    # Finish all calculations before refreshing the named output files. Preserve unrelated files.
    with TemporaryDirectory(dir=dest.parent, prefix=".noncomp-") as tmp:
        stage = Path(tmp)
        write_exhibits(stage, data_dir)
        dest.mkdir(exist_ok=True)
        files = sorted(stage.iterdir(), key=lambda f: (f.name == "index.csv", f.name))
        for file in files:
            if (dest / file.name).is_dir():
                raise IsADirectoryError(dest / file.name)
        # Restore existing files if publishing fails partway through.
        backup = stage / "previous"
        backup.mkdir()
        saved, installed = [], []
        retired = obsolete_exhibits(dest, {file.name for file in files})
        try:
            for target in retired:
                target.replace(backup / target.name)
                saved.append(target.name)
            for file in files:
                target = dest / file.name
                if target.exists() or target.is_symlink():
                    target.replace(backup / file.name)
                    saved.append(file.name)
                file.replace(target)
                installed.append(target)
        except OSError:
            for target in reversed(installed):
                target.unlink()
            for name in saved:
                (backup / name).replace(dest / name)
            raise
    print(f"Saved {len(files)} files in {dest}. Open index.csv for the file list.")


if __name__ == "__main__":
    main()
