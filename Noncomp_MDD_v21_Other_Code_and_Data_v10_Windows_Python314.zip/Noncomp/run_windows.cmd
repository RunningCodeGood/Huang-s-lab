@echo off
setlocal
pushd "%~dp0" || exit /b 1
if exist ".venv314\Scripts\python.exe" goto check_env

py -3.14 -c "import sys" >nul 2>&1
if errorlevel 1 goto use_python
py -3.14 -m venv ".venv314"
if errorlevel 1 goto failed
goto check_env

:use_python
python -c "import sys; sys.exit(sys.version_info[:2] != (3, 14))" >nul 2>&1
if errorlevel 1 (
    echo Python 3.14 was not found. Open a terminal where your Python 3.14 interpreter is on PATH and run this launcher again.
    goto failed
)
python -m venv ".venv314"
if errorlevel 1 goto failed

:check_env
".venv314\Scripts\python.exe" -c "import sys, sysconfig; print(sys.version); sys.exit(sys.version_info[:2] != (3, 14) or sysconfig.get_platform() != 'win-amd64' or str(sysconfig.get_config_var('Py_GIL_DISABLED')) == '1')"
if errorlevel 1 (
    echo Use standard 64-bit Windows x86-64 Python 3.14 with this package.
    goto failed
)
if exist "wheels\" (
    ".venv314\Scripts\python.exe" -m pip --disable-pip-version-check install --no-index --find-links ".\wheels" -r "requirements.txt"
) else (
    ".venv314\Scripts\python.exe" -m pip --disable-pip-version-check install --only-binary=:all: -r "requirements.txt"
)
if errorlevel 1 goto failed
".venv314\Scripts\python.exe" -X faulthandler "noncomp.py"
if errorlevel 1 goto failed
echo Open the output folder to view the results.
popd
pause
exit /b 0

:failed
echo Run stopped. See the message above.
popd
pause
exit /b 1
