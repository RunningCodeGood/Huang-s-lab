# Noncomp expense model

Open `noncomp.py` in Positron, select your Python 3.14.5 session and run the whole file. The script reads the six CSV files in `data/` and writes the Other expense tables, figures and forecast results to `results/` next to the script. You can run it from any working directory.

Open `results/index.csv` for the file list. Table and figure filenames follow the numbering in MDD v21. Table 6.4 and Figure 6.6B show the nine quarterly S1 and S4 Other expense ratio forecasts. Figure 6.6A shows the corresponding Treasury yield paths. Running the script again refreshes the outputs.

## Data

| File in data/ | Use |
| --- | --- |
| expense_history.csv | Monthly Other and signed Card expense. |
| asset_history.csv | Historical quarterly average asset balances. |
| macro_history.csv | Historical levels of the 15 macroeconomic series. |
| macro_baseline.csv | S1 baseline macroeconomic levels. |
| macro_s4.csv | S4 10-year Treasury yield path. |
| occupancy_baseline.csv | Quarterly baseline assets and Occupancy expense. The asset balance is the mean of the three monthly asset forecasts in the same quarter. |

Occupancy expense is modeled in the accompanying `data/ooc_updated1.xls` workbook. The report `data/Occupancy_Cost(1).docx` describes the approach. The Python script uses the quarterly figures supplied in `occupancy_baseline.csv` for the combined baseline forecast.

## Python packages

The tested environment uses NumPy 2.3.5, pandas 2.3.3, Matplotlib 3.11.2, SciPy 1.16.3 and statsmodels 0.14.6. If these packages need to be installed, run the following once in the Positron Python Console and restart that Python session before running the file.

```text
%pip install numpy==2.3.5 pandas==2.3.3 matplotlib==3.11.2 scipy==1.16.3 statsmodels==0.14.6
```
