# Quarterly OREO Rate Model

This package reproduces the five-page English OREO rate evaluation. Every run builds the quarterly target from monthly observations, screens the macro series, estimates the regression, fits 20 rolling windows and evaluates nine held-out quarters. The published study retained the macro model as a research candidate because its holdout forecasts underperformed the last-observation benchmark.

## Run

Use Python 3.9 or later and R with `Rscript` on the system path. The Python command uses only the standard library. The R engine uses the same statistical packages as the original analysis. The reference environment was R 4.5.2 with urca 1.3-4, lmtest 0.9-40, sandwich 3.1-1 and tseries 0.10-59.

```sh
Rscript -e 'install.packages(c("urca","lmtest","sandwich","tseries"), repos="https://cloud.r-project.org")'
python3 oreo_rate_model.py
```

The command runs offline once the packages are installed. Input and output paths default to `data/` and `results/` beside the script. To run from another working directory or test revised inputs with the same schema and dates:

```sh
python3 /path/to/oreo_rate_model.py --data-dir /path/to/data --output-dir /path/to/new_results
```

Use a new or empty output directory. Input files are read-only. Estimates, selected terms, diagnostics and predictions are generated at runtime.

## Input files

| File | Rows | Contents |
| --- | ---: | --- |
| `data/oreo_mgt_history.csv` | 180 months | Month-end ISO date, signed OREO monthly flow and positive MGT balance, January 2011 to December 2025 |
| `data/macro_history.csv` | 60 quarters | Quarter-end ISO date and the 20 macro levels identified by the original mnemonics, 2011 Q1 to 2025 Q4 |
| `data/macro_dictionary.csv` | 20 series | Mnemonic, description, source unit and adjustment |

OREO and MGT retain the source amount units. The macro observations come from the checked August 2026 baseline workbook. The study uses the 60 quarters shared by target and macro data. Forecast scoring is conditional on this historical macro path, including revisions available in that vintage.

## Model and estimation

- Annualized quarterly rate in basis points: `120000 * sum(monthly OREO) / sum(monthly MGT)`. The primary target is the arithmetic change in this rate from the previous quarter. Negative rates are retained.
- Test target and macro stationarity over 2011 Q1–2023 Q3 and, separately, 2018 Q1–2023 Q3. ADF uses a constant and AIC lag selection up to four quarters. KPSS uses a constant and bandwidth four. Eligibility requires ADF p < 0.05 and KPSS at or below its 5% critical value. For percentage series, prefer levels, then first differences. For the others, prefer levels, quarterly log growth, then first differences. Log growth is 100 times the quarterly log difference.
- Estimate the primary model over the common 39 quarters from 2014 Q1 to 2023 Q3. Hold the intercept and only the first lag of the target change fixed. Test eligible macros at lags 1, 2 and 4. Entry requires a two-sided Student-t p < 0.05, maximum VIF < 10 and DW between 1.5 and 2.5 inclusive. Choose the qualifying term with the lowest p-value, then BIC and term name to break ties. Each series may enter only once. Stop if no term qualifies or three terms have entered.
- Re-estimate the selected model in each rolling window of 20 quarters. Inference checks include HC3, four-lag Newey–West, Holm adjustment at entry and a joint HC3 test with a prespecified 2018 Q1 split.
- Hold coefficients fixed at 2023 Q3. Predict the annualized rate in 2023 Q4–2025 Q4. One-step forecasts can use the previous actual rate. Recursive forecasts update the rate with the model’s own predictions. The pure AR comparator has the same single target lag and estimation dates. Other benchmarks carry the latest observation forward, forecast zero, use the trailing four-quarter mean or reuse the same quarter of the previous year.

## Generated output

| Files | Contents |
| --- | --- |
| `quarterly_panel.csv`, `period_summary.csv` | Quarterly rate reconciliation, macro levels, period means, medians, range and sign counts |
| `stationarity.csv`, `macro_eligibility.csv` | ADF and KPSS results and the transformation selected for each series and period |
| `macro_screening.csv`, `selection_rounds.csv` | Each term tried, lag, coefficient, p-value, DW, VIF, BIC and selection decision |
| `coefficients.csv`, `model_diagnostics.csv` | Final and pure AR estimates, residual and stability diagnostics |
| `rolling_coefficients.csv` | All window dates, coefficients, standard errors and Student-t p-values |
| `inference_sensitivity.csv`, `regime_sensitivity.csv` | Inference and 2018 split results for selected macro terms |
| `holdout_forecasts.csv`, `forecast_accuracy.csv` | Observed, one-step and recursive quarterly paths, MAE, RMSE and signed bias, all in bp |
| `session_info.txt` | Runtime and package versions |

The sensitivity outputs are generated when a macro term enters. The package provides historical validation for the report; the research decision does not support adopting a macro sensitivity for future scenario projections.
