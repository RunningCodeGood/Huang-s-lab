# Statistical engine for oreo_rate_model.py. Arguments: input directory, empty output directory.
suppressPackageStartupMessages({
  library(urca)
  library(lmtest)
  library(sandwich)
  library(tseries)
})
args <- commandArgs(trailingOnly = TRUE)
stopifnot(length(args) == 2)
options(digits = 16)
read_input <- function(file) read.csv(file.path(args[1], file), check.names = FALSE)
write_result <- function(table, name) {
  write.csv(table, file.path(args[2], paste0(name, ".csv")), row.names = FALSE, na = "")
}
lagged <- function(x, k) c(rep(NA_real_, k), head(x, -k))
transform_series <- function(x, name) {
  if (name == "level") return(x)
  if (name == "log1") {
    if (any(x <= 0, na.rm = TRUE)) return(rep(NA_real_, length(x)))
    x <- 100 * log(x)
  }
  x - lagged(x, if (name == "d4") 4 else 1)
}
monthly <- read_input("oreo_mgt_history.csv")
macro <- read_input("macro_history.csv")
dict <- read_input("macro_dictionary.csv")
codes <- dict$mnemonic
stopifnot(nrow(monthly) == 180, nrow(macro) == 60, length(codes) == 20,
          identical(names(macro), c("date", codes)), !anyDuplicated(codes),
          all(is.finite(as.matrix(monthly[, c("oreo", "mgt")]))), all(monthly$mgt > 0),
          all(is.finite(as.matrix(macro[, codes]))))
expected_dates <- seq(as.Date("2011-02-01"), by = "month", length.out = 180) - 1
stopifnot(identical(as.Date(monthly$date), expected_dates),
          identical(as.Date(macro$date), expected_dates[seq(3, 180, 3)]))
quarter <- paste0(format(expected_dates, "%Y"), "Q", (as.integer(format(expected_dates, "%m")) - 1) %/% 3 + 1)
panel <- aggregate(monthly[, c("oreo", "mgt")], list(quarter = quarter), sum)
names(panel)[2:3] <- c("oreo_quarter_sum", "mgt_quarter_sum")
panel$mgt_monthly_mean <- panel$mgt_quarter_sum / 3
panel$rate_bp <- 120000 * panel$oreo_quarter_sum / panel$mgt_quarter_sum
y <- panel$rate_bp
delta <- transform_series(y, "d1")
dates <- panel$quarter
dev <- which(dates <= "2023Q3")
fit_idx <- which(dates >= "2014Q1" & dates <= "2023Q3")
holdout <- which(dates >= "2023Q4")
stopifnot(length(dev) == 51, length(fit_idx) == 39, length(holdout) == 9)
write_result(cbind(panel, macro[, codes]), "quarterly_panel")
periods <- list(before_2018 = 1:28, from_2018 = 29:60, holdout = holdout)
write_result(do.call(rbind, lapply(names(periods), function(k) {
  ii <- periods[[k]]
  data.frame(period=k, quarters=length(ii), mean_bp=mean(y[ii]), median_bp=median(y[ii]),
             min_bp=min(y[ii]), max_bp=max(y[ii]), negative_quarters=sum(y[ii]<0),
             mean_oreo_quarter=mean(panel$oreo_quarter_sum[ii]), mean_monthly_mgt=mean(panel$mgt_monthly_mean[ii]))
})), "period_summary")

stationarity <- function(x, period, code, transform) {
  z <- na.omit(transform_series(x, transform))
  row <- data.frame(period, code, transform, n=length(z), adf_lag=NA_integer_, adf=NA_real_,
                    adf_p=NA_real_, kpss=NA_real_, kpss_cv=NA_real_, eligible=FALSE)
  if (!length(z) || diff(range(z)) == 0) return(row)
  a <- ur.df(z, type="drift", lags=4, selectlags="AIC")
  k <- ur.kpss(z, type="mu", use.lag=4)
  row$adf <- a@teststat[1]
  row$adf_lag <- sum(startsWith(rownames(coef(a@testreg)), "z.diff.lag"))
  row$adf_p <- punitroot(row$adf, trend="c")
  row$kpss <- k@teststat[1]
  row$kpss_cv <- k@cval[1, "5pct"]
  row$eligible <- row$adf_p < .05 && row$kpss <= row$kpss_cv
  row
}
series <- c(list(rate_bp=y), as.list(macro[, codes]))
test_periods <- list(full=dev, low=dev[dates[dev] >= "2018Q1"])
tests <- list()
for (period in names(test_periods)) {
  for (code in names(series)) {
    kinds <- if (code == "rate_bp") c("level","d1","d4") else c("level","d1","log1")
    for (kind in kinds) tests[[length(tests)+1L]] <- stationarity(
      series[[code]][test_periods[[period]]], period, code, kind)
  }
}
tests <- do.call(rbind, tests)
write_result(tests, "stationarity")
eligibility <- do.call(rbind, lapply(names(test_periods), function(period) {
  do.call(rbind, lapply(codes, function(code) {
    unit <- dict$unit[match(code, codes)]
    priority <- if (unit %in% c("Percent","Net percent")) c("level","d1") else c("level","log1","d1")
    ok <- tests$transform[tests$code == code & tests$period == period & tests$eligible]
    data.frame(period, code, transform=intersect(priority,ok)[1])
  }))
}))
write_result(eligibility,"macro_eligibility")

# Only eligible in-sample macro transforms are allowed to enter the price/credit screen.
features <- data.frame(quarter=dates, target=delta, ar1=lagged(delta,1))
meta <- list()
for (i in which(eligibility$period == "full" & !is.na(eligibility$transform))) {
  code <- eligibility$code[i]
  kind <- eligibility$transform[i]
  x <- transform_series(macro[[code]],kind)
  for (lag in c(1,2,4)) {
    name <- paste(code,kind,paste0("L",lag),sep="__")
    features[[name]] <- lagged(x,lag)
    meta[[name]] <- data.frame(name,code,kind,lag)
  }
}
regress <- function(terms, ii=fit_idx) {
  lm(reformulate(c("ar1",terms), response="target"), data=features[ii,], na.action=na.fail)
}
diagnostics <- function(model) {
  x <- model.matrix(model)[,-1,drop=FALSE]
  e <- residuals(model)
  ar_radius <- abs(unname(coef(model)["ar1"]))
  data.frame(n=nobs(model), adj_r2=summary(model)$adj.r.squared, bic=BIC(model),
             dw=sum(diff(e)^2)/sum(e^2), max_vif=max(diag(solve(cor(x)))),
             ar_radius=ar_radius, bg4_p=bgtest(model,order=4)$p.value,
             bp_p=bptest(model)$p.value, jb_p=jarque.bera.test(e)$p.value)
}
selected <- character()
trials <- list()
rounds <- list()
for (round in 1:3) {
  used <- vapply(meta[selected], function(z) z$code, character(1))
  candidates <- names(Filter(function(z) !z$code %in% used, meta))
  if (!length(candidates)) break
  rows <- do.call(rbind, lapply(candidates, function(name) {
    model <- regress(c(selected,name))
    co <- coef(summary(model))[name,]
    stats <- diagnostics(model)
    p <- unname(co[4])
    data.frame(round=round, meta[[name]], estimate=unname(co[1]), p_student_t=p, stats,
               passed=p < .05 && stats$max_vif < 10 && stats$dw >= 1.5 && stats$dw <= 2.5)
  }))
  ok <- rows[rows$passed,,drop=FALSE]
  winner <- if (nrow(ok)) ok$name[order(ok$p_student_t,ok$bic,ok$name)[1]] else ""
  rows$entered <- rows$name == winner
  trials[[round]] <- rows
  rounds[[round]] <- data.frame(round, tested=nrow(rows), passed=nrow(ok), entered=winner)
  if (winner == "") break
  selected <- c(selected,winner)
}
if(length(trials)) write_result(do.call(rbind,trials), "macro_screening")
if(length(rounds)) write_result(do.call(rbind,rounds), "selection_rounds")
models <- list(pure_ar=regress(character()),selected=regress(selected))
write_result(do.call(rbind,lapply(names(models),function(k) cbind(model=k,diagnostics(models[[k]])))),
             "model_diagnostics")
coefficient_table <- function(model) {
  tab <- coef(summary(model))
  data.frame(term=rownames(tab), estimate=tab[,1], std_error=tab[,2],
             p_student_t=tab[,4], row.names=NULL)
}
write_result(do.call(rbind,lapply(names(models),function(k) cbind(model=k,coefficient_table(models[[k]])))),
             "coefficients")

rolling <- lapply(seq_len(length(fit_idx)-19), function(i) {
  ii <- fit_idx[i:(i+19)]
  cbind(window=i, first=dates[min(ii)], last=dates[max(ii)], coefficient_table(regress(selected,ii)))
})
write_result(do.call(rbind,rolling),"rolling_coefficients")
if (length(selected)) {
  final <- models$selected
  hc3 <- coeftest(final, vcov.=vcovHC(final,type="HC3"))
  hac <- coeftest(final, vcov.=NeweyWest(final,lag=4,prewhite=FALSE,adjust=TRUE))
  sensitivity <- do.call(rbind,lapply(seq_along(selected),function(i) {
    term <- selected[i]
    round <- trials[[i]]
    data.frame(term, p_ols=coef(summary(final))[term,4], p_hc3=hc3[term,4], p_hac4=hac[term,4],
               p_holm_entry_round=p.adjust(round$p_student_t,"holm")[round$name==term])
  }))
  write_result(sensitivity,"inference_sensitivity")
  split_data <- features[fit_idx,,drop=FALSE]
  split_data$late <- as.integer(split_data$quarter >= "2018Q1")
  interacting <- paste(c("ar1",selected),collapse="+")
  split_model <- lm(as.formula(paste0("target~(",interacting,")*late")),data=split_data)
  b <- coef(split_model)
  j <- grep("late",names(b))
  V <- vcovHC(split_model,type="HC3")[j,j,drop=FALSE]
  wald <- drop(crossprod(b[j],solve(V,b[j])))
  write_result(data.frame(term=selected, early_slope=b[selected],
               late_slope=b[selected]+b[paste0(selected,":late")], joint_wald=wald,
               df=length(j), joint_p=pchisq(wald,length(j),lower.tail=FALSE)), "regime_sensitivity")
}

forecast_path <- function(model, terms, recursive) {
  history <- y
  history[holdout] <- NA_real_
  out <- numeric(length(holdout))
  for (j in seq_along(holdout)) {
    t <- holdout[j]
    x <- c(1,history[t-1]-history[t-2],
           as.numeric(features[t,terms,drop=TRUE]))
    out[j] <- history[t-1]+sum(coef(model)*x)
    history[t] <- if (recursive) out[j] else y[t]
  }
  out
}
path <- function(k,one,recursive) data.frame(model=k,quarter=dates[holdout],
                                           actual_bp=y[holdout],one_step=one,recursive)
pred <- lapply(names(models), function(k) {
  terms <- if(k=="selected") selected else character()
  path(k, forecast_path(models[[k]],terms,FALSE), forecast_path(models[[k]],terms,TRUE))
})
origin <- max(dev)
pred <- do.call(rbind,c(pred,list(
  path("last_observation",y[holdout-1],y[origin]),
  path("zero",0,0),
  path("trailing_four_mean",sapply(holdout,function(t)mean(y[(t-4):(t-1)])),mean(y[(origin-3):origin])),
  path("same_quarter_last_year",y[holdout-4],rep(y[(origin-3):origin],length.out=length(holdout)))
)))
scores <- do.call(rbind,lapply(split(pred,pred$model),function(p){
  do.call(rbind,lapply(c("one_step","recursive"),function(method){
    e <- p[[method]]-p$actual_bp
    data.frame(model=p$model[1],method,mae_bp=mean(abs(e)),rmse_bp=sqrt(mean(e^2)),bias_bp=mean(e))
  }))
}))
stopifnot(!anyNA(scores), all(abs(pred$one_step[pred$quarter==dates[holdout[1]]]-
                                 pred$recursive[pred$quarter==dates[holdout[1]]])<1e-8))
write_result(pred,"holdout_forecasts")
write_result(scores,"forecast_accuracy")
capture.output(sessionInfo(),file=file.path(args[2],"session_info.txt"))
