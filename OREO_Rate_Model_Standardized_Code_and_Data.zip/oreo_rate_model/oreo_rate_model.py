#!/usr/bin/env python3
"""Reproduce the quarterly OREO research report from the packaged CSV inputs."""
import argparse
import csv
import os
from pathlib import Path
import shutil
import subprocess
from tempfile import TemporaryDirectory

ROOT = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-dir", type=Path, default=ROOT / "data")
    parser.add_argument("--output-dir", type=Path, default=ROOT / "results")
    args = parser.parse_args()
    data_dir, output_dir = args.data_dir.resolve(), args.output_dir.resolve()
    if output_dir.exists() and (not output_dir.is_dir() or any(output_dir.iterdir())):
        parser.error("--output-dir must be new or empty")
    for name in ("oreo_mgt_history.csv", "macro_history.csv", "macro_dictionary.csv"):
        if not (data_dir / name).is_file():
            parser.error(f"missing input: {data_dir / name}")
    runner = shutil.which("Rscript")
    if not runner:
        parser.error("Rscript is required; see README.md for installation")
    output_dir.parent.mkdir(parents=True, exist_ok=True)
    with TemporaryDirectory(prefix=".oreo-", dir=output_dir.parent) as temp:
        stage = Path(temp) / "results"
        stage.mkdir()
        subprocess.run([runner, "--vanilla", str(ROOT / "estimate.R"),
                        str(data_dir), str(stage)], check=True)
        # Rename the complete run only after the estimation and checks succeed.
        os.replace(stage, output_dir)
    with (output_dir / "forecast_accuracy.csv").open() as stream:
        for row in csv.DictReader(stream):
            if row["model"] in {"selected", "last_observation"}:
                print(f'{row["model"]:18} {row["method"]:10} MAE {float(row["mae_bp"]):.2f} bp')
    print(f"Results: {output_dir}")


if __name__ == "__main__":
    main()
