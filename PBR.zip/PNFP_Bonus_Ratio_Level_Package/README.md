# PNFP bonus ratio level model research

English report, analytical inputs and replication code. Edition: October 9, 2026.

Every experiment models the **bonus ratio in levels**, `R = bonus / (compensation - bonus)`, estimated as `y = 100 * R`. The quantitative approach was **not adopted**; the assessment has moved to documented qualitative judgment. This archive retains favorable and unfavorable evidence. It is not a production model or an approved forecast.

## Run the three segments

Use Python 3.12. From this extracted directory:

```sh
python3.12 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python run_all.py
```

On Windows, activate with `.venv\Scripts\activate`. Dependencies are not bundled. Installation requires access to the Python package index. After dependencies are installed, no Excel installation, online data download or user-specific file path is required. The scripts resolve all inputs relative to their own location.

To run separately, use this order:

```sh
python segment1_prepare_data.py
python segment2_models.py
python segment3_diagnostics.py
```

| Segment | Contents |
|---|---|
| 1 | Quarterly input checks, ratio-level target, macro transformations and ADF/KPSS tests |
| 2 | Core ARDLs with and without HY, alternative forward-selection starts, no-dummy sensitivity and lagged bonus-growth challenger |
| 3 | 20/24/28-quarter rolling coefficients, archived nine-quarter S4 recursion and numerical replication checks |

Runs overwrite generated files only under `results/`. The input data, archived references and report are not changed. A successful full run ends with `PASS: E02-E08 reproduced.` Earlier evidence IDs are preserved for traceability; only ratio-level experiments are included here.

## Package contents

- `reports/`: English review of the attempted ratio-level approach and rationale for nonadoption.
- `data/`: numerical quarterly inputs, macro catalog, candidate transformation rules and S4 path.
- `code/`: original numerical algorithms adapted to portable inputs and outputs.
- `reference/`: fixed E02-E08 results, original library versions and source-result checksums.
- `results/`: rerun outputs, CSV tables and `replication_validation.json`.
- `manifest.json`: SHA-256 inventory of packaged files, excluding the manifest itself.

The adaptations replace local spreadsheet ingestion and workstation paths with frozen quarterly analytical inputs. Search, estimation, inference and forecasting calculations are retained. Original research files remain unchanged. Models of non-bonus compensation growth or ratio growth are not included. Growth rates may still appear as **explanatory variables**; the dependent variable is always the ratio level.

## Data and units

`quarterly_levels.json` contains 60 consecutive quarters, 2011Q1-2025Q4, with compensation, bonus and 22 macro variables. Compensation and bonus retain a common source monetary unit, which cancels in the ratio. The pipeline recomputes non-bonus compensation and the ratio from these two inputs. Quarterly values are used directly, without rounding, imputation, annualization or further averaging.

`macro_catalog.json` supplies English names, mnemonics, units and descriptions. HY remains in the inventory and in the historical HY comparison. `transform_rules.json` contains candidate forms and their priority: `level` preserves source units, `loglevel` takes natural logs, `diff1` is a one-quarter point change, and `dlog1`/`dlog4` are 100 times the one-/four-quarter log change. Macro-family eligibility follows the first passing form in the archived priority order.

`s4_unemployment.json` contains the January 2026 FLBR_S4.IUSA scenario in percent for 2026Q1-2028Q1. Segment 1 writes `quarterly_levels.csv`, `transformed_features.csv` and `stationarity.csv` to `results/` for convenient inspection. JSON and CSV numerical values retain double precision.

## Model settings and evidence

### E02 and E03 Core models

The common model sample is 2012Q2-2025Q4: 43 training observations through 2022Q4 and 12 holdout observations. The 55-observation full refit is not new independent validation. Models have an intercept, one target lag and one-quarter macro lags. The default dummy equals 1 in 2020Q1-2021Q1 and 0 otherwise. No acquisition dummy or pre/post-acquisition sample split is used.

Stationarity screening uses only training data: ADF with a constant, maximum lag 4 and AIC selection; KPSS with a constant and automatic bandwidth. Both ADF p < 0.05 and KPSS p > 0.05 are required. Forward entry requires added-term OLS p < 0.05, maximum VIF < 10, DW between 1.5 and 2.5, and JB p > 0.05. At most two macro terms enter. The procedure does not perform backward deletion or exhaustive subset search. HAC results use Bartlett weights, four lags, finite-sample correction and t inference.

Unemployment enters in levels. HY passed initial forward entry and improved fit and holdout errors, but was not retained following the rolling-significance review. Both specifications remain in this archive. Lagged bonus growth is an explanatory-variable challenger, not a separate target. Nominal p-values are not adjusted for model selection or repeated comparisons.

Frozen one-step forecasts use the observed prior-quarter target. Frozen recursive forecasts use the preceding forecast. Expanding forecasts re-estimate using data available up to the preceding quarter. All holdout exercises condition on realized macro paths, rather than real-time macro forecasts.

### E04 and E05 Alternative starts and dummy sensitivity

With the default dummy, four first-round candidates passed: unemployment level, finance and insurance employment growth, financial-activities hourly earnings growth, and bank asset growth. Each is followed as a separate seed, including attempts to add another macro. The resulting two-macro models are not all statistically admissible.

The no-dummy version retains pandemic observations. Only unemployment passes its original first-round gates; other starting variables are forced sensitivity branches. This is distinct from deleting pandemic response quarters. Pandemic-deletion tests preserve calendar lags and reduce the sample; they do not establish that macro effects are absent.

### E06 and E07 Rolling coefficients

Fixed structures are re-estimated over 20-, 24- and 28-quarter windows, moving one quarter at a time across the full modeling period, including the original holdout. OLS and HAC significance are reported separately. Overlapping windows are dependent. No minimum significant-window share was prescribed in advance, and low local significance is not a formal rejection of coefficient stability. Windows with a constant-zero dummy omit that unidentifiable regressor.

### E08 Archived S4 recursion

Coefficients are frozen on the 43-observation training sample. The recursion initializes at actual 2025Q4 y and unemployment; future D = 0. Because unemployment is lagged one quarter, the 2026Q1 forecast uses 2025Q4 unemployment. The ninth supplied unemployment value affects a quarter beyond this horizon.

The average of nine projected ratios is about 23.1513%; the sum of unscaled R values is about 2.083616. Neither is total bonus or a denominator-weighted aggregate ratio. Bonus amounts require a non-bonus compensation path, which was not supplied. No prediction interval is provided. Historical and scenario vintages are not synchronized, so this is not a contemporaneous real-time forecast record. These projections remain evidence of the attempted approach, not the adopted forecast.

## Verification and interpretation

`verify_results.py` compares rerun coefficients, p-values, model statistics, selected terms, screening flags, rolling records and S4 values to fixed references. It uses absolute tolerance 1e-7 and relative tolerance 1e-8, while dates, labels identifying specifications, flags and record counts must match. Translated descriptive prose is not compared. Independent ARDL/OLS and RollingOLS checks are also embedded in the original algorithms.

Some models have significant coefficients and better historical errors. Nonadoption reflects the combined limitations of economic interpretation, unusual-period dependence, local precision and scenario transferability. A positive unemployment coefficient on a ratio does not show that unemployment causes larger bonus payments. Denominator changes and omitted bank operating factors are hypotheses requiring business evidence.

The qualitative process proposed in the report documents business transmission, pay policy, numerator and denominator paths, scenario judgment and review evidence. It does not invent a replacement numerical forecast.
