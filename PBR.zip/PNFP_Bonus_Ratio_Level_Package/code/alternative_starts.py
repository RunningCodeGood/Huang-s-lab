"""Compare all first-round passers without modifying the production model.

Fixed original sample, transformation choices, lag structure, entry gates and
two-macro cap. Alternative seeds are a sensitivity exercise, not a new search
over transformations, lags or holdout outcomes. All original inputs are read-only.
"""
from pathlib import Path
import ast
import hashlib
import json
import warnings

import numpy as np
import pandas as pd
import statsmodels
import statsmodels.regression.linear_model as sm
from statsmodels.regression.rolling import RollingOLS
from statsmodels.tsa.ardl import ARDL
from statsmodels.stats.stattools import durbin_watson, jarque_bera
from statsmodels.stats.diagnostic import acorr_breusch_godfrey, het_breuschpagan
from statsmodels.stats.outliers_influence import variance_inflation_factor

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / 'results' / 'with_dummy'
OUT.mkdir(parents=True, exist_ok=True)
SOURCE = ROOT / 'results/without_hy/analysis.json'
PRIOR = ROOT / 'results/with_dummy/comparison_results.json'
ENGINE = ROOT / 'code/ratio_helpers.py'
protected = [SOURCE, ENGINE]
hashes_before = {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in protected}
hashes = hashes_before
d = json.loads(SOURCE.read_text())

def frame(rows):
    df = pd.DataFrame(rows).set_index('quarter')
    df.index = pd.PeriodIndex(df.index, freq='Q')
    return df.astype(float)

levels = frame(d['levels'])
features = frame(d['features'])
y = levels.y
assert levels.index.equals(pd.period_range('2011Q1', '2025Q4', freq='Q'))
assert np.allclose(y, 100 * levels.bonus / (levels.comp - levels.bonus))
assert np.array_equal(features.pandemic, ((features.index >= '2020Q1') & (features.index <= '2021Q1')).astype(float))
TRAIN_END = pd.Period('2022Q4', freq='Q')
COMMON_START = pd.Period('2012Q2', freq='Q')
all_ids = y.loc[COMMON_START:].index
train_ids = all_ids[all_ids <= TRAIN_END]
test_ids = all_ids[all_ids > TRAIN_END]
assert (len(all_ids), len(train_ids), len(test_ids)) == (55, 43, 12)
X = features.drop(columns='pandemic').shift(1).rename(columns=lambda c: c + '.L1')
X.insert(0, 'R.L1', y.shift(1))
X.insert(0, 'const', 1.0)
X['pandemic'] = features.pandemic
assert X.loc[all_ids].notna().all().all()
group = next(r for r in d['groups'] if r['scope'] == 'Pandemic dummy')
eligible = [v + '.L1' for v in group['chosen_transforms'].values()]
assert len(eligible) == 17
assert not any('hy_' in s.lower() for s in eligible)
guide = {r['feature']: r for r in d['guide']}

# Verify the stored chosen features against raw quarterly levels independently.
feature_checks = {}
for term in eligible:
    key = term.removesuffix('.L1')
    meta = guide[key]
    v = levels[meta['family']]
    kind = meta['transform']
    if kind == 'level':
        check = v
    elif kind == 'diff1':
        check = v.diff()
    elif kind == 'dlog1':
        check = 100 * np.log(v / v.shift(1))
    else:
        raise AssertionError(f'Unexpected chosen transform: {kind}')
    assert np.allclose(check, features[key], equal_nan=True, atol=1e-12)
    feature_checks[key] = float((check - features[key]).abs().max())

# Load only pure helpers; never execute the old engine's CLI or output blocks.
wanted = {'estimate', 'diagnostics', 'gates', 'add_model'}
tree = ast.parse(ENGINE.read_text())
helpers = ast.Module(body=[n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name in wanted], type_ignores=[])
assert len(helpers.body) == len(wanted)
exec(compile(helpers, str(ENGINE), 'exec'), globals())
models, coefficients, predictions = [], [], []

first_round = [r for r in d['screening'] if r['scope'] == 'Pandemic dummy' and r['round'] == 1]
assert len(first_round) == len(eligible)
replication_errors = []
for row in first_round:
    fit = estimate(train_ids, [row['candidate'], 'pandemic'])
    dg = diagnostics(fit)
    comparisons = [abs(fit.params[row['candidate']] - row['coefficient']),
                   abs(fit.pvalues[row['candidate']] - row['p_student_t'])]
    comparisons += [abs(dg[k] - row[k]) for k in dg if isinstance(dg[k], (int, float))]
    replication_errors.extend(comparisons)
assert max(replication_errors) < 1e-9
passers = sorted([r for r in first_round if r['passes']], key=lambda r: (r['p_student_t'], -r['adj_R2'], r['candidate']))
assert len(passers) == 4
assert set(r['candidate'] for r in passers) == {'unemp_level.L1', 'FE52_B.IUSA_dlog1.L1', 'earnings_dlog1.L1', 'assets_dlog1.L1'}

def display_name(term):
    g = guide[term.removesuffix('.L1')]
    transform = {'level': 'level', 'diff1': 'QoQ difference', 'dlog1': 'QoQ log growth'}[g['transform']]
    return f"{g['name']} | {transform}, lag 1"

registry = {}
def register(macros):
    key = tuple(sorted(macros))
    if key not in registry:
        label = ' + '.join(macros) if macros else 'AR(1) + pandemic benchmark'
        row = add_model(label, 'Pandemic dummy', COMMON_START, macros + ['pandemic'], 'Exploratory comparison; not a replacement selection')
        macro_rows = [c for c in coefficients if c['model'] == label and c['sample'] == 'Train' and c['term'] in macros]
        row['all_macro_OLS_p_below_005'] = all(c['OLS_p'] < .05 for c in macro_rows) if macros else None
        row['all_macro_HAC_p_below_005'] = all(c['HAC_p'] < .05 for c in macro_rows) if macros else None
        row['display_terms'] = [display_name(m) for m in macros]
        registry[key] = label
    return registry[key]

register([])
single_models = {r['candidate']: register([r['candidate']]) for r in passers}
second_round, branches = [], []
for first in passers:
    seed = first['candidate']
    trials = []
    for candidate in eligible:
        if candidate == seed:
            continue
        fit = estimate(train_ids, [seed, candidate, 'pandemic'])
        dg = diagnostics(fit)
        p = float(fit.pvalues[candidate])
        pg = gates(p, dg)
        trials.append(dict(seed=seed, candidate=candidate, coefficient=float(fit.params[candidate]),
                           p_student_t=p, seed_p_after_addition=float(fit.pvalues[seed]),
                           **dg, **pg, passes=all(pg.values())))
    passing = sorted([r for r in trials if r['passes']], key=lambda r: (r['p_student_t'], -r['adj_R2'], r['candidate']))
    added = passing[0]['candidate'] if passing else None
    for row in trials:
        row['chosen'] = row['candidate'] == added
    second_round.extend(trials)
    branches.append(dict(seed=seed, added=added, second_round_pass_count=len(passing),
                         passing_candidates=[r['candidate'] for r in passing],
                         model=register([seed, added] if added else [seed])))
assert len(second_round) == 64

# Evaluate every passing second-round pair, including runners-up, not just the
# greedy winner. This is an explicitly exploratory branching comparison.
passing_pair_models = []
for row in second_round:
    if row['passes']:
        pair_label = register([row['seed'], row['candidate']])
        if pair_label not in passing_pair_models:
            passing_pair_models.append(pair_label)
assert len(passing_pair_models) == 6
assert len(models) == 11  # Four singles, six pairs, one fixed-controls benchmark.

# Frozen original-model replication, including all three holdout forecast modes.
original = next(m for m in d['models'] if m['model'] == 'Covid macro ARDL')
replica = next(m for m in models if m['model'] == single_models['unemp_level.L1'])
for key in ['one_step_RMSE', 'recursive_RMSE', 'expanding_RMSE']:
    assert abs(original[key] - replica[key]) < 1e-10

rolling_records, rolling_summary, pandemic_robustness, independent_checks = [], [], [], []
for model in models:
    label = model['model']
    macros = [t for t in model['terms'] if t != 'pandemic']
    cols = ['const', 'R.L1'] + model['terms']
    xx = X.loc[all_ids, cols]
    yy = y.loc[all_ids]
    np_coef = np.linalg.lstsq(X.loc[train_ids, cols].to_numpy(), y.loc[train_ids].to_numpy(), rcond=None)[0]
    fit_train = estimate(train_ids, model['terms'])
    delta = float(np.max(np.abs(np_coef - fit_train.params.to_numpy())))
    assert delta < 1e-9
    independent_checks.append(dict(model=label, numpy_lstsq_max_difference=delta, ARDL_match=True))

    # Remove response quarters only; keep true calendar lags instead of collapsing time.
    no_pandemic_ids = train_ids[X.loc[train_ids, 'pandemic'] == 0]
    assert len(no_pandemic_ids) == 38
    fit_non = estimate(no_pandemic_ids, macros)
    # Gap-sensitive deletion is a descriptive OLS sensitivity check, not a HAC result.
    pandemic_robustness.append(dict(model=label, n=38, adj_R2=float(fit_non.rsquared_adj),
        coefficients=[dict(term=t, coefficient=float(fit_non.params[t]), OLS_p=float(fit_non.pvalues[t])) for t in macros]))
    if not macros:
        continue
    for w in [20, 24, 28]:
        ro = RollingOLS(yy, xx, window=w, min_nobs=w).fit(method='pinv', params_only=True)
        rz = RollingOLS(yy, xx.drop(columns='pandemic'), window=w, min_nobs=w).fit(method='pinv', params_only=True)
        checks = []
        for end in range(w - 1, len(xx)):
            xw = xx.iloc[end - w + 1:end + 1].copy()
            yw = yy.iloc[end - w + 1:end + 1]
            n_dummy = int(xw.pandemic.sum())
            if n_dummy == 0:
                xw = xw.drop(columns='pandemic')
            assert np.linalg.matrix_rank(xw) == xw.shape[1]
            f = sm.OLS(yw, xw).fit()
            h = f.get_robustcov_results(cov_type='HAC', maxlags=4, kernel='bartlett', use_correction=True, use_t=True)
            alt = ro if n_dummy else rz
            delta = float(np.max(np.abs(f.params - alt.params.loc[xw.index[-1], xw.columns])))
            assert delta < 1e-8
            checks.append(delta)
            for term in macros:
                j = xw.columns.get_loc(term)
                rolling_records.append(dict(model=label, window=w, start=str(xw.index[0]), end=str(xw.index[-1]),
                    dummy_n=n_dummy, term=term, coefficient=float(f.params[term]),
                    OLS_p=float(f.pvalues[term]), HAC_p=float(h.pvalues[j]),
                    HAC_low=float(h.conf_int()[j, 0]), HAC_high=float(h.conf_int()[j, 1])))
        independent_checks.append(dict(model=label, window=w, n_fits=len(checks), RollingOLS_max_difference=max(checks)))
        for term in macros:
            rows = [r for r in rolling_records if r['model'] == label and r['window'] == w and r['term'] == term]
            rolling_summary.append(dict(model=label, window=w, term=term, n_windows=len(rows),
                positive=sum(r['coefficient'] > 0 for r in rows), negative=sum(r['coefficient'] < 0 for r in rows),
                OLS_significant=sum(r['OLS_p'] < .05 for r in rows), HAC_significant=sum(r['HAC_p'] < .05 for r in rows),
                min_coefficient=min(r['coefficient'] for r in rows), max_coefficient=max(r['coefficient'] for r in rows),
                latest_coefficient=rows[-1]['coefficient'], latest_OLS_p=rows[-1]['OLS_p'], latest_HAC_p=rows[-1]['HAC_p']))

# Global fixed-design controls and source protection checks.
assert all('pandemic' in m['terms'] and m['train']['n'] == 43 and m['full']['n'] == 55 for m in models)
assert all(hashlib.sha256(p.read_bytes()).hexdigest() == hashes_before[str(p.relative_to(ROOT))] for p in protected)
result = dict(
    settings=dict(target='100 * Bonus / (Compensation - Bonus)', units='percentage points',
        train_start=str(COMMON_START), train_end=str(TRAIN_END), train_n=43,
        holdout_start=str(test_ids[0]), holdout_end=str(test_ids[-1]), holdout_n=12,
        own_lags=[1], macro_lags=[1], max_macros=2, dummy_start='2020Q1', dummy_end='2021Q1',
        dummy_fixed=True, HY_excluded_from_model=True, transform_selection='Original training-only prespecified first-passing forms',
        entry_gates='Added term OLS Student-t p<0.05; max VIF<10; 1.5<=DW<=2.5; JB p>0.05',
        forward_ranking='Smallest added-term p, then largest adjusted R2, then candidate name',
        backward_deletion=False, HAC='Bartlett, 4 lags, finite-sample correction, t inference',
        rolling_windows=[20, 24, 28], rolling_step=1,
        holdout_macro_values='Realized lagged macros; conditional evaluation, not ex-ante macro forecasts',
        selection_warning='Exploratory seed sensitivity; nominal p-values and rolling intervals are not selection/multiplicity adjusted; overlapping windows',
        replacement_model_selected=False, current_report_unchanged=True),
    source_sha256=hashes_before, versions=dict(numpy=np.__version__, pandas=pd.__version__, statsmodels=statsmodels.__version__),
    first_round=first_round, passing_seeds=[r['candidate'] for r in passers], single_models=single_models,
    second_round=second_round, branches=branches, passing_pair_models=passing_pair_models,
    models=models, coefficients=coefficients,
    predictions=predictions, rolling_summary=rolling_summary, rolling_records=rolling_records,
    pandemic_removal= pandemic_robustness,
    verification=dict(first_round_max_difference=max(replication_errors), feature_checks=feature_checks,
        independent_checks=independent_checks, original_model_reproduced=True, protected_sources_unchanged=True))
(OUT / 'comparison_results.json').write_text(json.dumps(result, indent=2, allow_nan=False))
print('Completed with_dummy alternatives.')
