"""Remove the pandemic regressor, retain all dates, compare unchanged designs.

The original report/model are read-only. Reproduce all 17 first-round tests,
then inspect all four previous seeds. Seeds that no longer pass are labeled
forced sensitivity checks, not valid new forward-selection paths.
"""
from pathlib import Path
import ast
import hashlib
import json
import warnings

import numpy as np
import pandas as pd
import statsmodels
import statsmodels.regression.linear_model as sm
from statsmodels.regression.rolling import RollingOLS
from statsmodels.tsa.ardl import ARDL
from statsmodels.stats.stattools import durbin_watson, jarque_bera
from statsmodels.stats.diagnostic import acorr_breusch_godfrey, het_breuschpagan
from statsmodels.stats.outliers_influence import variance_inflation_factor

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / 'results' / 'without_dummy'
OUT.mkdir(parents=True, exist_ok=True)
SOURCE = ROOT / 'results/without_hy/analysis.json'
PRIOR = ROOT / 'results/with_dummy/comparison_results.json'
ENGINE = ROOT / 'code/ratio_helpers.py'
protected = [SOURCE, ENGINE]
hashes_before = {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in protected}
hashes = hashes_before
d = json.loads(SOURCE.read_text())
prior = json.loads(PRIOR.read_text())

def frame(rows):
    f = pd.DataFrame(rows).set_index('quarter')
    f.index = pd.PeriodIndex(f.index, freq='Q')
    return f.astype(float)

levels, features = frame(d['levels']), frame(d['features'])
y = levels.y
assert np.allclose(y, 100 * levels.bonus / (levels.comp - levels.bonus))
assert levels.index.equals(pd.period_range('2011Q1', '2025Q4', freq='Q'))
TRAIN_END, COMMON_START = pd.Period('2022Q4', freq='Q'), pd.Period('2012Q2', freq='Q')
all_ids = y.loc[COMMON_START:].index
train_ids = all_ids[all_ids <= TRAIN_END]
test_ids = all_ids[all_ids > TRAIN_END]
assert (len(all_ids), len(train_ids), len(test_ids)) == (55, 43, 12)
assert features.loc[train_ids, 'pandemic'].sum() == 5
X = features.drop(columns='pandemic').shift(1).rename(columns=lambda c: c + '.L1')
X.insert(0, 'R.L1', y.shift(1))
X.insert(0, 'const', 1.0)
assert X.loc[all_ids].notna().all().all()
assert 'pandemic' not in X.columns
group = next(g for g in d['groups'] if g['scope'] == 'No dummy')
eligible = [v + '.L1' for v in group['chosen_transforms'].values()]
assert len(eligible) == 17 and not any('hy_' in v.lower() for v in eligible)
assert group['chosen_transforms'] == next(g for g in d['groups'] if g['scope'] == 'Pandemic dummy')['chosen_transforms']
guide = {r['feature']: r for r in d['guide']}
for term in eligible:
    meta = guide[term.removesuffix('.L1')]
    v = levels[meta['family']]
    transformed = v if meta['transform'] == 'level' else (v.diff() if meta['transform'] == 'diff1' else 100*np.log(v/v.shift(1)))
    assert np.allclose(transformed, features[meta['feature']], equal_nan=True, atol=1e-12)

wanted = {'estimate', 'diagnostics', 'gates', 'add_model'}
tree = ast.parse(ENGINE.read_text())
helpers = ast.Module(body=[n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name in wanted], type_ignores=[])
assert len(helpers.body) == len(wanted)
exec(compile(helpers, str(ENGINE), 'exec'), globals())
models, coefficients, predictions = [], [], []

first_round = []
replication_errors = []
for term in eligible:
    fit = estimate(train_ids, [term])
    dg = diagnostics(fit)
    p = float(fit.pvalues[term])
    pg = gates(p, dg)
    row = dict(candidate=term, coefficient=float(fit.params[term]), p_student_t=p, **dg, **pg, passes=all(pg.values()))
    first_round.append(row)
    original = next(r for r in d['screening'] if r['scope']=='No dummy' and r['round']==1 and r['candidate']==term)
    replication_errors.extend(abs(row[k] - original[k]) for k in row if isinstance(row[k], (int, float)))
assert max(replication_errors) < 1e-10
first_passers = sorted([r for r in first_round if r['passes']], key=lambda r: (r['p_student_t'], -r['adj_R2'], r['candidate']))

registry = {}
def register(terms):
    key = tuple(sorted(terms))
    if key not in registry:
        label = ' + '.join(terms) if terms else 'AR(1) benchmark'
        row = add_model(label, 'No dummy', COMMON_START, terms, 'Sensitivity comparison; no production-model replacement')
        cs = [c for c in coefficients if c['model']==label and c['sample']=='Train' and c['term'] in terms]
        row['all_macro_OLS_significant'] = all(c['OLS_p'] < .05 for c in cs) if terms else None
        row['all_macro_HAC_significant'] = all(c['HAC_p'] < .05 for c in cs) if terms else None
        row['residual_gates_pass'] = all(gates(0, row['train']).values())
        registry[key] = label
    return registry[key]

# Exact like-for-like refits of every previously compared structure.
pairwise_matches = []
for old in prior['models']:
    terms = [t for t in old['terms'] if t != 'pandemic']
    pairwise_matches.append(dict(with_dummy_model=old['model'], without_dummy_model=register(terms)))

seeds = list(dict.fromkeys(prior['passing_seeds'] + [r['candidate'] for r in first_passers]))
first_lookup = {r['candidate']: r for r in first_round}
second_round, branches = [], []
for seed in seeds:
    trials = []
    for term in eligible:
        if term == seed:
            continue
        f = estimate(train_ids, [seed, term])
        dg = diagnostics(f)
        p = float(f.pvalues[term])
        pg = gates(p, dg)
        trials.append(dict(seed=seed, seed_passed_first_round=first_lookup[seed]['passes'],
            candidate=term, coefficient=float(f.params[term]), p_student_t=p,
            seed_p_after_addition=float(f.pvalues[seed]), **dg, **pg, passes=all(pg.values())))
    passing = sorted([r for r in trials if r['passes']], key=lambda r: (r['p_student_t'], -r['adj_R2'], r['candidate']))
    winner = passing[0]['candidate'] if passing else None
    for r in trials:
        r['chosen'] = r['candidate'] == winner
        if r['passes']:
            register([seed, r['candidate']])
    second_round.extend(trials)
    branches.append(dict(seed=seed, seed_passed_first_round=first_lookup[seed]['passes'], added=winner,
        passing_candidates=[r['candidate'] for r in passing],
        interpretation='Valid no-dummy forward path' if first_lookup[seed]['passes'] else 'Forced seed sensitivity only; seed failed first round',
        model=register([seed, winner] if winner else [seed])))

main_label = register(group['selected'])
main = next(m for m in models if m['model'] == main_label)
reference = next(m for m in d['models'] if m['model'] == 'NoD macro ARDL')
for k in ['one_step_RMSE', 'recursive_RMSE', 'expanding_RMSE']:
    assert abs(main[k] - reference[k]) < 1e-10

rolling_records, rolling_summary, verification = [], [], []
for m in models:
    terms, label = m['terms'], m['model']
    xx = X.loc[all_ids, ['const', 'R.L1'] + terms]
    yy = y.loc[all_ids]
    f = estimate(train_ids, terms)
    alt = np.linalg.lstsq(xx.loc[train_ids].to_numpy(), yy.loc[train_ids].to_numpy(), rcond=None)[0]
    delta = float(np.max(np.abs(alt - f.params.to_numpy())))
    assert delta < 1e-9
    verification.append(dict(model=label, numpy_lstsq_difference=delta, ARDL_match=True))
    if not terms:
        continue
    for w in [20, 24, 28]:
        ro = RollingOLS(yy, xx, window=w, min_nobs=w).fit(method='pinv', params_only=True)
        differences = []
        for end in range(w - 1, len(xx)):
            xw, yw = xx.iloc[end-w+1:end+1], yy.iloc[end-w+1:end+1]
            f = sm.OLS(yw, xw).fit()
            h = f.get_robustcov_results(cov_type='HAC', maxlags=4, kernel='bartlett', use_correction=True, use_t=True)
            delta = float(np.max(np.abs(f.params - ro.params.loc[xw.index[-1]])))
            assert delta < 1e-8
            differences.append(delta)
            for term in terms:
                j = xw.columns.get_loc(term)
                rolling_records.append(dict(model=label, window=w, start=str(xw.index[0]), end=str(xw.index[-1]),
                    term=term, coefficient=float(f.params[term]), OLS_p=float(f.pvalues[term]), HAC_p=float(h.pvalues[j]),
                    HAC_low=float(h.conf_int()[j, 0]), HAC_high=float(h.conf_int()[j, 1])))
        verification.append(dict(model=label, window=w, n_fits=len(differences), RollingOLS_difference=max(differences)))
        for term in terms:
            rr = [r for r in rolling_records if r['model']==label and r['window']==w and r['term']==term]
            rolling_summary.append(dict(model=label, term=term, window=w, n_windows=len(rr),
                positive=sum(r['coefficient']>0 for r in rr), negative=sum(r['coefficient']<0 for r in rr),
                OLS_significant=sum(r['OLS_p']<.05 for r in rr), HAC_significant=sum(r['HAC_p']<.05 for r in rr),
                min_coefficient=min(r['coefficient'] for r in rr), max_coefficient=max(r['coefficient'] for r in rr),
                latest_coefficient=rr[-1]['coefficient'], latest_OLS_p=rr[-1]['OLS_p'], latest_HAC_p=rr[-1]['HAC_p']))

matched_comparison = []
for pair in pairwise_matches:
    old = next(m for m in prior['models'] if m['model']==pair['with_dummy_model'])
    new = next(m for m in models if m['model']==pair['without_dummy_model'])
    metrics = ['one_step_RMSE', 'one_step_MAE', 'recursive_RMSE', 'expanding_RMSE']
    matched_comparison.append(dict(**pair, terms=new['terms'],
        with_dummy=dict(adj_R2=old['train']['adj_R2'], **{k:old[k] for k in metrics}),
        without_dummy=dict(adj_R2=new['train']['adj_R2'], **{k:new[k] for k in metrics})))

# Exact nesting check: dummy's two-sided OLS t-test equals the one-restriction F-test.
main_terms = group['selected']
x_full = X.loc[train_ids, ['const', 'R.L1']+main_terms].copy()
x_full['pandemic'] = features.loc[train_ids, 'pandemic']
fit_d = sm.OLS(y.loc[train_ids], x_full).fit()
fit_n = estimate(train_ids, main_terms)
F, F_p, df_diff = fit_d.compare_f_test(fit_n)
assert abs(F_p - fit_d.pvalues['pandemic']) < 1e-12
nested_dummy_test = dict(F=float(F), p=float(F_p), df_difference=int(df_diff))
assert all('pandemic' not in m['terms'] and m['train']['n']==43 and m['full']['n']==55 for m in models)
assert all(hashlib.sha256(p.read_bytes()).hexdigest()==hashes[str(p.relative_to(ROOT))] for p in protected)
result = dict(settings=dict(target='100*Bonus/(Compensation-Bonus)', units='percentage points',
    train_start=str(COMMON_START), train_end=str(TRAIN_END), train_n=43,
    holdout_start=str(test_ids[0]), holdout_end=str(test_ids[-1]), holdout_n=12,
    pandemic_observations_retained=True, dummy_included=False, macro_lag=1, own_lag=1,
    max_macros=2, eligible_macros=17, HY_excluded=True, transformations_unchanged=True,
    HAC='Bartlett, 4 lags, finite correction, t inference', rolling_windows=[20,24,28],
    no_selection_or_multiplicity_adjustment=True, forecasts_conditional_on_realized_macros=True,
    current_report_unchanged=True, production_model_unchanged=True),
    source_sha256=hashes, versions=dict(numpy=np.__version__, pandas=pd.__version__, statsmodels=statsmodels.__version__),
    first_round=first_round, first_round_passers=[r['candidate'] for r in first_passers],
    second_round=second_round, branches=branches, models=models, coefficients=coefficients, predictions=predictions,
    rolling_summary=rolling_summary, rolling_records=rolling_records,
    matched_comparison=matched_comparison, nested_dummy_test=nested_dummy_test,
    verification=dict(first_round_max_difference=max(replication_errors), models=verification,
                      original_no_dummy_model_reproduced=True, protected_sources_unchanged=True))
(OUT/'comparison_results.json').write_text(json.dumps(result, indent=2, allow_nan=False))
print('Completed without_dummy alternatives.')
