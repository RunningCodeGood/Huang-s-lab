"""Numerical helpers retained from the original ratio experiments."""
from pathlib import Path
import json, warnings, argparse
import numpy as np
import pandas as pd
import scipy, statsmodels
import statsmodels.regression.linear_model as sm
from scipy.stats import norm
from statsmodels.tsa.ardl import ARDL
from statsmodels.tsa.stattools import adfuller, kpss
from statsmodels.stats.stattools import durbin_watson, jarque_bera
from statsmodels.stats.diagnostic import acorr_breusch_godfrey, het_breuschpagan
from statsmodels.stats.outliers_influence import variance_inflation_factor

def transform(x,kind):
    if kind=='level': return x
    if kind=='diff1': return x.diff()
    assert (x.dropna()>0).all(), 'Nonpositive log input'
    if kind=='loglevel': return np.log(x)
    return 100*np.log(x/x.shift(1 if kind=='dlog1' else 4))

def stationarity(x):
    x=x.dropna()
    with warnings.catch_warnings(record=True) as ws:
        warnings.simplefilter('always')
        a=adfuller(x,maxlag=4,regression='c',autolag='AIC',result_object=False)
        k=kpss(x,regression='c',nlags='auto',result_object=False)
    bound='>0.10' if k[1]==.1 else '<0.01' if k[1]==.01 else 'exact within table'
    return dict(n=len(x),ADF_stat=float(a[0]),ADF_p=float(a[1]),ADF_lags=int(a[2]),ADF_n=int(a[3]),
                KPSS_stat=float(k[0]),KPSS_p=float(k[1]),KPSS_lags=int(k[2]),KPSS_bound=bound,
                stationary=bool(a[1]<.05 and k[1]>.05))

def estimate(ids,extra):
    xx=X.loc[ids,['const','R.L1']+extra]
    assert np.isfinite(xx).all().all() and np.linalg.matrix_rank(xx)==xx.shape[1]
    return sm.OLS(y.loc[ids],xx,missing='raise').fit()

def diagnostics(fit):
    x=fit.model.exog
    vf=[variance_inflation_factor(x,j) for j in range(1,x.shape[1])]
    jb=jarque_bera(fit.resid)
    bg1=acorr_breusch_godfrey(fit,nlags=1,result_object=False)
    bg4=acorr_breusch_godfrey(fit,nlags=4,result_object=False)
    bp=het_breuschpagan(fit.resid,x)
    phi=float(fit.params['R.L1'])
    return dict(n=int(fit.nobs),k=x.shape[1],df_resid=int(fit.df_resid),R2=float(fit.rsquared),
                adj_R2=float(fit.rsquared_adj),AIC=float(fit.aic),BIC=float(fit.bic),
                DW=float(durbin_watson(fit.resid)),JB_stat=float(jb[0]),JB_p=float(jb[1]),
                max_VIF=float(max(vf)),BG1_LM_p=float(bg1[1]),BG1_F_p=float(bg1[3]),
                BG4_LM_p=float(bg4[1]),BG4_F_p=float(bg4[3]),BP_p=float(bp[1]),
                phi=phi,AR_stable=abs(phi)<1)

def gates(p,d):
    return dict(p_gate=bool(p<.05),VIF_gate=bool(d['max_VIF']<10),
                DW_gate=bool(1.5<=d['DW']<=2.5),JB_gate=bool(d['JB_p']>.05))

def add_model(label,scope,start,extra,eligibility):
    train_ids=all_ids[(all_ids>=start)&(all_ids<=TRAIN_END)]
    full_ids=all_ids[all_ids>=start]
    test_ids=all_ids[all_ids>TRAIN_END]
    train=estimate(train_ids,extra)
    full=estimate(full_ids,extra)
    ds=diagnostics(train); df=diagnostics(full)
    # Independent implementation check against statsmodels ARDL, same dates and regressors.
    raw_features=[term.removesuffix('.L1') for term in extra if term!='pandemic']
    idx=pd.period_range(start-1,TRAIN_END,freq='Q')
    with warnings.catch_warnings():
        warnings.simplefilter('ignore')
        fixed=X.loc[idx,['pandemic']] if 'pandemic' in extra else None
        if raw_features:
            check=ARDL(y.loc[idx],lags=1,exog=features.loc[idx,raw_features],
                       order={v:[1] for v in raw_features},fixed=fixed,causal=True,hold_back=1,trend='c').fit()
        else:
            check=ARDL(y.loc[idx],lags=1,fixed=fixed,hold_back=1,trend='c').fit()
    assert np.allclose(check.params.to_numpy(),train.params.to_numpy(),rtol=1e-10,atol=1e-10)
    one=[]; recursive=[]; rolling=[]
    previous=float(y.loc[TRAIN_END])
    for t in test_ids:
        xx=X.loc[t,train.params.index].copy()
        one.append(float(xx@train.params))
        xx['R.L1']=previous
        previous=float(xx@train.params)
        recursive.append(previous)
        expanding_ids=full_ids[full_ids<t]
        refit=estimate(expanding_ids,extra)
        rolling.append(float(X.loc[t,refit.params.index]@refit.params))
    actual=y.loc[test_ids].to_numpy()
    metrics={}
    for key,pred in [('one_step',one),('recursive',recursive),('expanding',rolling)]:
        err=actual-np.array(pred)
        metrics[key+'_RMSE']=float(np.sqrt(np.mean(err**2)))
        metrics[key+'_MAE']=float(np.mean(np.abs(err)))
    row=dict(model=label,scope=scope,start=str(start),train_end=str(TRAIN_END),terms=extra,
             eligibility=eligibility,train=ds,full=df,**metrics)
    models.append(row)
    for span,fit in [('Train',train),('Full refit',full)]:
        robust=fit.get_robustcov_results(cov_type='HAC',maxlags=4,use_correction=True,use_t=True)
        ci=robust.conf_int()
        for j,term in enumerate(fit.params.index):
            coefficients.append(dict(model=label,sample=span,term=term,coefficient=float(fit.params.iloc[j]),
                                     OLS_SE=float(fit.bse.iloc[j]),OLS_p=float(fit.pvalues.iloc[j]),
                                     HAC_SE=float(robust.bse[j]),HAC_p=float(robust.pvalues[j]),
                                     CI_low=float(ci[j,0]),CI_high=float(ci[j,1])))
    for i,t in enumerate(test_ids):
        predictions.append(dict(model=label,quarter=str(t),actual=float(actual[i]),
                                one_step=one[i],recursive=recursive[i],expanding=rolling[i]))
    return row

def records(frame):
    return [dict(quarter=str(idx),**{k:float(v) if pd.notna(v) else None for k,v in row.items()}) for idx,row in frame.iterrows()]
