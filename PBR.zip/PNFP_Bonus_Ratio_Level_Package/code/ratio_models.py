"""Original ratio selection logic with portable prepared-data input."""
from pathlib import Path
import json, warnings, argparse
import numpy as np
import pandas as pd
import scipy, statsmodels
import statsmodels.regression.linear_model as sm
from scipy.stats import norm
from statsmodels.tsa.ardl import ARDL
from statsmodels.tsa.stattools import adfuller, kpss
from statsmodels.stats.stattools import durbin_watson, jarque_bera
from statsmodels.stats.diagnostic import acorr_breusch_godfrey, het_breuschpagan
from statsmodels.stats.outliers_influence import variance_inflation_factor

def transform(x,kind):
    if kind=='level': return x
    if kind=='diff1': return x.diff()
    assert (x.dropna()>0).all(), 'Nonpositive log input'
    if kind=='loglevel': return np.log(x)
    return 100*np.log(x/x.shift(1 if kind=='dlog1' else 4))

def stationarity(x):
    x=x.dropna()
    with warnings.catch_warnings(record=True) as ws:
        warnings.simplefilter('always')
        a=adfuller(x,maxlag=4,regression='c',autolag='AIC',result_object=False)
        k=kpss(x,regression='c',nlags='auto',result_object=False)
    bound='>0.10' if k[1]==.1 else '<0.01' if k[1]==.01 else 'exact within table'
    return dict(n=len(x),ADF_stat=float(a[0]),ADF_p=float(a[1]),ADF_lags=int(a[2]),ADF_n=int(a[3]),
                KPSS_stat=float(k[0]),KPSS_p=float(k[1]),KPSS_lags=int(k[2]),KPSS_bound=bound,
                stationary=bool(a[1]<.05 and k[1]>.05))

def estimate(ids,extra):
    xx=X.loc[ids,['const','R.L1']+extra]
    assert np.isfinite(xx).all().all() and np.linalg.matrix_rank(xx)==xx.shape[1]
    return sm.OLS(y.loc[ids],xx,missing='raise').fit()

def diagnostics(fit):
    x=fit.model.exog
    vf=[variance_inflation_factor(x,j) for j in range(1,x.shape[1])]
    jb=jarque_bera(fit.resid)
    bg1=acorr_breusch_godfrey(fit,nlags=1,result_object=False)
    bg4=acorr_breusch_godfrey(fit,nlags=4,result_object=False)
    bp=het_breuschpagan(fit.resid,x)
    phi=float(fit.params['R.L1'])
    return dict(n=int(fit.nobs),k=x.shape[1],df_resid=int(fit.df_resid),R2=float(fit.rsquared),
                adj_R2=float(fit.rsquared_adj),AIC=float(fit.aic),BIC=float(fit.bic),
                DW=float(durbin_watson(fit.resid)),JB_stat=float(jb[0]),JB_p=float(jb[1]),
                max_VIF=float(max(vf)),BG1_LM_p=float(bg1[1]),BG1_F_p=float(bg1[3]),
                BG4_LM_p=float(bg4[1]),BG4_F_p=float(bg4[3]),BP_p=float(bp[1]),
                phi=phi,AR_stable=abs(phi)<1)

def gates(p,d):
    return dict(p_gate=bool(p<.05),VIF_gate=bool(d['max_VIF']<10),
                DW_gate=bool(1.5<=d['DW']<=2.5),JB_gate=bool(d['JB_p']>.05))

def add_model(label,scope,start,extra,eligibility):
    train_ids=all_ids[(all_ids>=start)&(all_ids<=TRAIN_END)]
    full_ids=all_ids[all_ids>=start]
    test_ids=all_ids[all_ids>TRAIN_END]
    train=estimate(train_ids,extra)
    full=estimate(full_ids,extra)
    ds=diagnostics(train); df=diagnostics(full)
    # Independent implementation check against statsmodels ARDL, same dates and regressors.
    raw_features=[term.removesuffix('.L1') for term in extra if term!='pandemic']
    idx=pd.period_range(start-1,TRAIN_END,freq='Q')
    with warnings.catch_warnings():
        warnings.simplefilter('ignore')
        fixed=X.loc[idx,['pandemic']] if 'pandemic' in extra else None
        if raw_features:
            check=ARDL(y.loc[idx],lags=1,exog=features.loc[idx,raw_features],
                       order={v:[1] for v in raw_features},fixed=fixed,causal=True,hold_back=1,trend='c').fit()
        else:
            check=ARDL(y.loc[idx],lags=1,fixed=fixed,hold_back=1,trend='c').fit()
    assert np.allclose(check.params.to_numpy(),train.params.to_numpy(),rtol=1e-10,atol=1e-10)
    one=[]; recursive=[]; rolling=[]
    previous=float(y.loc[TRAIN_END])
    for t in test_ids:
        xx=X.loc[t,train.params.index].copy()
        one.append(float(xx@train.params))
        xx['R.L1']=previous
        previous=float(xx@train.params)
        recursive.append(previous)
        expanding_ids=full_ids[full_ids<t]
        refit=estimate(expanding_ids,extra)
        rolling.append(float(X.loc[t,refit.params.index]@refit.params))
    actual=y.loc[test_ids].to_numpy()
    metrics={}
    for key,pred in [('one_step',one),('recursive',recursive),('expanding',rolling)]:
        err=actual-np.array(pred)
        metrics[key+'_RMSE']=float(np.sqrt(np.mean(err**2)))
        metrics[key+'_MAE']=float(np.mean(np.abs(err)))
    row=dict(model=label,scope=scope,start=str(start),train_end=str(TRAIN_END),terms=extra,
             eligibility=eligibility,train=ds,full=df,**metrics)
    models.append(row)
    for span,fit in [('Train',train),('Full refit',full)]:
        robust=fit.get_robustcov_results(cov_type='HAC',maxlags=4,use_correction=True,use_t=True)
        ci=robust.conf_int()
        for j,term in enumerate(fit.params.index):
            coefficients.append(dict(model=label,sample=span,term=term,coefficient=float(fit.params.iloc[j]),
                                     OLS_SE=float(fit.bse.iloc[j]),OLS_p=float(fit.pvalues.iloc[j]),
                                     HAC_SE=float(robust.bse[j]),HAC_p=float(robust.pvalues[j]),
                                     CI_low=float(ci[j,0]),CI_high=float(ci[j,1])))
    for i,t in enumerate(test_ids):
        predictions.append(dict(model=label,quarter=str(t),actual=float(actual[i]),
                                one_step=one[i],recursive=recursive[i],expanding=rolling[i]))
    return row

def records(frame):
    return [dict(quarter=str(idx),**{k:float(v) if pd.notna(v) else None for k,v in row.items()}) for idx,row in frame.iterrows()]

ROOT=Path(__file__).resolve().parent.parent
parser=argparse.ArgumentParser();parser.add_argument('--with-hy',action='store_true');args=parser.parse_args()
OUT=ROOT/'results'/('with_hy' if args.with_hy else 'without_hy');OUT.mkdir(parents=True,exist_ok=True)
prepared=json.loads((ROOT/'results/prepared.json').read_text())
def frame(rows):
    f=pd.DataFrame(rows).set_index('quarter');f.index=pd.PeriodIndex(f.index,freq='Q');return f.astype(float)
levels=frame(prepared['levels']);features=frame(prepared['features']).drop(columns='pandemic')
feature_meta=[g for g in prepared['guide'] if args.with_hy or g['family']!='hy']
features=features[[g['feature'] for g in feature_meta]]
if not args.with_hy:levels=levels.drop(columns='hy')
TRAIN_END=pd.Period('2022Q4');COMMON_START=pd.Period('2012Q2')
PANDEMIC_START=pd.Period('2020Q1');PANDEMIC_END=pd.Period('2021Q1');PANDEMIC_N=5
BONUS='bonus_dlog4'
X=features.shift(1).rename(columns=lambda c:c+'.L1')
y=levels.y;X.insert(0,'R.L1',y.shift(1));X.insert(0,'const',1.0)
X['pandemic']=((X.index>=PANDEMIC_START)&(X.index<=PANDEMIC_END)).astype(float)
all_ids=y.loc[COMMON_START:].index
stationarity_rows=[];trial_rows=[];models=[];coefficients=[];predictions=[];groups=[]

for scope,controls in [('No dummy',[]),('Pandemic dummy',['pandemic'])]:
    start=COMMON_START
    train_ids=all_ids[(all_ids>=start)&(all_ids<=TRAIN_END)]
    target_test=stationarity(y.loc[train_ids])
    scope_tests=[dict(scope='Unified sample',feature='R',family='target',name='Bonus / non-bonus compensation',
                                  transform='ratio',start=str(start),end=str(TRAIN_END),chosen=False,
                                  reason='Target diagnostic',**target_test)]
    eligible=[]; transform_picks={}
    for meta in feature_meta:
        key=meta['feature']; term=key+'.L1'
        t=stationarity(X.loc[train_ids,term])
        row=dict(scope='Unified sample',feature=key,family=meta['family'],name=meta['name'],transform=meta['transform'],
                 start=str(start-1),end=str(TRAIN_END-1),chosen=False,reason='',**t)
        if meta['family']=='bonus':
            row['reason']='Bonus challenge only' if t['stationary'] else 'Bonus challenge: stationarity gate failed'
        elif not t['stationary']:
            row['reason']='ADF/KPSS joint gate failed'
        elif meta['family'] in transform_picks:
            row['reason']='Earlier preferred transform already passed'
        else:
            row['chosen']=True
            row['reason']='First passing transform in prespecified order'
            transform_picks[meta['family']]=key
            eligible.append(term)
        scope_tests.append(row)
    if not controls:
        stationarity_rows.extend(scope_tests)
    remaining=eligible.copy(); selected=[]; round_no=1
    while remaining and len(selected)<2:
        current=[]
        for candidate in remaining:
            fit=estimate(train_ids,selected+[candidate]+controls)
            dg=diagnostics(fit)
            p=float(fit.pvalues[candidate]); pg=gates(p,dg)
            row=dict(scope=scope,round=round_no,candidate=candidate,existing='; '.join(selected),
                     coefficient=float(fit.params[candidate]),p_student_t=p,
                     p_normal=float(2*norm.sf(abs(fit.tvalues[candidate]))),**dg,**pg,
                     passes=all(pg.values()),chosen=False,
                     failed='; '.join(k for k,v in pg.items() if not v))
            current.append(row)
        passing=sorted([r for r in current if r['passes']],key=lambda r:(r['p_student_t'],-r['adj_R2'],r['candidate']))
        winner=passing[0]['candidate'] if passing else None
        for row in current: row['chosen']=row['candidate']==winner
        trial_rows.extend(current)
        if winner is None: break
        selected.append(winner); remaining.remove(winner); round_no+=1
    short='NoD' if not controls else 'Covid'
    ar=add_model(short+' AR benchmark',scope,start,controls,'Benchmark, not a selected macro model')
    fit=estimate(train_ids,selected+controls); dg=diagnostics(fit)
    residual_ok=gates(0,dg)
    macro_accepted=bool(selected and target_test['stationary'] and all(residual_ok.values()) and dg['AR_stable'])
    status='Passes training gates' if macro_accepted else 'No accepted macro model under current rules'
    main=add_model(short+' macro ARDL',scope,start,selected+controls,status)
    bonus_term=BONUS+'.L1'
    bonus_fit=estimate(train_ids,selected+[bonus_term]+controls); bd=diagnostics(bonus_fit)
    bp=float(bonus_fit.pvalues[bonus_term]); bg=gates(bp,bd)
    bs=next(r for r in scope_tests if r['feature']==BONUS)
    bonus_accepted=bool(all(bg.values()) and bs['stationary'] and target_test['stationary'] and bd['AR_stable'])
    bonus=add_model(short+' bonus challenge',scope,start,selected+[bonus_term]+controls,
                    'Passes training gates' if bonus_accepted else 'Challenge only: failed training gates')
    groups.append(dict(scope=scope,start=str(start),train_n=len(train_ids),candidate_transforms=len(feature_meta)-1,
                       controls=controls,
                       stationary_transforms=sum(r['stationary'] for r in scope_tests if r['family'] not in ['target','bonus']),
                       chosen_transforms=transform_picks,eligible_count=len(eligible),selected=selected,
                       macro_accepted=macro_accepted,target_stationary=target_test['stationary'],
                       bonus_accepted=bonus_accepted,bonus_p=bp,bonus_gates=bg,bonus_stationary=bs['stationary']))

test_ids=all_ids[all_ids>TRAIN_END]
benchmarks=[]
for label,pred in [('Persistence',y.shift(1).loc[test_ids]),('Seasonal naive',y.shift(4).loc[test_ids]),
                   ('Training mean',pd.Series(y.loc[COMMON_START:TRAIN_END].mean(),index=test_ids))]:
    err=y.loc[test_ids]-pred
    benchmarks.append(dict(model=label,RMSE=float(np.sqrt(np.mean(err**2))),MAE=float(np.mean(np.abs(err)))))
    for t in test_ids:
        predictions.append(dict(model=label,quarter=str(t),actual=float(y.loc[t]),one_step=float(pred.loc[t]),recursive=None,expanding=None))

# Audit selection dates: no holdout observation enters transformation or term selection.
assert max(all_ids[all_ids<=TRAIN_END])==TRAIN_END
assert all(pd.Period(r['end'])<=TRAIN_END for r in stationarity_rows)
assert all(r['n']==43 for r in trial_rows)
assert X.loc[all_ids[all_ids<=TRAIN_END],'pandemic'].sum()==PANDEMIC_N
assert X.loc[test_ids,'pandemic'].sum()==0

# Fixed-structure, post-hoc robustness checks. Never feed these back into selection.
primary_terms=groups[1]['selected']+['pandemic']
primary_train_ids=all_ids[all_ids<=TRAIN_END]
primary_fit=estimate(primary_train_ids,primary_terms)
influence=primary_fit.get_influence()
influence_rows=[]
for i in np.argsort(influence.cooks_distance[0])[::-1][:8]:
    influence_rows.append(dict(quarter=str(primary_train_ids[i]),Cook_D=float(influence.cooks_distance[0][i]),
                               leverage=float(influence.hat_matrix_diag[i]),
                               student_resid=float(influence.resid_studentized_external[i])))
robustness=[]
for label,mask in [('Exclude dummy quarters',~((primary_train_ids>=PANDEMIC_START)&(primary_train_ids<=PANDEMIC_END))),
                   ('Exclude highest Cook D',primary_train_ids!=pd.Period(influence_rows[0]['quarter']))]:
    ids=primary_train_ids[mask]
    terms=[x for x in primary_terms if x!='pandemic'] if label=='Exclude dummy quarters' else primary_terms
    fit=estimate(ids,terms)
    for term in fit.params.index:
        robustness.append(dict(check=label,n=len(ids),term=term,coefficient=float(fit.params[term]),
                               OLS_p=float(fit.pvalues[term]),note='Fixed structure; classical OLS only. Calendar gaps: no HAC reported.'))
# Separate the effect of adding the fixed dummy from any macro re-selection.
fixed_extra=groups[0]['selected']+['pandemic']
fixed_fit=estimate(primary_train_ids,fixed_extra)
fixed_hac=fixed_fit.get_robustcov_results(cov_type='HAC',maxlags=4,use_correction=True,use_t=True)
dummy_j=list(fixed_fit.params.index).index('pandemic')
dummy_comparison=dict(same_macro_set=set(groups[0]['selected'])==set(groups[1]['selected']),
                      fixed_macro_terms=groups[0]['selected'],
                      coefficient=float(fixed_fit.params['pandemic']),OLS_p=float(fixed_fit.pvalues['pandemic']),
                      HAC_p=float(fixed_hac.pvalues[dummy_j]),BIC=float(fixed_fit.bic))


result=dict(levels=records(levels),features=records(features.assign(pandemic=X.pandemic)),guide=feature_meta,
stationarity=stationarity_rows,screening=trial_rows,groups=groups,models=models,coefficients=coefficients,
predictions=predictions,benchmarks=benchmarks,influence=influence_rows,robustness=robustness,dummy_comparison=dummy_comparison)
(OUT/'analysis.json').write_text(json.dumps(result,indent=2,allow_nan=False))
for key in ['stationarity','screening','coefficients','predictions']:
    pd.DataFrame(result[key]).to_csv(OUT/(key+'.csv'),index=False)
print('Ratio experiment complete:',OUT.name)
