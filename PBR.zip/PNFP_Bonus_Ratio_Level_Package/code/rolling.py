"""Fixed-structure rolling coefficient diagnostic; original sources unchanged."""
from pathlib import Path
import json
import argparse
import numpy as np
import pandas as pd
import statsmodels.regression.linear_model as sm
from statsmodels.regression.rolling import RollingOLS
from statsmodels.stats.outliers_influence import variance_inflation_factor

ROOT = Path(__file__).parent
parser=argparse.ArgumentParser()
parser.add_argument('--analysis',type=Path,required=True)
parser.add_argument('--out-dir',type=Path,required=True)
args=parser.parse_args()
args.out_dir.mkdir(parents=True,exist_ok=True)
d = json.loads(args.analysis.read_text())
levels = pd.DataFrame(d['levels']).set_index('quarter')
features = pd.DataFrame(d['features']).set_index('quarter')
x = pd.DataFrame(index=levels.index)
x['const'] = 1.0
x['R.L1'] = levels['y'].shift(1)
primary=next(m for m in d['models'] if m['model']=='Covid macro ARDL')
for term in primary['terms']:
    if term!='pandemic': x[term] = features[term.removesuffix('.L1')].shift(1)
x['pandemic'] = features['pandemic']
x = x.loc['2012Q2':'2025Q4'].astype(float)
y = levels.loc[x.index,'y'].astype(float)
assert len(x)==55 and x.notna().all().all()
assert x['pandemic'].sum()==5
terms = list(x.columns)
full = sm.OLS(y,x).fit()
for row in d['coefficients']:
    if row['model']=='Covid macro ARDL' and row['sample']=='Full refit':
        assert abs(full.params[row['term']]-row['coefficient'])<1e-9

records=[]; windows=[]; checks=[]
for w in [20,24,28]:
    # Independent RollingOLS benchmark for periods with identifiable dummy.
    ro = RollingOLS(y,x,window=w,min_nobs=w).fit(method='pinv',params_only=True)
    # Separate no-dummy benchmark for zero-dummy windows.
    rz = RollingOLS(y,x.drop(columns='pandemic'),window=w,min_nobs=w).fit(method='pinv',params_only=True)
    for end in range(w-1,len(x)):
        xx=x.iloc[end-w+1:end+1].copy(); yy=y.iloc[end-w+1:end+1]
        n_dummy=int(xx['pandemic'].sum())
        if xx['pandemic'].nunique()==1:
            assert n_dummy==0
            xx=xx.drop(columns='pandemic')
        assert np.linalg.matrix_rank(xx)==len(xx.columns)
        fit=sm.OLS(yy,xx).fit()
        hac=fit.get_robustcov_results(cov_type='HAC',maxlags=4,kernel='bartlett',use_correction=True,use_t=True)
        ci=hac.conf_int(); ols_ci=fit.conf_int()
        alt=ro if 'pandemic' in xx else rz
        delta=float(np.max(np.abs(fit.params-alt.params.loc[xx.index[-1],xx.columns])))
        assert delta<1e-8
        checks.append(delta)
        maxvif=max(variance_inflation_factor(xx.to_numpy(),j) for j in range(1,len(xx.columns)))
        win=dict(window=w,start=xx.index[0],end=xx.index[-1],n=w,dummy_n=n_dummy,
                 k=len(xx.columns),df_resid=int(fit.df_resid),max_VIF=float(maxvif),
                 max_leverage=float(fit.get_influence().hat_matrix_diag.max()))
        windows.append(win)
        for term in terms:
            if term not in xx:
                records.append(dict(**win,term=term,coefficient=None,OLS_p=None,HAC_p=None,
                    OLS_low=None,OLS_high=None,HAC_low=None,HAC_high=None,status='Not estimable: D is zero throughout window'))
            else:
                j=xx.columns.get_loc(term)
                records.append(dict(**win,term=term,coefficient=float(fit.params[term]),
                    OLS_p=float(fit.pvalues[term]),HAC_p=float(hac.pvalues[j]),
                    OLS_low=float(ols_ci.loc[term,0]),OLS_high=float(ols_ci.loc[term,1]),
                    HAC_low=float(ci[j,0]),HAC_high=float(ci[j,1]),
                    status='Limited dummy support' if n_dummy in [1,2] else 'Estimated'))

summary=[]
for w in [20,24,28]:
    for term in terms:
        rr=[r for r in records if r['window']==w and r['term']==term and r['coefficient'] is not None]
        lo=min(rr,key=lambda r:r['coefficient']);hi=max(rr,key=lambda r:r['coefficient'])
        summary.append(dict(window=w,term=term,n_windows=len(rr),
            min=lo['coefficient'],min_end=lo['end'],max=hi['coefficient'],max_end=hi['end'],
            positive=sum(r['coefficient']>0 for r in rr),negative=sum(r['coefficient']<0 for r in rr),
            OLS_significant=sum(r['OLS_p']<.05 for r in rr),HAC_significant=sum(r['HAC_p']<.05 for r in rr),
            last=rr[-1]['coefficient'],last_OLS_p=rr[-1]['OLS_p'],last_HAC_p=rr[-1]['HAC_p']))
result=dict(settings=dict(target='y=100R',sample_start='2012Q2',sample_end='2025Q4',
    main_window=24,sensitivity_windows=[20,28],step=1,HAC_lags=4,
    fixed_terms=terms,dummy_start='2020Q1',dummy_end='2021Q1',
    inference='Pointwise nominal t intervals, not selection or multiplicity adjusted; overlapping windows'),
    records=records,windows=windows,summary=summary,
    checks=dict(n_fits=len(windows),n_coefficient_records=len(records),
        max_RollingOLS_difference=max(checks),full_refit_matches=True,
        original_analysis_unchanged=True))
(args.out_dir/'rolling_results.json').write_text(json.dumps(result,indent=2,allow_nan=False))
print('Rolling diagnostics complete:',args.out_dir.name)
