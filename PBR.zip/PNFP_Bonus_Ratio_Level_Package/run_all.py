"""Run the three segments in order."""
from pathlib import Path
import runpy
ROOT=Path(__file__).resolve().parent
for filename in ['segment1_prepare_data.py','segment2_models.py','segment3_diagnostics.py']:
    runpy.run_path(str(ROOT/filename),run_name='__main__')
