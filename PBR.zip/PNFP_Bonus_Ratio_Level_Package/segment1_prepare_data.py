"""Segment 1: verify quarterly inputs, transform and test stationarity."""
from pathlib import Path
import json, csv, sys
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'code'))
from ratio_helpers import transform, stationarity, records
OUT=ROOT/'results';OUT.mkdir(exist_ok=True)
levels=pd.DataFrame(json.loads((ROOT/'data/quarterly_levels.json').read_text())).set_index('quarter')
levels.index=pd.PeriodIndex(levels.index,freq='Q')
assert levels.index.equals(pd.period_range('2011Q1','2025Q4',freq='Q'))
assert levels.notna().all().all() and not levels.index.duplicated().any()
assert len(levels.columns)==24
levels['net']=levels.comp-levels.bonus
assert (levels[['comp','bonus','net']]>0).all().all()
levels['ratio']=levels.bonus/levels.net
levels['y']=100*levels.ratio
guide=json.loads((ROOT/'data/transform_rules.json').read_text())
features=pd.DataFrame({g['feature']:transform(levels[g['family']],g['transform']) for g in guide})
features['pandemic']=((levels.index>='2020Q1')&(levels.index<='2021Q1')).astype(float)
train=pd.period_range('2012Q2','2022Q4',freq='Q')
tests=[dict(feature='R',family='target',**stationarity(levels.loc[train,'y']))]
for g in guide:
    tests.append(dict(feature=g['feature'],family=g['family'],priority=g['priority'],**stationarity(features[g['feature']].shift(1).loc[train])))
assert len(train)==43 and features.loc[train,'pandemic'].sum()==5
prepared=dict(levels=records(levels),features=records(features),guide=guide,stationarity=tests)
(OUT/'prepared.json').write_text(json.dumps(prepared,indent=2,allow_nan=False))
levels.to_csv(OUT/'quarterly_levels.csv',index_label='quarter')
features.to_csv(OUT/'transformed_features.csv',index_label='quarter')
pd.DataFrame(tests).to_csv(OUT/'stationarity.csv',index=False)
print('Segment 1 complete: 60 quarters, 22 macros, 43 training observations.')
