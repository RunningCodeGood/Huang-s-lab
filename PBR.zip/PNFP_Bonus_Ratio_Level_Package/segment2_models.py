"""Segment 2: ratio-level selection and alternative starting variables."""
from pathlib import Path
import runpy,sys
ROOT=Path(__file__).resolve().parent
assert (ROOT/'results/prepared.json').exists(), 'Run segment1_prepare_data.py first'
for script,args in [('ratio_models.py',[]),('ratio_models.py',['--with-hy']),('alternative_starts.py',[]),('no_dummy.py',[])]:
    previous_argv=sys.argv[:]
    try:
        sys.argv=[str(ROOT/'code'/script),*args]
        runpy.run_path(sys.argv[0],run_name='__main__')
    finally:
        sys.argv=previous_argv
print('Segment 2 complete. All historical specifications remain non-adopted research models.')
