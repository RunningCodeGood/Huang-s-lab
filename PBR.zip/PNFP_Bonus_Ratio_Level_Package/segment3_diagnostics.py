"""Segment 3: rolling coefficients, archived S4 recursion and replication tests."""
from pathlib import Path
import runpy,sys,json
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parent
for variant in ['without_hy','with_hy']:
    folder=ROOT/'results'/variant
    previous_argv=sys.argv[:]
    try:
        sys.argv=[str(ROOT/'code/rolling.py'),'--analysis',str(folder/'analysis.json'),'--out-dir',str(folder)]
        runpy.run_path(sys.argv[0],run_name='__main__')
    finally:
        sys.argv=previous_argv
d=json.loads((ROOT/'results/without_hy/analysis.json').read_text())
coef={r['term']:r['coefficient'] for r in d['coefficients'] if r['model']=='Covid macro ARDL' and r['sample']=='Train'}
last=d['levels'][-1];previous=last['y'];u_lag=last['unemp']
scenario=json.loads((ROOT/'data/s4_unemployment.json').read_text())
rows=[]
for r in scenario['path']:
    estimate=coef['const']+coef['R.L1']*previous+coef['unemp_level.L1']*u_lag
    rows.append(dict(quarter=r['quarter'],unemployment_pct=r['unemployment_pct'],used_unemployment_lag_pct=u_lag,own_lag_pct=previous,pandemic=0,forecast_pct=estimate,ratio=estimate/100))
    previous=estimate;u_lag=r['unemployment_pct']
result=dict(forecast=rows,sum_ratios=sum(r['ratio'] for r in rows),mean_ratio_pct=float(np.mean([r['forecast_pct'] for r in rows])),bonus_total=None,bonus_total_reason='Non-bonus compensation path is required; ratios are not additive amounts.')
(ROOT/'results/s4_forecast.json').write_text(json.dumps(result,indent=2))
pd.DataFrame(rows).to_csv(ROOT/'results/s4_forecast.csv',index=False)
runpy.run_path(str(ROOT/'verify_results.py'),run_name='__main__')
print('Segment 3 complete. S4 output is archived research, not the adopted forecast.')
