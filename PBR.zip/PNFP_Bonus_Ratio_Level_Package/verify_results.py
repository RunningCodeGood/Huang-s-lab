"""Compare rerun numerical results to immutable archived evidence (E02-E08)."""
from pathlib import Path
import json, math

ROOT = Path(__file__).resolve().parent
ATOL, RTOL = 1e-7, 1e-8
# Narrative labels were translated. Identifiers, dates, selected terms, numerical
# results and flags must match; descriptive prose is not a statistical output.
IDENTIFIERS = {'model', 'term', 'terms', 'feature', 'family', 'variable', 'quarter',
               'start', 'end', 'train_end', 'sample', 'scope', 'candidate',
               'existing', 'selected', 'chosen_transforms', 'transform',
               'passing_seeds', 'first_round_passers', 'specification', 'orders'}
counts = {'numeric': 0, 'flags': 0, 'identifiers': 0}
failures = []

def compare(actual, expected, path, exact=False):
    if isinstance(expected, dict):
        if not isinstance(actual, dict):
            failures.append(path + ': expected dictionary'); return
        for key, value in expected.items():
            if key not in actual:
                failures.append(path + '.' + key + ': missing'); continue
            compare(actual[key], value, path + '.' + key, exact or key in IDENTIFIERS)
    elif isinstance(expected, list):
        if not isinstance(actual, list) or len(actual) != len(expected):
            failures.append(path + ': list size mismatch'); return
        for i, (a, e) in enumerate(zip(actual, expected)):
            compare(a, e, f'{path}[{i}]', exact)
    elif expected is None or isinstance(expected, bool):
        counts['flags'] += 1
        if actual != expected: failures.append(f'{path}: {actual!r} != {expected!r}')
    elif isinstance(expected, (int, float)):
        counts['numeric'] += 1
        ok = isinstance(actual, (int, float)) and (
            (math.isnan(expected) and math.isnan(actual)) or
            math.isclose(actual, expected, abs_tol=ATOL, rel_tol=RTOL))
        if not ok: failures.append(f'{path}: {actual!r} != {expected!r}')
    elif exact:
        counts['identifiers'] += 1
        if actual != expected: failures.append(f'{path}: {actual!r} != {expected!r}')

CASES = {
    'E02': ('without_hy/analysis.json', ['stationarity', 'screening', 'groups',
             'models', 'coefficients', 'predictions', 'robustness']),
    'E03': ('with_hy/analysis.json', ['stationarity', 'screening', 'groups',
             'models', 'coefficients', 'predictions']),
    'E04': ('with_dummy/comparison_results.json', ['first_round', 'passing_seeds',
             'second_round', 'branches', 'models', 'coefficients', 'predictions',
             'rolling_summary', 'pandemic_removal']),
    'E05': ('without_dummy/comparison_results.json', ['first_round', 'first_round_passers',
             'second_round', 'branches', 'models', 'coefficients', 'predictions',
             'rolling_summary', 'nested_dummy_test']),
    'E06': ('without_hy/rolling_results.json', ['records', 'summary']),
    'E07': ('with_hy/rolling_results.json', ['records', 'summary']),
    'E08': ('s4_forecast.json', ['forecast', 'sum_ratios', 'mean_ratio_pct', 'bonus_total']),
}
for evidence, (filename, keys) in CASES.items():
    original = json.loads((ROOT / 'reference' / (evidence + '.json')).read_text())
    result = json.loads((ROOT / 'results' / filename).read_text())
    compare({k: result[k] for k in keys}, {k: original[k] for k in keys}, evidence)
report = {'passed': not failures, 'evidence_ids': list(CASES), 'checks': counts,
          'absolute_tolerance': ATOL, 'relative_tolerance': RTOL,
          'failures': failures}
(ROOT / 'results/replication_validation.json').write_text(json.dumps(report, indent=2))
if failures:
    print('\n'.join(failures[:30]))
    raise SystemExit(f'Replication failed: {len(failures)} differences. See results/replication_validation.json.')
print('PASS: E02-E08 reproduced.', counts)
