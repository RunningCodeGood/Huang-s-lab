# PNFP bonus-ratio level: 22-macro ARDL research package

This package reproduces the quarterly bonus-ratio experiment using exactly two
CSV input files. All analytical outputs are CSV. HY is included in the candidate
pool and may remain in the selected model. No bonus-growth challenger or future
Baseline/S4 scenario forecast is included.

## Quick start

Python 3.12 is recommended. Install the versions in `requirements.txt` in your
own environment, then run from this folder:

```sh
python -m pip install -r requirements.txt
python run_all.py
python -m unittest -v test_pipeline.py
```

Or run the three segments separately:

```sh
python segment1_prepare_data.py
python segment2_ardl_backtest.py
python segment3_rolling_diagnostics.py
```

Each segment reads the same two inputs directly and can run independently; no
pre-existing output, spreadsheet, JSON, network connection, or external file
path is needed. `model_core.py` contains the shared implementation and explicit
model settings. All commands accept `--input-dir PATH --output-dir PATH`.
Rerunning overwrites the generated CSVs with the same names, not the inputs.

## Exactly two input files

| File | Columns | Rows |
|---|---|---:|
| `inputs/macro.csv` | `Quarter` plus 22 original macro mnemonics | 60 |
| `inputs/bonus.csv` | `Quarter,Quarter_Comp,Quarter_Bonus` | 60 |

The period is 2011Q1 through 2025Q4, inclusive. Dates are ISO quarter-end dates.
`YYYYQn` and U.S. quarter-end dates are also accepted. Both files must contain
the complete, non-duplicated 60-quarter sample. Rows are sorted by quarter.
Missing/nonfinite numbers, unexpected columns, duplicate quarters, non-quarter-end
dates, and nonpositive non-bonus compensation cause explicit errors.

Input macro values are **quarterly levels**, not already transformed rates.
They retain the existing data's numerical precision. No additional quarterly
averaging, interpolation, annualization, or seasonal adjustment is performed.
Do not divide SAAR series by four before running the package. Rate values are
in the stated units: unemployment 9 means 9%, not 0.09. The generated
`macro_dictionary.csv` identifies all 22 variables, units, and transform priorities.
Compensation and bonus use the same USD denomination.

The code generates:

- Non-bonus compensation = `Quarter_Comp - Quarter_Bonus`.
- Ratio level `R = Quarter_Bonus / non-bonus compensation`.
- Estimation target `y = 100 R`. Thus y=20 means a bonus/non-bonus ratio of 20%,
  **not** a bonus share of total compensation. No growth-rate target is fitted.
- Pandemic dummy D=1 for 2020Q1 through 2021Q1 (five quarters), otherwise zero.

## Samples and timing

| Purpose | Response quarters | Observations |
|---|---|---:|
| Raw input | 2011Q1–2025Q4 | 60 |
| Training / selection | 2012Q2–2022Q4 | 43 |
| Historical out-of-time (OOT) backtest | 2023Q1–2025Q4 | 12 |
| Descriptive full refit / rolling diagnostics | 2012Q2–2025Q4 | 55 |

The training start is deliberately retained for comparability with the existing
experiment. Removing an optional model does not advance the start date. Earlier
quarters provide lag and transform history. No quarter is removed for an
acquisition; no acquisition dummy or pre/post split is applied.

## Segment 1: transformations and stationarity

The 22 raw macro series produce 45 candidate forms. Per macro, test forms in
the following fixed order and retain the **first** passing form, not the form
with the best in-sample fit:

- Positive amounts and cost/compensation indexes: `100 ln(X_t/X_(t-1))`, then
  `100 ln(X_t/X_(t-4))`.
- Interest rates, unemployment, confidence, optimism, output gap and HY:
  level, then first quarterly difference.
- VIX: level, natural-log level, then quarterly log growth.

ADF uses an intercept, maximum lag 4 and AIC lag selection. KPSS uses an
intercept and automatic bandwidth. The joint admission gate is ADF p<0.05 and
KPSS p>0.05. KPSS boundary p-values are recorded with explicit bound labels;
0.10 is a tabulated upper boundary, not a precise probability estimate.

The target is tested over 2012Q2–2022Q4. Macro tests use the actual lagged
regressor dates 2012Q1–2022Q3, so transformation selection never uses OOT data.
Passing a finite-sample test is not proof of unconditional stationarity.

## Segment 2: selection and historical backtest

The primary specification is:

`y_t = c + phi*y_(t-1) + delta*D_t + sum(beta_j*Z_j,(t-1)) + error_t`

The constant, own lag and pandemic dummy are fixed controls, retained regardless
of significance. Macro lag is one quarter. At most two different macro families
enter; 22 is the **candidate pool size**, not a requirement to include all 22
in one regression. There is no backward deletion, distributed-lag search, or
post-rolling automatic deletion of HY.

At each forward step, each remaining eligible family is added to the current
model. All four gates must pass: added-term classical Student-t p<0.05;
maximum nonconstant VIF<10; 1.5<=Durbin–Watson<=2.5; Jarque–Bera p>0.05.
Passing additions are ranked by added-term p ascending, adjusted R-squared
descending, then candidate name. Every candidate and every gate are exported
to `forward_selection.csv`, including candidates that do not enter.

The package also repeats selection without the dummy as a labeled sensitivity,
and fits AR(1) benchmarks both with and without the same dummy. These are not
alternative dependent variables. Additional persistence, seasonal-naive and
training-mean benchmarks are included. Coefficients have classical OLS and
HAC standard errors/p-values (Bartlett, lag 4, finite-sample correction,
Student-t inference). HAC does not replace the classical entry gate.

Historical OOT methods:

1. **Frozen one-step:** coefficients and structure fixed at 2022Q4; uses observed
   y_(t-1) and macro Z_(t-1) for each of the 12 holdout quarters.
2. **Frozen recursive:** same training coefficients; starts from actual 2022Q4
   y and uses its own preceding prediction thereafter. The macro path is the
   supplied historical path. This is a conditional historical simulation, not
   a feasible ex-ante 12-quarter forecast with unknown macros.
3. **Expanding one-step:** fixed selected structure, refitted through t-1 at each
   holdout origin, using only preceding target observations.

No model is selected using OOT accuracy. Full-sample refit coefficients are
descriptive and never substituted into frozen OOT predictions. This is a
historical holdout using the available data vintage, not a real-time vintage
backtest; release delays and subsequent macro revisions are not modeled.

`oot_backtest.csv` gives every quarter's actual, prediction and error (actual
minus prediction), in both y percentage-point units and R decimal-ratio units.
`oot_metrics.csv` gives RMSE and MAE. `ar1_comparison.csv` directly compares each
macro model with its like-for-like AR(1) benchmark; positive improvement means
lower macro-model RMSE. Ratios are not added into a multi-quarter dollar total.

## Segment 3: stability and influence

Keep the training-selected primary macro structure fixed and fit rolling
windows over the 55-response-quarter sample. Main window: 24 quarters;
sensitivity windows: 20 and 28 quarters; step: one quarter. All coefficients,
pointwise 95% OLS/HAC intervals and p-values are exported. If D is zero
throughout a window, drop the unidentifiable column for that window only and
record its coefficient/p-value as blank with an explicit status. It is not
assigned a zero coefficient or treated as an insignificant estimate.

Rolling significance counts use only estimable windows. Windows overlap and
p-values are nominal, without selection or multiple-testing adjustment. The
rolling exercise includes OOT dates and is a post-estimation stability diagnostic,
not information used to improve the earlier holdout forecasts. Weak rolling
significance is a limitation to report, not an automatic deletion rule.

Influence diagnostics cover all 43 training observations. Two deletion
sensitivities remove the five dummy response quarters or the largest Cook's-D
response quarter, while preserving original calendar lags. Only classical OLS
inference is reported for these gapped samples. `dummy_comparison.csv` separately
isolates the dummy's effect while holding the no-dummy selected macro set fixed.

## Output map

| Segment | Main output CSVs |
|---|---|
| 1 | `run_info`, `data_validation`, `macro_dictionary`, `prepared_quarterly`, `transformed_macros`, `model_design`, `stationarity`, `transformation_selection` |
| 2 | `forward_selection`, `selected_specifications`, `model_summary`, `coefficients`, `in_sample_fit`, `oot_backtest`, `oot_metrics`, `ar1_comparison`, `model_verification` |
| 3 | `rolling_coefficients`, `rolling_summary`, `rolling_window_diagnostics`, `influence`, `sensitivity`, `dummy_comparison`, `rolling_verification` |

All names above have the `.csv` extension and are in `outputs/`. Blank numeric
cells signify undefined warm-up transforms/lags or explicitly unidentifiable
rolling dummy terms, not zero observations. `run_info.csv` records settings,
dependency versions and SHA-256 hashes of the two inputs. The supplied results
can be regenerated from scratch; they are never read as hidden inputs.

## Interpretation and verification

### Reproduced results for the supplied inputs

The stationarity gate admits 25 of 45 candidate forms and 18 distinct macro
families. Both dummy and no-dummy forward selections retain lagged unemployment
level and lagged HY spread level. The default model retains the pandemic dummy.

| Model | Training R-squared | Training adjusted R-squared | OOT frozen one-step RMSE (y units) |
|---|---:|---:|---:|
| Primary macro ARDL + dummy | 0.4216 | 0.3607 | 4.0479 |
| AR(1) + dummy benchmark | 0.1570 | 0.1148 | 5.0560 |
| No-dummy macro sensitivity | 0.3451 | 0.2948 | 3.8516 |
| No-dummy AR(1) benchmark | 0.1383 | 0.1172 | 4.8506 |

The primary model reduces one-step OOT RMSE by 19.94% against the like-for-like
AR(1)+dummy benchmark. Its recursive RMSE is 4.2576 and expanding one-step RMSE
is 4.0252. These are percentage points of the bonus/non-bonus ratio; divide by
100 for decimal-ratio RMSE.

HY passes the training forward-selection gate but has weak rolling significance
in the main 24-quarter exercise: its coefficient is negative in all 32 windows,
while only 1/32 windows has classical OLS p<0.05 and 7/32 has HAC p<0.05. It is
**retained** in this experiment as requested. In the same windows, unemployment
is positive throughout and significant in 28/32 OLS and 27/32 HAC tests. These
results should not be described as uniformly stable economic effects.

Selection p-values and fit statistics are descriptive research evidence, not
causal estimates or selection-adjusted significance. The dependent ratio
combines bonus and non-bonus compensation; macro coefficient signs can reflect
both numerator and denominator responses. Neither a significant macro term nor
an OOT improvement alone establishes a reliable structural forecasting model.

Every fitted training specification is checked against the independent
statsmodels ARDL implementation; every rolling fit is checked against RollingOLS.
The included tests cover target math, input validation, calendar timing, the
reference selection, and unchanged selection/coefficients after perturbing
holdout target values. Regression-reference tests are specific to the supplied
data; revise expected results deliberately if replacing the data.
