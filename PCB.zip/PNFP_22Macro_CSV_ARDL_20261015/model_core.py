"""CSV-only quarterly bonus-ratio research pipeline. Python 3.12 recommended.

All data dependencies are inputs/macro.csv and inputs/bonus.csv. Selection is
confined to the training sample; rolling and holdout diagnostics never reselect.
"""
from pathlib import Path
import argparse
import csv
import hashlib
import platform
import re
import warnings

import numpy as np
import pandas as pd
import scipy
import statsmodels
from scipy.stats import norm
from statsmodels.regression.linear_model import OLS
from statsmodels.regression.rolling import RollingOLS
from statsmodels.stats.diagnostic import acorr_breusch_godfrey, het_breuschpagan
from statsmodels.stats.outliers_influence import variance_inflation_factor
from statsmodels.stats.stattools import durbin_watson, jarque_bera
from statsmodels.tsa.ardl import ARDL
from statsmodels.tsa.stattools import adfuller, kpss

ROOT = Path(__file__).resolve().parent
RAW_START, RAW_END = pd.Period('2011Q1'), pd.Period('2025Q4')
TRAIN_START, TRAIN_END = pd.Period('2012Q2'), pd.Period('2022Q4')
OOT_START, OOT_END = pd.Period('2023Q1'), pd.Period('2025Q4')
D_START, D_END = pd.Period('2020Q1'), pd.Period('2021Q1')
MAX_MACROS, HAC_LAGS = 2, 4
ROLLING_WINDOWS = (20, 24, 28)

# Ordered macro list. Transform priority is fixed before selection, not fit-ranked.
# family, CSV column, description, raw unit, seasonal adjustment, transform rule
CATALOG = [
    ('earnings','FAHEFI_B.IUSA','Financial activities average hourly earnings','USD per hour','SA','growth'),
    ('ulc','FPCNBULC_B.IUSA','Nonfarm business unit labor costs','Index 2017=100','SA','growth'),
    ('eci','FECICPQ_B.IUSA','Private industry total compensation ECI','Index Dec 2005=100','SA','growth'),
    ('fed','FRFED_B.IUSA','Federal funds rate','Percent per annum','NSA','level_difference'),
    ('t2y','FRGT2Y_B.IUSA','Two year Treasury constant maturity rate','Percent per annum','NSA','level_difference'),
    ('t10y','FRGT10Y_B.IUSA','Ten year Treasury constant maturity rate','Percent per annum','NSA','level_difference'),
    ('unemp','FLBR_B.IUSA','Unemployment rate','Percent','SA','level_difference'),
    ('confidence','FCBC_B.IUSA','Consumer confidence index','Index 1985=100','SA','level_difference'),
    ('optimism','FSBINQ_B.IUSA','Small business normalized optimism index','Index 1986=100','SA','level_difference'),
    ('gdp','FGDP$_B.IUSA','Real gross domestic product','Billion chained 2017 USD','SAAR','growth'),
    ('gap','FGAP_B.IUSA','Real GDP versus potential GDP output gap','Percent','SA','level_difference'),
    ('assets','FBBACBQ_B.IUSA','Commercial banks total assets','Billion USD','SA','growth'),
    ('loans','FBBABLLCBQ_B.IUSA','Commercial banks loans and leases in bank credit','Billion USD','SA','growth'),
    ('vix','FCBOEVIXQ_B.IUSA','CBOE S&P 500 volatility index period average','Index','NSA','vix'),
    ('hy','FIRHYBOASQ_B.IUSA','High yield bond option adjusted spread','Percentage points','NSA','level_difference'),
    ('FPCNBCPH_B.IUSA','FPCNBCPH_B.IUSA','Nonfarm business hourly compensation','Index 2017=100','SA','growth'),
    ('FLBOPQ_B.IUSA','FLBOPQ_B.IUSA','Total nonfarm job openings','Million jobs','SA','growth'),
    ('FYPEW52Q_B.IUSA','FYPEW52Q_B.IUSA','Finance and insurance wages and salaries','Billion USD','SAAR','growth'),
    ('FGDP52Q_B.IUSA','FGDP52Q_B.IUSA','Finance and insurance gross product originating','Billion USD','SAAR','growth'),
    ('FE52_B.IUSA','FE52_B.IUSA','Finance and insurance employment','Million','SA','growth'),
    ('FYPCPIQ_B.IUSA','FYPCPIQ_B.IUSA','Per capita income','USD','SAAR','growth'),
    ('FECICCQ_B.IUSA','FECICCQ_B.IUSA','All civilian workers total compensation ECI','Index Dec 2005=100','SA','growth'),
]
RULES = {'growth': ('dlog1','dlog4'), 'level_difference': ('level','diff1'),
         'vix': ('level','loglevel','dlog1')}
FORMULAS = {'level':'X_t', 'diff1':'X_t - X_(t-1)', 'loglevel':'ln(X_t)',
            'dlog1':'100 * ln(X_t / X_(t-1))', 'dlog4':'100 * ln(X_t / X_(t-4))'}


def cli(description):
    parser = argparse.ArgumentParser(description=description)
    parser.add_argument('--input-dir', type=Path, default=ROOT/'inputs')
    parser.add_argument('--output-dir', type=Path, default=ROOT/'outputs')
    return parser.parse_args()


def save(out, name, records):
    """All analytical outputs use CSV, UTF-8, no index, round-trip precision."""
    out = Path(out)
    out.mkdir(parents=True, exist_ok=True)
    frame = records if isinstance(records, pd.DataFrame) else pd.DataFrame(records)
    frame.to_csv(out/(name+'.csv'), index=False, float_format='%.17g', na_rep='')


def period(value):
    value = str(value).strip()
    if re.fullmatch(r'\d{4}Q[1-4]', value):
        return pd.Period(value, freq='Q')
    for pattern, fmt in [(r'\d{4}-\d{2}-\d{2}', '%Y-%m-%d'),
                         (r'\d{1,2}/\d{1,2}/\d{4}', '%m/%d/%Y')]:
        if re.fullmatch(pattern, value):
            dt = pd.to_datetime(value, format=fmt, errors='raise')
            p = dt.to_period('Q')
            if dt.normalize() != p.end_time.normalize():
                raise ValueError(f'Quarter must be a quarter-end date: {value}')
            return p
    raise ValueError(f'Invalid Quarter: {value!r}')


def read_input(path, columns):
    with Path(path).open(newline='', encoding='utf-8-sig') as handle:
        header = next(csv.reader(handle))
    if len(header) != len(set(header)) or set(header) != set(columns):
        raise ValueError(f'{Path(path).name}: expected exactly {columns}; received {header}')
    frame = pd.read_csv(path, encoding='utf-8-sig', float_precision='round_trip', dtype={'Quarter':str})
    frame = frame[columns]
    frame.index = pd.PeriodIndex([period(v) for v in frame.pop('Quarter')], freq='Q', name='Quarter')
    if frame.index.has_duplicates:
        raise ValueError(f'{Path(path).name}: duplicate quarter')
    frame = frame.sort_index()
    expected = pd.period_range(RAW_START, RAW_END, freq='Q')
    if not frame.index.equals(expected):
        raise ValueError(f'{Path(path).name}: requires all 60 quarters {RAW_START} through {RAW_END}, without gaps or extras')
    frame = frame.apply(pd.to_numeric, errors='raise').astype(float)
    if not np.isfinite(frame.to_numpy()).all():
        raise ValueError(f'{Path(path).name}: missing or nonfinite numeric values')
    return frame


def transform(x, kind):
    if kind == 'level':
        return x.copy()
    if kind == 'diff1':
        return x.diff()
    if not (x > 0).all():
        raise ValueError(f'{x.name}: nonpositive values cannot be log transformed')
    if kind == 'loglevel':
        return np.log(x)
    if kind in ('dlog1','dlog4'):
        return 100*np.log(x/x.shift(1 if kind == 'dlog1' else 4))
    raise ValueError(f'Unknown transform {kind}')


def stationarity(x):
    if x.isna().any():
        raise ValueError('Stationarity sample contains missing observations')
    with warnings.catch_warnings():
        warnings.simplefilter('ignore')
        a = adfuller(x, maxlag=4, regression='c', autolag='AIC', result_object=False)
        k = kpss(x, regression='c', nlags='auto', result_object=False)
    return dict(n=len(x), ADF_stat=a[0], ADF_p=a[1], ADF_lags=a[2], ADF_n=a[3],
                KPSS_stat=k[0], KPSS_p=k[1], KPSS_lags=k[2],
                KPSS_bound='>0.10' if k[1] == .1 else '<0.01' if k[1] == .01 else 'within table',
                stationary=bool(a[1] < .05 and k[1] > .05))


class Data:
    def __init__(self, input_dir):
        self.input_dir = Path(input_dir)
        macro = read_input(self.input_dir/'macro.csv', ['Quarter']+[c[1] for c in CATALOG])
        bonus = read_input(self.input_dir/'bonus.csv', ['Quarter','Quarter_Comp','Quarter_Bonus'])
        if not (bonus.Quarter_Comp - bonus.Quarter_Bonus > 0).all():
            raise ValueError('Quarter_Comp - Quarter_Bonus must be strictly positive')
        self.levels = bonus.rename(columns={'Quarter_Comp':'comp','Quarter_Bonus':'bonus'}).join(
            macro.rename(columns={c[1]:c[0] for c in CATALOG}))
        self.levels['non_bonus_comp'] = self.levels.comp-self.levels.bonus
        self.levels['R'] = self.levels.bonus/self.levels.non_bonus_comp
        self.levels['y'] = 100*self.levels.R
        self.y = self.levels.y
        self.features = pd.DataFrame(index=self.levels.index)
        self.meta = []
        for family, code, name, unit, adjustment, rule in CATALOG:
            for priority, kind in enumerate(RULES[rule]):
                feature = family+'_'+kind
                self.features[feature] = transform(self.levels[family], kind)
                self.meta.append(dict(feature=feature, family=family, code=code, name=name,
                    transform=kind, formula=FORMULAS[kind], priority=priority, raw_unit=unit,
                    transformed_unit=('% log change' if kind.startswith('dlog') else
                                      'Natural log of level' if kind == 'loglevel' else unit),
                    adjustment=adjustment, model_lag=1))
        self.X = self.features.shift(1).rename(columns=lambda c:c+'.L1')
        self.X.insert(0, 'R.L1', self.y.shift(1))
        self.X.insert(0, 'const', 1.)
        self.X['pandemic'] = ((self.X.index >= D_START)&(self.X.index <= D_END)).astype(float)
        self.train = pd.period_range(TRAIN_START, TRAIN_END, freq='Q')
        self.test = pd.period_range(OOT_START, OOT_END, freq='Q')
        self.full = pd.period_range(TRAIN_START, OOT_END, freq='Q')
        if not np.isfinite(self.X.loc[self.full].to_numpy()).all():
            raise ValueError('Incomplete lagged modeling sample')
        self.stationarity = [dict(feature='R', family='target', code='', name='Bonus / non-bonus compensation',
            transform='ratio level', start=str(TRAIN_START), end=str(TRAIN_END), chosen=False,
            reason='Target diagnostic; tested as y = 100 R', **stationarity(self.y.loc[self.train]))]
        self.eligible = []
        picks = set()
        for meta in self.meta:
            test = stationarity(self.X.loc[self.train, meta['feature']+'.L1'])
            chosen = test['stationary'] and meta['family'] not in picks
            reason = ('First passing transform in prespecified order' if chosen else
                      'Earlier preferred transform already passed' if test['stationary'] else 'ADF/KPSS joint gate failed')
            if chosen:
                picks.add(meta['family'])
                self.eligible.append(meta['feature']+'.L1')
            self.stationarity.append(dict(**meta, start=str(TRAIN_START-1), end=str(TRAIN_END-1),
                                          chosen=chosen, reason=reason, **test))
        self.groups, self.trials = None, None

    def fit(self, ids, extra):
        x = self.X.loc[ids, ['const','R.L1']+extra]
        if not np.isfinite(x.to_numpy()).all() or np.linalg.matrix_rank(x) != x.shape[1]:
            raise ValueError('Nonfinite or rank-deficient model design')
        return OLS(self.y.loc[ids], x, missing='raise').fit()


def diagnostics(fit):
    x = fit.model.exog
    vf = [variance_inflation_factor(x,j) for j in range(1,x.shape[1])]
    jb = jarque_bera(fit.resid)
    bg1 = acorr_breusch_godfrey(fit, nlags=1, result_object=False)
    bg4 = acorr_breusch_godfrey(fit, nlags=4, result_object=False)
    bp = het_breuschpagan(fit.resid, x)
    phi = float(fit.params['R.L1'])
    return dict(n=int(fit.nobs), k=x.shape[1], df_resid=int(fit.df_resid), R2=fit.rsquared,
        adj_R2=fit.rsquared_adj, AIC=fit.aic, BIC=fit.bic, DW=durbin_watson(fit.resid),
        JB_stat=jb[0], JB_p=jb[1], max_VIF=max(vf), BG1_LM_p=bg1[1], BG1_F_p=bg1[3],
        BG4_LM_p=bg4[1], BG4_F_p=bg4[3], BP_p=bp[1], phi=phi, AR_stable=abs(phi)<1)


def gates(p, d):
    return dict(p_gate=p<.05, VIF_gate=d['max_VIF']<10,
                DW_gate=1.5<=d['DW']<=2.5, JB_gate=d['JB_p']>.05)


def select(data):
    if data.groups is not None:
        return data.groups, data.trials
    groups, trials = [], []
    for scope, controls in [('No dummy',[]), ('Pandemic dummy',['pandemic'])]:
        remaining, selected, round_no = data.eligible.copy(), [], 1
        while remaining and len(selected) < MAX_MACROS:
            current = []
            for candidate in remaining:
                fit = data.fit(data.train, selected+[candidate]+controls)
                dg = diagnostics(fit)
                p = float(fit.pvalues[candidate])
                flags = gates(p,dg)
                current.append(dict(scope=scope, round=round_no, candidate=candidate,
                    existing='; '.join(selected), coefficient=fit.params[candidate], p_student_t=p,
                    p_normal=2*norm.sf(abs(fit.tvalues[candidate])), **dg, **flags,
                    passes=all(flags.values()), chosen=False,
                    failed='; '.join(k for k,v in flags.items() if not v)))
            passing = sorted([r for r in current if r['passes']], key=lambda r:(r['p_student_t'],-r['adj_R2'],r['candidate']))
            winner = passing[0]['candidate'] if passing else None
            for row in current:
                row['chosen'] = row['candidate'] == winner
            trials.extend(current)
            if winner is None:
                break
            selected.append(winner)
            remaining.remove(winner)
            round_no += 1
        dg = diagnostics(data.fit(data.train, selected+controls))
        accepted = bool(selected and data.stationarity[0]['stationary'] and
                        all(gates(0,dg).values()) and dg['AR_stable'])
        groups.append(dict(scope=scope, selected=selected, controls=controls, accepted=accepted))
    data.groups, data.trials = groups, trials
    return groups, trials


def segment1(data, out):
    """Validate, derive target, transform all macros and apply stationarity gate."""
    checks = [dict(check='Exactly 22 macro series', value=len(CATALOG), passed=len(CATALOG)==22),
        dict(check='Complete raw quarterly sample', value=len(data.levels), passed=len(data.levels)==60),
        dict(check='Training response observations', value=len(data.train), passed=len(data.train)==43),
        dict(check='Historical OOT observations', value=len(data.test), passed=len(data.test)==12),
        dict(check='Pandemic training quarters', value=int(data.X.loc[data.train,'pandemic'].sum()),
             passed=data.X.loc[data.train,'pandemic'].sum()==5),
        dict(check='Pandemic OOT quarters', value=int(data.X.loc[data.test,'pandemic'].sum()),
             passed=data.X.loc[data.test,'pandemic'].sum()==0)]
    if not all(row['passed'] for row in checks):
        raise ValueError('Data validation failed')
    save(out, 'data_validation', checks)
    dictionary = [dict(family=c[0], CSV_column=c[1], name=c[2], unit=c[3], adjustment=c[4],
                      transform_order='; '.join(RULES[c[5]]),
                      quarterly_basis='Supplied quarterly level; no additional aggregation') for c in CATALOG]
    save(out, 'macro_dictionary', dictionary)
    prepared = data.levels.copy()
    prepared['pandemic'] = data.X.pandemic
    prepared['sample'] = ['warmup' if t<TRAIN_START else 'train' if t<=TRAIN_END else 'OOT' for t in prepared.index]
    save(out, 'prepared_quarterly', prepared.rename_axis('Quarter').reset_index())
    save(out, 'transformed_macros', data.features.rename_axis('Quarter').reset_index())
    save(out, 'model_design', data.X.rename_axis('Quarter').reset_index())
    save(out, 'stationarity', data.stationarity)
    save(out, 'transformation_selection', [dict(family=c[0], CSV_column=c[1],
        selected_feature=next((r['feature'] for r in data.stationarity if r['family']==c[0] and r['chosen']),''),
        eligible=any(r['family']==c[0] and r['chosen'] for r in data.stationarity)) for c in CATALOG])
    settings = dict(target='R = Quarter_Bonus / (Quarter_Comp - Quarter_Bonus)',
        estimation_scale='y = 100 R; predictions and errors in percentage points of bonus/non-bonus ratio',
        raw_start=str(RAW_START), raw_end=str(RAW_END), train_start=str(TRAIN_START), train_end=str(TRAIN_END),
        OOT_start=str(OOT_START), OOT_end=str(OOT_END), dummy_start=str(D_START), dummy_end=str(D_END),
        macro_count=len(CATALOG), candidate_transforms=len(data.meta), eligible_families=len(data.eligible),
        stationary_transforms=sum(r['stationary'] for r in data.stationarity[1:]),
        own_lag=1, macro_lag=1, max_macros=MAX_MACROS, HAC_lags=HAC_LAGS,
        ADF='Constant; maxlag 4; autolag AIC; p < 0.05', KPSS='Constant; automatic bandwidth; p > 0.05',
        selection='Added-term classical Student t p < 0.05; max VIF < 10; 1.5 <= DW <= 2.5; JB p > 0.05',
        ranking='Added-term p ascending; adjusted R2 descending; candidate name ascending',
        main_rolling_window=24, sensitivity_rolling_windows='20;28',
        HY='Included in pool and eligible for selection; rolling diagnostics do not delete terms',
        future_scenario_forecasts=False, quarterly_aggregation='None; supplied quarterly levels',
        python=platform.python_version(), numpy=np.__version__, pandas=pd.__version__,
        scipy=scipy.__version__, statsmodels=statsmodels.__version__)
    for filename in ('macro.csv','bonus.csv'):
        settings[filename+'_sha256'] = hashlib.sha256((data.input_dir/filename).read_bytes()).hexdigest()
    save(out, 'run_info', [dict(setting=k,value=v) for k,v in settings.items()])


def segment2(data, out):
    """Forward selection, full diagnostics and frozen/expanding historical OOT."""
    groups, trials = select(data)
    save(out, 'forward_selection', trials)
    specs, summaries, coefs, predictions, fits, metrics, verification = [], [], [], [], [], [], []
    for group in groups:
        short = 'Covid' if group['controls'] else 'NoD'
        for role, macros in [('AR benchmark',[]), ('macro ARDL',group['selected'])]:
            label = short+' '+role
            extra = macros+group['controls']
            train, full = data.fit(data.train, extra), data.fit(data.full, extra)
            status = 'Benchmark' if role == 'AR benchmark' else ('Passes training gates' if group['accepted'] else 'Does not pass training gates')
            for term in train.params.index:
                specs.append(dict(model=label, role='Primary' if label=='Covid macro ARDL' else 'Comparison',
                    term=term, scope=group['scope'], status=status))
            for sample, fit in [('Train',train), ('Full refit',full)]:
                summaries.append(dict(model=label, sample=sample, status=status,
                    start=str(TRAIN_START), end=str(TRAIN_END if sample=='Train' else OOT_END), **diagnostics(fit)))
                hac = fit.get_robustcov_results(cov_type='HAC', maxlags=HAC_LAGS, kernel='bartlett', use_correction=True, use_t=True)
                ci = hac.conf_int()
                for j, term in enumerate(fit.params.index):
                    coefs.append(dict(model=label, sample=sample, term=term, coefficient=fit.params.iloc[j],
                        OLS_SE=fit.bse.iloc[j], OLS_p=fit.pvalues.iloc[j], HAC_SE=hac.bse[j], HAC_p=hac.pvalues[j],
                        HAC_CI_low=ci[j,0], HAC_CI_high=ci[j,1]))
            for t in data.train:
                fits.append(dict(model=label, Quarter=str(t), actual_y=data.y[t], fitted_y=train.fittedvalues[t],
                                 residual_y=train.resid[t], actual_R=data.y[t]/100, fitted_R=train.fittedvalues[t]/100))
            # Independent ARDL library implementation, not just a second OLS call.
            idx = pd.period_range(TRAIN_START-1, TRAIN_END, freq='Q')
            raw = [term.removesuffix('.L1') for term in macros]
            fixed = data.X.loc[idx,['pandemic']] if group['controls'] else None
            with warnings.catch_warnings():
                warnings.simplefilter('ignore')
                if raw:
                    alternate = ARDL(data.y.loc[idx], lags=1, exog=data.features.loc[idx,raw],
                        order={v:[1] for v in raw}, fixed=fixed, causal=True, hold_back=1, trend='c').fit()
                else:
                    alternate = ARDL(data.y.loc[idx], lags=1, fixed=fixed, hold_back=1, trend='c').fit()
            delta = np.max(np.abs(alternate.params.to_numpy()-train.params.to_numpy()))
            np.testing.assert_allclose(alternate.params,train.params,rtol=1e-10,atol=1e-10)
            verification.append(dict(check='ARDL coefficients match OLS', model=label, max_difference=delta, passed=True))
            paths = {key:[] for key in ('one_step','recursive','expanding')}
            previous = float(data.y[TRAIN_END])
            for t in data.test:
                row = data.X.loc[t,train.params.index].copy()
                paths['one_step'].append(float(row@train.params))
                row['R.L1'] = previous
                previous = float(row@train.params)
                paths['recursive'].append(previous)
                refit = data.fit(data.full[data.full<t], extra)
                paths['expanding'].append(float(data.X.loc[t,refit.params.index]@refit.params))
            for method, path in paths.items():
                errors = data.y.loc[data.test].to_numpy()-np.array(path)
                metrics.append(dict(model=label, method=method, n=len(data.test), start=str(OOT_START), end=str(OOT_END),
                    RMSE_y=np.sqrt(np.mean(errors**2)), MAE_y=np.mean(np.abs(errors)),
                    RMSE_R=np.sqrt(np.mean(errors**2))/100, MAE_R=np.mean(np.abs(errors))/100))
                for i,t in enumerate(data.test):
                    predictions.append(dict(model=label, method=method, Quarter=str(t), actual_y=data.y[t],
                        predicted_y=path[i], error_y=errors[i], actual_R=data.y[t]/100,
                        predicted_R=path[i]/100, error_R=errors[i]/100,
                        estimation_end=str(t-1 if method=='expanding' else TRAIN_END)))
    # Additional simple historical benchmarks (all use only observations available before t).
    for label, pred in [('Persistence',data.y.shift(1).loc[data.test]),
                        ('Seasonal naive',data.y.shift(4).loc[data.test]),
                        ('Training mean',pd.Series(data.y.loc[data.train].mean(),index=data.test))]:
        err = data.y.loc[data.test]-pred
        metrics.append(dict(model=label, method='one_step', n=len(data.test), start=str(OOT_START), end=str(OOT_END),
            RMSE_y=np.sqrt(np.mean(err**2)), MAE_y=np.mean(np.abs(err)),
            RMSE_R=np.sqrt(np.mean(err**2))/100, MAE_R=np.mean(np.abs(err))/100))
        for t in data.test:
            predictions.append(dict(model=label,method='one_step',Quarter=str(t), actual_y=data.y[t],
                predicted_y=pred[t],error_y=err[t],actual_R=data.y[t]/100,predicted_R=pred[t]/100,error_R=err[t]/100,
                estimation_end=str(TRAIN_END) if label=='Training mean' else 'Not fitted'))
    for name, rows in [('selected_specifications',specs), ('model_summary',summaries), ('coefficients',coefs),
                       ('in_sample_fit',fits), ('oot_backtest',predictions), ('oot_metrics',metrics),
                       ('model_verification',verification)]:
        save(out,name,rows)
    metric_df = pd.DataFrame(metrics)
    comparisons = []
    for short in ('Covid','NoD'):
        for method in ('one_step','recursive','expanding'):
            main = metric_df[(metric_df.model==short+' macro ARDL') & (metric_df.method==method)].iloc[0]
            bench = metric_df[(metric_df.model==short+' AR benchmark') & (metric_df.method==method)].iloc[0]
            comparisons.append(dict(model=main.model, benchmark=bench.model, method=method,
                RMSE_y=main.RMSE_y, benchmark_RMSE_y=bench.RMSE_y,
                RMSE_improvement_pct=100*(1-main.RMSE_y/bench.RMSE_y),
                MAE_y=main.MAE_y, benchmark_MAE_y=bench.MAE_y))
    save(out,'ar1_comparison',comparisons)
    return summaries, metrics


def segment3(data, out):
    """Fixed primary model: rolling coefficients and influence/deletion checks."""
    groups, _ = select(data)
    extra = groups[1]['selected']+['pandemic']
    terms = ['const','R.L1']+extra
    x, y = data.X.loc[data.full,terms], data.y.loc[data.full]
    records, windows, checks = [], [], []
    for w in ROLLING_WINDOWS:
        alternate = RollingOLS(y,x,window=w,min_nobs=w).fit(method='pinv',params_only=True)
        zero_dummy = RollingOLS(y,x.drop(columns='pandemic'),window=w,min_nobs=w).fit(method='pinv',params_only=True)
        for end in range(w-1,len(x)):
            xx, yy = x.iloc[end-w+1:end+1].copy(), y.iloc[end-w+1:end+1]
            n_dummy = int(xx.pandemic.sum())
            if xx.pandemic.nunique()==1:
                if n_dummy != 0:
                    raise ValueError('Dummy confounded with intercept throughout rolling window')
                xx = xx.drop(columns='pandemic')
            if np.linalg.matrix_rank(xx)!=xx.shape[1]:
                raise ValueError('Rank-deficient rolling window')
            fit = OLS(yy,xx).fit()
            hac = fit.get_robustcov_results(cov_type='HAC',maxlags=HAC_LAGS,kernel='bartlett',use_correction=True,use_t=True)
            ci, oi = hac.conf_int(), fit.conf_int()
            alt = alternate if 'pandemic' in xx else zero_dummy
            delta = np.max(np.abs(fit.params-alt.params.loc[xx.index[-1],xx.columns]))
            if not delta < 1e-8:
                raise AssertionError('RollingOLS verification failed')
            win = dict(window=w, start=str(xx.index[0]), end=str(xx.index[-1]), n=w, dummy_n=n_dummy,
                k=xx.shape[1], df_resid=int(fit.df_resid),
                max_VIF=max(variance_inflation_factor(xx.to_numpy(),j) for j in range(1,xx.shape[1])),
                max_leverage=fit.get_influence().hat_matrix_diag.max(), RollingOLS_max_difference=delta)
            windows.append(win)
            for term in terms:
                row = dict(window=w,start=win['start'],end=win['end'],term=term,dummy_n=n_dummy)
                if term not in xx:
                    row.update(coefficient=np.nan,OLS_p=np.nan,HAC_p=np.nan,OLS_low=np.nan,OLS_high=np.nan,
                               HAC_low=np.nan,HAC_high=np.nan,status='Not estimable: dummy is zero throughout window')
                else:
                    j = xx.columns.get_loc(term)
                    row.update(coefficient=fit.params[term],OLS_p=fit.pvalues[term],HAC_p=hac.pvalues[j],
                        OLS_low=oi.loc[term,0],OLS_high=oi.loc[term,1],HAC_low=ci[j,0],HAC_high=ci[j,1],
                        status='Limited dummy support' if n_dummy in (1,2) else 'Estimated')
                records.append(row)
    rolling = pd.DataFrame(records)
    summary = []
    for (w,term), rr in rolling.groupby(['window','term'],sort=False):
        valid = rr.dropna(subset=['coefficient'])
        if valid.empty:
            summary.append(dict(window=w,term=term,total_windows=len(rr),n_windows=0))
            continue
        lo, hi = valid.loc[valid.coefficient.idxmin()], valid.loc[valid.coefficient.idxmax()]
        summary.append(dict(window=w,term=term,total_windows=len(rr),n_windows=len(valid),
            min=lo.coefficient,min_end=lo.end,max=hi.coefficient,max_end=hi.end,
            positive=int((valid.coefficient>0).sum()),negative=int((valid.coefficient<0).sum()),
            OLS_significant=int((valid.OLS_p<.05).sum()),HAC_significant=int((valid.HAC_p<.05).sum()),
            OLS_significant_share=(valid.OLS_p<.05).mean(),HAC_significant_share=(valid.HAC_p<.05).mean(),
            last=valid.iloc[-1].coefficient,last_OLS_p=valid.iloc[-1].OLS_p,last_HAC_p=valid.iloc[-1].HAC_p))
    fit = data.fit(data.train,extra)
    influence = fit.get_influence()
    influence_rows = [dict(Quarter=str(t),Cook_D=influence.cooks_distance[0][i],
        leverage=influence.hat_matrix_diag[i],student_resid=influence.resid_studentized_external[i]) for i,t in enumerate(data.train)]
    highest = data.train[int(np.argmax(influence.cooks_distance[0]))]
    sensitivity = []
    for label, ids, model_terms in [
        ('Exclude dummy response quarters',data.train[(data.train<D_START)|(data.train>D_END)],[v for v in extra if v!='pandemic']),
        ('Exclude highest Cook D response quarter',data.train[data.train!=highest],extra)]:
        fit = data.fit(ids,model_terms)
        for term in fit.params.index:
            sensitivity.append(dict(check=label,n=len(ids),excluded_quarter=str(highest) if 'Cook' in label else '2020Q1-2021Q1',
                term=term,coefficient=fit.params[term],OLS_p=fit.pvalues[term],
                note='Fixed structure; original calendar lags retained; no HAC inference on gapped sample'))
    # Isolate the dummy effect while holding the no-dummy selected macro set fixed.
    fit = data.fit(data.train,groups[0]['selected']+['pandemic'])
    hac = fit.get_robustcov_results(cov_type='HAC',maxlags=HAC_LAGS,use_correction=True,use_t=True)
    j = fit.params.index.get_loc('pandemic')
    save(out,'dummy_comparison',[dict(fixed_macro_terms='; '.join(groups[0]['selected']),
        same_macro_set=set(groups[0]['selected'])==set(groups[1]['selected']),
        coefficient=fit.params['pandemic'],OLS_p=fit.pvalues['pandemic'],HAC_p=hac.pvalues[j],BIC=fit.bic)])
    checks.append(dict(check='Independent RollingOLS fits',n_fits=len(windows),
        max_difference=max(w['RollingOLS_max_difference'] for w in windows),passed=True))
    for name, rows in [('rolling_coefficients',rolling),('rolling_summary',summary),
        ('rolling_window_diagnostics',windows),('influence',influence_rows),('sensitivity',sensitivity),
        ('rolling_verification',checks)]:
        save(out,name,rows)
    return summary
