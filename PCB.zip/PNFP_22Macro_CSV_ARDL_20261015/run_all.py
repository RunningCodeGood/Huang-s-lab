"""Run all three segments from exactly two input CSVs."""
from model_core import Data, cli, segment1, segment2, segment3

if __name__ == '__main__':
    args = cli(__doc__)
    data = Data(args.input_dir)
    segment1(data,args.output_dir)
    print('Segment 1 complete.',flush=True)
    segment2(data,args.output_dir)
    print('Segment 2 complete.',flush=True)
    segment3(data,args.output_dir)
    print('Segment 3 complete. All analytical outputs are CSV.',flush=True)
