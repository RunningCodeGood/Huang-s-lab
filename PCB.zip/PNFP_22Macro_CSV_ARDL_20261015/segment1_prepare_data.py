"""Segment 1: two-CSV validation, target construction and macro stationarity."""
from model_core import Data, cli, segment1

if __name__ == '__main__':
    args = cli(__doc__)
    segment1(Data(args.input_dir), args.output_dir)
    print('Segment 1 complete: data and stationarity CSV outputs written.')
