"""Segment 2: full-pool forward selection and historical OOT/AR(1) comparison."""
from model_core import Data, cli, segment2

if __name__ == '__main__':
    args = cli(__doc__)
    segment2(Data(args.input_dir), args.output_dir)
    print('Segment 2 complete: model, historical OOT and AR(1) CSV outputs written.')
