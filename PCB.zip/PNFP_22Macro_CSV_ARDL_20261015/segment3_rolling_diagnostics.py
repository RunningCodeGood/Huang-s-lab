"""Segment 3: rolling coefficient stability, influence and sensitivity checks."""
from model_core import Data, cli, segment3

if __name__ == '__main__':
    args = cli(__doc__)
    segment3(Data(args.input_dir), args.output_dir)
    print('Segment 3 complete: rolling and sensitivity CSV outputs written.')
