"""Run with: python -m unittest -v test_pipeline.py. No external data fixtures."""
from pathlib import Path
import shutil
import tempfile
import unittest

import numpy as np
import pandas as pd

from model_core import ROOT, CATALOG, Data, period, read_input, select, transform


class PipelineTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.data = Data(ROOT/'inputs')

    def test_shape_and_target(self):
        d = self.data
        self.assertEqual(len(CATALOG),22)
        self.assertEqual((len(d.levels),len(d.train),len(d.test)),(60,43,12))
        self.assertEqual(len(d.meta),45)
        self.assertIn('hy_level',d.features)
        np.testing.assert_array_equal(d.levels.R,d.levels.bonus/(d.levels.comp-d.levels.bonus))
        np.testing.assert_array_equal(d.y,d.levels.R*100)
        self.assertEqual(d.X.loc[d.train,'pandemic'].sum(),5)
        self.assertEqual(d.X.loc[d.test,'pandemic'].sum(),0)

    def test_transform_and_calendar_lag(self):
        x = pd.Series([100.,110.,121.,133.1,146.41])
        self.assertAlmostEqual(transform(x,'dlog1').iloc[-1],100*np.log(1.1))
        self.assertAlmostEqual(transform(x,'dlog4').iloc[-1],100*np.log(1.4641))
        d = self.data
        t = pd.Period('2023Q1')
        self.assertEqual(d.X.loc[t,'R.L1'],d.y[t-1])
        self.assertEqual(d.X.loc[t,'unemp_level.L1'],d.levels.loc[t-1,'unemp'])
        self.assertEqual(d.X.loc[t,'hy_level.L1'],d.levels.loc[t-1,'hy'])

    def test_reference_selection(self):
        d = self.data
        groups, rows = select(d)
        self.assertEqual(len(d.eligible),18)
        self.assertEqual(groups[1]['selected'],['unemp_level.L1','hy_level.L1'])
        fit = d.fit(d.train,groups[1]['selected']+['pandemic'])
        self.assertAlmostEqual(fit.rsquared,0.4216173653,places=9)
        self.assertAlmostEqual(fit.rsquared_adj,0.3607349827,places=9)
        self.assertTrue(all(r['n']==43 for r in rows))

    def test_holdout_target_does_not_change_selection(self):
        baseline, _ = select(self.data)
        with tempfile.TemporaryDirectory() as tmp:
            tmp = Path(tmp)
            shutil.copy2(ROOT/'inputs/macro.csv',tmp/'macro.csv')
            b = pd.read_csv(ROOT/'inputs/bonus.csv',float_precision='round_trip')
            b.loc[b.Quarter>='2023-01-01','Quarter_Bonus'] *= 1.25
            b.to_csv(tmp/'bonus.csv',index=False,float_format='%.17g')
            altered = Data(tmp)
            groups, _ = select(altered)
            self.assertEqual(groups,baseline)
            for group in groups:
                terms = group['selected']+group['controls']
                np.testing.assert_array_equal(altered.fit(altered.train,terms).params,
                                              self.data.fit(self.data.train,terms).params)

    def test_duplicate_missing_and_wrong_headers_fail(self):
        original = pd.read_csv(ROOT/'inputs/bonus.csv',float_precision='round_trip')
        variants = [pd.concat([original,original.iloc[[0]]]), original.iloc[1:],
                    original.rename(columns={'Quarter_Bonus':'Bonus'})]
        invalid = original.copy(); invalid.loc[0,'Quarter_Bonus'] = np.nan
        variants.append(invalid)
        invalid = original.copy(); invalid.loc[0,'Quarter'] = '2011-03-30'
        variants.append(invalid)
        with tempfile.TemporaryDirectory() as tmp:
            p = Path(tmp)/'bonus.csv'
            for invalid in variants:
                invalid.to_csv(p,index=False)
                with self.assertRaises(ValueError):
                    read_input(p,['Quarter','Quarter_Comp','Quarter_Bonus'])

    def test_nonpositive_denominator_fails(self):
        with tempfile.TemporaryDirectory() as tmp:
            tmp = Path(tmp)
            shutil.copy2(ROOT/'inputs/macro.csv',tmp/'macro.csv')
            b = pd.read_csv(ROOT/'inputs/bonus.csv',float_precision='round_trip')
            b.loc[0,'Quarter_Bonus'] = b.loc[0,'Quarter_Comp']
            b.to_csv(tmp/'bonus.csv',index=False,float_format='%.17g')
            with self.assertRaisesRegex(ValueError,'strictly positive'):
                Data(tmp)

    def test_quarter_labels_and_invalid_log(self):
        self.assertEqual(period('2011-03-31'),period('2011Q1'))
        self.assertEqual(period('3/31/2011'),period('2011Q1'))
        with self.assertRaises(ValueError):
            transform(pd.Series([1.,0.]),'dlog1')


if __name__ == '__main__':
    unittest.main(verbosity=2)
