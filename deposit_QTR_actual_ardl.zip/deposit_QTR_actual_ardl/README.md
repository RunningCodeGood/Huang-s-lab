# Quarterly Deposit Fee Revenue Model

The Python script runs the quarterly revenue study from the Excel observations: trend analysis, stationarity tests, AR order selection, forward selection, model simplification, residual diagnostics, rolling estimates, out-of-time evaluation and S1/S4 scenario forecasts. Every coefficient and forecast is estimated or calculated during the run.

## Package structure

```text
deposit_QTR_actual_ardl/
    deposit_QTR_actual_ardl.py
    README.md
    requirements.txt
    input/
        Quarterly_Target_Data_2011Q1_2025Q4.xls
        macro_history.xls
        macro_S1.xls
        macro_S4.xls
    output/
        figures and statistical tables
```

All plotting code is included in `generate_figures()` in the main script. There are no additional Python modules to run. All outputs are saved directly in a single `output/` directory.

## Run

Use Python 3.12 or newer and install the dependencies:

```bash
python -m pip install -r requirements.txt
python deposit_QTR_actual_ardl.py --output-dir output_new
```

The package includes the generated `output/` folder. Use a new output directory for another run. If `output/` is absent or empty, the script can be run with no arguments. An existing nonempty output directory is not overwritten. Paths default to locations beside the script, so the command can be launched from another working directory. `--input-dir` accepts another folder with the same four workbook names and schemas.

## Excel inputs

| Workbook | Coverage | Contents |
| --- | --- | --- |
| `Quarterly_Target_Data_2011Q1_2025Q4.xls` | 2011Q1–2025Q4, 60 quarters | Original target workbook, retained intact. The script reads `YYYYMM` and `Quarterly_actual_num` from `Quarterly_targets`. |
| `macro_history.xls` | 2010Q1–2025Q4, 64 quarters | Levels of all 33 historical macro candidates. |
| `macro_S1.xls` | 2026Q1–2028Q1, 9 quarters | Bank deposits and C&I loans, August 2026 Baseline, labeled S1. |
| `macro_S4.xls` | 2026Q1–2028Q4, 12 quarters | Bank deposits and C&I loans, January 2026 downside scenario. |

The three macro workbooks have a `levels` sheet keyed by quarter and a `definitions` sheet with the variable names, units and source information. Historical macro levels come from the six confirmed intake batches. Original column Y is excluded. Scenario levels were transcribed from the supplied spreadsheet photographs at the displayed precision. The script reads these workbooks directly and calculates all changes and lags in Python.

## Research sequence

1. **Sample and trend structure.** The target is the sum of actual revenue in the three months of each quarter. IS is 2011Q1–2023Q3; OOT is the last nine quarters, 2023Q4–2025Q4. The initial equation contains a constant, linear time trend, 2020Q1 slope change and a COVID indicator equal to one in 2020Q1–2020Q4 and zero otherwise.
2. **Stationarity and lag selection.** ADF uses a constant, a four-lag maximum and AIC lag selection. KPSS uses a constant and automatic bandwidth. A transform is eligible when ADF p < 0.05 and KPSS p > 0.05. Levels are tried first; rates use differences, while positive amounts and indices next use log differences. If needed, a first difference is also tried. Eligible macro transforms enter the pool at quarterly lags 1, 2 and 4. AR orders 0–4 are compared by BIC among dynamically stable models on the common IS sample, 2012Q1–2023Q3.
3. **Forward selection.** Each candidate must satisfy added-term Student-t p < 0.05, maximum non-intercept VIF < 10, and 1.5 ≤ DW ≤ 2.5. Among passing candidates, the smallest added-term p enters first; BIC and feature name resolve ties. Only one term per macro family is allowed, with a cap of three macro terms. JB is calculated once at the end of each round for the resulting model and does not determine entry or stopping.
4. **Model simplification.** The selected three-macro equation is estimated on the common IS sample. A reduced equation removes VIX and the 2020Q1 slope-change term. Both parameter tables and the joint-removal F test are reported. The reduced model retains the constant, trend, COVID indicator, AR(1), bank-deposit dlog lag 1 and C&I-loan dlog lag 2. All later diagnostics and forecasts use this reduced equation.
5. **Diagnostics and stability.** Outputs include conventional coefficient t tests and intervals, JB, Durbin–Watson, Breusch–Godfrey, Breusch–Pagan, Ljung–Box where applicable, VIF, influence diagnostics and 20-quarter rolling coefficients. All regression inference uses ordinary nonrobust OLS, without HAC.
6. **OOT evaluation.** IS coefficients remain fixed. One-step predictions use observed lagged target values; recursive predictions use their own prior predictions. Realized lagged macro inputs are used in both designs. Last-observation and seasonal-naive forecasts are included as benchmarks.
7. **Scenario forecasts.** S1 and S4 use fixed IS coefficients and actual 2025Q4 revenue as the starting target. The shared 2025 macro history supplies lagged inputs at the forecast origin. Forecasts span the common scenario coverage, 2026Q1–2028Q1; the additional S4 input quarters remain in its workbook. Scenario differences first affect revenue through the specified macro lags.

## Output files and units

CSV files beginning with `selection_` contain the stationarity screen, AR comparison, candidate trials and round-end diagnostics. Files beginning with `reduced_` contain the two-model IS comparison and final-model diagnostics, rolling coefficients and OOT results. Files beginning with `scenario_` contain scenario levels, transformed inputs and forecasts.

`all_statistics.csv` contains the complete numerical and descriptive statistical results, organized by analysis section and statistic. Dedicated tables include `target_stationarity_tests.csv`, `joint_removal_F_test.csv`, `final_IS_diagnostics.csv` and `rolling_summary.csv`.

Raw target data and internal estimation use USD. Charts and tables whose names end in `million_USD.csv` express revenue in millions of dollars. Non-AR coefficients, standard errors and confidence limits scale with the target; the AR coefficient is unchanged. AIC and BIC on the million-dollar scale equal the USD scores minus `2*n*ln(1e6)`. Macro levels retain source units; dlog is the unscaled natural-log difference, not multiplied by 100. Percentages, p-values, VIF and DW are unchanged by the revenue-unit conversion.

## Figures

| Figure | File | Content |
| --- | --- | --- |
| 1 | `figure_1_trend_residuals.png` | Direct trend fit and residuals |
| 2 | `figure_2_is_refit_comparison.png` | IS fit before and after model simplification |
| 3 | `figure_3_reduced_is_fit.png` | Final two-macro IS fit |
| 4 | `figure_4_rolling_coefficients.png` | Rolling macro coefficients and conventional 95% intervals |
| 5 | `figure_5_oot_predictions.png` | One-step and recursive OOT predictions |
| 6 | `figure_6_macro_paths.png` | S1/S4 macro levels |
| 7 | `figure_7_scenario_forecasts.png` | S1/S4 quarterly revenue forecasts |
