#!/usr/bin/env python3
"""Quarterly deposit fee revenue: OLS ARDL research and scenario forecasts.

Run: python deposit_QTR_actual_ardl.py
Inputs: four Excel .xls workbooks in input/.
Outputs: all figures, coefficient tables, tests and forecasts in output/.
All observations are read from Excel; all estimates are calculated at runtime.
"""
from pathlib import Path
from types import SimpleNamespace
import argparse
import csv
import warnings
import numpy as np
import pandas as pd
import statsmodels
import statsmodels.api as sm
from statsmodels.tsa.stattools import adfuller, kpss
from statsmodels.stats.stattools import durbin_watson, jarque_bera
from statsmodels.stats.diagnostic import acorr_ljungbox, acorr_breusch_godfrey, het_breuschpagan
from statsmodels.stats.outliers_influence import variance_inflation_factor
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from matplotlib.ticker import StrMethodFormatter

SELECTION_PROTOCOL = {
    'fixed_controls': ['const', 'trend', 'H2020', 'covid'],
    'ar_orders': [0, 1, 2, 3, 4],
    'macro_lags': [1, 2, 4],
    'maximum_macro_terms': 3,
    'inference': 'Conventional nonrobust OLS with Student-t p-values; no HAC',
    'stationarity': 'ADF p < 0.05 and KPSS p > 0.05, IS only',
    'forward_entry': 'Added coefficient p < 0.05; max VIF < 10; 1.5 <= DW <= 2.5',
    'forward_ranking': 'Lowest added-term p, then BIC, then feature name',
    'jb_timing': 'Once after each round entry decision; diagnostic only',
}


def read_inputs(input_dir):
    """Read raw historical levels and scenario levels; reject missing or duplicate quarters."""
    target_file = input_dir / 'Quarterly_Target_Data_2011Q1_2025Q4.xls'
    frame = pd.read_excel(target_file, sheet_name='Quarterly_targets', engine='xlrd')
    dates = pd.to_datetime(frame['YYYYMM'].astype(int).astype(str), format='%Y%m')
    target = pd.DataFrame({'y': frame['Quarterly_actual_num'].to_numpy(dtype=float)},
                          index=pd.PeriodIndex(dates, freq='Q'))
    target.index.name = 'quarter'
    def levels(file):
        df = pd.read_excel(file, sheet_name='levels', index_col='quarter', engine='xlrd')
        df.index = pd.PeriodIndex(df.index, freq='Q')
        if df.index.has_duplicates or not df.index.is_monotonic_increasing:
            raise ValueError(f'Quarters must be unique and sorted: {file.name}')
        if not np.isfinite(df.to_numpy(dtype=float)).all():
            raise ValueError(f'Missing or nonnumeric input: {file.name}')
        return df.astype(float)
    macro = levels(input_dir / 'macro_history.xls')
    definitions = pd.read_excel(input_dir / 'macro_history.xls', sheet_name='definitions',
                                engine='xlrd', nrows=33, keep_default_na=False).to_dict('records')
    scenarios = {}
    for label, suffix in [('S1', 'B'), ('S4', 'S4')]:
        frame = levels(input_dir / f'macro_{label}.xls')
        scenarios[label] = frame.rename(columns={
            f'FBBLDPCBQ_{suffix}.IUSA': 'deposits',
            f'FBBABLLICBQ_{suffix}.IUSA': 'ci_loans'})
    if target.index.has_duplicates or not np.isfinite(target.y).all():
        raise ValueError('Target quarters must be unique and observations finite.')
    if not macro.index.equals(pd.period_range('2010Q1', '2025Q4', freq='Q')):
        raise ValueError('Historical macro inputs must cover 2010Q1 through 2025Q4.')
    if set(macro.columns) != {v['mnemonic'] for v in definitions}:
        raise ValueError('Macro definitions must match the historical columns.')
    return {'target': target, 'macro': macro, 'definitions': definitions, 'scenarios': scenarios}

def forward_select(y, features, feature_info, design, baseline, fit, maxvif,
                   maximum_macro_terms):
    selected, trials, path, round_diagnostics = [], [], [], []
    current = baseline
    stop = ''
    for roundno in range(1, maximum_macro_terms + 1):
        used = {feature_info[name]['mnemonic'] for name in selected}
        passing = []
        tried = 0
        # Candidate evaluation deliberately does not compute or consult JB.
        for name in features:
            if feature_info[name]['mnemonic'] in used:
                continue
            x = design(y.index, selected + [name])
            model = fit(y, x)
            p = float(model.pvalues[name])
            vif = maxvif(x)
            dw = float(durbin_watson(model.resid))
            passes = p < .05 and vif < 10 and 1.5 <= dw <= 2.5
            row = dict(round=roundno, feature=name, p=p, max_vif=vif,
                       dw=dw, bic=float(model.bic), passes=passes)
            trials.append(row)
            tried += 1
            if passes:
                passing.append((row, model))

        best = None
        if passing:
            best, current = min(passing, key=lambda pair:
                                (pair[0]['p'], pair[0]['bic'], pair[0]['feature']))
            selected.append(best['feature'])

        # One diagnostic for the resulting model, even if no addition passed.
        # It never changes eligibility, ranking, acceptance or stopping.
        jb_stat, jb_p, skew, kurtosis = jarque_bera(current.resid)
        diagnostic = dict(round=roundno, tried=tried, passed=len(passing),
                          selected_feature=best['feature'] if best else None,
                          status='added' if best else 'no_passing_candidate',
                          jb_stat=float(jb_stat), jb_p=float(jb_p),
                          skewness=float(skew), kurtosis=float(kurtosis))
        round_diagnostics.append(diagnostic)
        if best is None:
            stop = f'No remaining candidate passed all three entry rules in round {roundno}'
            break
        # Copy: adding a round diagnostic must not add JB to the trial row.
        path.append({**best, 'jb_p': diagnostic['jb_p']})
    else:
        stop = f'Prespecified cap of {maximum_macro_terms} macro terms reached'
    return selected, trials, path, round_diagnostics, current, stop


def select_macros(inputs, output_dir, results):
    """1. Trend estimation, AR order selection, stationarity and forward selection."""
    matplotlib.use('Agg')
    protocol = SELECTION_PROTOCOL.copy()
    selection_controls = protocol['fixed_controls']
    df = inputs['target'].copy()
    assert df.index.equals(pd.period_range('2011Q1', '2025Q4', freq='Q'))
    df['const'] = 1.0
    df['trend'] = np.arange(1, 61, dtype=float)
    df['H2020'] = np.maximum(df.trend - 36, 0)
    df['covid'] = (df.index.year == 2020).astype(float)
    controls = selection_controls
    for lag in range(1, 5):
        df[f'AR{lag}'] = df.y.shift(lag)
    train = df.loc[:'2023Q3'].copy()
    assert len(train) == 51 and len(df.loc['2023Q4':]) == 9
    common = train.iloc[4:].copy()
    assert len(common) == 47
    variables = inputs['definitions']
    macro = inputs['macro'].copy()
    assert macro.shape == (64, 33) and (not macro.isna().any().any())
    assert len({v['mnemonic'] for v in variables}) == 33
    df.to_csv(output_dir / 'selection_target_and_controls.csv', index_label='quarter')
    macro.to_csv(output_dir / 'selection_macro_levels.csv', index_label='quarter')

    def fit(y, x):
        assert np.isfinite(x).all().all() and np.isfinite(y).all()
        assert np.linalg.matrix_rank(x / np.linalg.norm(x, axis=0)) == x.shape[1]
        m = sm.OLS(y, x).fit(cov_type='nonrobust', use_t=True)
        assert m.cov_type == 'nonrobust'
        return m

    def diagnostic(m):
        lb = acorr_ljungbox(m.resid, lags=[1, 4, 8], return_df=True)
        with warnings.catch_warnings():
            warnings.simplefilter('ignore', FutureWarning)
            bg1 = acorr_breusch_godfrey(m, nlags=1)[3]
            bg4 = acorr_breusch_godfrey(m, nlags=4)[3]
        return dict(n=int(m.nobs), k=len(m.params), r2=m.rsquared, adj_r2=m.rsquared_adj, rmse=float(np.sqrt(np.mean(m.resid ** 2))), mae=float(np.mean(abs(m.resid))), aic=m.aic, bic=m.bic, dw=float(durbin_watson(m.resid)), jb_p=float(jarque_bera(m.resid)[1]), bp_f_p=float(het_breuschpagan(m.resid, m.model.exog)[3]), bg1_p=float(bg1), bg4_p=float(bg4), **{f'lb{l}_p': float(lb.loc[l, 'lb_pvalue']) for l in [1, 4, 8]})

    def coefficients(m):
        ci = m.conf_int()
        return [dict(term=t, coef=float(m.params[t]), se=float(m.bse[t]), t=float(m.tvalues[t]), p=float(m.pvalues[t]), low=float(ci.loc[t, 0]), high=float(ci.loc[t, 1])) for t in m.params.index]

    def tests(x, adf_reg='c', kpss_reg='c'):
        a = np.asarray(x, float)
        a = a[np.isfinite(a)]
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter('always')
            ad = adfuller(a, maxlag=4, regression=adf_reg, autolag='AIC')
            kp = kpss(a, regression=kpss_reg, nlags='auto')
        bound = '>' if kp[1] == 0.1 else '<' if kp[1] == 0.01 else ''
        return dict(n=len(a), adf_stat=float(ad[0]), adf_p=float(ad[1]), adf_lag=int(ad[2]), adf_n=int(ad[3]), kpss_stat=float(kp[0]), kpss_p=float(kp[1]), kpss_bound=bound, kpss_lag=int(kp[2]), eligible=bool(ad[1] < 0.05 and kp[1] > 0.05))
    trend = fit(train.y, train[controls])
    trend_tests = tests(trend.resid, 'n')
    pre = train.loc[:'2019Q4', 'y']
    pre_tests = {r: tests(pre, r, r) for r in ['c', 'ct']}
    ar_models = {}
    ar_rows = []
    for p in protocol['ar_orders']:
        m = fit(common.y, common[controls + [f'AR{i}' for i in range(1, p + 1)]])
        roots = np.roots([1] + [-m.params[f'AR{i}'] for i in range(1, p + 1)]) if p else []
        radius = float(max(abs(np.asarray(roots)))) if p else 0.0
        ar_models[p] = m
        ar_rows.append(dict(order=p, spectral_radius=radius, stable=radius < 1, **diagnostic(m)))
    chosen_p = min((r for r in ar_rows if r['stable']), key=lambda r: (r['bic'], r['order']))['order']
    base_terms = controls + [f'AR{i}' for i in range(1, chosen_p + 1)]
    baseline = ar_models[chosen_p]
    pd.DataFrame(ar_rows).to_csv(output_dir / 'selection_ar_comparison.csv', index=False)
    stationarity = []
    screen = []
    features = pd.DataFrame(index=macro.index)
    feature_info = {}
    for v in variables:
        key = v['mnemonic']
        s = macro[key]
        is_rate = '%' in v['units'] or 'Percentage points' in v['units']
        positive = bool((s.loc[:'2023Q3'] > 0).all())
        order = ['level', 'diff'] if is_rate or not positive else ['level', 'dlog', 'diff']
        selected_transform = None
        for transform in order:
            if transform == 'level':
                z = s.copy()
            elif transform == 'diff':
                z = s.diff()
            else:
                z = np.log(s.where(s > 0)).diff()
            t = tests(z.loc['2011Q1':'2023Q3'])
            stationarity.append(dict(mnemonic=key, transform=transform, **t))
            if t['eligible']:
                selected_transform = transform
                for lag in protocol['macro_lags']:
                    name = f'{key}__{transform}__L{lag}'
                    features[name] = z.shift(lag)
                    feature_info[name] = {**v, 'transform': transform, 'lag': lag}
                break
        screen.append(dict(**v, chosen_transform=selected_transform, **t))
    pd.DataFrame(stationarity).to_csv(output_dir / 'selection_macro_stationarity_trials.csv', index=False)
    pd.DataFrame(screen).to_csv(output_dir / 'selection_macro_screen.csv', index=False)
    features = features.reindex(df.index)
    assert not features.loc[common.index].isna().any().any()

    def maxvif(x):
        z = x.copy()
        for col in z:
            if col != 'const':
                z[col] = (z[col] - z[col].mean()) / z[col].std()
        return float(max((variance_inflation_factor(z.to_numpy(), i) for i in range(1, z.shape[1]))))

    def design(index, terms):
        return pd.concat([df.loc[index, base_terms], features.loc[index, terms]], axis=1)
    (selected, trials, path, round_diagnostics, current, stop) = forward_select(common.y, features, feature_info, design, baseline, fit, maxvif, protocol['maximum_macro_terms'])
    final = current
    pd.DataFrame(trials).to_csv(output_dir / 'selection_selection_trials.csv', index=False)
    pd.DataFrame(path).to_csv(output_dir / 'selection_selection_path.csv', index=False)
    pd.DataFrame(round_diagnostics).to_csv(output_dir / 'selection_selection_round_diagnostics.csv', index=False)
    frozen = {k: float(v) for (k, v) in final.params.items()}
    results['selection_frozen_is_model'] = dict(ar_order=chosen_p, terms=selected, coefficients=frozen, training_end='2023Q3')
    post = trend.t_test([0, 1, 1, 0])
    ci = post.conf_int()[0]
    result = dict(protocol=protocol, trend=dict(coefficients=coefficients(trend), metrics=diagnostic(trend), tests=trend_tests, post_break_slope=dict(coef=float(np.asarray(post.effect).item()), se=float(np.asarray(post.sd).item()), p=float(post.pvalue), low=float(ci[0]), high=float(ci[1]))), pre_tests=pre_tests, ar_comparison=ar_rows, ar_order=chosen_p, baseline=dict(coefficients=coefficients(baseline), metrics=diagnostic(baseline)), final=dict(coefficients=coefficients(final), metrics=diagnostic(final), max_vif=maxvif(design(common.index, selected))), macro_screen=screen, feature_info={k: feature_info[k] for k in selected}, eligible_variables=sum((r['chosen_transform'] is not None for r in screen)), candidate_terms=len(features.columns), selected=selected, selection_path=path, selection_round_diagnostics=round_diagnostics, stop=stop, software=statsmodels.__version__)
    results['selection_analysis_results'] = result
    influence = final.get_influence()
    pd.DataFrame({'quarter': common.index.astype(str), 'residual': final.resid.to_numpy(), 'studentized_residual': influence.resid_studentized_internal, 'cooks_distance': influence.cooks_distance[0]}).to_csv(output_dir / 'selection_influence_diagnostics.csv', index=False)


def fit_reduced_model(inputs, output_dir, results):
    """2. Estimate the three-macro equation and the reduced two-macro equation on the same IS sample."""
    matplotlib.use('Agg')
    target_path = output_dir / 'selection_target_and_controls.csv'
    macro_path = output_dir / 'selection_macro_levels.csv'
    target = pd.read_csv(target_path, index_col='quarter')
    target.index = pd.PeriodIndex(target.index, freq='Q')
    target = target.loc[:'2023Q3']
    selection = results['selection_analysis_results']
    macro = pd.read_csv(macro_path, index_col='quarter')
    macro.index = pd.PeriodIndex(macro.index, freq='Q')
    macro = macro.loc[:'2023Q3']
    data = target.loc['2012Q1':'2023Q3'].copy()
    aliases = {'FBBLDPCBQ_B.IUSA__dlog__L1': 'deposits_dlog_L1', 'FBBABLLICBQ_B.IUSA__dlog__L2': 'ci_loans_dlog_L2', 'FCBOEVIXQ_B.IUSA__level__L2': 'vix_L2'}
    macro_terms = []
    for feature in selection['selected']:
        spec = selection['feature_info'][feature]
        series = macro[spec['mnemonic']]
        if spec['transform'] == 'dlog':
            series = np.log(series).diff()
        elif spec['transform'] == 'diff':
            series = series.diff()
        name = aliases.get(feature, feature)
        data[name] = series.shift(spec['lag'])
        macro_terms.append(name)
    full_terms = ['const', 'trend', 'H2020', 'covid'] + [f'AR{i}' for i in range(1, selection['ar_order'] + 1)] + macro_terms
    reduced_terms = [t for t in full_terms if t not in ['H2020', 'vix_L2']]
    assert len(data) == 47 and (not data[full_terms + ['y']].isna().any().any())
    assert str(data.index[-1]) == '2023Q3'
    assert data.loc['2021Q1', 'covid'] == 0 and data.covid.sum() == 4
    models = {}
    coefficients = []
    metrics = []
    for (name, terms) in [('full_three_macro', full_terms), ('without_vix_and_break', reduced_terms)]:
        x = data[terms]
        assert np.linalg.matrix_rank(x / np.linalg.norm(x, axis=0)) == len(terms)
        m = sm.OLS(data.y, x).fit(cov_type='nonrobust', use_t=True)
        models[name] = m
        ci = m.conf_int()
        for term in terms:
            coefficients.append(dict(model=name, term=term, coefficient=float(m.params[term]), se=float(m.bse[term]), t=float(m.tvalues[term]), p=float(m.pvalues[term]), ci_low=float(ci.loc[term, 0]), ci_high=float(ci.loc[term, 1])))
        z = x.copy()
        for col in z:
            if col != 'const':
                z[col] = (z[col] - z[col].mean()) / z[col].std()
        with warnings.catch_warnings():
            warnings.simplefilter('ignore', FutureWarning)
            bg1 = acorr_breusch_godfrey(m, nlags=1)[3]
            bg4 = acorr_breusch_godfrey(m, nlags=4)[3]
        jb = jarque_bera(m.resid)
        metrics.append(dict(model=name, n=int(m.nobs), k=len(terms), df_resid=int(m.df_resid), r2=float(m.rsquared), adjusted_r2=float(m.rsquared_adj), rmse=float(np.sqrt(np.mean(m.resid ** 2))), mae=float(np.mean(abs(m.resid))), aic=float(m.aic), bic=float(m.bic), dw=float(durbin_watson(m.resid)), jb_p=float(jb[1]), skewness=float(jb[2]), kurtosis=float(jb[3]), bg1_f_p=float(bg1), bg4_f_p=float(bg4), bp_f_p=float(het_breuschpagan(m.resid, x)[3]), max_vif=float(max((variance_inflation_factor(z.to_numpy(), i) for i in range(1, len(terms)))))))
    (full, reduced) = models.values()
    (f_stat, f_p, f_df) = full.compare_f_test(reduced)
    assert np.sum(full.resid ** 2) <= np.sum(reduced.resid ** 2)
    result = dict(experiment='IS model simplification: remove VIX and the 2020Q1 slope-change term', estimation_period=['2012Q1', '2023Q3'], n=47, retained_terms=reduced_terms, removed_terms=['vix_L2', 'H2020'], inference='Conventional nonrobust OLS; no HAC', variable_selection_rerun=False, oot_evaluated=False, target='Quarterly actual num', definitions={'trend': '2011Q1=1, increases by one each quarter', 'covid': '2020Q1-Q4=1; otherwise 0', 'deposits_dlog_L1': 'ln(deposits[t-1])-ln(deposits[t-2])', 'ci_loans_dlog_L2': 'ln(C&I loans[t-2])-ln(C&I loans[t-3])'}, coefficients=coefficients, metrics=metrics, joint_removal_f_test={'null': 'H2020 and VIX coefficients jointly zero', 'f_statistic': float(f_stat), 'p': float(f_p), 'df_num': int(f_df), 'df_denom': int(full.df_resid)})
    pd.DataFrame(coefficients).to_csv(output_dir / 'reduced_is_coefficients.csv', index=False)
    pd.DataFrame(metrics).to_csv(output_dir / 'reduced_is_model_comparison.csv', index=False)
    data[['y'] + reduced_terms].to_csv(output_dir / 'reduced_is_design_data.csv', index_label='quarter')
    fits = pd.DataFrame({'actual': data.y}, index=data.index)
    for (name, m) in models.items():
        fits[name + '_fitted'] = m.fittedvalues
        fits[name + '_residual'] = m.resid
    fits.to_csv(output_dir / 'reduced_is_fitted_and_residuals.csv', index_label='quarter')
    results['reduced_analysis_results'] = result


def evaluate_model(inputs, output_dir, results):
    """3. Final-model residual diagnostics, rolling estimates and fixed-coefficient OOT evaluation."""
    matplotlib.use('Agg')
    old = results['reduced_analysis_results']
    df = pd.read_csv(output_dir / 'selection_target_and_controls.csv', index_col='quarter')
    df.index = pd.PeriodIndex(df.index, freq='Q')
    macro = pd.read_csv(output_dir / 'selection_macro_levels.csv', usecols=['quarter', 'FBBLDPCBQ_B.IUSA', 'FBBABLLICBQ_B.IUSA'], index_col='quarter')
    macro.index = pd.PeriodIndex(macro.index, freq='Q')
    df['deposits_dlog_L1'] = np.log(macro['FBBLDPCBQ_B.IUSA']).diff().shift(1)
    df['ci_loans_dlog_L2'] = np.log(macro['FBBABLLICBQ_B.IUSA']).diff().shift(2)
    terms = ['const', 'trend', 'covid', 'AR1', 'deposits_dlog_L1', 'ci_loans_dlog_L2']
    macros = terms[-2:]
    train = df.loc['2012Q1':'2023Q3']
    oot = df.loc['2023Q4':'2025Q4']
    assert len(train) == 47 and len(oot) == 9 and (len(df) == 60)
    assert not df.loc['2012Q1':, terms + ['y']].isna().any().any()
    assert df.loc['2021Q1', 'covid'] == 0 and df.covid.sum() == 4
    m = sm.OLS(train.y, train[terms]).fit(cov_type='nonrobust', use_t=True)
    frozen = m.params.to_dict()
    pred = pd.DataFrame({'actual': oot.y, 'macro_one_step': m.predict(oot[terms])}, index=oot.index)
    history = df.y.loc[:'2023Q3'].to_dict()
    recursive = []
    for q in oot.index:
        row = oot.loc[q, terms].copy()
        row['AR1'] = history[q - 1]
        val = float(row @ m.params)
        history[q] = val
        recursive.append(val)
    pred['macro_recursive'] = recursive
    pred['last_observation'] = df.y.shift(1).loc[oot.index]
    pred['seasonal_naive'] = df.y.shift(4).loc[oot.index]
    scores = []
    for (col, model, mode) in [('macro_one_step', 'macro', 'one_step'), ('macro_recursive', 'macro', 'recursive'), ('last_observation', 'last_observation', 'benchmark'), ('seasonal_naive', 'seasonal_naive', 'benchmark')]:
        err = pred[col] - pred.actual
        scores.append(dict(model=model, mode=mode, n=9, rmse=float(np.sqrt(np.mean(err ** 2))), mae=float(np.mean(abs(err))), mape=float(100 * np.mean(abs(err) / pred.actual)), bias=float(err.mean()), underpredicted_quarters=int((err < 0).sum())))
    rolling = []
    skips = []
    for end in range(20, len(train) + 1):
        data = train.iloc[end - 20:end]
        x = data[terms].copy()
        inactive = []
        if (x.covid == 0).all():
            x = x.drop(columns='covid')
            inactive = ['covid']
        if np.linalg.matrix_rank(x / np.linalg.norm(x, axis=0)) < x.shape[1]:
            skips.append(str(data.index[-1]))
            continue
        fit = sm.OLS(data.y, x).fit(cov_type='nonrobust', use_t=True)
        ci = fit.conf_int()
        for t in fit.params.index:
            rolling.append(dict(start=str(data.index[0]), end=str(data.index[-1]), term=t, coef=float(fit.params[t]), se=float(fit.bse[t]), p=float(fit.pvalues[t]), low=float(ci.loc[t, 0]), high=float(ci.loc[t, 1]), inactive_controls=','.join(inactive)))
    summary = []
    for t in macros:
        rows = [v for v in rolling if v['term'] == t]
        summary.append(dict(term=t, windows=len(rows), same_sign_pct=100 * np.mean([np.sign(v['coef']) == np.sign(m.params[t]) for v in rows]), significant_pct=100 * np.mean([v['p'] < 0.05 for v in rows]), reference_in_ci_pct=100 * np.mean([v['low'] <= m.params[t] <= v['high'] for v in rows])))
    assert len(summary) == 2 and all((x['windows'] == 28 for x in summary)) and (skips == [])
    infl = m.get_influence()
    influence = pd.DataFrame({'residual': m.resid, 'studentized_residual': infl.resid_studentized_internal, 'cooks_distance': infl.cooks_distance[0]}, index=train.index)
    metrics = old['metrics'][1]
    result = dict(model='Reduced two macro model without VIX or trend break', terms=terms, estimation_period=['2012Q1', '2023Q3'], n=47, oot_period=['2023Q4', '2025Q4'], inference='Conventional nonrobust OLS; no HAC', is_metrics=metrics, oot_metrics=scores, rolling_summary=summary, rolling_skipped_ends=skips, influence_2020Q2={k: float(v) for (k, v) in influence.loc['2020Q2'].items()})
    results['reduced_evaluation_results'] = result
    results['reduced_frozen_reduced_is_model'] = dict(terms=terms, coefficients=frozen, training_end='2023Q3')
    pred.to_csv(output_dir / 'reduced_oot_predictions.csv', index_label='quarter')
    pd.DataFrame(scores).to_csv(output_dir / 'reduced_oot_metrics.csv', index=False)
    pd.DataFrame(rolling).to_csv(output_dir / 'reduced_rolling_coefficients.csv', index=False)
    influence.to_csv(output_dir / 'reduced_influence_diagnostics.csv', index_label='quarter')
    df[['y'] + terms].to_csv(output_dir / 'reduced_design_all_quarters.csv', index_label='quarter')


def forecast_scenarios(inputs, output_dir, results):
    """4. Recursive S1 and S4 forecasts using the fixed IS model and the common historical bridge."""
    matplotlib.use('Agg')
    frozen = results['reduced_frozen_reduced_is_model']
    co = frozen['coefficients']
    assert set(co) == {'const', 'trend', 'covid', 'AR1', 'deposits_dlog_L1', 'ci_loans_dlog_L2'}
    macro = pd.read_csv(output_dir / 'selection_macro_levels.csv', index_col='quarter')
    macro.index = pd.PeriodIndex(macro.index, freq='Q')
    target = pd.read_csv(output_dir / 'selection_target_and_controls.csv', index_col='quarter')
    target.index = pd.PeriodIndex(target.index, freq='Q')
    start = pd.Period('2026Q1', freq='Q')
    end = pd.Period('2028Q1', freq='Q')
    period = pd.period_range(start, end, freq='Q')
    base_y = float(target.loc['2025Q4', 'y'])
    assert len(period) == 9 and target.loc['2025Q4', 'trend'] == 60
    hist = macro.loc['2025Q2':'2025Q4', ['FBBLDPCBQ_B.IUSA', 'FBBABLLICBQ_B.IUSA']].copy()
    hist.columns = ['deposits', 'ci_loans']
    paths = {}
    rows = []
    for (label, frame) in inputs['scenarios'].items():
        df = frame.loc[period, ['deposits', 'ci_loans']].copy()
        assert df.shape == (9, 2) and (df > 0).all().all()
        paths[label] = df
        joined = pd.concat([hist, df])
        features = pd.DataFrame({'deposits_dlog_L1': np.log(joined.deposits).diff().shift(1), 'ci_loans_dlog_L2': np.log(joined.ci_loans).diff().shift(2)})
        prior = base_y
        for (i, q) in enumerate(period):
            x = {'const': 1.0, 'trend': float(61 + i), 'covid': 0.0, 'AR1': prior, **{c: float(features.loc[q, c]) for c in features.columns}}
            forecast = sum((co[k] * x[k] for k in co))
            rows.append({'quarter': str(q), 'scenario': label, 'forecast': forecast, 'prior_target': prior, **{k: v for (k, v) in x.items() if k not in ['const', 'AR1']}})
            prior = forecast
    pred = pd.DataFrame(rows)
    comparison = pred.pivot(index='quarter', columns='scenario', values='forecast').loc[period.astype(str)]
    comparison['S4_minus_S1'] = comparison.S4 - comparison.S1
    comparison['S4_vs_S1_pct'] = 100 * (comparison.S4 / comparison.S1 - 1)
    pred.to_csv(output_dir / 'scenario_forecast_detail.csv', index=False)
    comparison.to_csv(output_dir / 'scenario_forecast_comparison.csv', index_label='quarter')
    pd.concat(paths, names=['scenario', 'quarter']).to_csv(output_dir / 'scenario_macro_paths.csv')
    summary = {'period': ['2026Q1', '2028Q1'], 'n': 9, 'coefficient_training_end': '2023Q3', 'coefficients_refitted': False, 'initial_target_quarter': '2025Q4', 'initial_target': base_y, 'historical_macro_bridge': {str(q): {c: float(hist.loc[q, c]) for c in hist} for q in hist.index}, 'historical_macro_vintage': 'August 2026', 'scenario_labels': {'S1': 'User-defined alias for Scenario Consistent Baseline, August 2026', 'S4': 'Alternative Scenario 4 - Downside - 96th Percentile, January 2026'}, 'forecast_design': 'Fixed IS coefficients, common 2025 historical bridge, recursive target lags, deterministic conditional forecasts', 'final_quarter': {k: float(v) for (k, v) in comparison.iloc[-1].items()}}
    results['scenario_forecast_summary'] = summary


def generate_figures(inputs, output_dir, results):
    """5. Generate all seven report figures from the calculations in this run."""
    matplotlib.use('Agg')

    def read(path):
        d = pd.read_csv(path, index_col='quarter')
        d.index = pd.PeriodIndex(d.index, freq='Q')
        return d
    plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 10, 'axes.spines.top': False, 'axes.spines.right': False})
    r = results['selection_analysis_results']
    train = read(output_dir / 'selection_target_and_controls.csv').loc[:'2023Q3']
    co = {x['term']: x['coef'] for x in r['trend']['coefficients']}
    yhat = sum((train[k] * v for (k, v) in co.items()))
    trend = SimpleNamespace(fittedvalues=yhat, resid=train.y - yhat)

    def dates(index):
        return index.to_timestamp()

    def style(ax):
        ax.grid(axis='y', alpha=0.2)
        ax.xaxis.set_major_locator(mdates.YearLocator(2))
        ax.xaxis.set_major_formatter(mdates.DateFormatter('%Y'))
    (fig, axes) = plt.subplots(2, 1, figsize=(9, 6), sharex=True, constrained_layout=True)
    axes[0].plot(dates(train.index), train.y / 1000000.0, label='Actual', color='#35566e')
    axes[0].plot(dates(train.index), trend.fittedvalues / 1000000.0, label='IS direct OLS', color='#bd5b24')
    axes[1].plot(dates(train.index), trend.resid / 1000000.0, color='#35566e')
    axes[1].axhline(0, color='gray', lw=0.8)
    for a in axes:
        a.axvspan(pd.Timestamp('2020-01-01'), pd.Timestamp('2021-01-01'), alpha=0.15, color='#bd8c54')
        style(a)
        a.set_ylabel('million $')
    axes[0].legend(frameon=False)
    axes[0].set_title('IS target and fitted deterministic path')
    axes[1].set_title('Unfiltered OLS residuals')
    fig.savefig(output_dir / 'figure_1_trend_residuals.png', dpi=180)
    plt.close(fig)
    fits = read(output_dir / 'reduced_is_fitted_and_residuals.csv')
    train = SimpleNamespace(index=fits.index, y=fits.actual)
    frozen = results['reduced_frozen_reduced_is_model']
    m = SimpleNamespace(fittedvalues=fits.without_vix_and_break_fitted, params=frozen['coefficients'])
    rolling = pd.read_csv(output_dir / 'reduced_rolling_coefficients.csv').to_dict('records')
    macros = ['deposits_dlog_L1', 'ci_loans_dlog_L2']
    pred = read(output_dir / 'reduced_oot_predictions.csv')
    (fig, ax) = plt.subplots(figsize=(9, 4), constrained_layout=True)
    ax.plot(train.index.to_timestamp(), train.y / 1000000.0, label='Actual', color='#222222')
    ax.plot(train.index.to_timestamp(), m.fittedvalues / 1000000.0, label='Two macro model', color='#168a8b')
    ax.legend(frameon=False)
    ax.grid(axis='y', alpha=0.2)
    ax.set_ylabel('million $')
    ax.xaxis.set_major_locator(mdates.YearLocator(2))
    ax.xaxis.set_major_formatter(mdates.DateFormatter('%Y'))
    fig.savefig(output_dir / 'figure_3_reduced_is_fit.png', dpi=180)
    plt.close(fig)
    labels = {'deposits_dlog_L1': 'Bank deposits log change lag 1', 'ci_loans_dlog_L2': 'C&I loans log change lag 2'}
    (fig, axes) = plt.subplots(2, 1, figsize=(9, 6), constrained_layout=True)
    for (ax, t) in zip(axes, macros):
        rows = [v for v in rolling if v['term'] == t]
        dates = pd.PeriodIndex([v['end'] for v in rows], freq='Q').to_timestamp()
        ax.plot(dates, [v['coef'] / 1000000.0 for v in rows], color='#35566e', label='20-quarter rolling estimate')
        ax.fill_between(dates, [v['low'] / 1000000.0 for v in rows], [v['high'] / 1000000.0 for v in rows], color='#35566e', alpha=0.17, label='Conventional 95% CI')
        ax.axhline(m.params[t] / 1000000.0, color='#168a8b', ls='--', label='IS reference')
        ax.axhline(0, color='gray', lw=0.8)
        ax.grid(axis='y', alpha=0.2)
        ax.set_title(labels[t])
        ax.set_ylabel('Coefficient (million $)')
        ax.legend(frameon=False, fontsize=8)
        ax.xaxis.set_major_locator(mdates.YearLocator(2))
        ax.xaxis.set_major_formatter(mdates.DateFormatter('%Y'))
    fig.savefig(output_dir / 'figure_4_rolling_coefficients.png', dpi=180)
    plt.close(fig)
    (fig, axes) = plt.subplots(2, 1, figsize=(9, 6), sharex=True, constrained_layout=True)
    for (ax, mode, title) in zip(axes, ['one_step', 'recursive'], ['Fixed coefficient one step predictions', 'Fixed coefficient recursive target path']):
        for (col, label, color) in [('actual', 'Actual', '#222222'), (f'macro_{mode}', 'Two macro model', '#168a8b')]:
            ax.plot(range(9), pred[col] / 1000000.0, label=label, color=color, marker='o', ms=3)
        ax.set_title(title)
        ax.set_ylabel('million $')
        ax.grid(axis='y', alpha=0.2)
    axes[0].legend(frameon=False)
    axes[1].set_xticks(range(9), [str(q) for q in pred.index], rotation=35)
    fig.savefig(output_dir / 'figure_5_oot_predictions.png', dpi=180)
    plt.close(fig)
    fits = pd.read_csv(output_dir / 'reduced_is_fitted_and_residuals.csv', index_col='quarter')
    dates = pd.PeriodIndex(fits.index, freq='Q').to_timestamp()
    (fig, axes) = plt.subplots(2, 1, figsize=(11, 6.8), sharex=True, gridspec_kw={'height_ratios': [1.6, 1]}, constrained_layout=True)
    axes[0].plot(dates, fits.actual / 1000000.0, label='Actual', color='#202a30', lw=1.9)
    for (name, label, color, ls) in [('full_three_macro', 'Original: 3 macros + trend break', '#9b6c43', '--'), ('without_vix_and_break', 'Reduced: no VIX or trend break', '#157e86', '-')]:
        axes[0].plot(dates, fits[name + '_fitted'] / 1000000.0, label=label, color=color, ls=ls, lw=1.6)
        axes[1].plot(dates, fits[name + '_residual'] / 1000000.0, color=color, ls=ls, lw=1.4)
    axes[0].set_title('In-sample fit after removing VIX and the 2020Q1 trend break', loc='left', fontsize=15)
    axes[0].set_ylabel('Quarterly revenue\n(million $)')
    axes[0].legend(frameon=False, fontsize=9)
    axes[1].axhline(0, color='#606060', lw=0.8)
    axes[1].set_ylabel('Residual\n(million $)')
    axes[1].set_xlabel('Same 47 IS quarters: 2012Q1–2023Q3 | Ordinary OLS')
    for ax in axes:
        ax.grid(axis='y', alpha=0.2)
        ax.xaxis.set_major_locator(mdates.YearLocator(2))
        ax.xaxis.set_major_formatter(mdates.DateFormatter('%Y'))
    fig.savefig(output_dir / 'figure_2_is_refit_comparison.png', dpi=180)
    plt.close(fig)
    paths_frame = pd.read_csv(output_dir / 'scenario_macro_paths.csv')
    paths = {key: g.set_index('quarter')[['deposits', 'ci_loans']] for (key, g) in paths_frame.groupby('scenario')}
    comparison = pd.read_csv(output_dir / 'scenario_forecast_comparison.csv', index_col='quarter')
    period = pd.PeriodIndex(comparison.index, freq='Q')
    x = np.arange(len(period))
    styles = {'S1': ('#35566e', 'o', '-'), 'S4': ('#bd5b24', 's', '--')}
    (fig, axes) = plt.subplots(2, 1, figsize=(9, 6.3), sharex=True, constrained_layout=True)
    for (ax, col, title) in zip(axes, ['deposits', 'ci_loans'], ['Commercial bank deposits', 'Commercial and industrial loans at commercial banks']):
        for (label, frame) in paths.items():
            (color, marker, ls) = styles[label]
            ax.plot(x, frame[col], label=label, color=color, marker=marker, ls=ls, ms=4, lw=1.8)
        ax.set_title(title)
        ax.set_ylabel('USD billions, SA')
        ax.grid(axis='y', alpha=0.2)
        ax.yaxis.set_major_formatter(StrMethodFormatter('{x:,.0f}'))
        ax.legend(frameon=False)
    axes[1].set_xticks(x, period.astype(str), rotation=35)
    fig.savefig(output_dir / 'figure_6_macro_paths.png', dpi=180)
    plt.close(fig)
    (fig, ax) = plt.subplots(figsize=(9, 4.2), constrained_layout=True)
    for label in ['S1', 'S4']:
        (color, marker, ls) = styles[label]
        ax.plot(x, comparison[label] / 1000000.0, label=label, color=color, marker=marker, ls=ls, ms=4, lw=1.9)
    ax.set_title('Quarterly actual deposit fee revenue under S1 and S4')
    ax.set_ylabel('Revenue in million $')
    ax.set_xticks(x, period.astype(str), rotation=35)
    ax.grid(axis='y', alpha=0.2)
    ax.legend(frameon=False)
    fig.savefig(output_dir / 'figure_7_scenario_forecasts.png', dpi=180)
    plt.close(fig)


def export_statistics(output_dir, results):
    """Write the full collection of statistical results as CSV and display revenue in million USD."""
    rows = []
    def flatten(section, key, value):
        if isinstance(value, dict):
            for k, v in value.items():
                flatten(section, f'{key}.{k}' if key else str(k), v)
        elif isinstance(value, (list, tuple)):
            for i, v in enumerate(value):
                flatten(section, f'{key}[{i}]', v)
        else:
            rows.append({'section': section, 'statistic': key, 'value': value})
    for section, values in results.items():
        flatten(section, '', values)
    pd.DataFrame(rows).to_csv(output_dir / 'all_statistics.csv', index=False)
    analysis = results['selection_analysis_results']
    pd.DataFrame(analysis['trend']['coefficients']).to_csv(output_dir / 'trend_coefficients_USD.csv', index=False)
    pd.DataFrame([{'sample': 'IS trend residuals', **analysis['trend']['tests']}] +
                 [{'sample': f'Pre-2020 target ({regression})', **values}
                  for regression, values in analysis['pre_tests'].items()]).to_csv(
                 output_dir / 'target_stationarity_tests.csv', index=False)
    reduced = results['reduced_analysis_results']
    pd.DataFrame([reduced['joint_removal_f_test']]).to_csv(output_dir / 'joint_removal_F_test.csv', index=False)
    evaluation = results['reduced_evaluation_results']
    pd.DataFrame([evaluation['is_metrics']]).to_csv(output_dir / 'final_IS_diagnostics.csv', index=False)
    pd.DataFrame(evaluation['rolling_summary']).to_csv(output_dir / 'rolling_summary.csv', index=False)
    co = pd.read_csv(output_dir / 'reduced_is_coefficients.csv')
    value_cols = ['coefficient', 'se', 'ci_low', 'ci_high']
    # All non-AR coefficients and uncertainty limits scale with the target units.
    mask = ~co['term'].str.startswith('AR')
    co.loc[mask, value_cols] = co.loc[mask, value_cols] / 1e6
    co.to_csv(output_dir / 'IS_coefficients_million_USD.csv', index=False)
    for source, dest, cols in [
        ('scenario_forecast_comparison.csv', 'scenario_forecasts_million_USD.csv', ['S1','S4','S4_minus_S1']),
        ('reduced_oot_predictions.csv', 'OOT_predictions_million_USD.csv', ['actual','macro_one_step','macro_recursive','last_observation','seasonal_naive']),
    ]:
        data = pd.read_csv(output_dir / source)
        data[cols] /= 1e6
        data.to_csv(output_dir / dest, index=False)
    for source, dest in [('reduced_is_model_comparison.csv', 'IS_metrics_million_USD.csv'),
                         ('reduced_oot_metrics.csv', 'OOT_metrics_million_USD.csv')]:
        data = pd.read_csv(output_dir / source)
        for name in ['rmse', 'mae', 'bias']:
            if name in data: data[name] /= 1e6
        for name in ['aic', 'bic']:
            if name in data: data[name] -= 2 * data['n'] * np.log(1e6)
        data.to_csv(output_dir / dest, index=False)
    with (output_dir / 'figure_index.csv').open('w', newline='') as stream:
        writer = csv.writer(stream)
        writer.writerow(['figure', 'file', 'code_function'])
        for i, file in enumerate(sorted(output_dir.glob('figure_*.png')), 1):
            writer.writerow([i, file.name, 'generate_figures'])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    base = Path(__file__).resolve().parent
    parser.add_argument('--input-dir', type=Path, default=base / 'input')
    parser.add_argument('--output-dir', type=Path, default=base / 'output')
    args = parser.parse_args()
    input_dir, output_dir = args.input_dir.resolve(), args.output_dir.resolve()
    if output_dir == input_dir or input_dir in output_dir.parents or output_dir in input_dir.parents:
        parser.error('Input and output must be separate directories.')
    if output_dir.exists() and any(output_dir.iterdir()):
        parser.error('Output directory is not empty. Choose a new directory with --output-dir.')
    inputs = read_inputs(input_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    results = {}
    stages = [select_macros, fit_reduced_model, evaluate_model, forecast_scenarios, generate_figures]
    for i, function in enumerate(stages, 1):
        print(f'[{i}/{len(stages)}] {function.__doc__}', flush=True)
        function(inputs, output_dir, results)
    export_statistics(output_dir, results)
    print(f'Analysis complete. Figures and statistical outputs: {output_dir}')


if __name__ == '__main__':
    main()
