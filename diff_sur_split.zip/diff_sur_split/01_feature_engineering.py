"""
01_feature_engineering.py
Read the deposit input and macro files, build the dependent variables and candidate features,
and save everything to modelsrc.xlsx.

Input : input_1.xlsx (sheet deposit_bal_input), macro.xlsx
Output: output/modelsrc.xlsx
          dependent  – date, YYYYMM, MMA_pct, NOW_pct, NIB_Comm_pct, d_mma, d_now, d_nib_comm
          features   – date + candidate driver columns (D1 / MOM / YOY, lags 1/3/6/12)
          macro_raw  – macro series after renaming (incl. TERM_SPREAD)
          dictionary – one row per feature: variable, transform, lag, definition, source description
          info       – run settings and input file names
"""
import pandas as pd

from config import CONFIG, DEP, PATHS, out_path
from utils import build_features, load_deposits, load_macro, require, setup_logging


def main():
    log = setup_logging("01_feature_engineering")
    require(PATHS["input"], PATHS["macro"])

    dep = load_deposits()
    mac, desc = load_macro()
    feats, dictionary = build_features(mac, desc)
    log.info("Deposit months: %d (%s to %s)", len(dep), dep.index.min().date(), dep.index.max().date())
    log.info("Macro months: %d (%s to %s)", len(mac), mac.index.min().date(), mac.index.max().date())
    log.info("Candidate features: %d", feats.shape[1])

    s, e = CONFIG["est_start"], CONFIG["est_end"]
    n_missing = int(feats.loc[s:e].isna().sum().sum())
    if n_missing:
        log.warning("WARNING: %d missing feature values inside the estimation window %s to %s", n_missing, s, e)
    else:
        log.info("No missing feature values in the estimation window %s to %s", s, e)

    dependent = dep[["YYYYMM"] + list(DEP.values()) + list(DEP.keys())]
    info = pd.DataFrame({"item": ["input_file", "input_sheet", "macro_file", "est_start", "est_end", "lags",
                                  "dependent_definition"],
                         "value": [str(PATHS["input"]), PATHS["input_sheet"], str(PATHS["macro"]),
                                   s, e, str(CONFIG["lags"]), "d_x(t) = x(t) - x(t-1), x = share of total deposits"]})

    path = out_path("modelsrc")
    with pd.ExcelWriter(path) as w:
        dependent.to_excel(w, sheet_name="dependent")
        feats.to_excel(w, sheet_name="features")
        mac.to_excel(w, sheet_name="macro_raw")
        dictionary.to_excel(w, sheet_name="dictionary", index=False)
        info.to_excel(w, sheet_name="info", index=False)
    log.info("Saved %s", path)


if __name__ == "__main__":
    main()
