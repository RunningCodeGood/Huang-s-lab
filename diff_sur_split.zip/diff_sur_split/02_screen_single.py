"""
02_screen_single.py
Exhaustive single-equation OLS screen (HAC standard errors) for each dependent variable.

Model per candidate: dY(t) = a + phi * dY(t-1) + sum beta * x(t-L)
Gates: <= 1 driver per economic family, |corr| <= max_abs_corr, expected signs, |phi| < 1,
       all driver p < p_max, Durbin-Watson within dw_range.
Out-of-time: re-estimated through train_end; recursive forecast of the last 27 months
             (dY(t-1) = own forecast), cumulated to the share level.

Input : output/modelsrc.xlsx
Output: output/candidates.csv (all models passing the gates, with statistics)
"""
import itertools

import numpy as np
import pandas as pd
import statsmodels.api as sm

from config import CONFIG, DEP, EXPECTED_SIGN, FAMILY, out_path
from utils import durbin_watson, read_modelsrc, recursive_level_forecast, root, setup_logging


def screen(dep, X, log):
    s, e, tr_end = CONFIG["est_start"], CONFIG["est_end"], CONFIG["train_end"]
    idx = dep.loc[s:e].index
    cols = list(X.columns)
    Xs = X.loc[idx, cols]
    if Xs.isna().any().any():
        raise SystemExit("Missing feature values in the estimation window; check modelsrc.xlsx")
    C = np.corrcoef(Xs.values.T)
    pos = {c: i for i, c in enumerate(cols)}
    tr = idx <= tr_end
    te = ~tr
    lo, hi = CONFIG["dw_range"]
    rows = []
    for y, lvl in DEP.items():
        Y = dep.loc[idx, y].values
        ylag = dep[y].shift(1).loc[idx].values
        lev_te = dep.loc[idx[te], lvl].values
        y0, dy0 = dep.loc[tr_end, lvl], dep.loc[tr_end, y]
        n_t = n_s = n_dw = 0
        for k in range(1, CONFIG["max_vars"] + 1):
            for combo in itertools.combinations(cols, k):
                fams = [FAMILY[root(c)] for c in combo]
                if len(set(fams)) < k:
                    continue
                if k > 1 and any(abs(C[pos[a], pos[b]]) > CONFIG["max_abs_corr"]
                                 for a, b in itertools.combinations(combo, 2)):
                    continue
                Xc = Xs[list(combo)].values
                Z = np.column_stack([np.ones(len(Y)), ylag, Xc])
                beta = np.linalg.lstsq(Z, Y, rcond=None)[0]
                if not abs(beta[1]) < 1:
                    continue
                if any(EXPECTED_SIGN[y].get(root(c), 0) and np.sign(beta[2 + i]) != EXPECTED_SIGN[y][root(c)]
                       for i, c in enumerate(combo)):
                    continue
                n_t += 1
                f = sm.OLS(Y, Z).fit(cov_type="HAC", cov_kwds={"maxlags": CONFIG["hac_lags"]})
                if (f.pvalues[2:] >= CONFIG["p_max"]).any():
                    continue
                n_s += 1
                dw = durbin_watson(f.resid)
                if not lo <= dw <= hi:
                    continue
                n_dw += 1
                bt = np.linalg.lstsq(Z[tr], Y[tr], rcond=None)[0]
                lv, _ = recursive_level_forecast(bt, Xc[te], y0, dy0)
                el = lev_te - lv
                rows.append(dict(dep=y, n_vars=k, drivers=" + ".join(combo),
                                 adj_r2=f.rsquared_adj, phi=f.params[1], phi_p=f.pvalues[1],
                                 max_p=f.pvalues[2:].max(), dw=dw,
                                 oot_rmse_lvl=np.sqrt(np.mean(el ** 2)), oot_bias_lvl=el.mean(),
                                 oot_rmse_lvl9=np.sqrt(np.mean(el[:CONFIG["first_window"]] ** 2)),
                                 coefs=", ".join(f"{c}={b:+.6f}" for c, b in zip(combo, f.params[2:]))))
        log.info("%-11s sign/phi-consistent: %d | significant: %d | DW pass: %d", y, n_t, n_s, n_dw)
    return pd.DataFrame(rows)


def main():
    log = setup_logging("02_screen_single")
    dep, X = read_modelsrc()
    log.info("Features: %d | estimation window %s to %s | train through %s",
             X.shape[1], CONFIG["est_start"], CONFIG["est_end"], CONFIG["train_end"])
    cands = screen(dep, X, log)
    path = out_path("candidates")
    cands.to_csv(path, index=False)
    log.info("Saved %s (%d models)", path, len(cands))


if __name__ == "__main__":
    main()
