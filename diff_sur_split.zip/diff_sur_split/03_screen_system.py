"""
03_screen_system.py
System-level screen with SUR feasible GLS and model selection.

1. Take the best sys_top_n single-equation models per equation (by OOT level RMSE) from candidates.csv
   and form all combinations as candidate systems (20^3 = 8,000 by default).
2. Estimate every system by SUR-GLS (HAC Bartlett). Re-check the gates on the GLS estimates:
   driver p < p_max, expected signs, |phi| < 1, Durbin-Watson within dw_range.
3. Out-of-time: SUR-GLS re-estimated through train_end, recursive 27-month level forecast;
   system score = mean of the three equation RMSEs.
4. Selection: best top_n_oot systems by score -> fewest drivers -> highest mean R2.

Input : output/modelsrc.xlsx, output/candidates.csv
Output: output/systems.csv (passing systems; in_pool / selected flags)
        output/selected_spec.json (selected drivers; can be edited by hand to override)
"""
import itertools
import json

import numpy as np
import pandas as pd

from config import CONFIG, DEP, EXPECTED_SIGN, out_path
from utils import design, durbin_watson, fit_sur, read_modelsrc, require, root, setup_logging, system_oot


def equation_gate(res, y, Z):
    drivers = [n for n in Z.columns if n not in ("const", "DY_LAG1")]
    b, p = res.params, res.pvalues
    if any(p[f"{y}_{n}"] >= CONFIG["p_max"] for n in drivers):
        return "p"
    if any(EXPECTED_SIGN[y].get(root(n), 0) and np.sign(b[f"{y}_{n}"]) != EXPECTED_SIGN[y][root(n)] for n in drivers):
        return "sign"
    if not abs(b[f"{y}_DY_LAG1"]) < 1:
        return "phi"
    lo, hi = CONFIG["dw_range"]
    if not lo <= durbin_watson(res.resids[y].values) <= hi:
        return "dw"
    return None


def system_screen(dep, X, cands, log):
    s, e, t = CONFIG["est_start"], CONFIG["est_end"], CONFIG["train_end"]
    pools = {y: cands[cands.dep == y].nsmallest(CONFIG["sys_top_n"], "oot_rmse_lvl") for y in DEP}
    for y in DEP:
        if pools[y].empty:
            raise SystemExit(f"No single-equation candidate for {y}")
    dz = {y: {d: design(dep, X, y, d.split(" + "), s, e) for d in pools[y].drivers} for y in DEP}
    fail = dict(p=0, sign=0, phi=0, dw=0)
    rows = []
    for combo in itertools.product(*[list(pools[y].drivers) for y in DEP]):
        eqs = {y: {"dependent": dep.loc[s:e, y], "exog": dz[y][d]} for y, d in zip(DEP, combo)}
        g = fit_sur(eqs)
        why = next((w for w in (equation_gate(g, y, dz[y][d]) for y, d in zip(DEP, combo)) if w), None)
        if why:
            fail[why] += 1
            continue
        gt = fit_sur({y: {"dependent": dep.loc[s:t, y], "exog": dz[y][d].loc[:t]} for y, d in zip(DEP, combo)},
                     hac=False)
        row = dict(n_vars=sum(len(d.split(" + ")) for d in combo))
        rm, r2 = [], []
        for y, d in zip(DEP, combo):
            names = list(dz[y][d].columns)
            m, _ = system_oot(dep, X, y, d.split(" + "), {n: gt.params[f"{y}_{n}"] for n in names})
            r = g.resids[y].values
            yy = dep.loc[s:e, y]
            r2.append(1 - (r ** 2).sum() / ((yy - yy.mean()) ** 2).sum())
            rm.append(m["rmse"])
            row.update({f"{y}__drivers": d, f"{y}__phi": float(g.params[f"{y}_DY_LAG1"]),
                        f"{y}__dw": durbin_watson(r), f"{y}__r2": r2[-1],
                        f"{y}__oot_rmse": m["rmse"], f"{y}__oot_bias": m["bias"]})
        row["oot_mean"], row["r2_mean"] = float(np.mean(rm)), float(np.mean(r2))
        rows.append(row)
    n_sys = int(np.prod([len(pools[y]) for y in DEP]))
    log.info("Systems estimated: %d | first failing gate: %s | pass: %d", n_sys, fail, len(rows))
    return pd.DataFrame(rows), fail, n_sys


def main():
    log = setup_logging("03_screen_system")
    require(out_path("candidates"))
    dep, X = read_modelsrc()
    cands = pd.read_csv(out_path("candidates"))
    sys_df, fail, n_sys = system_screen(dep, X, cands, log)
    if sys_df.empty:
        raise SystemExit("No system passes the gates under SUR-GLS.")

    pool = sys_df.nsmallest(CONFIG["top_n_oot"], "oot_mean")
    best_id = pool.sort_values(["n_vars", "r2_mean"], ascending=[True, False]).index[0]
    best = sys_df.loc[best_id]
    spec = {y: best[f"{y}__drivers"].split(" + ") for y in DEP}

    sys_df.assign(in_pool=sys_df.index.isin(pool.index), selected=sys_df.index == best_id) \
          .sort_values("oot_mean").to_csv(out_path("systems"), index=False)
    with open(out_path("selected_spec"), "w") as f:
        json.dump(dict(spec=spec, rule="best %d by mean OOT level RMSE -> fewest drivers -> highest mean R2"
                       % CONFIG["top_n_oot"], systems_estimated=n_sys, systems_passing=len(sys_df),
                       first_failing_gate=fail, oot_mean=float(best.oot_mean), r2_mean=float(best.r2_mean)),
                  f, indent=2)
    log.info("Pool:\n%s", pool[["n_vars", "oot_mean", "r2_mean"] + [f"{y}__drivers" for y in DEP]].round(4).to_string())
    log.info("Selected: %s", spec)
    log.info("Saved %s and %s", out_path("systems"), out_path("selected_spec"))


if __name__ == "__main__":
    main()
