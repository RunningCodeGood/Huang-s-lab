"""
04_estimate.py
Final SUR feasible GLS estimation of the selected system and diagnostics.

Input : output/modelsrc.xlsx, output/selected_spec.json
Output: output/coefficients.csv – coefficient, s.e., t, p (full sample), training-sample coefficient,
                                  long-run effect beta / (1 - phi)
        output/fitted.csv       – actual and fitted dY
        output/backtest.csv     – out-of-time recursive level forecast (training coefficients) vs actual
        output/diagnostics.json – R2, DW, Breusch-Godfrey (reported only), OOT metrics,
                                  residual correlation, Breusch-Pagan LM, Hausman (reported only)
        output/04_estimate.log  – full SUR summary
"""
import json

import pandas as pd
from scipy.stats import chi2

from config import CONFIG, DEP, out_path
from utils import (bg_test, design, durbin_watson, fit_sur, hausman, read_modelsrc, read_spec,
                   setup_logging, system_oot)


def main():
    log = setup_logging("04_estimate")
    dep, X = read_modelsrc()
    spec = read_spec()
    log.info("Specification: %s", spec)
    s, e, t = CONFIG["est_start"], CONFIG["est_end"], CONFIG["train_end"]

    eqs = {y: {"dependent": dep.loc[s:e, y], "exog": design(dep, X, y, c, s, e)} for y, c in spec.items()}
    res = fit_sur(eqs)
    res_tr = fit_sur({y: {"dependent": dep.loc[s:t, y], "exog": design(dep, X, y, c, s, t)}
                      for y, c in spec.items()}, hac=False)
    log.info("%s", res.summary)

    rc = res.resids.corr()
    T = len(res.resids)
    keys = list(spec)
    lm = T * sum(rc.loc[a, b] ** 2 for i, a in enumerate(keys) for b in keys[i + 1:])
    bp_p = float(chi2.sf(lm, len(keys) * (len(keys) - 1) // 2))
    H = hausman(eqs)
    diag = dict(sample=[s, e], train_end=t, observations=T, residual_correlation=rc.round(6).to_dict(),
                breusch_pagan_lm=float(lm), breusch_pagan_p=bp_p,
                hausman=dict(stat=H[0], df=H[1], p=H[2], note="reported only"), equations={})
    log.info("Residual correlation:\n%s", rc.round(3))
    log.info("Breusch-Pagan LM = %.2f, p = %.2e | Hausman H = %.2f, df = %d, p = %.4f (reported only)",
             lm, bp_p, *H)

    coef_rows, fitted, backtest = [], {}, {}
    for y, c in spec.items():
        Z = eqs[y]["exog"]
        names = list(Z.columns)
        r = res.resids[y].values
        yy = dep.loc[s:e, y]
        phi = float(res.params[f"{y}_DY_LAG1"])
        m, path = system_oot(dep, X, y, c, {n: res_tr.params[f"{y}_{n}"] for n in names})
        bg = {L: bg_test(r, Z.values, L) for L in CONFIG["bg_report_lags"]}
        r2 = float(1 - (r ** 2).sum() / ((yy - yy.mean()) ** 2).sum())
        diag["equations"][y] = dict(drivers=c, r2=r2, durbin_watson=durbin_watson(r), phi=phi,
                                    breusch_godfrey_p=bg, oot_level=m)
        log.info("%-11s R2=%.3f DW=%.2f phi=%.3f BG p=%s | OOT level RMSE=%.4f bias=%+.4f first9=%.4f",
                 y, r2, durbin_watson(r), phi, {k: round(v, 3) for k, v in bg.items()},
                 m["rmse"], m["bias"], m["rmse9"])
        for n in names:
            pn = f"{y}_{n}"
            coef_rows.append(dict(equation=y, variable=n, coef=res.params[pn], se=res.std_errors[pn],
                                  t=res.tstats[pn], p=res.pvalues[pn], coef_train=res_tr.params[pn],
                                  long_run=(res.params[pn] / (1 - phi)) if n not in ("const", "DY_LAG1") else None))
        fitted[f"{y}_actual"] = yy
        fitted[f"{y}_fitted"] = yy - res.resids[y]
        backtest[f"{DEP[y]}_actual"] = dep.loc[path.index, DEP[y]]
        backtest[f"{DEP[y]}_forecast"] = path

    pd.DataFrame(coef_rows).to_csv(out_path("coefficients"), index=False)
    pd.DataFrame(fitted).rename_axis("date").to_csv(out_path("fitted"))
    pd.DataFrame(backtest).rename_axis("date").to_csv(out_path("backtest"))
    with open(out_path("diagnostics"), "w") as f:
        json.dump(diag, f, indent=2, default=float)
    log.info("Saved coefficients, fitted, backtest and diagnostics to %s", out_path("coefficients").parent)


if __name__ == "__main__":
    main()
