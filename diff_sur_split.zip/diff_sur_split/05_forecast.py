"""
05_forecast.py
Scenario projections with the estimated SUR coefficients.

Each scenario file must have the same layout as macro.xlsx (column A dates, row 1 mnemonics,
row 2 descriptions) and contain history plus the scenario months, so that differences, growth rates
and lags can be computed. Features are rebuilt with the same function used in step 01.

Projection starts the month after the last observed deposit month. dY(t-1) is the last observed
change for the first month and the model's own projection afterwards; levels are cumulated from the
last observed share. Projection stops at the first month with a missing feature.

Usage
    python 05_forecast.py --scenario baseline=macro_baseline.xlsx --scenario severe=macro_severe.xlsx
    python 05_forecast.py                      # uses macro.xlsx as a single "base" scenario

Input : output/modelsrc.xlsx, output/coefficients.csv, scenario macro file(s)
Output: output/forecast.xlsx (one sheet per scenario + a summary sheet)
"""
import argparse
from pathlib import Path

import numpy as np
import pandas as pd

from config import DEP, PATHS, out_path
from utils import build_features, load_macro, read_modelsrc, require, setup_logging


def project(dep, feats, coefs, horizon_end=None):
    last = dep.index.max()
    out = {}
    for y, lvl in DEP.items():
        c = coefs[coefs.equation == y].set_index("variable")["coef"]
        drivers = [n for n in c.index if n not in ("const", "DY_LAG1")]
        missing = [d for d in drivers if d not in feats.columns]
        if missing:
            raise SystemExit(f"Scenario features missing for {y}: {missing}")
        future = feats.loc[last + pd.offsets.MonthEnd(1):horizon_end, drivers]
        ok = future.notna().all(axis=1).values
        if not ok.all():
            future = future.iloc[:int(np.argmin(ok))]   # stop at the first month with a missing feature
        prev, lev = dep.loc[last, y], dep.loc[last, lvl]
        d_path, l_path = [], []
        for _, row in future.iterrows():
            d = c["const"] + c["DY_LAG1"] * prev + float(row.values @ c[drivers].values)
            prev, lev = d, lev + d
            d_path.append(d)
            l_path.append(lev)
        out[f"{y}"] = pd.Series(d_path, index=future.index)
        out[f"{lvl}"] = pd.Series(l_path, index=future.index)
    return pd.DataFrame(out).rename_axis("date")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--scenario", action="append", default=[],
                    help="name=path to a scenario macro file (repeatable)")
    ap.add_argument("--end", default=None, help="last projection month, e.g. 2028-03-31")
    args = ap.parse_args()
    log = setup_logging("05_forecast")
    require(out_path("coefficients"))
    dep, _ = read_modelsrc()
    coefs = pd.read_csv(out_path("coefficients"))

    scen = dict(s.split("=", 1) for s in args.scenario) or {"base": str(PATHS["macro"])}
    summary = []
    path = out_path("forecast")
    with pd.ExcelWriter(path) as w:
        for name, f in scen.items():
            require(Path(f))
            mac, desc = load_macro(f)
            feats, _ = build_features(mac, desc)
            proj = project(dep, feats, coefs, args.end)
            proj.to_excel(w, sheet_name=name[:31])
            if proj.empty:
                log.info("%s: no projection months (scenario data do not extend past %s)", name, dep.index.max().date())
            else:
                log.info("%s: projected %s to %s", name, proj.index.min().date(), proj.index.max().date())
                for lvl in DEP.values():
                    summary.append(dict(scenario=name, share=lvl, start=dep[lvl].iloc[-1],
                                        end=proj[lvl].iloc[-1], change=proj[lvl].iloc[-1] - dep[lvl].iloc[-1],
                                        months=len(proj)))
        pd.DataFrame(summary).to_excel(w, sheet_name="summary", index=False)
    log.info("Saved %s", path)


if __name__ == "__main__":
    main()
