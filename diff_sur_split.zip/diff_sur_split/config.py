"""
config.py – all parameters, rules and file names for the differenced-share SUR model.
Every other script imports from here; change settings in this file only.
"""
from pathlib import Path

# -----------------------------------------------------------------------------
# File locations (relative to the folder the scripts are run from)
# -----------------------------------------------------------------------------
PATHS = {
    "input": Path("input_1.xlsx"),             # deposit shares, sheet "deposit_bal_input"
    "input_sheet": "deposit_bal_input",
    "macro": Path("macro.xlsx"),               # macro history (row 1 mnemonics, row 2 descriptions)
    "outdir": Path("output"),
    "modelsrc": "modelsrc.xlsx",               # 01 -> dependent variables + candidate features + dictionary
    "candidates": "candidates.csv",            # 02 -> single-equation screen
    "systems": "systems.csv",                  # 03 -> systems passing the SUR-GLS gates
    "selected_spec": "selected_spec.json",     # 03 -> selected drivers (edit by hand to override)
    "coefficients": "coefficients.csv",        # 04 -> final SUR-GLS estimates
    "fitted": "fitted.csv",                    # 04 -> in-sample fitted dY
    "backtest": "backtest.csv",                # 04 -> out-of-time recursive level forecast
    "diagnostics": "diagnostics.json",         # 04 -> summary statistics
    "forecast": "forecast.xlsx",               # 05 -> scenario projections
}

# -----------------------------------------------------------------------------
# Modeling settings
# -----------------------------------------------------------------------------
CONFIG = {
    "est_start": "2013-01-31",   # every candidate available (YoY lagged 12 needs 24 months)
    "est_end": "2025-12-31",
    "train_end": "2023-09-30",   # out-of-time: last 27 months (9 CCAR quarters)
    "lags": [1, 3, 6, 12],
    "hac_lags": 12,              # Bartlett bandwidth
    "max_vars": 3,               # macro drivers per equation
    "p_max": 0.05,               # driver HAC p-value gate
    "max_abs_corr": 0.70,        # pairwise driver correlation gate
    "dw_range": (1.5, 2.5),      # Durbin-Watson gate
    "sys_top_n": 20,             # best N single-equation models per equation feed the system screen
    "top_n_oot": 5,              # selection pool (systems)
    "first_window": 9,           # months for "first 9 months" OOT RMSE
    "bg_report_lags": [3, 6, 12],  # Breusch-Godfrey reported only (no gate)
}

# Dependent variables: name -> share column in the input file. dY(t) = Y(t) - Y(t-1)
DEP = {"d_mma": "MMA_pct", "d_now": "NOW_pct", "d_nib_comm": "NIB_Comm_pct"}

# -----------------------------------------------------------------------------
# Macro variables
# -----------------------------------------------------------------------------
MNEMONIC_MAP = {
    "M_FBBABLLICBQ_B.IUSA": "CI_LOANS", "M_FCASHFLOW_B.IUSA": "CORP_CF", "M_FCBOEVIXQ_B.IUSA": "VIX",
    "M_FETP_B.IUSA": "EMP", "M_FGDP$_B.IUSA": "RGDP", "M_FIP_B.IUSA": "IP", "M_FIRHYBOASQ_B.IUSA": "HY_OAS",
    "M_FLBR_B.IUSA": "UNEMP", "M_FRGT10Y_B.IUSA": "UST10Y", "M_FRGT2Y_B.IUSA": "UST2Y",
    "M_FRTFS_B.IUSA": "RETAIL", "M_FXSLASCILQ_B.IUSA": "SLOOS_CI", "M_FYPDPIQ_B.IUSA": "DPI",
    "M_FRFED_B.IUSA": "FFR", "M_FYPSAVQ_B.IUSA": "SAVE_RATE",
}
DESC_PREFIX = "Scenario Consistent Baseline (August 2026): "

# Rates, spreads, ratios, indices -> monthly change (D1)
LEVEL_VARS = ["FFR", "UST2Y", "UST10Y", "TERM_SPREAD", "HY_OAS", "UNEMP", "SAVE_RATE", "VIX", "SLOOS_CI"]
# Trending quantities -> month-over-month (MOM) and year-over-year (YOY) % growth
GROWTH_VARS = ["CI_LOANS", "CORP_CF", "EMP", "RGDP", "IP", "RETAIL", "DPI"]

# At most one driver per economic family in an equation
FAMILY = {"FFR": "rate", "UST2Y": "rate", "UST10Y": "rate", "TERM_SPREAD": "curve", "HY_OAS": "stress",
          "VIX": "stress", "SLOOS_CI": "credit", "CI_LOANS": "credit", "UNEMP": "labor", "EMP": "labor",
          "SAVE_RATE": "income", "DPI": "income", "CORP_CF": "corp", "RGDP": "activity", "IP": "activity",
          "RETAIL": "activity"}

# Expected signs on the underlying variable (+1 / -1 enforced; missing = not restricted)
RATES = {"FFR", "UST2Y", "UST10Y"}
EXPECTED_SIGN = {
    "d_mma": {},
    "d_now": {**{r: +1 for r in RATES}, "TERM_SPREAD": -1},
    "d_nib_comm": {**{r: -1 for r in RATES}, "TERM_SPREAD": +1, "HY_OAS": +1, "VIX": +1, "UNEMP": +1,
                   "SLOOS_CI": +1, "SAVE_RATE": +1, "CORP_CF": +1},
}


def out_path(key):
    """Full path of an output file, creating the output folder if needed."""
    PATHS["outdir"].mkdir(parents=True, exist_ok=True)
    return PATHS["outdir"] / PATHS[key]
