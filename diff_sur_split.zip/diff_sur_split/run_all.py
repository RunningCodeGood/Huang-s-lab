"""
run_all.py – run the steps in order. Each step reads the previous step's files from output/,
so any step can also be run on its own.

    python run_all.py              # steps 01-04
    python run_all.py --from 03    # resume from step 03 (e.g. after editing config.py gates)
    python run_all.py --forecast   # also run step 05 with macro.xlsx as the scenario
"""
import argparse
import subprocess
import sys

STEPS = ["01_feature_engineering.py", "02_screen_single.py", "03_screen_system.py", "04_estimate.py"]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--from", dest="start", default="01", help="first step to run (01-04)")
    ap.add_argument("--forecast", action="store_true", help="also run 05_forecast.py")
    args = ap.parse_args()
    steps = [s for s in STEPS if s[:2] >= args.start]
    if args.forecast:
        steps.append("05_forecast.py")
    for s in steps:
        print(f"\n===== {s} =====", flush=True)
        if subprocess.run([sys.executable, s]).returncode != 0:
            sys.exit(f"{s} failed; stopping.")


if __name__ == "__main__":
    main()
