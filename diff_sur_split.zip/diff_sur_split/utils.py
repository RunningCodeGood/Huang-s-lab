"""
utils.py – shared data loading, feature engineering and statistical helpers.
"""
import json
import logging
import re
import sys

import numpy as np
import pandas as pd
from linearmodels.system import SUR
from scipy.stats import chi2

from config import (CONFIG, DEP, DESC_PREFIX, GROWTH_VARS, LEVEL_VARS, MNEMONIC_MAP, PATHS, out_path)


# =============================================================================
# Logging and file checks
# =============================================================================
def setup_logging(name):
    PATHS["outdir"].mkdir(parents=True, exist_ok=True)
    logging.basicConfig(level=logging.INFO, format="%(message)s",
                        handlers=[logging.StreamHandler(),
                                  logging.FileHandler(PATHS["outdir"] / f"{name}.log", mode="w")])
    return logging.getLogger(name)


def require(*paths):
    """Stop with a clear message if an input file is missing."""
    missing = [str(p) for p in paths if not p.exists()]
    if missing:
        sys.exit("Missing input file(s): " + ", ".join(missing) + ". Run the earlier step first.")


# =============================================================================
# Raw data
# =============================================================================
def load_deposits(path=None, sheet=None):
    raw = pd.read_excel(path or PATHS["input"], sheet_name=sheet or PATHS["input_sheet"])
    df = raw[["YYYYMM"] + list(DEP.values())].dropna().copy()
    df["YYYYMM"] = df["YYYYMM"].astype(int)
    df.index = pd.to_datetime(df["YYYYMM"].astype(str), format="%Y%m") + pd.offsets.MonthEnd(0)
    df.index.name = "date"
    for d, lvl in DEP.items():
        df[d] = df[lvl].diff()
    return df


def load_macro(path=None):
    """Macro file: column A dates, row 1 mnemonics, row 2 descriptions, data from row 3."""
    m = pd.read_excel(path or PATHS["macro"], header=None)
    codes = m.iloc[0, 1:].tolist()
    descs = m.iloc[1, 1:].tolist()
    mac = m.iloc[2:, :].copy()
    mac.columns = ["date"] + codes
    mac["date"] = pd.to_datetime(mac["date"]) + pd.offsets.MonthEnd(0)
    mac = mac.set_index("date").astype(float).rename(columns=MNEMONIC_MAP)
    mac.index.name = "date"
    mac["TERM_SPREAD"] = mac["UST10Y"] - mac["UST2Y"]
    desc = {MNEMONIC_MAP[c]: str(x).replace(DESC_PREFIX, "") for c, x in zip(codes, descs)}
    desc["TERM_SPREAD"] = "Term spread = 10Y - 2Y Treasury (% pts.)"
    return mac, desc


# =============================================================================
# Feature engineering (used by step 01 and step 05)
# =============================================================================
def build_features(mac, desc=None):
    """Candidate drivers: D1 for LEVEL_VARS, MOM and YOY % growth for GROWTH_VARS, each lagged CONFIG['lags'].
    Returns (features DataFrame, dictionary DataFrame)."""
    base, meta = {}, {}
    for v in LEVEL_VARS:
        base[f"{v}_D1"] = mac[v].diff()
        meta[f"{v}_D1"] = (v, "D1", "monthly change (level(t) - level(t-1))")
    for v in GROWTH_VARS:
        base[f"{v}_MOM"] = mac[v].pct_change() * 100
        meta[f"{v}_MOM"] = (v, "MOM", "month-over-month % growth")
        base[f"{v}_YOY"] = mac[v].pct_change(12) * 100
        meta[f"{v}_YOY"] = (v, "YOY", "year-over-year % growth")
    X, rows = {}, []
    for k, s in base.items():
        for L in CONFIG["lags"]:
            col = f"{k}_L{L}"
            X[col] = s.shift(L)
            var, tr, txt = meta[k]
            rows.append(dict(feature=col, variable=var, transform=tr, lag_months=L,
                             definition=f"{txt}, lagged {L} month(s)",
                             source_description=(desc or {}).get(var, "")))
    feats = pd.DataFrame(X, index=mac.index)
    feats.index.name = "date"
    return feats, pd.DataFrame(rows)


def root(col):
    """Underlying macro variable of a feature column, e.g. FFR_D1_L3 -> FFR."""
    return re.sub(r"_(D1|MOM|YOY)_L\d+$", "", col)


# =============================================================================
# modelsrc.xlsx
# =============================================================================
def read_modelsrc():
    path = out_path("modelsrc")
    require(path)
    dep = pd.read_excel(path, sheet_name="dependent", index_col="date", parse_dates=True)
    X = pd.read_excel(path, sheet_name="features", index_col="date", parse_dates=True)
    dep.index = dep.index + pd.offsets.MonthEnd(0)
    X.index = X.index + pd.offsets.MonthEnd(0)
    return dep, X


def read_spec():
    path = out_path("selected_spec")
    require(path)
    with open(path) as f:
        return json.load(f)["spec"]


# =============================================================================
# Statistics
# =============================================================================
def durbin_watson(e):
    e = np.asarray(e, float)
    return float(np.sum(np.diff(e) ** 2) / np.sum(e ** 2))


def bg_test(e, Z, p):
    """Breusch-Godfrey LM p-value (reported only)."""
    e = np.asarray(e, float)
    L = np.column_stack([np.r_[np.zeros(k), e[:-k]] for k in range(1, p + 1)])
    A = np.column_stack([np.asarray(Z, float), L])
    u = e - A @ np.linalg.lstsq(A, e, rcond=None)[0]
    lm = len(e) * (1 - (u @ u) / ((e - e.mean()) @ (e - e.mean())))
    return float(chi2.sf(lm, p))


def recursive_level_forecast(b, Xm, y_level0, dy0):
    """b = [const, phi, betas...]. dY(t-1) is the model's own forecast after the first step.
    Returns (level path, dY path)."""
    lv, dl, prev, lev = [], [], dy0, y_level0
    for t in range(len(Xm)):
        d = b[0] + b[1] * prev + Xm[t] @ b[2:]
        prev, lev = d, lev + d
        dl.append(d)
        lv.append(lev)
    return np.array(lv), np.array(dl)


def design(dep, X, y, combo, start, end):
    """Regressors for one equation: const, dY(t-1), then the drivers."""
    i = dep.loc[start:end].index
    Z = pd.DataFrame({"const": 1.0, "DY_LAG1": dep[y].shift(1).loc[i]}, index=i)
    for c in combo:
        Z[c] = X.loc[i, c]
    return Z


def fit_sur(eqs, method="gls", hac=True):
    if hac:
        return SUR(eqs).fit(method=method, cov_type="kernel", kernel="bartlett", bandwidth=CONFIG["hac_lags"])
    return SUR(eqs).fit(method=method, cov_type="unadjusted")


def hausman(eqs):
    """Classical Hausman test, system OLS vs SUR-GLS (reported only)."""
    o, g = fit_sur(eqs, "ols", hac=False), fit_sur(eqs, "gls", hac=False)
    d = (o.params - g.params).values
    V = (o.cov - g.cov).values
    w = np.linalg.eigvalsh(V)
    k = int((w > 1e-14 * max(1.0, w.max())).sum())
    H = float(d @ np.linalg.pinv(V) @ d)
    return H, k, float(chi2.sf(H, k))


def oot_window(dep):
    return dep.loc[pd.Timestamp(CONFIG["train_end"]) + pd.offsets.MonthEnd(1):CONFIG["est_end"]].index


def system_oot(dep, X, y, combo, params):
    """Recursive level forecast over the out-of-time window with the given coefficients (dict name -> value)."""
    tr_end = CONFIG["train_end"]
    te = oot_window(dep)
    b = np.r_[params["const"], params["DY_LAG1"], [params[c] for c in combo]]
    lv, _ = recursive_level_forecast(b, X.loc[te, list(combo)].values, dep.loc[tr_end, DEP[y]], dep.loc[tr_end, y])
    el = dep.loc[te, DEP[y]].values - lv
    m = dict(rmse=float(np.sqrt(np.mean(el ** 2))), bias=float(el.mean()),
             rmse9=float(np.sqrt(np.mean(el[:CONFIG["first_window"]] ** 2))))
    return m, pd.Series(lv, index=te)
