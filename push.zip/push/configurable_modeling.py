#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""可配置的月度收入建模：只需本文件和两份源数据，不依赖其他项目脚本。

快速使用
  1. 修改下方 CONFIG 中 dependent_columns 和 macro_variables。
  2. python configurable_modeling.py --list-variables   查看源表字段
  3. python configurable_modeling.py                  运行完整流程
     python configurable_modeling.py --screen-only    只做工程与筛选
     python configurable_modeling.py --help           查看可选命令行覆盖

依赖：python >= 3.10；numpy pandas scipy statsmodels openpyxl xlrd matplotlib
安装：python -m pip install numpy pandas scipy statsmodels openpyxl xlrd matplotlib
本工作区已配好：.venv/bin/python configurable_modeling.py

dependent_columns 各列先加权相加，再变换；macro_variables 选择业务宏观候选，
每次运行自动加入 FLBR、FCPIU、FYPDPIQ 三个 Core。因子仍需通过筛选才进入
宏观回归规格，不强迫不合格因子进入回归。IC 指 Spearman information coefficient。
输出为独立目录中的英文 HTML 报告、全精度 CSV 和 JSON；源文件保持只读。
"""

from __future__ import annotations

# ======================= 用户配置区：通常只改这里 =======================
# 固定的 Core 候选，每次建模自动加入，无需在 macro_variables 中重复填写。
CORE_VARIABLES = ("FLBR", "FCPIU", "FYPDPIQ")
CONFIG = {
    "card_file": "/Users/hyx/Desktop/CommercialPart/Cardfee.xlsx",
    "card_sheet": "汇总数据",
    "card_header": 0,                       # Python 从0计数；0表示Excel第1行
    "card_date_column": "YYYYMM",
    "macro_file": "/Users/hyx/Desktop/Revise Version/Macro_Data_201001-202612.xls",
    "macro_sheet": "Macro Data",
    "macro_header": 1,
    "macro_date_column": "YYYYMM",

    # 选一列就是单项；选多列就是合计。示例：["Consumer Card"]。
    # 可选：QualPay, Commercial Card, Sponsorships, Small Business,
    #       Consumer Card, Debit Card, Other
    "dependent_name": None,                 # None=按所选组件自动命名，也可填写自定义标题
    "dependent_columns": ["Commercial Card", "QualPay", "Sponsorships", "Small Business"],
    "dependent_weights": {},                # 未列出的列权重=1；例如 {"QualPay": 0.5}
    # 仅对已明确授权的文本短横线记0；空白缺失不会被记0。
    # 仅在当前目标包含以下全部项目时应用，避免误用于单独 QualPay。
    "dash_zero_columns": ["QualPay"],
    "dash_zero_requires": ["Commercial Card", "QualPay", "Sponsorships", "Small Business"],

    # 业务扩展候选：支持短码、源表完整列名，或字符串 "all"。
    # 三个Core始终自动加入；[] 表示只筛Core；与Core重叠的选择自动去重。
    # 全部14个短码：FLBR FCPIU FYPDPIQ FRT FCBC FSBINQ FGDP42Q FIP FZA
    #              FDJMIIUSDD_WCFTDQ FRT4451 FRT447 FRT454 FETP
    "macro_variables": ["FZA", "FIP", "FDJMIIUSDD_WCFTDQ"],
    "target_transforms": ["diff", "dlog", "yoylog"],
    "diagnostic_transforms": ["level", "log", "diff", "dlog", "yoylog"],
    "macro_transforms": ["loglevel", "diff", "dlog", "yoylog"],
    "macro_lags": [1, 3, 6],
    "interactions": True,                   # 同一变换、同一滞后的不同宏观变量相乘
    "interaction_transforms": ["diff", "dlog", "yoylog"],

    "adf_alpha": 0.05,                      # ADF p <= 此值
    "kpss_alpha": 0.05,                     # KPSS p >= 此值
    "min_screen_obs": 36,
    "ic_t_threshold": 2.0,                  # |Spearman近似t| >= 此值
    "require_sign_stability": True,         # 前后两半IC同号且非零
    "top_per_family": 1,
    "max_interactions": 2,
    "hierarchy": "strong",                 # strong: 两个具体父项先入选；none: 原流程
    "hac_lags": 12,
    "bh_q_threshold": None,                 # None: HAC/BH仅辅助；如0.05则增加硬门槛

    "train_start": "2013-01",              # 仅限制拟合；筛选使用开发期所有可用历史
    "development_end": "2023-09",          # 此日期后只用于持出检验，不能反向选模型
    "holdout_end": None,                    # None=最后一个收入观测月
    "validation_months": 33,                # 开发期末33个月做内层时间验证
    "validation_block_months": 12,          # 每块起点重新筛选/选AR与季节项
    "ar_lag_sets": [[1], [1, 2, 3], [1, 12]],# 可加 []，表示不含因变量滞后
    "harmonics": [0, 2, 5],                 # 月度Fourier谐波对数：0=无季节项
    "windows": [None, 60],                  # None=扩展窗口，其余是日历月数
    "event_dates": [],                     # 可填["2021-01", "2023-06"]；不会自动套用
    "compare_without_events": True,
    "min_fit_obs": 30,
    "min_residual_df": 12,
    "model_criterion": "BIC",              # BIC / AIC / AICc，仅同变换、窗口和日期比较
    "require_target_stationarity": True,    # 失败变换仍列为挑战模型，但不能被推荐
    "acf_lags": 24,
    "forecast_months": 12,                  # 0关闭未来预测；宏观路径必须有数据
    "output_root": "outputs/configurable",
    "make_plots": True,
}
# ======================= 配置区结束 =======================

import argparse
import base64
import copy
from datetime import datetime
import hashlib
import html
import io
import itertools
import json
from pathlib import Path
import re
import sys
import warnings

try:
    import numpy as np
    import pandas as pd
    import scipy
    from scipy import stats
    import statsmodels
    import statsmodels.api as sm
    from statsmodels.stats.diagnostic import acorr_ljungbox, het_breuschpagan
    from statsmodels.stats.multitest import multipletests
    from statsmodels.stats.outliers_influence import variance_inflation_factor
    from statsmodels.tsa.stattools import acf, pacf, adfuller, kpss
except ImportError as exc:
    raise SystemExit(f"缺少依赖：{exc}\n请运行：python -m pip install numpy pandas scipy statsmodels openpyxl xlrd matplotlib") from exc

ROOT = Path(__file__).resolve().parent
LOG_TRANSFORMS = {"log", "loglevel", "dlog", "yoylog"}
VALID_TRANSFORMS = {"level", "log", "loglevel", "diff", "dlog", "yoylog"}


def month(value):
    """接受 YYYY-MM、YYYYMM、Excel datetime，统一到月初。"""
    if pd.isna(value):
        raise ValueError("月份不能为空")
    text = str(value).strip()
    if re.fullmatch(r"\d{6}(?:\.0)?", text):
        stamp = pd.to_datetime(text[:6], format="%Y%m")
    else:
        if isinstance(value, (int, float, np.number)):
            raise ValueError(f"不识别的数值日期 {value}；请使用YYYYMM或Excel日期")
        stamp = pd.Timestamp(value)
    return stamp.to_period("M").to_timestamp()


def validate_config(cfg):
    if cfg["dependent_name"] is not None and not isinstance(cfg["dependent_name"], str):
        raise ValueError("dependent_name 必须是文字或None")
    if not cfg["dependent_columns"] or len(set(cfg["dependent_columns"])) != len(cfg["dependent_columns"]):
        raise ValueError("dependent_columns 必须非空且不能重复")
    if not set(cfg["dependent_weights"]).issubset(cfg["dependent_columns"]):
        raise ValueError("dependent_weights 包含未选择的收入列")
    weights = [cfg["dependent_weights"].get(c, 1.0) for c in cfg["dependent_columns"]]
    if not all(np.isfinite(w) for w in weights) or not any(w != 0 for w in weights):
        raise ValueError("收入权重必须为有限数值，且不能全部为0")
    for key in ["target_transforms", "diagnostic_transforms", "macro_transforms"]:
        if not cfg[key] or not set(cfg[key]).issubset(VALID_TRANSFORMS) or len(set(cfg[key])) != len(cfg[key]):
            raise ValueError(f"{key} 包含重复或不支持的变换")
    if not set(cfg["interaction_transforms"]).issubset(cfg["macro_transforms"]):
        raise ValueError("interaction_transforms 必须属于 macro_transforms")
    for key in ["macro_lags", "harmonics"]:
        if not cfg[key] or len(set(cfg[key])) != len(cfg[key]) or any(type(v) is not int or v < 0 for v in cfg[key]):
            raise ValueError(f"{key} 必须是无重复的非负整数列表")
    if any(v > 5 for v in cfg["harmonics"]):
        raise ValueError("月度 Fourier harmonics 请使用0到5")
    if not cfg["ar_lag_sets"] or any(len(set(a)) != len(a) or any(type(v) is not int or v < 1 for v in a) for a in cfg["ar_lag_sets"]):
        raise ValueError("ar_lag_sets 的每组必须由不重复的正整数构成，可用[]关闭AR")
    if not cfg["windows"] or any(v is not None and (type(v) is not int or v < 1) for v in cfg["windows"]):
        raise ValueError("windows 只能包含None或正整数月数")
    if len(set(cfg["windows"])) != len(cfg["windows"]):
        raise ValueError("windows 不能重复")
    if cfg["hierarchy"] not in {"strong", "none"} or cfg["model_criterion"] not in {"BIC", "AIC", "AICc"}:
        raise ValueError("hierarchy 或 model_criterion 设置不支持")
    for key in ["min_screen_obs", "min_fit_obs", "min_residual_df", "validation_block_months", "top_per_family"]:
        if type(cfg[key]) is not int or cfg[key] < 1:
            raise ValueError(f"{key} 必须为正整数")
    for key in ["validation_months", "forecast_months", "hac_lags", "acf_lags", "max_interactions"]:
        if type(cfg[key]) is not int or cfg[key] < 0:
            raise ValueError(f"{key} 必须为非负整数")
    if cfg["min_screen_obs"] < 8 or cfg["min_fit_obs"] < 8 or cfg["ic_t_threshold"] < 0:
        raise ValueError("筛选/拟合至少8个观测，IC阈值不能为负")
    for key in ["adf_alpha", "kpss_alpha"]:
        if not 0 < cfg[key] < 1:
            raise ValueError(f"{key} 必须在0和1之间")
    if cfg["bh_q_threshold"] is not None and not 0 < cfg["bh_q_threshold"] < 1:
        raise ValueError("bh_q_threshold 必须为None或0到1之间的值")
    if cfg["train_start"] and month(cfg["train_start"]) > month(cfg["development_end"]):
        raise ValueError("train_start 晚于 development_end")


def source_frame(path, sheet, header, date_column):
    path = Path(path).expanduser()
    if not path.is_file():
        raise ValueError(f"源文件不存在：{path}")
    # 先读取表头，避免 pandas 对重复字段自动添加后缀而掩盖源数据问题。
    raw_header = pd.read_excel(path, sheet_name=sheet, header=None, skiprows=header, nrows=1).iloc[0]
    names = [str(x).strip() for x in raw_header if pd.notna(x)]
    if len(names) != len(set(names)):
        raise ValueError(f"{path.name}/{sheet} 存在重复字段名")
    df = pd.read_excel(path, sheet_name=sheet, header=header)
    df.columns = [str(c).strip() for c in df.columns]
    if date_column not in df:
        raise ValueError(f"找不到日期列 {date_column}；可用字段：{list(df.columns)}")
    df = df.dropna(how="all")
    dates = pd.DatetimeIndex([month(v) for v in df[date_column]], name="date")
    if dates.duplicated().any():
        raise ValueError(f"{path.name} 存在重复月份：{dates[dates.duplicated()].strftime('%Y-%m').tolist()}")
    df = df.drop(columns=[date_column]).set_axis(dates).sort_index()
    return df


def macro_catalog(frame):
    mapping = {}
    for col in frame.columns:
        match = re.fullmatch(r"M_(.+?)_B\.IUSA(?:\s*\(.*\))?", col)
        alias = match.group(1) if match else col
        if alias in mapping:
            raise ValueError(f"宏观短码冲突：{alias}")
        mapping[alias] = col
    return mapping


def numeric_column(series, zero_dash=False):
    text = series.astype(str).str.strip()
    dash = text.isin(["-", "–", "—"])
    cleaned = series.mask(dash, 0.0 if zero_dash else np.nan)
    numeric = pd.to_numeric(cleaned, errors="coerce").astype(float)
    invalid = cleaned.notna() & numeric.isna()
    if invalid.any():
        examples = cleaned[invalid].head(3).to_dict()
        raise ValueError(f"列 {series.name} 有无法解析的文本：{examples}")
    if np.isinf(numeric).any():
        raise ValueError(f"列 {series.name} 含无穷值")
    return numeric, int(dash.sum())


def load_data(cfg):
    validate_config(cfg)
    card = source_frame(cfg["card_file"], cfg["card_sheet"], cfg["card_header"], cfg["card_date_column"])
    macro = source_frame(cfg["macro_file"], cfg["macro_sheet"], cfg["macro_header"], cfg["macro_date_column"])
    mapping = macro_catalog(macro)
    cols = cfg["dependent_columns"]
    absent = set(cols) - set(card.columns)
    if absent:
        raise ValueError(f"收入字段不存在：{sorted(absent)}；可用字段：{list(card.columns)}")
    requested = list(mapping) if cfg["macro_variables"] == "all" else cfg["macro_variables"]
    if not isinstance(requested, list):
        raise ValueError('macro_variables 请设为列表或字符串 "all"')
    aliases = []
    for name in requested:
        alias = name if name in mapping else next((a for a, c in mapping.items() if c == name), None)
        if alias is None:
            raise ValueError(f"宏观字段不存在：{name}；可用短码：{list(mapping)}")
        if alias in aliases or alias == "y" or "__x__" in alias:
            raise ValueError(f"重复或保留的宏观短码：{alias}")
        aliases.append(alias)
    missing_core = [c for c in CORE_VARIABLES if c not in mapping]
    if missing_core:
        raise ValueError(f"源表缺少每次建模必需的 Core 宏观变量：{missing_core}")
    business_aliases = [a for a in aliases if a not in CORE_VARIABLES]
    aliases = list(CORE_VARIABLES) + business_aliases
    start = min(card.index.min(), macro.index.min())
    last_y = card.index.max()
    end = max(macro.index.max(), last_y + pd.DateOffset(months=cfg["forecast_months"]))
    index = pd.date_range(start, end, freq="MS", name="date")
    data = pd.DataFrame(index=index)
    audit = {"income_available": list(card.columns), "macro_available": mapping,
             "macro_core": list(CORE_VARIABLES), "macro_business_selected": business_aliases,
             "macro_selected": aliases, "source_target_end": last_y, "cleaning": []}
    components = pd.DataFrame(index=index)
    allow_zero = set(cfg["dash_zero_requires"]).issubset(cols)
    for col in cols:
        zero = allow_zero and col in cfg["dash_zero_columns"]
        s, dashes = numeric_column(card[col], zero)
        weight = cfg["dependent_weights"].get(col, 1.0)
        components[col] = s.reindex(index) * weight
        data[f"component::{col}"] = s.reindex(index)
        audit["cleaning"].append({"column": col, "weight": weight, "dash_count": dashes,
            "dash_policy": "reported_contribution_zero" if zero else "missing",
            "missing_after_cleaning": int(s.isna().sum()), "nonpositive": int(s.le(0).sum())})
    active = [c for c in cols if cfg["dependent_weights"].get(c, 1.0) != 0]
    data["y"] = components[active].sum(axis=1, min_count=len(active))
    for alias in aliases:
        data[alias], count = numeric_column(macro[mapping[alias]])
        audit["cleaning"].append({"column": alias, "source_column": mapping[alias],
                                  "dash_count": count, "dash_policy": "missing"})
    observed = data.y.dropna()
    if observed.empty:
        raise ValueError("所选收入组合没有完整数值观测，请检查缺失口径与组件选择")
    audit.update(target_start=observed.index.min(), target_end=observed.index.max(), target_n=len(observed),
                 calendar_missing_income_months=int(len(pd.date_range(card.index.min(), card.index.max(), freq="MS"))-len(card)),
                 calendar_missing_macro_months=int(len(pd.date_range(macro.index.min(), macro.index.max(), freq="MS"))-len(macro)))
    return data, audit


def transform_series(series, kind):
    x = series.astype(float).copy()
    if kind not in VALID_TRANSFORMS:
        raise ValueError(f"不支持的变换：{kind}")
    if kind in LOG_TRANSFORMS:
        x = np.log(x.where(x > 0))
    if kind in {"diff", "dlog", "yoylog"}:
        x = x.diff(12 if kind == "yoylog" else 1)
    return x.replace([np.inf, -np.inf], np.nan)


def longest_monthly_block(series):
    """时序检验不把内部空档压缩成相邻月份；同长度时取较早的连续段。"""
    x = pd.Series(series, dtype=float).replace([np.inf, -np.inf], np.nan).sort_index()
    if isinstance(x.index, pd.DatetimeIndex) and len(x):
        x = x.reindex(pd.date_range(x.index.min(), x.index.max(), freq="MS"))
    valid = x.notna()
    groups = (~valid).cumsum()
    chunks = [g for _, g in x[valid].groupby(groups[valid])]
    return max(chunks, key=len) if chunks else x.iloc[:0]


def stationarity(series, cfg):
    x = longest_monthly_block(series)
    out = {"n": len(x), "n_available": int(pd.Series(series).notna().sum()),
           "test_start": x.index[0] if len(x) else None, "test_end": x.index[-1] if len(x) else None,
           "ADF_stat": np.nan, "ADF_p": np.nan, "ADF_lags": np.nan,
           "KPSS_stat": np.nan, "KPSS_p": np.nan, "KPSS_lags": np.nan,
           "KPSS_bound": "", "stationary_pass": False, "test_error": ""}
    if len(x) < cfg["min_screen_obs"] or x.std() < 1e-12:
        out["test_error"] = "Insufficient consecutive observations" if len(x) < cfg["min_screen_obs"] else "Constant series"
        return out
    try:
        with warnings.catch_warnings():
            warnings.filterwarnings("ignore", message="adfuller currently returns.*", category=FutureWarning)
            a = adfuller(x, regression="c", autolag="AIC")
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            k = kpss(x, regression="c", nlags="auto")
        bound = ">=" if any("greater" in str(w.message) for w in caught) else ("<=" if any("smaller" in str(w.message) for w in caught) else "=")
        # 边界概率只在阈值足以判定时通过，不能把表格截断值当成精确概率。
        kpass = k[1] >= cfg["kpss_alpha"] and not (bound == "<=" and k[1] <= cfg["kpss_alpha"])
        out.update(ADF_stat=a[0], ADF_p=a[1], ADF_lags=a[2], KPSS_stat=k[0], KPSS_p=k[1],
                   KPSS_lags=k[2], KPSS_bound=bound,
                   stationary_pass=bool(a[1] <= cfg["adf_alpha"] and kpass))
    except (ValueError, OverflowError, np.linalg.LinAlgError) as exc:
        out["test_error"] = str(exc)
    return out


def correlation_table(series, cfg, **labels):
    x = longest_monthly_block(series)
    limit = min(cfg["acf_lags"], max(0, len(x)//2-1))
    if len(x) < 8 or x.std() < 1e-12 or limit == 0:
        return []
    av = acf(x, nlags=limit, fft=False)
    pv = pacf(x, nlags=limit, method="ywm")
    lb = acorr_ljungbox(x, lags=list(range(1, limit+1)), return_df=True)
    return [dict(**labels, lag=k, n=len(x), start=x.index[0], end=x.index[-1], ACF=av[k], PACF=pv[k],
                 reference_95=1.96/np.sqrt(len(x)), LjungBox_Q=lb.loc[k, "lb_stat"], LjungBox_p=lb.loc[k, "lb_pvalue"])
            for k in range(1, limit+1)]


def engineer(data, cfg):
    macros = [c for c in data if c != "y" and not c.startswith("component::")]
    features, meta = {}, []
    for m, kind, lag in itertools.product(macros, cfg["macro_transforms"], cfg["macro_lags"]):
        name = f"{m}_{kind}_L{lag}"
        features[name] = transform_series(data[m], kind).shift(lag)
        meta.append(dict(feature=name, family=m, transform=kind, lag=lag, interaction=False, parent1="", parent2=""))
    if cfg["interactions"]:
        for kind, lag, pair in itertools.product(cfg["interaction_transforms"], cfg["macro_lags"], itertools.combinations(macros, 2)):
            a, b = [f"{m}_{kind}_L{lag}" for m in pair]
            name = f"{a}__x__{b}"
            features[name] = features[a] * features[b]
            meta.append(dict(feature=name, family="x".join(pair), transform=kind, lag=lag, interaction=True, parent1=a, parent2=b))
    return pd.DataFrame(features, index=data.index).replace([np.inf, -np.inf], np.nan), meta


def valid_target(y, kind, cutoff):
    # 只依据当时可见数据决定资格，未来负值不会反向改变开发期模型。
    observed = y.loc[:cutoff].dropna()
    return not observed.empty and (kind not in LOG_TRANSFORMS or bool((observed > 0).all()))


def screen(data, features, meta, cutoff, cfg):
    cutoff = month(cutoff)
    rows = []
    selected = {t: [] for t in cfg["target_transforms"]}
    for t in cfg["target_transforms"]:
        z = transform_series(data.y, t)
        for m in meta:
            joint = pd.concat([features[m["feature"]].rename("x"), z.rename("z")], axis=1).loc[:cutoff].dropna()
            n = len(joint)
            tt = stationarity(joint.x, cfg)
            row = dict(target=t, cutoff=cutoff, **m, **{k: v for k, v in tt.items() if k != "n"}, n_stationarity=tt["n"], n=n,
                       IC=np.nan, IC_t_iid=np.nan, IC_p_iid=np.nan, IC_t_HAC12=np.nan, IC_p_HAC12=np.nan,
                       HAC_lags=cfg["hac_lags"], IC_first=np.nan, IC_second=np.nan,
                       sign_stable=False, strict_pass=False, screen_error="")
            if not valid_target(data.y, t, cutoff):
                row["screen_error"] = "Nonpositive target values in development; log-based transformation is unavailable"
            elif n < cfg["min_screen_obs"] or joint.x.std() < 1e-12 or joint.z.std() < 1e-12:
                row["screen_error"] = "Insufficient paired observations or a constant factor/target"
            else:
                rho = stats.spearmanr(joint.x, joint.z).statistic
                it = rho*np.sqrt((n-2)/max(1e-12, 1-rho*rho))
                def half_ic(part):
                    return stats.spearmanr(part.x, part.z).statistic if part.x.std() > 1e-12 and part.z.std() > 1e-12 else np.nan
                a = half_ic(joint.iloc[:n//2])
                b = half_ic(joint.iloc[n//2:])
                stable = bool(np.isfinite(a) and np.isfinite(b) and np.sign(a) == np.sign(b) and np.sign(a) != 0)
                row.update(IC=rho, IC_t_iid=it, IC_p_iid=2*stats.t.sf(abs(it), n-2), IC_first=a, IC_second=b, sign_stable=stable)
                # HAC按连续月份计算，存在缺月时仅使用最长连续配对段，单独披露n。
                contiguous = longest_monthly_block(joint.x)
                ids = contiguous.index
                row["n_HAC"] = len(ids)
                if len(ids) >= cfg["min_screen_obs"] and contiguous.std() > 1e-12 and joint.loc[ids, "z"].std() > 1e-12:
                    rx, ry = stats.rankdata(joint.loc[ids, "x"]), stats.rankdata(joint.loc[ids, "z"])
                    rx = (rx-rx.mean())/rx.std(); ry = (ry-ry.mean())/ry.std()
                    rr = sm.OLS(ry, sm.add_constant(rx)).fit().get_robustcov_results(
                        cov_type="HAC", maxlags=min(cfg["hac_lags"], len(ids)-1), use_correction=True, use_t=True)
                    row.update(IC_t_HAC12=rr.tvalues[1], IC_p_HAC12=rr.pvalues[1])
                row["strict_pass"] = bool(tt["stationary_pass"] and abs(it) >= cfg["ic_t_threshold"] and
                                           (stable or not cfg["require_sign_stability"]))
            rows.append(row)
    columns = ["target", "feature", "stationary_pass", "strict_pass", "selected_for_model", "selection_reason", "IC_HAC_BH_q"]
    if not rows:
        return pd.DataFrame(columns=columns), selected
    result = pd.DataFrame(rows)
    result["IC_HAC_BH_q"] = np.nan
    for t in cfg["target_transforms"]:
        mask = result.target.eq(t) & np.isfinite(result.IC_p_HAC12)
        if mask.any():
            result.loc[mask, "IC_HAC_BH_q"] = multipletests(result.loc[mask, "IC_p_HAC12"], method="fdr_bh")[1]
    result["pass_with_optional_BH"] = result.strict_pass
    if cfg["bh_q_threshold"] is not None:
        result["pass_with_optional_BH"] &= result.IC_HAC_BH_q.le(cfg["bh_q_threshold"])
    for t in cfg["target_transforms"]:
        passed = result[result.target.eq(t) & result.pass_with_optional_BH].copy()
        passed["strength"] = passed.IC_t_iid.abs()
        main = passed[~passed.interaction].sort_values(["strength", "feature"], ascending=[False, True])
        picks = main.groupby("family", sort=False).head(cfg["top_per_family"]).feature.tolist()
        ints = passed[passed.interaction]
        if cfg["hierarchy"] == "strong":
            ints = ints[ints.parent1.isin(picks) & ints.parent2.isin(picks)]
        selected[t] = picks + ints.sort_values(["strength", "feature"], ascending=[False, True]).head(cfg["max_interactions"]).feature.tolist()
    result["selected_for_model"] = [r.feature in selected[r.target] for r in result.itertuples()]
    reasons = []
    for r in result.itertuples():
        if r.selected_for_model:
            reason = "Selected"
        elif r.screen_error:
            reason = r.screen_error
        elif not r.stationary_pass:
            reason = "Factor failed the joint ADF/KPSS gate" + (f": {r.test_error}" if r.test_error else "")
        elif not np.isfinite(r.IC_t_iid) or abs(r.IC_t_iid) < cfg["ic_t_threshold"]:
            reason = "Approximate Spearman t-statistic below threshold"
        elif cfg["require_sign_stability"] and not r.sign_stable:
            reason = "Half-sample ICs have different signs, are zero, or are undefined"
        elif not r.pass_with_optional_BH:
            reason = "Optional BH q-value threshold not met"
        elif r.interaction and cfg["hierarchy"] == "strong" and not {r.parent1, r.parent2}.issubset(selected[r.target]):
            reason = "At least one specific parent main effect was not selected"
        else:
            reason = "Excluded by within-family ranking or the interaction count limit"
        reasons.append(reason)
    result["selection_reason"] = reasons
    return result, selected


def target_diagnostics(data, cutoff, cfg):
    tests, corrs = [], []
    for t in dict.fromkeys(cfg["diagnostic_transforms"] + cfg["target_transforms"]):
        transformed = transform_series(data.y, t).loc[:cutoff]
        row = dict(target=t, transform_valid=valid_target(data.y, t, cutoff), **stationarity(transformed, cfg))
        if not row["transform_valid"]:
            row.update(stationary_pass=False, test_error="Nonpositive target values in development; log-based model is disabled")
        tests.append(row)
        if row["transform_valid"]:
            corrs.extend(correlation_table(transformed, cfg, target=t))
    return pd.DataFrame(tests), pd.DataFrame(corrs)


def design_matrix(data, features, spec, cutoff):
    t = spec["target"]
    z = transform_series(data.y, t)
    x = pd.DataFrame({"const": 1.0}, index=data.index)
    if t in {"level", "log", "loglevel"}:
        x["trend_years"] = np.arange(len(data))/12
    for h in range(1, spec["harmonics"]+1):
        x[f"sin{h}"] = np.sin(2*np.pi*h*x.index.month/12)
        x[f"cos{h}"] = np.cos(2*np.pi*h*x.index.month/12)
    for lag in spec["p"]:
        x[f"AR_L{lag}"] = z.shift(lag)
    for name in spec["macro"]:
        x[name] = features[name]
    if spec["breaks"]:
        for event in spec.get("event_dates", []):
            dt = month(event)
            step = pd.Series((x.index >= dt).astype(float) if dt <= cutoff else np.zeros(len(x)), index=x.index)
            if t in {"diff", "dlog", "yoylog"}:
                step = step.diff(12 if t == "yoylog" else 1)
            x[f"break_{dt:%Y%m}"] = step
    return z, x.replace([np.inf, -np.inf], np.nan)


def candidate_dates(data, cutoff, window, cfg):
    start = month(cfg["train_start"]) if cfg["train_start"] else data.index.min()
    if window is not None:
        start = max(start, cutoff - pd.DateOffset(months=window-1))
    return data.index[(data.index >= start) & (data.index <= cutoff)]


def fit_spec(data, features, spec, cutoff, cfg, training_dates=None):
    cutoff = month(cutoff)
    if not valid_target(data.y, spec["target"], cutoff):
        return None
    z, x = design_matrix(data, features, spec, cutoff)
    ids = candidate_dates(data, cutoff, spec["window"], cfg)
    if training_dates is not None:
        ids = ids.intersection(pd.DatetimeIndex(training_dates))
    good = x.loc[ids].notna().all(axis=1) & z.loc[ids].notna()
    ids = ids[good]
    xx, yy = x.loc[ids], z.loc[ids]
    if len(yy) < cfg["min_fit_obs"]:
        return None
    keep = [c for c in xx if c == "const" or xx[c].std() > 1e-12]
    xx = xx[keep]
    scales = xx.std(); scales["const"] = 1.0
    xs = xx/scales
    if len(yy)-len(keep) < cfg["min_residual_df"] or np.linalg.matrix_rank(xs) < len(keep):
        return None
    result = sm.OLS(yy, xs).fit()
    if not np.isfinite(result.llf):
        return None
    return dict(result=result, scales=scales, design=x, train_dates=ids, target=z)


def select_models(data, features, selected, cutoff, cfg):
    cutoff = month(cutoff)
    candidates, rows, chosen = [], [], []
    breaks = [False, True] if cfg["event_dates"] and cfg["compare_without_events"] else [bool(cfg["event_dates"])]
    for t, window, br, mode, p, h in itertools.product(cfg["target_transforms"], cfg["windows"], breaks,
                                                      ["none", "screened"], cfg["ar_lag_sets"], cfg["harmonics"]):
        family = f"{t}_{mode}_B{int(br)}_W{window or 'all'}"
        candidates.append(dict(target=t, window=window, breaks=br, macro_mode=mode,
                               macro=selected.get(t, []) if mode == "screened" else [], p=list(p), harmonics=h,
                               event_dates=cfg["event_dates"], family=family,
                               name=f"{family}_AR{'_'.join(map(str, p)) or '0'}_H{h}"))
    # 所有可比候选先取设计完整日期的交集，窗口固定为日历月份。
    for t, window in itertools.product(cfg["target_transforms"], cfg["windows"]):
        group = [s for s in candidates if s["target"] == t and s["window"] == window]
        ids = candidate_dates(data, cutoff, window, cfg)
        for spec in group:
            z, x = design_matrix(data, features, spec, cutoff)
            good = z.loc[ids].notna() & x.loc[ids].notna().all(axis=1)
            ids = ids[good]
        digest = hashlib.sha256(ids.asi8.tobytes()).hexdigest()[:16]
        valid = []
        for spec in group:
            fit = fit_spec(data, features, spec, cutoff, cfg, ids)
            row = dict(model=spec["name"], family=spec["family"], target=t, window=window or 0,
                       cutoff=cutoff, AR_lags=spec["p"], harmonics=spec["harmonics"], macro=spec["macro"],
                       breaks=spec["breaks"], n_common=len(ids), sample_hash=digest,
                       comparison_group=f"{t}_W{window or 'all'}_{digest}", selected_within_family=False)
            if fit is None:
                row.update(status="skipped", reason="Invalid target transformation, insufficient common observations/residual degrees of freedom, or a rank-deficient design")
            else:
                r = fit["result"]; n = int(r.nobs); k = len(r.params)+1
                aic = -2*r.llf+2*k; bic = -2*r.llf+k*np.log(n)
                row.update(status="fitted", reason="", n=n, k_with_variance=k, AIC=aic, BIC=bic,
                           AICc=aic+2*k*(k+1)/(n-k-1) if n > k+1 else np.inf, adj_R2=r.rsquared_adj)
                valid.append((row, spec))
            rows.append(row)
        for family in dict.fromkeys(s["family"] for s in group):
            options = [(r, s) for r, s in valid if s["family"] == family]
            if options:
                best, spec = min(options, key=lambda pair: (pair[0][cfg["model_criterion"]], pair[1]["name"]))
                best["selected_within_family"] = True
                # 保留共同样本，避免后续报告的开发期系数与BIC搜索使用不同日期。
                chosen.append(dict(spec, selection_dates=[str(d.date()) for d in ids]))
    return chosen, pd.DataFrame(rows)


def inverse_prediction(value, kind, date, history):
    if kind == "level":
        return value
    if kind in {"log", "loglevel"}:
        return float(np.exp(value)) if value < 700 else np.nan
    lag = 12 if kind == "yoylog" else 1
    base = history.get(date-pd.DateOffset(months=lag), np.nan)
    if kind == "diff":
        return base+value
    return base*np.exp(value) if np.isfinite(base) and base > 0 and value < 700 else np.nan


def predict_path(data, features, spec, dates, origin, cfg, mode="rolling"):
    dates = pd.DatetimeIndex(dates)
    work = data.copy()
    fixed_fit = None
    if mode == "fixed":
        work.loc[work.index > origin, "y"] = np.nan
        fixed_fit = fit_spec(work, features, spec, origin, cfg, spec.get("selection_dates"))
    rows = []
    for date in dates:
        cutoff = origin if mode == "fixed" else date-pd.DateOffset(months=1)
        fit = fixed_fit if mode == "fixed" else fit_spec(work, features, spec, cutoff, cfg)
        prediction, error = np.nan, ""
        if fit is None:
            error = "Model cannot be fitted at this forecast origin"
        else:
            _, x = design_matrix(work, features, spec, cutoff)
            r, scales = fit["result"], fit["scales"]
            row = x.loc[date, r.params.index]
            if row.isna().any():
                error = "Required macro, AR, or event inputs are missing for this forecast month"
            else:
                value = float((row/scales).dot(r.params))
                # 单步使用残差smearing；固定起点递归明确输出plug-in路径，不逐步反复修正。
                if mode == "rolling" and spec["target"] in LOG_TRANSFORMS:
                    residuals = np.asarray(r.resid)
                    value += float(scipy.special.logsumexp(residuals)-np.log(len(residuals)))
                with np.errstate(over="ignore", invalid="ignore"):
                    prediction = inverse_prediction(value, spec["target"], date, work.y)
                if not np.isfinite(prediction):
                    prediction, error = np.nan, "Missing base-period value for inverse transformation or numerical overflow"
        rows.append(dict(date=date, family=spec["family"], model=spec["name"], mode=mode,
                         actual=data.y.get(date, np.nan), prediction=prediction, error=error))
        if mode == "fixed":
            work.loc[date, "y"] = prediction
    return rows


def baseline_predictions(data, dates, origin, mode):
    rows = []
    for name in ["Naive", "Seasonal_Naive", "Drift"]:
        work = data.y.copy()
        if mode == "fixed":
            work.loc[work.index > origin] = np.nan
        for date in dates:
            cut = origin if mode == "fixed" else date-pd.DateOffset(months=1)
            hist = data.y.loc[:cut].dropna()
            p = np.nan
            if len(hist):
                h = (date.year-hist.index[-1].year)*12+date.month-hist.index[-1].month
                if name == "Naive":
                    p = hist.iloc[-1]
                elif name == "Seasonal_Naive":
                    p = work.get(date-pd.DateOffset(months=12), np.nan)
                elif len(hist) > 1:
                    span = (hist.index[-1].year-hist.index[0].year)*12+hist.index[-1].month-hist.index[0].month
                    p = hist.iloc[-1]+h*(hist.iloc[-1]-hist.iloc[0])/span
            rows.append(dict(date=date, family=name, model=name, mode=mode, actual=data.y.get(date, np.nan),
                             prediction=p, error="" if np.isfinite(p) else "Historical inputs required by the baseline are missing"))
            if mode == "fixed":
                work.loc[date] = p
    return rows


def score_predictions(predictions, dates, data, scale_cutoff):
    if predictions.empty:
        return pd.DataFrame()
    expected = pd.DatetimeIndex(dates)[data.y.reindex(dates).notna()]
    denom = (data.y-data.y.shift(12)).loc[:scale_cutoff].abs().mean()
    rows = []
    for (family, mode), g in predictions.groupby(["family", "mode"]):
        g = g.set_index("date").reindex(expected)
        ok = np.isfinite(g.prediction) & np.isfinite(g.actual)
        n = int(ok.sum()); complete = bool(n == len(expected) and n > 0)
        row = dict(family=family, mode=mode, n=n, expected_n=len(expected), complete=complete)
        if n:
            a, p = g.loc[ok, "actual"].to_numpy(float), g.loc[ok, "prediction"].to_numpy(float)
            e = p-a; absbase = np.abs(a)+np.abs(p)
            row.update(RMSE=np.sqrt(np.mean(e*e)), MAE=np.mean(np.abs(e)),
                       sMAPE=np.mean(np.divide(2*np.abs(e), absbase, out=np.zeros_like(e), where=absbase > 0)),
                       Bias=np.mean(e), R2=1-np.sum(e*e)/np.sum((a-a.mean())**2) if np.std(a) else np.nan,
                       MASE=np.mean(np.abs(e))/denom if denom > 0 else np.nan)
        rows.append(row)
    return pd.DataFrame(rows).sort_values(["complete", "RMSE"], ascending=[False, True]) if rows and any("RMSE" in r for r in rows) else pd.DataFrame(rows)


def validation_blocks(data, cutoff, cfg):
    if cfg["validation_months"] == 0:
        return []
    observed = data.y.loc[:cutoff].dropna()
    if observed.empty:
        return []
    fitstart = max(observed.index.min(), month(cfg["train_start"]) if cfg["train_start"] else observed.index.min())
    start = max(cutoff-pd.DateOffset(months=cfg["validation_months"]-1),
                fitstart+pd.DateOffset(months=cfg["min_fit_obs"]+max(max(p, default=0) for p in cfg["ar_lag_sets"])))
    blocks = []
    while start <= cutoff:
        end = min(cutoff, start+pd.DateOffset(months=cfg["validation_block_months"]-1))
        blocks.append((start-pd.DateOffset(months=1), pd.date_range(start, end, freq="MS")))
        start = end+pd.DateOffset(months=1)
    return blocks


def fitted_diagnostics(data, features, spec, cutoff, cfg, sample="development"):
    fit = fit_spec(data, features, spec, cutoff, cfg, spec.get("selection_dates") if sample == "development" else None)
    if fit is None:
        return [], [], [], []
    r, scales = fit["result"], fit["scales"]
    # HAC相邻行必须代表相邻月；有内部缺月时不提供假连续的HAC推断。
    continuous = len(fit["train_dates"]) == len(pd.date_range(fit["train_dates"].min(), fit["train_dates"].max(), freq="MS"))
    hac = r.get_robustcov_results(cov_type="HAC", maxlags=min(cfg["hac_lags"], int(r.nobs)-1),
                                use_correction=True, use_t=True) if continuous else None
    coeff = []
    for j, term in enumerate(r.params.index):
        pulse = term.startswith("break_") and spec["target"] in {"diff", "dlog"}
        note = "Significance is not reported for a single-month event pulse" if pulse else ("Internal calendar gaps in the estimation sample; HAC inference is not reported" if hac is None else "")
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            vif = variance_inflation_factor(r.model.exog, j) if term != "const" else np.nan
        coeff.append(dict(sample=sample, family=spec["family"], model=spec["name"], term=term,
                          beta=r.params.iloc[j]/scales[term], SE_OLS=np.nan if pulse else r.bse.iloc[j]/scales[term],
                          t_OLS=np.nan if pulse else r.tvalues.iloc[j], p_OLS=np.nan if pulse else r.pvalues.iloc[j],
                          HAC_lags=cfg["hac_lags"], SE_HAC=np.nan if pulse or hac is None else hac.bse[j]/scales[term],
                          t_HAC=np.nan if pulse or hac is None else hac.tvalues[j], p_HAC=np.nan if pulse or hac is None else hac.pvalues[j],
                          CI95_low=np.nan if pulse or hac is None else hac.conf_int()[j, 0]/scales[term],
                          CI95_high=np.nan if pulse or hac is None else hac.conf_int()[j, 1]/scales[term], VIF=vif, inference_note=note))
    diag = dict(sample=sample, family=spec["family"], model=spec["name"], fit_n=int(r.nobs), adj_R2=r.rsquared_adj,
                **{f"resid_{k}": v for k, v in stationarity(r.resid, cfg).items()})
    jb = stats.jarque_bera(r.resid); diag["JarqueBera_p"] = jb.pvalue
    try:
        diag["BreuschPagan_p"] = het_breuschpagan(r.resid, r.model.exog)[1]
    except ValueError:
        diag["BreuschPagan_p"] = np.nan
    residual_acf = correlation_table(r.resid, cfg, sample=sample, family=spec["family"])
    for lag in [12, 24]:
        diag[f"LjungBox{lag}_p"] = next((v["LjungBox_p"] for v in residual_acf if v["lag"] == lag), np.nan)
    fitted = [dict(sample=sample, family=spec["family"], date=dt, target=spec["target"],
                   actual_transformed=fit["target"].loc[dt], fitted_transformed=r.fittedvalues.loc[dt], residual=r.resid.loc[dt])
              for dt in fit["train_dates"]]
    return coeff, [diag], residual_acf, fitted


def clean_json(obj):
    if isinstance(obj, dict):
        return {str(k): clean_json(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple, np.ndarray, pd.Index)):
        return [clean_json(v) for v in obj]
    if isinstance(obj, (pd.Timestamp, datetime)):
        return obj.isoformat()
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, (np.bool_,)):
        return bool(obj)
    if isinstance(obj, (np.floating, float)):
        return float(obj) if np.isfinite(obj) else None
    if obj is pd.NA or obj is pd.NaT:
        return None
    return obj


def export_frame(out, name, frame):
    # UTF-8 BOM便于直接用Excel打开；统计数值保留全精度。
    frame = frame.copy()
    for col in frame.select_dtypes(include="object"):
        frame[col] = frame[col].map(lambda x: json.dumps(clean_json(x), ensure_ascii=False) if isinstance(x, (list, dict, tuple)) else x)
    frame.to_csv(out/f"{name}.csv", index=False, encoding="utf-8-sig")


def plot_data(data, target_acf, predictions, recommendation, cfg):
    if not cfg["make_plots"]:
        return []
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        return []
    plots = []
    def save(fig, title):
        buffer = io.BytesIO(); fig.savefig(buffer, format="png", dpi=145, bbox_inches="tight")
        plots.append((title, base64.b64encode(buffer.getvalue()).decode("ascii"))); plt.close(fig)
    fig, ax = plt.subplots(figsize=(10.5, 3.1))
    yy = data.y.dropna(); ax.plot(yy.index, yy, color="#234e70", lw=1.3)
    ax.axvline(month(cfg["development_end"]), color="#a35f29", ls="--", label="Development cutoff")
    ax.set_ylabel("Original source units"); ax.grid(alpha=.15); ax.legend(frameon=False); save(fig, "Dependent variable and development cutoff")
    if not target_acf.empty:
        kinds = target_acf.target.unique().tolist()
        fig, axes = plt.subplots(len(kinds), 1, figsize=(10.5, 2*len(kinds)), squeeze=False)
        for axis, kind in zip(axes[:, 0], kinds):
            g = target_acf[target_acf.target.eq(kind)]
            axis.vlines(g.lag, 0, g.ACF, color="#234e70"); axis.scatter(g.lag, g.ACF, s=10)
            axis.axhline(0, color="#777", lw=.6)
            axis.axhline(g.reference_95.iloc[0], ls="--", color="#999"); axis.axhline(-g.reference_95.iloc[0], ls="--", color="#999")
            axis.set_ylabel(kind); axis.set_xlim(.5, max(g.lag)+.5)
        axes[-1, 0].set_xlabel("Calendar lag (months)"); fig.tight_layout(); save(fig, "Development-sample ACF by target transformation")
    if recommendation and not predictions.empty:
        g = predictions[predictions.family.eq(recommendation) & predictions["mode"].eq("rolling")]
        if len(g):
            fig, ax = plt.subplots(figsize=(10.5, 3.1))
            ax.plot(g.date, g.actual, label="Actual", color="#234e70")
            ax.plot(g.date, g.prediction, label="Rolling one-step", color="#a35f29")
            ax.legend(frameon=False); ax.grid(alpha=.15); save(fig, "Holdout evaluation of the development-selected regression candidate")
    return plots


def indexed_expression(symbol, lag=0, markup=False):
    index = f't{f"−{lag}" if lag else ""}'
    return f'{html.escape(symbol)}<sub>{index}</sub>' if markup else f'{symbol}[{index}]'


def transformed_expression(symbol, kind, lag=0, markup=False):
    current = indexed_expression(symbol, lag, markup)
    if kind == "level":
        return current
    if kind in {"log", "loglevel"}:
        return f"ln({current})"
    previous = indexed_expression(symbol, lag + (12 if kind == "yoylog" else 1), markup)
    return f"{current} − {previous}" if kind == "diff" else f"ln({current}) − ln({previous})"


def factor_formula(name, metadata, markup=False):
    row = metadata[name]
    if row["interaction"]:
        return f'({factor_formula(row["parent1"], metadata, markup)}) × ({factor_formula(row["parent2"], metadata, markup)})'
    return transformed_expression(row["family"], row["transform"], int(row["lag"]), markup)


def model_form_html(coefficients, tables, manifest, data):
    """Describe each reported fit using its actual retained terms and coefficients."""
    if coefficients.empty:
        return ""
    specs = {s["name"]: s for s in manifest.get("development_specs", [])}
    metadata = {r["feature"]: r for r in tables["factor_metadata"].to_dict("records")}
    fitted = tables.get("fitted_values", pd.DataFrame())

    def at(symbol, lag=0):
        return indexed_expression(symbol, lag, markup=True)

    parts = ['<p>Each equation below uses the estimated coefficients for its stated sample. '
             'Y<sub>t</sub> is the dependent variable defined above; z<sub>t</sub> is its modeled transformation. '
             'ln denotes the natural logarithm; log changes are not multiplied by 100. '
             'ε<sub>t</sub> is the regression error, estimated by the transformed-scale residual.</p>']
    for (sample, family, model), group in coefficients.groupby(["sample", "family", "model"], sort=False):
        spec = specs.get(model)
        if spec is None:
            parts.append(f'<p class="muted">Model specification unavailable for {html.escape(model)}.</p>')
            continue
        title = {"development": "Development fit", "full_history": "Full-history refit for future forecasts"}.get(sample, sample)
        parts.append(f'<h4>{html.escape(title)}</h4><p><b>Model:</b> <code>{html.escape(model)}</code>.</p>')
        dates = pd.DatetimeIndex([])
        if not fitted.empty:
            rows = fitted[fitted["sample"].eq(sample) & fitted.family.eq(family)]
            dates = pd.DatetimeIndex(pd.to_datetime(rows.date))
        if len(dates):
            parts.append(f'<p><b>Estimation sample:</b> {dates.min():%Y-%m} through {dates.max():%Y-%m}; {len(dates)} observations.</p>')
        terms = group.term.tolist()
        ar_lags = [term.removeprefix("AR_L") for term in terms if term.startswith("AR_L")]
        macros = [term for term in terms if term in metadata]
        harmonics = sum(bool(re.fullmatch(r"sin\d+", term)) for term in terms)
        events = [term for term in terms if term.startswith("break_")]
        window = ("expanding window" if spec["window"] is None else f'trailing {spec["window"]}-calendar-month window')
        parts.append(f'<p><b>Specification:</b> OLS; AR lags in months: {", ".join(ar_lags) or "none"}; '
                     f'Fourier harmonic pairs: {harmonics}; macro terms: {len(macros)}; event terms: {len(events)}; '
                     f'linear trend: {"included" if "trend_years" in terms else "none"}; {window}.</p>')
        parts.append(f'<p><b>Target transformation:</b> z<sub>t</sub> = {transformed_expression("Y", spec["target"], markup=True)}.</p>')
        pieces, definitions = [], []
        for row in group.itertuples():
            term = row.term
            if term == "const":
                symbol = ""
            elif term.startswith("AR_L"):
                symbol = at("z", int(term.removeprefix("AR_L")))
            elif re.fullmatch(r"(sin|cos)\d+", term):
                symbol = f'{term[:3]}(2π × {int(term[3:])} × m<sub>t</sub> / 12)'
            else:
                symbol = at(term)
                if term in metadata:
                    definitions.append(f'{symbol} = {factor_formula(term, metadata, markup=True)}')
                elif term == "trend_years":
                    definitions.append(f'{symbol} = number of calendar months since {data.index.min():%Y-%m}, divided by 12')
                elif term.startswith("break_"):
                    event = month(term.removeprefix("break_"))
                    cutoff = month(manifest["config"]["development_end"]) if sample == "development" else data.y.last_valid_index()
                    definition = at("D")
                    if spec["target"] in {"diff", "dlog", "yoylog"}:
                        definition += f' − {at("D", 12 if spec["target"] == "yoylog" else 1)}'
                    if event > cutoff:
                        definition = "0 (event is after the estimation cutoff)"
                    definitions.append(f'{symbol} = {definition}, where D<sub>t</sub> = 1 from {event:%Y-%m} onward and 0 earlier')
            sign = ("−" if row.beta < 0 else "") if not pieces else (" − " if row.beta < 0 else " + ")
            pieces.append(f'<span>{sign}{abs(row.beta):.6g}{f" × {symbol}" if symbol else ""}</span>')
        parts.append('<div class="equation">z<sub>t</sub> = '+''.join(pieces)+' + ε<sub>t</sub></div>')
        if harmonics:
            definitions.append('m<sub>t</sub> is the calendar month number (January = 1, …, December = 12)')
        if definitions:
            parts.append('<ul>'+''.join(f'<li>{definition}.</li>' for definition in definitions)+'</ul>')
    parts.append('<p class="muted">Equation coefficients are rounded to six significant digits; CSV coefficients retain full precision. '
                 'The development fit supplies the fixed-origin holdout coefficients. Rolling forecasts re-estimate coefficients each month; '
                 'the full-history refit supplies the future forecast path.</p>')
    return '\n'.join(parts)


def write_report(out, cfg, audit, tables, manifest, data):
    def tbl(frame, limit=25):
        if frame is None or frame.empty:
            return '<p class="muted">No records. Review sample availability and reasons for skipped tests; an unperformed test does not count as a pass.</p>'
        display = frame.head(limit).copy()
        for col in display:
            if pd.api.types.is_datetime64_any_dtype(display[col]):
                display[col] = display[col].dt.strftime("%Y-%m")
        display = display.rename(columns={
            "target": "Target transformation", "feature": "Factor", "formula": "Calculation formula", "n": "Observations",
            "transform_valid": "Transformation valid", "test_start": "Test start", "test_end": "Test end",
            "ADF_p": "ADF p-value", "KPSS_p": "KPSS p-value", "KPSS_bound": "KPSS bound",
            "stationary_pass": "ADF/KPSS gate passed", "test_error": "Test note",
            "candidates": "Candidates", "stationary": "Stationarity passed", "IC_gate": "IC threshold passed",
            "strict": "All marginal gates passed", "selected": "Selected",
            "IC": "Spearman IC", "IC_t_iid": "Approximate IC t-statistic",
            "IC_first": "First-half IC", "IC_second": "Second-half IC", "IC_HAC_BH_q": "HAC BH q-value",
            "selected_for_model": "Selected for model", "selection_reason": "Selection reason",
            "family": "Model family", "mode": "Forecast mode", "expected_n": "Expected observations",
            "complete": "Complete coverage", "eligible_target": "Target eligible",
            "available_at_development_end": "Available at development end",
            "development_selected_regression": "Development-selected regression", "sample": "Sample",
            "term": "Term", "beta": "Coefficient", "inference_note": "Inference note",
            "date": "Month", "actual": "Actual", "prediction": "Prediction", "error": "Issue",
        })
        rendered = display.to_html(index=False, escape=True, border=0,
                                   float_format=lambda v: f"{v:.4g}", na_rep="—")
        note = f"<p class='muted'>Showing the first {limit} records. See the corresponding CSV for the complete results.</p>" if len(frame) > limit else ""
        return '<div class="scroll">'+rendered+'</div>'+note
    def choose(name, cols):
        frame = tables.get(name, pd.DataFrame())
        return frame[[c for c in cols if c in frame]]
    parts = ['<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">',
             '<title>Configurable Factor Modeling Report</title><style>body{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;color:#182832;max-width:1200px;margin:36px auto;padding:0 24px;line-height:1.65}h1{font-size:28px}h2{margin-top:34px;font-size:21px}h3{font-size:17px}table{border-collapse:collapse;width:100%;font-size:13px;line-height:1.4}th,td{border:1px solid #d9dfe4;padding:8px;text-align:left;white-space:nowrap}th{background:#263c54;color:white}tr:nth-child(even){background:#f3f6f8}.scroll{overflow-x:auto;margin:14px 0}.muted{color:#5b6872;font-size:13px}pre{background:#f4f6f8;padding:16px;overflow:auto}a{color:#265b89}img{width:100%;height:auto}details{margin:18px 0}code{overflow-wrap:anywhere}.equation{background:#eef3f7;border-left:3px solid #263c54;padding:14px 18px;margin:14px 0;font-family:Georgia,serif;font-size:18px;line-height:2;overflow-x:auto}.equation span{display:inline-block}</style>',
             f'<h1>{html.escape(cfg["dependent_name"])}: Factor Screening and Model Fitting</h1>',
             f'<p>Run time: {html.escape(manifest["created_at"])}. Development cutoff: {month(cfg["development_end"]):%Y-%m}. All outputs were regenerated using this run\'s configuration.</p>']
    expression = " + ".join(f"{cfg['dependent_weights'].get(c, 1):g} × {c}" for c in cfg["dependent_columns"])
    parts.append(f'<p><b>Dependent variable:</b> {html.escape(expression)}. Components are summed before transformation. <b>Candidate macro variables:</b> {html.escape(", ".join(audit["macro_selected"]) or "None")}.</p>')
    parts.append(f'<p><b>Core variables included in every run:</b> {html.escape(", ".join(audit["macro_core"]))}. <b>Business-specific additions:</b> {html.escape(", ".join(audit["macro_business_selected"]) or "None")}. Core variables are always included in the candidate pool; their engineered factors must still pass screening before entering screened regression specifications. Models without macro regressors remain available as comparison baselines.</p>')
    parts.append(f'<p>The target has {audit["target_n"]} complete monthly observations, from {audit["target_start"]:%Y-%m} through {audit["target_end"]:%Y-%m}. This run generated {manifest["factor_count"]} factors and {len(tables["screening"])} factor–target screening records.</p>')
    if manifest["notes"]:
        parts.append('<ul>'+''.join('<li>'+html.escape(s)+'</li>' for s in manifest["notes"])+'</ul>')
    parts.append('<h2>Screening Rules and Target Diagnostics</h2>')
    parts.append(f'<p>Factors must satisfy ADF p≤{cfg["adf_alpha"]}, KPSS p≥{cfg["kpss_alpha"]}, and |approximate Spearman IC t-statistic|≥{cfg["ic_t_threshold"]}. Same nonzero sign required in both chronological halves: {cfg["require_sign_stability"]}. The main-effect limit per macro family is {cfg["top_per_family"]}; the interaction limit is {cfg["max_interactions"]}. Hierarchy rule: {html.escape(cfg["hierarchy"])}. The strong rule requires both specific parent main effects to have been selected; none follows the original workflow.</p>')
    parts.append('<p>IC means the Spearman information coefficient (rank correlation), with approximate t=ρ√[(n−2)/(1−ρ²)]. HAC rank regression checks sensitivity to serial dependence. Benjamini–Hochberg (BH) adjustment is applied across all valid candidate tests for each target; the candidate set is not split into smaller correction groups. ADF includes a constant and selects lags by AIC. KPSS uses the level-stationarity null with an automatic bandwidth. KPSS boundary values represent probability limits, not exact p-values.</p>')
    parts.append(f'<p>The maximum HAC lag is {cfg["hac_lags"]} months. For compatibility, screening.csv retains the column names IC_t_HAC12 and IC_p_HAC12; the configured lag is recorded in HAC_lags. Additional BH selection threshold: {cfg["bh_q_threshold"] if cfg["bh_q_threshold"] is not None else "disabled; supplementary diagnostic only"}.</p>')
    parts.append(tbl(choose("target_tests", ["target", "transform_valid", "n", "test_start", "test_end", "ADF_p", "KPSS_p", "KPSS_bound", "stationary_pass", "test_error"])))
    scr = tables["screening"]
    funnel = []
    for t in cfg["target_transforms"]:
        g = scr[scr.target.eq(t)]
        stationary = g[g.stationary_pass] if len(g) else g
        icpass = stationary[stationary.IC_t_iid.abs().ge(cfg["ic_t_threshold"])] if len(stationary) else stationary
        funnel.append(dict(target=t, candidates=len(g), stationary=len(stationary), IC_gate=len(icpass),
                           strict=int(g.strict_pass.sum()) if len(g) else 0,
                           selected=int(g.selected_for_model.sum()) if len(g) else 0))
    parts.append(tbl(pd.DataFrame(funnel)))
    if len(scr):
        parts.append('<h3>Factors Passing All Marginal Screening Gates</h3>')
        cols = ["target", "feature", "n", "IC", "IC_t_iid", "ADF_p", "KPSS_bound", "KPSS_p", "IC_first", "IC_second", "IC_HAC_BH_q", "selected_for_model", "selection_reason"]
        selected_rows = scr[scr.selection_reason.eq("Selected")][cols].copy()
        metadata = {r["feature"]: r for r in tables["factor_metadata"].to_dict("records")}
        selected_rows.insert(2, "formula", [factor_formula(name, metadata) for name in selected_rows.feature])
        parts.append('<p>This table shows only factors with Selection reason = Selected, after marginal gates, within-family ranking, and interaction hierarchy/count limits. Selection is specific to the target transformation and does not imply inclusion in the development-selected regression.</p>')
        parts.append(tbl(selected_rows, max(1, len(selected_rows))) if len(selected_rows) else '<p class="muted">No factors have Selection reason = Selected.</p>')
        parts.append('<p>In the calculation formulas, t is the modeled month and t−k is k calendar months earlier. ln is the natural logarithm; log differences are not multiplied by 100. Transformations are applied before lagging, and interaction factors multiply the two transformed, lagged parent factors.</p>')
    parts.append('<p>Missing months are retained on a complete monthly calendar before differencing and lagging. Missing values are not imputed, and negative values are preserved. Factor and target ADF/KPSS/ACF tests and screening HAC calculations use the longest consecutive valid monthly segment, with dates and sample sizes recorded. Spearman IC uses all valid pairs, so its sample size may differ when gaps exist. Log-based target transformations are disabled if nonpositive target observations are present by the relevant cutoff.</p>')
    if not manifest["screen_only"]:
        parts.append('<h2>Model Search and Validation Results</h2>')
        parts.append('<p>Models are estimated by OLS with candidate intercept, AR, Fourier seasonal, and selected macro terms. Level and log-level models also include a trend. AIC/AICc/BIC comparisons use the same target transformation, window, and exact training dates. The configured criterion selects AR and seasonal terms within each model family. Different transformations and windows are compared using inner-validation errors on the original revenue scale, without directly comparing BIC across groups.</p>')
        parts.append('<p>Factors and model specifications are selected again at each inner-validation block origin; coefficients are re-estimated monthly within the block. The model family and factor list are frozen at the end of development before holdout evaluation. Methods with incomplete prediction coverage are ineligible for selection. Naive uses the latest known value, Seasonal_Naive uses the value 12 months earlier, and Drift extrapolates the average monthly change between the first and last historical observations.</p>')
        recommendation = manifest.get("regression_candidate")
        parts.append(f'<p><b>Development-selected regression candidate:</b> {html.escape(recommendation or "None: no regression candidate meets target eligibility and complete validation requirements")}. <b>Best inner-validation method, including baselines:</b> {html.escape(manifest.get("validation_best_method") or "No complete validation results")}.</p>')
        parts.append('<h3>Inner Validation</h3>'+tbl(tables.get("validation_metrics"), 30))
        parts.append('<h3>Holdout Evaluation</h3>'+tbl(tables.get("holdout_metrics"), 30))
        parts.append('<p>Rolling forecasts are one-step predictions with monthly refitting using previously observed revenue. Fixed-origin forecasts freeze coefficients at a single origin and recurse without reading future actual revenue. Rolling log-based forecasts use residual smearing; fixed-origin forecasts use a recursive plug-in path. Results must be compared within the same forecast mode.</p>')
        parts.append('<h3>Regression Coefficients and Residuals</h3>')
        coef = tables.get("coefficients", pd.DataFrame())
        diag = tables.get("residual_tests", pd.DataFrame())
        if recommendation and len(coef):
            coef = coef[coef.family.eq(recommendation)]
            diag = diag[diag.family.eq(recommendation)]
        parts.append(model_form_html(coef, tables, manifest, data))
        parts.append(tbl(coef, 35)); parts.append(tbl(diag, 8))
        parts.append('<p>Coefficients are restored to the original feature scale, with OLS and HAC t-statistics/p-values and VIF. VIF is diagnostic and does not automatically remove factors. Multi-lag Ljung–Box results are descriptive residual checks without a full model-estimation degrees-of-freedom adjustment. Significance is not reported for single-month event pulses. Regression HAC inference is not reported when internal calendar gaps occur in the estimation sample.</p>')
        if cfg["forecast_months"]:
            parts.append('<h3>Future Paths</h3>'+tbl(tables.get("forecast"), 48))
            parts.append('<p>Future regression paths use coefficients re-estimated through the last observed revenue month, retaining the factors and specification selected during development. Missing macro paths or required base-period observations are reported as prediction issues. Future macro values are not imputed, and uncalibrated prediction intervals are not produced.</p>')
    for title, encoded in plot_data(data, tables["target_acf"], tables.get("holdout_predictions", pd.DataFrame()), manifest.get("regression_candidate"), cfg):
        parts.append(f'<h2>{html.escape(title)}</h2><img alt="{html.escape(title)}" src="data:image/png;base64,{encoded}">')
    parts.append('<h2>Interpretation and Reproducible Outputs</h2><p>Passing screening indicates marginal association, not causality or an out-of-sample improvement. Models whose target transformation fails the stationarity gate may be listed as challengers; they are not automatically suitable for operational use. The macro source does not provide release dates or real-time vintages. Calendar lags do not establish historical availability, and fixed-origin forecasts using subsequent macro paths are conditional scenario evaluations.</p>')
    parts.append('<p>When QualPay dashes are treated as zero, this means zero contribution to the reported aggregate, not proof of zero underlying business revenue. The start of separate reporting may change the target distribution. Event controls are applied only to dates explicitly supplied in the configuration. Source identifiers, worksheet names, and user-provided labels are preserved as supplied.</p>')
    descriptions = {"input_data": "Monthly inputs and components", "factor_metadata": "Factor construction definitions", "engineered_factors": "All engineered factor time series", "target_tests": "Target stationarity tests", "target_acf": "Target ACF/PACF/Ljung–Box", "factor_acf": "Factor ACF/PACF/Ljung–Box", "screening": "Complete screening statistics and exclusion reasons", "model_search": "Model criteria and common-sample identifiers", "validation_screening": "Independent screening at each validation origin", "validation_specs": "Specifications at each validation origin", "coefficients": "Regression coefficients and inference", "residual_tests": "Residual diagnostics", "residual_acf": "Residual ACF/PACF", "fitted_values": "Fitted values and residuals on the transformed scale", "validation_predictions": "Monthly inner-validation predictions", "validation_metrics": "Inner-validation errors", "holdout_predictions": "Monthly holdout predictions", "holdout_metrics": "Holdout errors", "forecast": "Future conditional paths"}
    parts.append('<ul>'+''.join(f'<li><a href="{key}.csv">{html.escape(descriptions.get(key,key))}</a> ({len(value)} records)</li>' for key, value in tables.items())+'</ul>')
    parts.append('<p><a href="run_manifest.json">Configuration, source file hashes, selection results, and methodology</a></p>')
    parts.append('<details><summary>Expand configuration and data-cleaning records</summary><pre>'+html.escape(json.dumps(clean_json({"config": cfg, "audit": audit}), ensure_ascii=False, indent=2))+'</pre></details></html>')
    (out/"report.html").write_text("\n".join(parts), encoding="utf-8")


def run_analysis(cfg, screen_only=False):
    cfg = copy.deepcopy(cfg)
    data, audit = load_data(cfg)
    if not cfg["dependent_name"]:
        default_columns = {"Commercial Card", "QualPay", "Sponsorships", "Small Business"}
        unweighted = all(cfg["dependent_weights"].get(c, 1.0) == 1.0 for c in cfg["dependent_columns"])
        cfg["dependent_name"] = ("Commercial Card (Four-Component Total)" if set(cfg["dependent_columns"]) == default_columns and unweighted
                                 else " + ".join(c if cfg["dependent_weights"].get(c, 1.0) == 1 else f"{cfg['dependent_weights'][c]:g} × {c}" for c in cfg["dependent_columns"]))
    cutoff = month(cfg["development_end"])
    if cutoff > audit["target_end"]:
        raise ValueError(f"development_end 晚于最后收入观测月 {audit['target_end']:%Y-%m}，请修改配置")
    if not data.y.loc[:cutoff].notna().any():
        raise ValueError("开发期没有完整因变量观测。请后移development_end或检查缺失口径")
    output_root = Path(cfg["output_root"]).expanduser()
    if not output_root.is_absolute():
        output_root = ROOT/output_root
    slug = re.sub(r"[^\w-]+", "_", cfg["dependent_name"], flags=re.UNICODE).strip("_")[:60] or "target"
    out = output_root/f"{datetime.now():%Y%m%d_%H%M%S_%f}_{slug}"
    out.mkdir(parents=True, exist_ok=False)
    print(f"目标：{cfg['dependent_name']}；宏观变量：{audit['macro_selected']}\n输出：{out}", flush=True)
    features, meta = engineer(data, cfg)
    print(f"生成 {features.shape[1]} 个因子，开始开发期筛选…", flush=True)
    screening, selected = screen(data, features, meta, cutoff, cfg)
    target_tests, target_acf = target_diagnostics(data, cutoff, cfg)
    factor_acf = []
    for name in features:
        factor_acf.extend(correlation_table(features[name].loc[:cutoff], cfg, feature=name))
    tables = {"input_data": data.reset_index(), "factor_metadata": pd.DataFrame(meta),
              "engineered_factors": features.reset_index(), "target_tests": target_tests,
              "target_acf": target_acf, "factor_acf": pd.DataFrame(factor_acf), "screening": screening}
    notes = []
    for row in audit["cleaning"]:
        if row.get("dash_policy") == "reported_contribution_zero" and row["dash_count"]:
            notes.append(f"The {row['dash_count']} text dashes in {row['column']} are treated as zero contributions to the reported aggregate under the confirmed convention; other blanks remain missing.")
    if not target_tests.transform_valid.all():
        notes.append("Some target transformations are disabled because development observations include nonpositive values; see the target diagnostics.")
    if 0 in cfg["macro_lags"]:
        notes.append("The configuration includes contemporaneous macro factors (L0); confirm whether the current month's macro inputs are known at the forecast origin.")
    if cfg["event_dates"]:
        notes.append("Event dates come from the current configuration. If identified retrospectively using the full sample, validation of event-adjusted models is exploratory.")
    sources = {}
    for key in ["card_file", "macro_file"]:
        path = Path(cfg[key]).expanduser()
        sources[key] = {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}
    manifest = dict(created_at=datetime.now().isoformat(timespec="seconds"), config=cfg, audit=audit,
                    sources=sources, versions={"python": sys.version, "numpy": np.__version__, "pandas": pd.__version__,
                    "scipy": scipy.__version__, "statsmodels": statsmodels.__version__},
                    factor_count=features.shape[1], selected_features=selected, screen_only=screen_only,
                    regression_candidate=None, validation_best_method=None, notes=notes,
                    methods={"core_variables": "FLBR, FCPIU, FYPDPIQ are always included in the candidate pool; factor selection is still required",
                             "IC": "Spearman information coefficient; approximate iid t", "BH": "per target, all finite HAC p-values in selected macro universe",
                             "time_gaps": "calendar MS before transform/lag; longest continuous block for time-series tests",
                             "BIC": "within same target/window/exact training dates; variance parameter included",
                             "macro_availability": "calendar lags; releases/vintages unverified"})
    # 先保存筛选结果，长验证中断时仍可查明已完成步骤。
    for key, value in tables.items():
        export_frame(out, key, value)
    if not screen_only:
        specs, model_search = select_models(data, features, selected, cutoff, cfg)
        tables["model_search"] = model_search
        print(f"开发期筛选：{selected}；可拟合模型家族：{len(specs)}", flush=True)
        validation_rows, validation_specs, validation_screens, validation_dates = [], [], [], []
        for origin, dates in validation_blocks(data, cutoff, cfg):
            print(f"内层验证起点 {origin:%Y-%m}：重新筛选并预测 {len(dates)} 个月…", flush=True)
            fold_screen, fold_selected = screen(data, features, meta, origin, cfg)
            fold_specs, _ = select_models(data, features, fold_selected, origin, cfg)
            validation_dates.extend(dates)
            validation_screens.extend(fold_screen.to_dict("records"))
            for spec in fold_specs:
                validation_specs.append(dict(origin=origin, **spec))
                validation_rows.extend(predict_path(data, features, spec, dates, origin, cfg))
        if validation_dates:
            validation_rows.extend(baseline_predictions(data, validation_dates, cutoff, "rolling"))
        cv_predictions = pd.DataFrame(validation_rows)
        cv_metrics = score_predictions(cv_predictions, validation_dates, data, cutoff)
        pass_targets = set(target_tests.loc[target_tests.stationary_pass & target_tests.transform_valid, "target"])
        valid_targets = set(target_tests.loc[target_tests.transform_valid, "target"])
        allowed = pass_targets if cfg["require_target_stationarity"] else valid_targets
        spec_map = {s["family"]: s for s in specs}
        if not cv_metrics.empty:
            cv_metrics["eligible_target"] = [f not in spec_map or spec_map[f]["target"] in allowed for f in cv_metrics.family]
            cv_metrics["available_at_development_end"] = cv_metrics.family.isin(list(spec_map)+["Naive", "Seasonal_Naive", "Drift"])
            valid = cv_metrics[cv_metrics.complete & cv_metrics.eligible_target & cv_metrics.available_at_development_end]
            regressions = valid[valid.family.isin(spec_map)]
            if len(regressions):
                manifest["regression_candidate"] = regressions.iloc[0].family
            if len(valid):
                manifest["validation_best_method"] = valid.iloc[0].family
        else:
            notes.append("Insufficient months for inner validation. Fittable models are still reported, but no winner is selected automatically across transformations or windows.")
        recommendation = manifest["regression_candidate"]
        if recommendation is None:
            notes.append("No regression candidate satisfies target eligibility, complete inner-validation coverage, and availability at the development cutoff.")
        manifest["development_specs"] = specs
        manifest["recommended_spec"] = spec_map.get(recommendation)
        print(f"已在持出检验前冻结回归候选：{recommendation}", flush=True)
        end = min(month(cfg["holdout_end"]), audit["target_end"]) if cfg["holdout_end"] else audit["target_end"]
        if end < cutoff:
            raise ValueError("holdout_end 不能早于 development_end")
        dates = pd.date_range(cutoff+pd.DateOffset(months=1), end, freq="MS")
        holdout_rows, coefficients, diagnostics, resid_acf, fitted = [], [], [], [], []
        for spec in specs:
            if len(dates):
                for mode in ["rolling", "fixed"]:
                    holdout_rows.extend(predict_path(data, features, spec, dates, cutoff, cfg, mode))
            c, d, a, f = fitted_diagnostics(data, features, spec, cutoff, cfg)
            coefficients.extend(c); diagnostics.extend(d); resid_acf.extend(a); fitted.extend(f)
        for mode in ["rolling", "fixed"]:
            holdout_rows.extend(baseline_predictions(data, dates, cutoff, mode))
        holdout_predictions = pd.DataFrame(holdout_rows)
        holdout_metrics = score_predictions(holdout_predictions, dates, data, cutoff)
        if len(holdout_metrics):
            holdout_metrics["development_selected_regression"] = holdout_metrics.family.eq(recommendation)
        forecast = []
        if cfg["forecast_months"]:
            final_origin = audit["target_end"]
            future_dates = pd.date_range(final_origin+pd.DateOffset(months=1), periods=cfg["forecast_months"], freq="MS")
            if recommendation:
                future_spec = {k: v for k, v in spec_map[recommendation].items() if k != "selection_dates"}
                forecast.extend(predict_path(data, features, future_spec, future_dates, final_origin, cfg, "fixed"))
                c, d, a, f = fitted_diagnostics(data, features, future_spec, final_origin, cfg, "full_history")
                coefficients.extend(c); diagnostics.extend(d); resid_acf.extend(a); fitted.extend(f)
            forecast.extend(baseline_predictions(data, future_dates, final_origin, "fixed"))
        tables.update(validation_predictions=cv_predictions, validation_metrics=cv_metrics,
                      validation_specs=pd.DataFrame(validation_specs), validation_screening=pd.DataFrame(validation_screens),
                      holdout_predictions=holdout_predictions, holdout_metrics=holdout_metrics,
                      coefficients=pd.DataFrame(coefficients), residual_tests=pd.DataFrame(diagnostics),
                      residual_acf=pd.DataFrame(resid_acf), fitted_values=pd.DataFrame(fitted), forecast=pd.DataFrame(forecast))
    for key, value in tables.items():
        export_frame(out, key, value)
    write_report(out, cfg, audit, tables, manifest, data)
    manifest["status"] = "completed"
    (out/"run_manifest.json").write_text(json.dumps(clean_json(manifest), ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")
    print(f"完成。报告：{out/'report.html'}", flush=True)
    return out, manifest, tables


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--list-variables", action="store_true", help="只列出源表的可选字段")
    parser.add_argument("--dependent", nargs="+", help="覆盖收入组件列表；含空格的列名用引号")
    parser.add_argument("--name", help="覆盖报告中的因变量名称")
    parser.add_argument("--macros", nargs="*", help="覆盖业务宏观短码；三个Core始终加入；all全选；空列表只筛Core")
    parser.add_argument("--card", help="覆盖收入源文件路径")
    parser.add_argument("--macro-file", help="覆盖宏观源文件路径")
    parser.add_argument("--dev-end", help="覆盖开发截止月YYYY-MM")
    parser.add_argument("--train-start", help="覆盖拟合起始月YYYY-MM")
    parser.add_argument("--out", help="输出根目录，每次运行另建带时间的子目录")
    parser.add_argument("--screen-only", action="store_true", help="只做数据、变换、工程、检验和筛选")
    parser.add_argument("--no-validation", action="store_true", help="跳过内层验证，仍拟合所有家族；不选跨组优胜模型")
    parser.add_argument("--no-plots", action="store_true", help="不生成图形")
    args = parser.parse_args(argv)
    cfg = copy.deepcopy(CONFIG)
    for arg, key in [("card", "card_file"), ("macro_file", "macro_file"), ("dev_end", "development_end"), ("train_start", "train_start"), ("out", "output_root")]:
        if getattr(args, arg) is not None:
            cfg[key] = getattr(args, arg)
    if args.dependent is not None:
        cfg["dependent_columns"] = args.dependent
        cfg["dependent_weights"] = {c: v for c, v in cfg["dependent_weights"].items() if c in args.dependent}
        cfg["dependent_name"] = " + ".join(args.dependent)
    if args.name:
        cfg["dependent_name"] = args.name
    if args.macros is not None:
        cfg["macro_variables"] = "all" if args.macros == ["all"] else args.macros
    if args.no_validation:
        cfg["validation_months"] = 0
    if args.no_plots:
        cfg["make_plots"] = False
    try:
        if args.list_variables:
            card = source_frame(cfg["card_file"], cfg["card_sheet"], cfg["card_header"], cfg["card_date_column"])
            macro = source_frame(cfg["macro_file"], cfg["macro_sheet"], cfg["macro_header"], cfg["macro_date_column"])
            print("可选 dependent_columns：\n"+"\n".join("  "+c for c in card.columns))
            print("\n可选 macro_variables（短码 -> 原字段）：")
            for alias, name in macro_catalog(macro).items():
                print(f"  {alias} -> {name}" + (" [Core：每次自动加入]" if alias in CORE_VARIABLES else ""))
        else:
            run_analysis(cfg, args.screen_only)
    except (ValueError, OSError, ImportError) as exc:
        parser.exit(2, f"分析停止：{exc}\n请修改CONFIG或命令行参数后重试；源文件未被修改。\n")


if __name__ == "__main__":
    main()
